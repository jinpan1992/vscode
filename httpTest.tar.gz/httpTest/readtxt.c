#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 1024

// 假设我们只关心result部分的JSON
const char *json_delimiter_start = "\"result\":";
const char *json_delimiter_end = ",\"timestamp\"";

char *extract_json(const char *text, const char *start_delimiter, const char *end_delimiter) {
    const char *start = strstr(text, start_delimiter);
    const char *end = strstr(text, end_delimiter);
    if (!start || !end || end < start) {
        return NULL; // 未找到指定的分隔符或格式不正确
    }

    start += strlen(start_delimiter); // 移动到start_delimiter的结尾
    size_t json_length = end - start;
    char *json_str = malloc(json_length + 1);
    if (!json_str) {
        return NULL; // 内存分配失败
    }

    // 复制JSON字符串并添加字符串结束符
    strncpy(json_str, start, json_length);
    json_str[json_length] = '\0';

    return json_str;
}

int main() {
    char buffer1[BUFFER_SIZE];
    char *file_content = NULL;
    size_t file_size = 0;
    char *json_result = NULL;

    // 打开文件
    FILE *file = fopen("json.txt", "r");
    if (!file) {
        perror("无法打开文件");
        return 1;
    }

    // 读取整个文件内容
    while (fgets(buffer1, sizeof(buffer1), file)) {
        size_t len = strlen(buffer1);
        file_content = realloc(file_content, file_size + len);
        if (!file_content) {
            perror("内存分配失败");
            fclose(file);
            return 1;
        }
        memcpy(file_content + file_size, buffer1, len);
        file_size += len;
    }

    // 检查是否读取了内容
    if (file_size == 0) {
        fprintf(stderr, "文件为空\n");
        fclose(file);
        return 1;
    }

    // 确保字符串以空字符结尾
    file_content[file_size] = '\0';

    // 提取JSON部分
    json_result = extract_json(file_content, json_delimiter_start, json_delimiter_end);

    // 打印结果
    if (json_result) {
        printf("提取的JSON内容:\n%s\n", json_result);
    } else {
        fprintf(stderr, "未能提取JSON内容\n");
    }

    // 清理
    free(file_content);
    if (json_result) {
        free(json_result);
    }
    fclose(file);

    return 0;
}
