# Details

Date : 2024-01-03 17:33:31

Directory /root/Desktop/testFile/httpTest

Total : 3 files,  2830 codes, 326 comments, 538 blanks, all 3694 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [cJSON.c](file:///root/Desktop/testFile/httpTest/cJSON.c) | C | 2,455 | 213 | 452 | 3,120 |
| [cJSON.h](file:///root/Desktop/testFile/httpTest/cJSON.h) | C++ | 156 | 102 | 43 | 301 |
| [test.c](file:///root/Desktop/testFile/httpTest/test.c) | C | 219 | 11 | 43 | 273 |

[summary](results.md)