# Summary

Date : 2024-01-03 17:33:31

Directory /root/Desktop/testFile/httpTest

Total : 3 files,  2830 codes, 326 comments, 538 blanks, all 3694 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C | 2 | 2,674 | 224 | 495 | 3,393 |
| C++ | 1 | 156 | 102 | 43 | 301 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 3 | 2,830 | 326 | 538 | 3,694 |

[details](details.md)