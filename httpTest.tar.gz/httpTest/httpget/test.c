#include <stdio.h>  
#include <stdlib.h>  
#include <string.h>  
#include <unistd.h>  
#include <sys/types.h>  
#include <sys/socket.h>  
#include <netinet/in.h>  
#include <arpa/inet.h>  
  
#define IPSTR "10.5.6.138"  
#define PORT 37004  
#define BUFSIZE 1024  
  
int main(int argc, char **argv)  
{  
    int sockfd, n;  
    struct sockaddr_in servaddr;  
    char buffer[BUFSIZE];  
      
    // 创建套接字  
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {  
        perror("socket creation failed");  
        exit(EXIT_FAILURE);  
    }  
      
    memset(&servaddr, 0, sizeof(servaddr));  
    servaddr.sin_family = AF_INET;  
    servaddr.sin_port = htons(PORT);  
      
    // 转换IP地址  
    if (inet_pton(AF_INET, IPSTR, &servaddr.sin_addr) <= 0) {  
        perror("invalid address/ Address not supported");  
        exit(EXIT_FAILURE);  
    }  
      
    // 连接到服务器  
    if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {  
        perror("Connection failed");  
        exit(EXIT_FAILURE);  
    }  
      
    printf("Connected to server\n");  
      
    // 发送HTTP GET请求  
    char *get_request = "GET /device/queryDeviceMqttBySn?sn=SUN-CN-1701075649132-0001 HTTP/1.1\r\n"  
                        "Host: 10.5.6.138\r\n"  
                        "Connection: close\r\n\r\n";  
      
    if (send(sockfd, get_request, strlen(get_request), 0) < 0) {  
        puts("Send failed");  
        exit(EXIT_FAILURE);  
    }  
      
    // 接收响应  
    while ((n = recv(sockfd, buffer, BUFSIZE - 1, 0)) > 0) {  
        buffer[n] = '\0';  
        printf("%s", buffer);  
    }  
      
    if (n < 0) {  
        perror("recv failed");  
    }  
      
    // 关闭套接字  
    close(sockfd);  
      
    return 0;  
}
