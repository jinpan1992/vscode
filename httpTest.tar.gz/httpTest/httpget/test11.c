#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//#include <cjson/cJSON.h>
#include "cJSON.h"
#include <sqlite3.h>
 
//get请求url：
// http://121.41.18.18:30248/ce/device/queryDeviceMqttBySn?sn=SUN-CN-1701075649132-0001 
 
#define IPSTR "10.5.6.138" //服务器IP地址;
 
#define PORT 37004
#define BUFSIZE 4096
 
int main(int argc, char **argv)
{
        int sockfd, ret, i, h;
        struct sockaddr_in servaddr;
        char str1[4096], str2[4096], buf[BUFSIZE], *str;
        socklen_t len;
        fd_set   t_set1;
        struct timeval  tv;
        char *json_str;
         
         //创建套接字
        if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) {
                printf("创建网络连接失败,本线程即将终止---socket error!\n");
                exit(0);
        };
 
        bzero(&servaddr, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(PORT);
        if (inet_pton(AF_INET, IPSTR, &servaddr.sin_addr) <= 0 ){
                printf("创建网络连接失败,本线程即将终止--inet_pton error!\n");
                exit(0);
        };
 
        if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0){
                printf("连接到服务器失败,connect error!\n");
                exit(0);
        }
        printf("与远端建立了连接\n");
        memset(str2, 0, 4096);
        strcat(str2, "theDataToPost");
        str=(char *)malloc(128);
        len = strlen(str2);
        sprintf(str, "%d", len);
 
        memset(str1, 0, 4096);
        strcat(str1, "GET /device/queryDeviceMqttBySn?sn=SUN-CN-1701075649132-0001 HTTP/1.1\r\n");
        strcat(str1, "Host: 10.5.6.138\r\n");
        
        //strcat(str1, "Content-Type: text/html\n");
        //strcat(str1, "Content-Length: ");
        strcat(str1, str);
        strcat(str1, "\r\n");
 
        strcat(str1, str2);
        strcat(str1, "\r\n\r\n");
        printf("%s\n",str1);
 
        ret = write(sockfd,str1,strlen(str1));
        if (ret < 0) {
                printf("发送失败！错误代码是%d，错误信息是'%s'\n",errno, strerror(errno));
                exit(0);
        }else{
                printf("消息发送成功，共发送了%d个字节！\n\n", ret);
        }
 
        FD_ZERO(&t_set1);
        FD_SET(sockfd, &t_set1);
 
        while(1){
                sleep(1);
                tv.tv_sec= 1;
                tv.tv_usec= 0;
                h= 0;
                printf("--------------->1");
                h= select(sockfd +1, &t_set1, NULL, NULL, &tv);
                printf("--------------->2");
 
                //if (h == 0) continue;
                if (h < 0) {
                        close(sockfd);
                        printf("在读取数据报文时SELECT检测到异常，该异常导致线程终止！\n");
                        return -1;
                };
 
                if (h > 0){
                        memset(buf, 0, 4096);
                        i= read(sockfd, buf, 4095);
                        if (i==0){
                                close(sockfd);
                                printf("读取数据报文时发现远端关闭，该线程终止！\n");
                                return -1;
                        }
 
                        printf("buf:%s", buf);
                        printf("\n");
                        //保存到文件中
                        FILE *fileJson = fopen("json.txt", "w");
                        if(fileJson == NULL)
                        {
                        printf("open error!\n");
                        }
                        fprintf(fileJson, "%s", buf);
                        printf("complete save json.txt\n");
                        fclose(fileJson);
                        
                        break;
                        
                }
        }
        close(sockfd);
        
        //读取文件内容
        printf("read json.txt \n");
        FILE *file = fopen("json.txt", "r");
        if(file == NULL)
        {
        printf("open error!\n");
        }
        char buffer[1024];
        char str3[120];
        fgets(buffer, sizeof(buffer), file);
        
         // 逐行读取文件内容并输出
        while (fgets(str3, sizeof(str3), file) != NULL) 
        {
                printf("%s", str3);
                strcat(buffer, str3);
        }
        fclose(file);
        //fgets(buffer, sizeof(buffer), file);
        
        char json_start[] = "{\"success\"";
        char json_end[] = "\"timestamp\"";
 
        char *start = strstr(buffer, json_start);
        char *end = strstr(buffer, json_end);
 
        if (start && end) 
        {
	        int length = end - start + 26;
	        char json_content[length + 1];
	        memcpy(json_content, start, length);
	        json_content[length] = '\0';
	        json_str = json_content;
	        printf("JSON内容：%s\n", json_content);
	  
	        cJSON *root = cJSON_Parse(json_content);
	        if (root == NULL) 
                {
                        printf("parse fail.\n");
                        return -1;
                }
        
                cJSON *code = cJSON_GetObjectItem(root, "code");
                if(code)
                {
                        int value = code -> valueint;
                        printf("%d\n", value);
                }
                
                cJSON *result = cJSON_GetObjectItem(root, "result");
                cJSON *password = cJSON_GetObjectItem(result, "password");
                char *password1 = password -> valuestring;
                printf("password: %s\n", password1);
                
                cJSON *clientId = cJSON_GetObjectItem(result, "clientId");
                char *clientId1 = clientId -> valuestring;
                printf("clientId: %s\n", clientId1);
                
                cJSON *port = cJSON_GetObjectItem(result, "port");
                char *port1 = port -> valuestring;
                printf("port: %s\n", port1);
                
                cJSON *prefix = cJSON_GetObjectItem(result, "prefix");
                char *prefix1 = prefix -> valuestring;
                printf("prefix: %s\n", prefix1);
                
                cJSON *host = cJSON_GetObjectItem(result, "host");
                char *host1 = host -> valuestring;
                printf("host: %s\n", host1);
                
                cJSON *username = cJSON_GetObjectItem(result, "username");
                char *username1 = username -> valuestring;
                printf("username: %s\n", username1);
                
                //sqlite3数据写入
                sqlite3 *db;
                char *err_msg = 0;
                int rc;
 
                // 打开数据库文件
                rc = sqlite3_open("websyscfg.db", &db); //x86-64
                //rc = sqlite3_open("/home/SGWeb/webserver/cfg/system/websyscfg.db", &db); //arm运行
                if (rc) 
                {
                        fprintf(stderr, "无法打开数据库： %s", sqlite3_errmsg(db));
                        return 0;
                } 
                else 
                {
                        fprintf(stdout, "成功打开数据库\n");
                }
                
                // 插入一行数据
                char sql[1024];
                int id = 1;
 
                sprintf(sql,"UPDATE  netcfg SET MqttPort ='%s'  WHERE id=%d;",port1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                
                sprintf(sql,"UPDATE  netcfg SET MqttClientID ='%s' WHERE id=%d;",clientId1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                
                sprintf(sql,"UPDATE  netcfg SET MqttAddr ='%s'  WHERE id=%d;",host1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                
                sprintf(sql,"UPDATE  netcfg SET MqttPwd ='%s'  WHERE id=%d;",password1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                
                sprintf(sql,"UPDATE  netcfg SET MqttUser ='%s'  WHERE id=%d;",username1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
 
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                printf("update!\n");
                rc = sqlite3_close(db);
 
        } 
        else 
        {
	        printf("未找到JSON内容");
        }
        
        return 0;
}
