#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//#include <cjson/cJSON.h>
#include "cJSON.h"
#include <sqlite3.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>

#define SHA_WHICH        NID_sha256
#define WHICH_DIGEST_LENGTH    SHA256_DIGEST_LENGTH

 

#define IPSTR "121.41.18.18" //服务器IP地址;

#define PORT 30248
#define BUFSIZE 1024

void parse_json(const char *json,char *findstring, char *retstr) 
{
    const char *key_start = NULL;
    const char *key_end = NULL;
    const char *value_start = NULL;
    const char *value_end = NULL;
    int i ;
    // const char *json = {"key1":"value1","key2":"value2","key3":"value3","key4":"value4"};
    for ( i = 0; json[i] != '\0'; i++) 
    {
        if ((json[i-1] == ','&&json[i] =='"')||(json[i-1] == '{'&&json[i] =='"')) 
        {
                key_start = &json[i + 1];
                // printf("key_start = %c\n",json[i + 1]);
        } 
        else if (json[i-1] == '"'&&json[i] ==':') 
        {
                key_end = &json[i - 1];
                // printf("key_end = %c\n",json[i -1]);
        }
        else if (json[i-1] == ':'&&json[i] =='"') 
        {
                value_start = &json[i +1];
                // printf("value_start = %c\n",json[i + 1]);
        }
        else if ((json[i-1] == '"'&&json[i] ==',')||(json[i-1] == '"'&&json[i] =='}')) 
        {
                value_end = &json[i - 1];
                // printf("value_end = %c\n",json[i - 1]);
           
        }
        if (key_start && key_end && value_start && value_end)
        {
            char key[1024];
            char* value = (char*)malloc(1024 * sizeof(char));
      
            strncpy(key, key_start, key_end - key_start);
            key[key_end - key_start] = '\0';
            strncpy(value, value_start, value_end - value_start);
            value[value_end - value_start] = '\0';
            key_start = NULL;
            key_end = NULL;
            value_start = NULL;
            value_end = NULL;
            int result  = strcmp(findstring,key);
            if(result == 0)
            {
                printf("Key: %s, Value: %s\n", key, value);
                strcpy(retstr, value);
                // retstr  = value;这是错误做法，函数传参是单向传递，不可能通过执行调用函数改变实参指针变量的值，但是可以改变实参指针变量所指变量的值
           
                // return retstr;

            }
            
        }   
    }   
}
void printHex(unsigned char *md, int len)
{

    int i = 0;
    for (i = 0; i < len; i++)
    {
        printf("%02x  ", md[i]);
    }

    printf("\n");
}

unsigned char* base64_decode(const char* data, size_t input_length, size_t* output_length) {
    BIO *b64, *bmem;
    size_t buffer_length = input_length * 3 / 4;
    unsigned char* buffer = (unsigned char*)malloc(buffer_length);

    b64 = BIO_new(BIO_f_base64());
    bmem = BIO_new_mem_buf((void*)data, input_length);
    bmem = BIO_push(b64, bmem);
    BIO_set_flags(bmem, BIO_FLAGS_BASE64_NO_NL); // 不使用换行符
    *output_length = BIO_read(bmem, buffer, buffer_length);

    BIO_free_all(bmem);

    return buffer;
}


int verifySignature(const char *publicKeyPath, const char *signatureBase64, const char *data) {
    // 加载公钥
    FILE *fp = fopen(publicKeyPath, "rb");
    if (!fp) {
        printf("Error opening public key file");
        return -1;
    }

    RSA *rsa = PEM_read_RSA_PUBKEY(fp, NULL, NULL, NULL);
    fclose(fp);

    if (!rsa) {
        printf("Error loading public key\n");
        return -1;
    }
	    size_t out_len;

   unsigned char * retsig = base64_decode(signatureBase64, strlen(signatureBase64), &out_len);
    printf("base64 decode len:%uld\n", out_len);

 	unsigned char md[WHICH_DIGEST_LENGTH];
    // 使用公钥进行验证
       SHA256((unsigned char *)data, strlen(data), md);
    	printHex(md, WHICH_DIGEST_LENGTH);

    	
    int result = RSA_verify(NID_sha256, (const unsigned char *)md, WHICH_DIGEST_LENGTH, (const unsigned char *)retsig, out_len, rsa);

    // 释放资源
    RSA_free(rsa);
 

    return result;
}


 
int httpget(int result)
{
        int sockfd, ret, i, h;
        struct sockaddr_in servaddr;
        char str1[4096], str2[4096], buf[BUFSIZE], *str;
        socklen_t len;
        fd_set   t_set1;
        struct timeval  tv;
        char *json_str;

        if(result == 1)
        {
                //创建套接字
                if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) {
                        printf("创建网络连接失败,本线程即将终止---socket error!\n");
                        exit(0);
                };
        
                bzero(&servaddr, sizeof(servaddr));
                servaddr.sin_family = AF_INET;
                servaddr.sin_port = htons(PORT);
                if (inet_pton(AF_INET, IPSTR, &servaddr.sin_addr) <= 0 ){
                        printf("创建网络连接失败,本线程即将终止--inet_pton error!\n");
                        exit(0);
                };
        
                if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0){
                        printf("连接到服务器失败,connect error!\n");
                        exit(0);
                }
                printf("与远端建立了连接\n");
                memset(str2, 0, 4096);
                strcat(str2, "theDataToPost");
                str=(char *)malloc(128);
                len = strlen(str2);
                sprintf(str, "%d", len);
        
                memset(str1, 0, 4096);
                strcat(str1, "GET /ce/device/queryDeviceMqttBySn?sn=SUN-CN-1701075649132-0001 HTTP/1.1\n");
                strcat(str1, "Host: 121.41.18.18:30248\n");
                strcat(str1, "Content-Type: text/html\n");
                strcat(str1, "Content-Length: ");
                strcat(str1, str);
                strcat(str1, "\n\n");
        
                strcat(str1, str2);
                strcat(str1, "\r\n\r\n");
                printf("%s\n",str1);
        
                ret = write(sockfd,str1,strlen(str1));
                if (ret < 0) {
                        printf("发送失败！错误代码是%d，错误信息是'%s'\n",errno, strerror(errno));
                        exit(0);
                }else{
                        printf("消息发送成功，共发送了%d个字节！\n\n", ret);
                }
        
                FD_ZERO(&t_set1);
                FD_SET(sockfd, &t_set1);
        
                while(1){
                        sleep(1);
                        tv.tv_sec= 1;
                        tv.tv_usec= 0;
                        h= 0;
                        printf("--------------->1");
                        h= select(sockfd +1, &t_set1, NULL, NULL, &tv);
                        printf("--------------->2");
        
                        //if (h == 0) continue;
                        if (h < 0) {
                                close(sockfd);
                                printf("在读取数据报文时SELECT检测到异常，该异常导致线程终止！\n");
                                return -1;
                        };
        
                        if (h > 0){
                                memset(buf, 0, 4096);
                                i= read(sockfd, buf, 4095);
                                if (i==0){
                                        close(sockfd);
                                        printf("读取数据报文时发现远端关闭，该线程终止！\n");
                                        return -1;
                                }
        
                                printf("buf:%s", buf);
                                printf("\n");
                                //保存到文件中
                                FILE *fileJson = fopen("json.txt", "w");
                                if(fileJson == NULL)
                                {
                                printf("open error!\n");
                                }
                                fprintf(fileJson, "%s", buf);
                                printf("complete save json.txt\n");
                                fclose(fileJson);
                                
                                break;
                                
                        }
                }
                close(sockfd);
                
                //读取文件内容
                printf("read json.txt \n");
                FILE *file = fopen("json.txt", "r");
                if(file == NULL)
                {
                printf("open error!\n");
                }/*  */
                char buffer[1024];
                char str3[120];
                fgets(buffer, sizeof(buffer), file);
                
                // 逐行读取文件内容并输出
                while (fgets(str3, sizeof(str3), file) != NULL) 
                {
                        printf("%s", str3);
                        strcat(buffer, str3);
                }
                fclose(file);
                //fgets(buffer, sizeof(buffer), file);
                
                char json_start[] = "{\"success\"";
                char json_end[] = "\"timestamp\"";

                char *start = strstr(buffer, json_start);
                char *end = strstr(buffer, json_end);

                if (start && end) 
                {
                        int length = end - start + 26;
                        char json_content[length + 1];
                        memcpy(json_content, start, length);
                        json_content[length] = '\0';
                        json_str = json_content;
                        printf("JSON内容：%s\n", json_content);
                
                        cJSON *root = cJSON_Parse(json_content);
                        if (root == NULL) 
                        {
                                printf("parse fail.\n");
                                return -1;
                        }
                
                        cJSON *code = cJSON_GetObjectItem(root, "code");
                        if(code)
                        {
                                int value = code -> valueint;
                                printf("%d\n", value);
                        }
                        
                        cJSON *result = cJSON_GetObjectItem(root, "result");
                        cJSON *password = cJSON_GetObjectItem(result, "password");
                        char *password1 = password -> valuestring;
                        printf("password: %s\n", password1);
                        
                        cJSON *clientId = cJSON_GetObjectItem(result, "clientId");
                        char *clientId1 = clientId -> valuestring;
                        printf("clientId: %s\n", clientId1);
                        
                        cJSON *port = cJSON_GetObjectItem(result, "port");
                        char *port1 = port -> valuestring;
                        printf("port: %s\n", port1);
                        
                        cJSON *prefix = cJSON_GetObjectItem(result, "prefix");
                        char *prefix1 = prefix -> valuestring;
                        printf("prefix: %s\n", prefix1);
                        
                        cJSON *host = cJSON_GetObjectItem(result, "host");
                        char *host1 = host -> valuestring;
                        printf("host: %s\n", host1);
                        
                        cJSON *username = cJSON_GetObjectItem(result, "username");
                        char *username1 = username -> valuestring;
                        printf("username: %s\n", username1);
                        
                        //sqlite3数据写入
                        sqlite3 *db;
                        char *err_msg = 0;
                        int rc;

                        // 打开数据库文件
                        rc = sqlite3_open("websyscfg.db", &db); //x86-64
                        //rc = sqlite3_open("/home/SGWeb/webserver/cfg/system/websyscfg.db", &db); //arm运行
                        if (rc) 
                        {
                                fprintf(stderr, "无法打开数据库： %s", sqlite3_errmsg(db));
                                return 0;
                        } 
                        else 
                        {
                                fprintf(stdout, "成功打开数据库\n");
                        }
                        
                        // 插入一行数据
                        char sql[1024];
                        int id = 1;
                        int si = 0;

                        si = sprintf(sql,"UPDATE  netcfg SET MqttPort ='%s'  WHERE id=%d;",port1, id);
                        si += sprintf(sql+si,"UPDATE  netcfg SET MqttClientID ='%s' WHERE id=%d;",clientId1, id);
                        si += sprintf(sql+si,"UPDATE  netcfg SET MqttAddr ='%s'  WHERE id=%d;",host1, id);
                        si += sprintf(sql+si,"UPDATE  netcfg SET MqttPwd ='%s'  WHERE id=%d;",password1, id);
                        si += sprintf(sql+si,"UPDATE  netcfg SET MqttUser ='%s'  WHERE id=%d;",username1, id);
                        
                        if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                        {
                                printf("%s\n",err_msg);
                                return -1;
                        }

                        /*
                        sprintf(sql,"UPDATE  netcfg SET MqttPort ='%s'  WHERE id=%d;",port1, id);
                        if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                        {
                                printf("%s\n",err_msg);
                                return -1;
                        }
                        
                        sprintf(sql,"UPDATE  netcfg SET MqttClientID ='%s' WHERE id=%d;",clientId1, id);
                        if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                        {
                                printf("%s\n",err_msg);
                                return -1;
                        }
                        
                        sprintf(sql,"UPDATE  netcfg SET MqttAddr ='%s'  WHERE id=%d;",host1, id);
                        if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                        {
                                printf("%s\n",err_msg);
                                return -1;
                        }
                        
                        sprintf(sql,"UPDATE  netcfg SET MqttPwd ='%s'  WHERE id=%d;",password1, id);
                        if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                        {
                                printf("%s\n",err_msg);
                                return -1;
                        }
                        
                        sprintf(sql,"UPDATE  netcfg SET MqttUser ='%s'  WHERE id=%d;",username1, id);
                        if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                        {
                                printf("%s\n",err_msg);
                                return -1;
                        }

                        if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                        {
                                printf("%s\n",err_msg);
                                return -1;
                        }
                        */
                        printf("update!\n");
                        rc = sqlite3_close(db);

                        //创建签名验证、get请求成功文件，并写入参数1
                        int SigOkFlag = 1;
                        FILE *fSigOk = NULL;
                        fSigOk = fopen("sigok.txt", "w");
                        fprintf(fSigOk, "%d", SigOkFlag);
                        fclose(fSigOk);
                        fSigOk = NULL;


                } 
                else 
                {
                        printf("未找到JSON内容");
                }
        }
        else
        {
                printf("数字签名认证未通过\n");
        }

        return 0;
        
}

int main()
{
    
    char *sn_string = "sn";
    char *signature_string = "signature";
    const char *publicKeyPath = "publickey.pem";
    //const char *signatureBase64_test = NULL;
    FILE *file;
    char buffer[2];
    int result = 0 ;
    char Cjson_buffer[4096];
    char data[1024];
    char signatureBase64[1024];
    char *Cjson_buffer1 = (char *)malloc(4096 * sizeof(char));
    
    while((result == 0)||(result == -1))
    {
        int len = 0;
        file = fopen("SUN-CN-1701075649132-0001_license.lic", "r");
        if (file == NULL)
        {
            perror("error fopen\n");
        }
        // int i = 0;
        while (fgets(buffer, sizeof(buffer), file) != NULL)
        {
            // printf("%s@", buffer);
            memcpy(Cjson_buffer+len,buffer,strlen(buffer));
            len = len + strlen(buffer);
            // printf("i=  %d len = %d\n",i,len);
            // i++;
        }
        memcpy(Cjson_buffer1,Cjson_buffer,strlen(Cjson_buffer));
        // Cjson_buffer1[2477]  ='\0';
        //printf("strlen(Cjson_buffer1) = %ld \n",strlen(Cjson_buffer1));
            // 使用cJSON_Parse函数解析字符数组

        parse_json(Cjson_buffer1,sn_string,data);
        parse_json(Cjson_buffer1,signature_string,signatureBase64);  
        printf("data = %s signatureBase64 =%s \n",data,signatureBase64);
        result = verifySignature(publicKeyPath, signatureBase64, data);
        printf("result=%d\n", result);
        if (result == 1) {
            printf("Signature is valid.\n");
        } else if (result == 0) {
            printf("Signature is invalid.\n");
        } else {
            printf("Error verifying signature\n");
        }
        fclose(file);
    }

        httpget(result);

        sleep(1);
        //插入要执行的可执行程序
        execlp("./CEMS", "CEMS", NULL);

        return 0;
}
