#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//#include <cjson/cJSON.h>
#include "cJSON.h"
#include <sqlite3.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>

#define SHA_WHICH        NID_sha256
#define WHICH_DIGEST_LENGTH    SHA256_DIGEST_LENGTH

 

#define IPSTR "10.5.6.138" //服务器IP地址;

#define PORT 37004
#define BUFSIZE 1024
#define BUFFER_SIZE 4096



int sockfd, i, n;  
    struct sockaddr_in servaddr;  
    char buffer[BUFSIZE]; 
    char *json_str; 
    FILE *fileJson;
    char data[2048];

void parse_json(const char *json,char *findstring, char *retstr) 
{
    const char *key_start = NULL;
    const char *key_end = NULL;
    const char *value_start = NULL;
    const char *value_end = NULL;
    int i ;
    // const char *json = {"key1":"value1","key2":"value2","key3":"value3","key4":"value4"};
    for ( i = 0; json[i] != '\0'; i++) 
    {
        if ((json[i-1] == ','&&json[i] =='"')||(json[i-1] == '{'&&json[i] =='"')) 
        {
                key_start = &json[i + 1];
                // printf("key_start = %c\n",json[i + 1]);
        } 
        else if (json[i-1] == '"'&&json[i] ==':') 
        {
                key_end = &json[i - 1];
                // printf("key_end = %c\n",json[i -1]);
        }
        else if (json[i-1] == ':'&&json[i] =='"') 
        {
                value_start = &json[i +1];
                // printf("value_start = %c\n",json[i + 1]);
        }
        else if ((json[i-1] == '"'&&json[i] ==',')||(json[i-1] == '"'&&json[i] =='}')) 
        {
                value_end = &json[i - 1];
                // printf("value_end = %c\n",json[i - 1]);
           
        }
        if (key_start && key_end && value_start && value_end)
        {
            char key[1024];
            char* value = (char*)malloc(1024 * sizeof(char));
      
            strncpy(key, key_start, key_end - key_start);
            key[key_end - key_start] = '\0';
            strncpy(value, value_start, value_end - value_start);
            value[value_end - value_start] = '\0';
            key_start = NULL;
            key_end = NULL;
            value_start = NULL;
            value_end = NULL;
            int result  = strcmp(findstring,key);
            if(result == 0)
            {
                // printf("Key: %s, Value: %s\n", key, value);
                strcpy(retstr, value);
                // retstr  = value;这是错误做法，函数传参是单向传递，不可能通过执行调用函数改变实参指针变量的值，但是可以改变实参指针变量所指变量的值
           
                // return retstr;

            }
            
        }   
    }   
}
void printHex(unsigned char *md, int len)
{

    int i = 0;
    for (i = 0; i < len; i++)
    {
        printf("%02x  ", md[i]);
    }

    printf("\n");
}

unsigned char* base64_decode(const char* data, size_t input_length, size_t* output_length) {
    BIO *b64, *bmem;
    size_t buffer_length = input_length * 3 / 4;
    unsigned char* buffer = (unsigned char*)malloc(buffer_length);

    b64 = BIO_new(BIO_f_base64());
    bmem = BIO_new_mem_buf((void*)data, input_length);
    bmem = BIO_push(b64, bmem);
    BIO_set_flags(bmem, BIO_FLAGS_BASE64_NO_NL); // 不使用换行符
    *output_length = BIO_read(bmem, buffer, buffer_length);

    BIO_free_all(bmem);

    return buffer;
}


int verifySignature(const char *publicKeyPath, const char *signatureBase64, const char *data) {
    // 加载公钥
    FILE *fp = fopen(publicKeyPath, "rb");
    if (!fp) {
        printf("Error opening public key file");
        return -1;
    }

    RSA *rsa = PEM_read_RSA_PUBKEY(fp, NULL, NULL, NULL);
    fclose(fp);

    if (!rsa) {
        printf("Error loading public key\n");
        return -1;
    }
	    size_t out_len;

   unsigned char * retsig = base64_decode(signatureBase64, strlen(signatureBase64), &out_len);
    printf("base64 decode len:%uld\n", out_len);

 	unsigned char md[WHICH_DIGEST_LENGTH];
    // 使用公钥进行验证
       SHA256((unsigned char *)data, strlen(data), md);
    	// printHex(md, WHICH_DIGEST_LENGTH);

    	
    int result = RSA_verify(NID_sha256, (const unsigned char *)md, WHICH_DIGEST_LENGTH, (const unsigned char *)retsig, out_len, rsa);

    // 释放资源
    RSA_free(rsa);
 

    return result;
}


// 假设我们只关心result部分的JSON
const char *json_delimiter_start = "\"result\":";
const char *json_delimiter_end = ",\"timestamp\"";
char buffer1[BUFFER_SIZE];
char *file_content = NULL;
size_t file_size = 0;
char *json_result = NULL;

char *extract_json(const char *text, const char *start_delimiter, const char *end_delimiter) {
    const char *start = strstr(text, start_delimiter);
    const char *end = strstr(text, end_delimiter);
    if (!start || !end || end < start) {
        return NULL; // 未找到指定的分隔符或格式不正确
    }

    start += strlen(start_delimiter); // 移动到start_delimiter的结尾
    size_t json_length = end - start;
    char *json_str = malloc(json_length + 1);
    if (!json_str) {
        return NULL; // 内存分配失败
    }

    // 复制JSON字符串并添加字符串结束符
    strncpy(json_str, start, json_length);
    json_str[json_length] = '\0';

    return json_str;
}

    

int httpget(int result1)
{
    
      
    // 创建套接字  
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {  
        perror("socket creation failed");  
        exit(EXIT_FAILURE);  
    }  
      
    memset(&servaddr, 0, sizeof(servaddr));  
    servaddr.sin_family = AF_INET;  
    servaddr.sin_port = htons(PORT);  
      
    // 转换IP地址  
    if (inet_pton(AF_INET, IPSTR, &servaddr.sin_addr) <= 0) {  
        perror("invalid address/ Address not supported");  
        exit(EXIT_FAILURE);  
    }  
      
    // 连接到服务器  
    if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {  
        perror("Connection failed");  
        exit(EXIT_FAILURE);  
    }  
      
    printf("Connected to server\n");  
      
    // 发送HTTP GET请求
    char getUrl[300];
    sprintf(getUrl, "GET /device/queryDeviceMqttBySn?sn=%s HTTP/1.1\r\n" "Host: 10.5.6.138\r\n" "Connection: close\r\n\r\n", data);  
    
    char *get_request = "GET /device/queryDeviceMqttBySn?sn=SUN-CN-1701075649132-0001 HTTP/1.1\r\n"  
                        "Host: 10.5.6.138\r\n"  
                        "Connection: close\r\n\r\n";  
      
    if (send(sockfd, getUrl, strlen(getUrl), 0) < 0) {  
        puts("Send failed");  
        exit(EXIT_FAILURE);  
    }  
      
    // 接收响应 
    /* 
    while ((n = recv(sockfd, buffer, BUFSIZE - 1, 0)) > 0) 
    {  
        buffer[n] = '\0';  
        printf("%s", buffer);  
        //保存到文件中
	fileJson = fopen("json.txt", "w");
	if(fileJson == NULL)
	{
	    printf("open error!\n");
	}
	fprintf(fileJson, "%s", buffer);
	
    }  
      
    if (n < 0) {  
        perror("recv failed");  
    }
    */  
    
    i= read(sockfd, buffer, BUFSIZE - 1);
    if (i==0)
    {
        close(sockfd);
        printf("读取数据报文时发现远端关闭，该线程终止！\n");
        return -1;
    }
    printf("buffer:%s", buffer);
printf("\n");
//保存到文件中
FILE *fileJson = fopen("json.txt", "w");
if(fileJson == NULL)
{
printf("open error!\n");
}
fprintf(fileJson, "%s", buffer);
printf("complete save json.txt\n");
fclose(fileJson);
  
	 
      close(sockfd);
  

   

    // 打开文件
    FILE *file = fopen("json.txt", "r");
    if (!file) 
    {
        perror("无法打开文件");
        return 1;
    }

    // 读取整个文件内容
    while (fgets(buffer1, sizeof(buffer1), file)) 
    {
        size_t len = strlen(buffer1);
        file_content = realloc(file_content, file_size + len);
        if (!file_content) {
            perror("内存分配失败");
            fclose(file);
            return 1;
        }
        memcpy(file_content + file_size, buffer1, len);
        file_size += len;
    }

    // 检查是否读取了内容
    if (file_size == 0) {
        fprintf(stderr, "文件为空\n");
        fclose(file);
        return 1;
    }

    // 确保字符串以空字符结尾
    file_content[file_size] = '\0';

    // 提取JSON部分
    json_result = extract_json(file_content, json_delimiter_start, json_delimiter_end);
    printf("json_result: %d\n", json_result);

    // 打印结果
    if (json_result) {
        printf("提取的JSON内容:\n%s\n", json_result);
    } else {
        fprintf(stderr, "未能提取JSON内容\n");
    }

    // 清理
    /*
    free(file_content);
    if (json_result) {
        free(json_result);
    }
    */
    fclose(file);
    
    cJSON *root = cJSON_Parse(json_result);
                if (root == NULL) 
                {
                        printf("parse fail.\n");
                        return -1;
                }
        
                cJSON *password = cJSON_GetObjectItem(root, "password");
                    char *password1 = password -> valuestring;
                    printf("password: %s\n", password1);

               
                
                cJSON *clientId = cJSON_GetObjectItem(root, "clientId");
                char *clientId1 = clientId -> valuestring;
                printf("clientId: %s\n", clientId1);
                
                cJSON *port = cJSON_GetObjectItem(root, "port");
                char *port1 = port -> valuestring;
                printf("port: %s\n", port1);
                
                cJSON *prefix = cJSON_GetObjectItem(root, "prefix");
                char *prefix1 = prefix -> valuestring;
                printf("prefix: %s\n", prefix1);
                
                cJSON *host = cJSON_GetObjectItem(root, "host");
                char *host1 = host -> valuestring;
                printf("host: %s\n", host1);
                
                cJSON *username = cJSON_GetObjectItem(root, "username");
                char *username1 = username -> valuestring;
                printf("username: %s\n", username1);
                
                cJSON *secretKey = cJSON_GetObjectItem(root, "secretKey");
                char *secretKey1 = secretKey -> valuestring;
                printf("secretKey: %s\n", secretKey1);
                
                
                //sqlite3数据写入
                sqlite3 *db;
                char *err_msg = 0;
                int rc;

                // 打开数据库文件
                rc = sqlite3_open("websyscfg.db", &db); //x86-64
                //rc = sqlite3_open("/home/SGWeb/webserver/cfg/system/websyscfg.db", &db); //arm
                if (rc) 
                {
                        fprintf(stderr, "无法打开数据库： %s", sqlite3_errmsg(db));
                        return 0;
                } 
                else 
                {
                        fprintf(stdout, "成功打开数据库\n");
                }
                
                // 插入一行数据
                char sql[1024];
                int id = 1;
                int si = 0;

                si = sprintf(sql,"UPDATE  netcfg SET MqttPort ='%s'  WHERE id=%d;",port1, id);
                si += sprintf(sql+si,"UPDATE  netcfg SET MqttClientID ='%s' WHERE id=%d;",clientId1, id);
                si += sprintf(sql+si,"UPDATE  netcfg SET MqttAddr ='%s'  WHERE id=%d;",host1, id);
                si += sprintf(sql+si,"UPDATE  netcfg SET MqttPwd ='%s'  WHERE id=%d;",password1, id);
                si += sprintf(sql+si,"UPDATE  netcfg SET MqttUser ='%s'  WHERE id=%d;",username1, id);
                si += sprintf(sql+si,"UPDATE  netcfg SET Mask1 ='%s'  WHERE id=%d;",secretKey1, id);
                
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }

                /*
                sprintf(sql,"UPDATE  netcfg SET MqttPort ='%s'  WHERE id=%d;",port1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                
                sprintf(sql,"UPDATE  netcfg SET MqttClientID ='%s' WHERE id=%d;",clientId1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                
                sprintf(sql,"UPDATE  netcfg SET MqttAddr ='%s'  WHERE id=%d;",host1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                
                sprintf(sql,"UPDATE  netcfg SET MqttPwd ='%s'  WHERE id=%d;",password1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                
                sprintf(sql,"UPDATE  netcfg SET MqttUser ='%s'  WHERE id=%d;",username1, id);
                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }

                if(sqlite3_exec(db,sql,NULL,NULL,&err_msg)!=SQLITE_OK)
                {
                        printf("%s\n",err_msg);
                        return -1;
                }
                */
                
                printf("update!\n");
                rc = sqlite3_close(db);

                //创建签名验证、get请求成功文件，并写入参数1
                int SigOkFlag = 1;
                FILE *fSigOk = NULL;
                fSigOk = fopen("sigok.txt", "w");
                fprintf(fSigOk, "%d", SigOkFlag);
                fclose(fSigOk);
                fSigOk = NULL;
                
                        
                        
            
 	
}

 

int main()
{
    
    char *sn_string = "sn";
    char *signature_string = "signature";
    const char *publicKeyPath = "publickey.pem";
    //const char *signatureBase64_test = NULL;
    FILE *file;
    char buffer[2];
    int result = 0 ;
    char Cjson_buffer[4096];
    //char data[2048];
    char signatureBase64[1024];
    char *Cjson_buffer1 = (char *)malloc(4096 * sizeof(char));
    
    while((result == 0)||(result == -1))
    {
        int len = 0;
        file = fopen("SUN-CN-1701075649132-0001_license.lic", "r");
        if (file == NULL)
        {
            perror("error fopen\n");
        }
        // int i = 0;
        while (fgets(buffer, sizeof(buffer), file) != NULL)
        {
            // printf("%s@", buffer);
            memcpy(Cjson_buffer+len,buffer,strlen(buffer));
            len = len + strlen(buffer);
            // printf("i=  %d len = %d\n",i,len);
            // i++;
        }
        memcpy(Cjson_buffer1,Cjson_buffer,strlen(Cjson_buffer));
        // Cjson_buffer1[2477]  ='\0';
        //printf("strlen(Cjson_buffer1) = %ld \n",strlen(Cjson_buffer1));
            // 使用cJSON_Parse函数解析字符数组

        parse_json(Cjson_buffer1,sn_string,data);
        parse_json(Cjson_buffer1,signature_string,signatureBase64);  
        printf("data = %s signatureBase64 =%s \n",data,signatureBase64);
        result = verifySignature(publicKeyPath, signatureBase64, data);
        printf("result=%d\n", result);
        if (result == 1) {
            printf("Signature is valid.\n");
        } else if (result == 0) {
            printf("Signature is invalid.\n");
        } else {
            printf("Error verifying signature\n");
        }
        fclose(file);
    }

        httpget(result);

        sleep(1);
        //插入要执行的可执行程序
        // execlp("./CEMS", "CEMS", NULL);

        return 0;
}
