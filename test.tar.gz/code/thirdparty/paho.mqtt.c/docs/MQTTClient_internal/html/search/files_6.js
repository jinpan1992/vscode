var searchData=
[
  ['utf_2d8_2ec_623',['utf-8.c',['../utf-8_8c.html',1,'']]]
];
