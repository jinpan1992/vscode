#ifndef _PRIV_PARENT_H_
#define _PRIV_PARENT_H_

#include "session.h"

void handle_parent(session_t *sess);

#endif /*_PRIV_PARENT_H_*/