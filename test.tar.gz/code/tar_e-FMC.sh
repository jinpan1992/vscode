#!/bin/sh

TAR_NAME=tmp
NEWTAR_NAME=$1

chmod 777 start.sh

./start.sh

rm -rf  /home/SGComm

mkdir /home/SGComm

mkdir /home/SGComm/conf

mkdir /home/SGComm/conf/dataprocess

cp -r ./CEMS ./daemon/HCd /home/SGComm

cp ./conf/AppVer.xml /home/SGComm/conf

cp -r ./conf/dataprocess/DataProcessConfig.xml ./conf/dataprocess/e-FMC.xml /home/SGComm/conf/dataprocess

chmod 777 -R  /home/SGComm/

#SGWeb
rm -rf  /home/SGWeb
mkdir /home/SGWeb

mkdir /home/SGWeb/webserver

cp ../webserver/cweb/code/webserver /home/SGWeb/webserver/

mkdir /home/SGWeb/webui

cp ../webui/* /home/SGWeb/webui -r

zip  -q -r  $TAR_NAME.zip /home/SGComm/* /home/SGWeb/*

md5sum $TAR_NAME.zip > md5.txt

md5=`cat md5.txt|cut -d  " " -f 1`

sed "1s/^/$md5/" $TAR_NAME.zip   >$NEWTAR_NAME.zip

rm -rf md5.txt $TAR_NAME.zip /home/SGComm/ /home/SGWeb/

exit 0
