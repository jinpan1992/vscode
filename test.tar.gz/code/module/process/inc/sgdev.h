#ifndef SGDEV_H_INCLUDED
#define SGDEV_H_INCLUDED

#include <semaphore.h>
#include <pthread.h>
#include "common.h"
#include "net.h"
#include "sdb.h"

#define MAX_SIGN 16                 //单个数据最大触发信号数量
#define DP_FUNC_MAX_NUM_D 768       //总最大注册函数数

#define CLIENT_MAX_NUM 32           //最大客户端app个数
#define SGDEV_MAX_TPYE 20           //设备最大种类
#define MAX_CLOCK_NUM  128
#define DATAOUT_MAX_NUM 4096        //输出模块缓冲

#define DI_NUM 16
#define DO_NUM 6

#define DI_BUF_NUM 10

#define ADC_NUM 5
#define ADC_BUF_NUM 1000

typedef struct {
    MODULE_ID_E eModuleId;
    MODULE_OPERATOR_T *pstOperate;
    BOOL is_registered;
} CUSTOM_T;

typedef struct script_sign_st
{
    //func_paras_s *paras;      //参数
    uint32_t paras_id;          //参数编号
    int32_t func_sign;          //函数编号
    BOOL untrip;                /*FALSE，触发回调函数；TRUE，不触发回调函数*/
}SCRIPT_SIGN_T;

//设备数据测点属性
typedef struct point_attribute_st
{
    char data_name[128];                    //数据名称
    uint16_t data_id;                       //测点编码
    uint32_t data_address;                  //寄存器地址
    uint16_t dev_code;                      //所属设备类型
    uint8_t data_len;                       //数据长度
    uint8_t data_type;                      //数据类型     i     F
    uint8_t data_sign;                      //数据正负  U   S

    SCRIPT_SIGN_T sscript_sign[MAX_SIGN];   //触发处理信号

}POINT_ATTRIBUTE_T;

//测点
typedef struct sgdev_data_st
{
//     DATA_U data;                    //数据值
    VALUE_INFO_T stValueInfo;
}SGDEV_DATA_T;

typedef struct sgdev_st
{
    uint16_t num;                   //设备数量
    //uint32_t dev_type;            //add cmt
    char name[64];                  //设备类型 INV、汇流箱
    char DevName[128];              //设备名称
    uint16_t dev_name;              //设备大类
    uint16_t dev_code;              //设备类型编码
    POINT_ATTRIBUTE_T *point_attr;  //测点属性数组
    uint32_t *map;                  //设备测点表索引 id<->point_attr_ptr
    uint16_t point_num;             //测点属性数组条数
    SGDEV_DATA_T **gdata;           //[attribute_num][num]//全局数据
    DEV_DATA_T *gdata_info;         //[attribute_num]//全局数据属性
    int32_t timeout;                //设置参数最大超时时间
    struct sgdev_st *next;          //下一个设备
}SGDEV_T;

//输出模块
typedef struct outdata_st
{
    uint16_t dev_code;  //设备类型编码
    uint16_t index;     //设备索引
    uint16_t data_id;   //测点编码
    uint8_t clientID;   //测点进程号
    VALUE_INFO_T value;
    int32_t cmd;
}OUTDATA_T;

typedef struct outpara_st
{
    DATA_U  data;              //输出参数数值
    uint8_t out_num;            //输出参数第几个
}OUTPARA_T;

//数据处理方法参数
typedef struct func_para_st
{
    uint16_t data_id;       //测点id
    uint16_t dev_code;      //测点所属的设备类型
    uint16_t index;         //测点所属的设备类型
    uint16_t dev_name;      //测点所属的设备名称
    DATA_U   data;          //测点数据值
    uint8_t dataType;     /* 数据类型:有符号、无符号、浮点型 */
}FUNC_PARA_T;

typedef struct func_inpara_st
{
    FUNC_PARA_T *inpara;        //输入参数id数组
    uint8_t in_argc;            //输入参数个数
}FUNC_INPARA_T;

typedef struct func_outpara_st
{
    FUNC_PARA_T *outpara;       //输出参数id数组
    uint8_t out_argc;           //输出参数个数
}FUNC_OUTPARA_T;

typedef struct func_paras_st
{
    FUNC_INPARA_T  inputpara;
    FUNC_OUTPARA_T outputpara;
    void *in;                   //通用输入参数
    void *out;                  //通用输出参数
}FUNC_PARAS_T;

//处理函数
typedef struct dp_func_st
{
    char name[64];                                                          //函数名称
    int32_t id;                                                             //编号
    FUNC_PARAS_T *paras;                                                    //参数
    uint32_t paras_num;                                                     //参数个数
    int32_t (*func)(void *in, void *out, DEV_DATA_T *data, DATA_U *old);    //函数体
}DP_FUNC_T;

//数据处理循环队列实现
//先进先出队列
typedef struct datapro_sign_st
{
    uint8_t cmd[DP_FUNC_MAX_NUM_D]; //信号值 dp_script 编号
    uint16_t front;                 //头指针
    uint16_t rear;                  //尾指针
    uint16_t size;                  //队列长度
    sem_t rwlock;
}DP_SIGN_T;

//闹钟
typedef struct clock_sign_st
{
    uint8_t id;                     //定时器id
    uint8_t cycle;                  //循环属性
    uint32_t start_delay;           //启动延迟
    int32_t timing;                 //定时值
    int32_t tim_cur;                //当前值
    uint16_t *store_id;             //定时存储的id
    uint32_t store_id_num;          //id个数
    uint8_t func_sign[MAX_SIGN];    //定时器到了发送的信号,最多发送MAX_SIGN个信号
    struct clock_sign_st *next;
}CLOCK_SIGN_T;

//闹钟操作命令
typedef struct clock_cmd_st
{
    uint32_t cmd;               //命令
    CLOCK_SIGN_T *in_clock;     //待插入定时器
    uint8_t opt_id;             //待操作时钟id
    int32_t timeout;            //新超时时间
}CLOCK_CMD_T;

//定时器
typedef struct stimer_st
{
    pthread_t timer_thread;     //定时扫描线程
    char fifopath[128];
    CLOCK_SIGN_T *clock_sign;   //闹钟
    uint32_t clock_sign_num;    //闹钟个数
    CLOCK_SIGN_T *end;
    BOOL isExit;
}STIMER_T;

//DI 节点
typedef struct di_node_st
{
    uint16_t id;            //序号
    uint8_t type;           //数据索引
    uint8_t func_sign;      //动作信号
    uint8_t output_do;      //输出DO
    uint32_t inputdelay;    //输入延迟
    uint32_t outputdelay;   //输出延迟
}DI_NODE_T;

//DO 节点
typedef struct do_node_st
{
    uint16_t id;            //序号
    uint8_t type;           //数据索引
    uint8_t func_sign;      //动作信号
    uint8_t action;         //动作标志
    uint32_t inputdelay;    //输入延迟
    uint32_t outputdelay;   //输出延迟
}DO_NODE_T;

//dido数据结构
typedef struct dido_ctl_st
{
    int smu_di[DI_NUM];
    int smu_do[DO_NUM];
    DI_NODE_T di_node[DI_NUM];
    DO_NODE_T do_node[DO_NUM];
    uint32_t smu_di_active_state;
    uint32_t smu_di_Init_state;
    uint32_t smu_di_state;
    uint32_t smu_di_state_buf[DI_BUF_NUM];
    uint32_t smu_di_final_state;
    uint32_t smu_di_final_state_rev;

    uint32_t smu_do_state;
    uint32_t smu_do_active_state;
    uint32_t smu_do_final_state;
    uint32_t smu_do_final_state_rev;
}DIDO_CTL_T;

//adc数据结构
typedef struct adc_ctl_st
{
    uint16_t slope;
    uint32_t id;
    char path[512];
    uint16_t type;                  //adc类型 0:4-20mA 1:0-5V
    uint32_t zero;                  //adc零点
    float cof;                      //adc系数
    uint32_t buf[ADC_BUF_NUM];      //adc环形数组缓冲
    uint32_t code;                  //adc 码
    float value;                    // adc输出值
    uint16_t front;                 //头指针
    uint16_t rear;                  //尾指针
    uint16_t size;                  //环形数组长度
    uint16_t count;                 //缓冲区填充计数
}ADC_CTL_T;

//采集器对象
typedef struct logger_st
{
    PLATFORMVER_T dev_Ver;
    char name[128];                         //设备处理模型名称:智能单元
    char kernel_Ver[128];                   //内核版本号
    char loggerSN[16];
    uint8_t SNflag;

    ETH_INFO_T Eth_info[2];                 //2个网卡
    int32_t eepromfd;                       //eeprom
    uint8_t eepromWrFlag;                   //eeprom首次写入标志
    uint32_t eepromaddress;                 //eeprom数据存储首地址
    uint32_t eepromsize;                    //eeprom实时数据存储长度
    uint32_t eepromrecordsize;              //eeprom记录数据(包括事件、故障、告警等)存储长度
    ADC_CTL_T adc_ctl[ADC_NUM];             //ADC
    DIDO_CTL_T dido_ctl;                    //DIDO

    uint8_t process_mode;
    uint32_t hisEstoreperiod;               //发电量功率图定时存储周期
    uint32_t hisDstoreperiod;               //历史数据定时存储周期
    uint32_t hisDExpiredMin;                //历史数据生存期(分钟)
    char     time_zone[128];
    uint16_t  DST;
    char ntp_server[128];
    uint8_t ntp_serverEn;
    uint16_t   time_sync[6];
    uint8_t time_syncEn;
    char  reboot_time[128];
    uint8_t reboot_time_EN;
    char  language[128];
    char storePath[64];
    uint8_t timeSyncMode;

    SGDEV_T *sgdev;                         //设备链表
    SGDEV_T *map[65536];                    //设备类型编码散列表
    uint32_t dev_num;                       //设备类型数量总数

    DEV_DATA_T fifobuf[4096];                //管道接收缓冲区
    uint32_t fifobuflen;                    //缓冲区内容字节数
    pthread_mutex_t fifo_rwlock;            //缓冲区读写锁
    pthread_cond_t fifo_cond;               //缓冲区读写条件变量

    OUTDATA_T outbuf[DATAOUT_MAX_NUM];      //输出缓冲
    uint16_t obufcnt;                       //输出缓冲计数

    pthread_t dp_thread;                    //数据处理线程
    DP_SIGN_T dp_sign;                      //信号队列
    sem_t dp_sem;                           //处理信号

    STIMER_T stimer;                        //定时器

    DP_FUNC_T *dp_Init;                     //初始化处理
    uint32_t dp_Init_num;                   //初始化处理函数数量
    DP_FUNC_T dp_func[DP_FUNC_MAX_NUM_D];   //处理函数
    sem_t dp_func_sem;                      //处理信号
    pthread_t dp_func_thread;               //定时函数处理线程

    uint16_t total_num;

    pthread_t data_thread;
    pthread_t cmd_thread;
    pthread_t proc_thread;
    BOOL dataThreadIsExit;
    BOOL cmdThreadIsExit;
    BOOL procThreadIsExit;
    CUSTOM_T cus[MODULE_MAX];

    BOOL isPauseProc;
}LOGGER_T;

#endif // SGDEV_H_INCLUDED
