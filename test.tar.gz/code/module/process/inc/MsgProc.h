#ifndef MSGPROC_H_INCLUDED
#define MSGPROC_H_INCLUDED

#include "common.h"
#include "IMC.h"
#include "IPC.h"

enum {
    SYS_MAINTAIN_UPGRADE = 1,
    SYS_MAINTAIN_RESTORE_FACTORY_DATA,
    SYS_MAINTAIN_REBOOT,
    SYS_MAINTAIN_DELETE_RUNRECORD,
    SYS_MAINTAIN_DELETE_HISDATA
};

int32_t MsgProc_Start();

int32_t MsgProc_Stop();

#endif // MSGPROC_H_INCLUDED
