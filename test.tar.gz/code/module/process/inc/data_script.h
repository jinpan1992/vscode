#ifndef DATA_SCRIPT_H_INCLUDED
#define DATA_SCRIPT_H_INCLUDED

#include "common.h"
#include "sgdev.h"
#include "function.h"

void SendRebootSignal(void);
uint16_t TotalInvNum(LOGGER_T *logger);
uint16_t CalcOnlineEquip(LOGGER_T *logger);

void CalculateInData(LOGGER_T *logger,FUNC_INPARA_T *inputpara);
void CalculateOutData(LOGGER_T *logger,FUNC_OUTPARA_T *outputpara);
void CalculateIPOutData(LOGGER_T *logger, FUNC_OUTPARA_T *outputpara);

void GetOutparamValue(LOGGER_T *logger, FUNC_OUTPARA_T *out);
void GetTimeInfo(xmlChar *szKey, uint16_t *buf);

int32_t DpFuncDone(LOGGER_T *logger, DP_FUNC_T *dp_func, DP_SIGN_T *dp_sign);
int32_t InitPlantProcessFunc(LOGGER_T *logger);

void SetVersion(LOGGER_T *logger);
void SetSN(LOGGER_T *logger);
void InsertIPDataq(ETH_INFO_T *Eth_info);
void InsertTime();

#endif // DATA_SCRIPT_H_INCLUDED
