#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED


#include "common.h"
#include "sgdev.h"

/**
 * @brief  注册回调函数
 * @param  func:函数指针
 *         funcName:函数名
 * @return OK：注册成功；ERRNO：错误码
 */
int32_t InsertDpFunc(INOUT LOGGER_T *logger,
    IN int32_t (*func)(void *in, void *out ,DEV_DATA_T *data, DATA_U *old),
    IN char *funcName);

/**
 * @brief  注册北向触发函数
 * @param  func:函数指针
 *         funcName:函数名
 * @return OK：注册成功；ERRNO：错误码
 */
int32_t InsertDpFuncNorth(LOGGER_T *logger, int32_t (*func)(void *in, void *out, DEV_DATA_T *data, DATA_U *old),
                          char *funcName, FUNC_INPARA_T *pin, FUNC_OUTPARA_T *pout);

/**
 * @brief  根据函数名找到该函数在函数列表中的索引
 * @param  dp_func:函数列表;funcName:函数名
 * @return 成功:id；失败：INVALID_VALUE
 */
int16_t GetFuncIdByNames(DP_FUNC_T *dp_func, char *funcName);

/**
 * @brief  根据函数名，获得该函数第id个出参信息
 * @param  funcName:函数名,id:出参索引
 * @return OK：成功；ERRNO：错误码
 */
int32_t GetOutpara(IN LOGGER_T *logger, IN char *funcName, INOUT FUNC_OUTPARA_T *out, IN uint16_t id);

/**
 * @brief  给回调函数注册入参
 * @param
 *
 * @return
 */
uint16_t login_function(uint32_t paras_id, LOGGER_T *logger, char *dataName, uint16_t func_sign,
                        int32_t dev_code, int32_t index, int32_t dev_name, BOOL untrip,
                        FUNC_PARA_T **inpara, uint8_t *in_argc);
/**
 * @brief  给回调函数注册出参
 * @param
 *
 * @return
 */
uint16_t login_function_outpara(LOGGER_T *logger, char *string, int32_t dev_code, int32_t index,
                                int32_t dev_name, FUNC_PARA_T **outpara, uint8_t *out_argc);

/**
 * @brief  清除所有回调函数
 * @param
 *
 * @return OK：注册成功；ERRNO：错误码
 */
int32_t ClearDpFunc(IN LOGGER_T *logger);
#endif // FUNCTION_H_INCLUDED
