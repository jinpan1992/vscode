#ifndef SEND_H_INCLUDED
#define SEND_H_INCLUDED


#include "common.h"
#include "sgdev.h"

int DpSend(LOGGER_T *logger);
// void OutData(LOGGER_T *logger, uint16_t outdevcode,uint8_t outindex, uint16_t outid, uint8_t outclientID);
void OutData(LOGGER_T *logger, uint16_t outdevcode, uint8_t outindex, uint16_t outid, uint8_t outclientID, uint8_t dataType, DATA_U data, int32_t cmd);

#endif // SEND_H_INCLUDED
