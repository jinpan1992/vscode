#ifndef STIMER_H_INCLUDED
#define STIMER_H_INCLUDED


#include "common.h"
#include "sgdev.h"

enum E_CLOCK_CMD_E
{
    E_CLOCK_CMD_INSERT= 1,
    E_CLOCK_CMD_UP,
    E_CLOCK_CMD_MODIFY,
};

void *DpTimer(void *arg);
int32_t InsertClock(STIMER_T *stimer, CLOCK_SIGN_T *clock_sign);
int32_t ClearAllClock(STIMER_T *stimer);

#endif // STIMER_H_INCLUDED
