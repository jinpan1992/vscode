#ifndef QUEUES_H_INCLUDED
#define QUEUES_H_INCLUDED


#include "common.h"
#include "sgdev.h"

void InitQueueS_D(DP_SIGN_T *Q,uint16_t Q_size);
int32_t IsQueueSempty_D(DP_SIGN_T *Q);
int32_t PostQueueS_D (DP_SIGN_T *Q,uint8_t *cmd,uint32_t flag);
int32_t DelQueueS_D (DP_SIGN_T *Q);
int32_t PendQueueS_D(DP_SIGN_T *Q, uint8_t cmd);

#endif // QUEUES_H_INCLUDED
