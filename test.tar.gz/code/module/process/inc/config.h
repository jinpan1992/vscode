#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

#include "common.h"
#include "sgdev.h"

typedef enum
{
    NO = 1,
    NC,
    DIDO_TYPE_MAX,
}DIDO_TYPE_E;

#define LOGGERV4_VER "LoggerV4 2017-03-15 V1.0.9.0"
#define LOGGERV4_MODBUS_VER 0x1000109

int SGDevConfig(char *configfilePATH, LOGGER_T *logger);
int GetAppVer(char *configfilePATH, LOGGER_T *dev);
uint16_t GetTypeFromSgdevicetype(char *element);

int SetloggerSN(char *configfilePATH, LOGGER_T *logger);
int SetloggerIP(char *configfilePATH, LOGGER_T *logger);

int32_t BindToLogger(LOGGER_T *logger, SGDEV_T *sgdev_p);

int32_t FillSgdevInfo(DEV_INFO_EXT_T *pDIExt, SGDEV_T *pSGDev);

#endif // CONFIG_H_INCLUDED
