#ifndef DATAPROCESS_H_INCLUDED
#define DATAPROCESS_H_INCLUDED

#include <stdint.h>
#include "common.h"
#include "sgdev.h"
#include "SGQueue.h"
#include "script_interface.h"
#include "control_interface.h"
#include "msg.h"
#include "err.h"


Q_EXTERN(DEV_DATA_T, dataOutQ);
Q_EXTERN(DEV_DATA_T, cmdqOutQ);
Q_EXTERN(DEV_DATA_T, cmdqInQ);
Q_EXTERN(DEV_DATA_T, dataInQ);

extern LOGGER_T logger;

enum
{
    DP_PROPERTY_GET_STATE = 0,
    DP_PROPERTY_GET_ALGO_PARAM,
    DP_PROPERTY_GET_PROTECT_STORAGE_PARAM,
    DP_PROPERTY_GET_PROTECT_NET_PARAM,
    DP_PROPERTY_GET_RUN_PARAM,
    DP_PROPERTY_GET_IO,
    DP_PROPERTY_MAX
};

uintptr_t Processor_Create(void);
int32_t Processor_CreateDevModel();
int32_t Processor_DestroyDevModel();
int32_t Processor_StartRecv();
int32_t Processor_StopRecv();
int32_t Processor_Start();
int32_t Processor_Destroy(uintptr_t handle);

int32_t Processor_Get(int32_t dwProperty, void **ppvRet, int32_t *pdwRetLen);
int32_t Processor_Register(MODULE_ID_E eModuleId, MODULE_OPERATOR_T *pOperate);
int32_t Processor_InsertDpFunc(int32_t (*func)(void *in, void *out, DEV_DATA_T *data, DATA_U *old), char *name);
int32_t Processor_InsertDpFuncNorth(int32_t (*func)(void *in, void *out, DEV_DATA_T *data, DATA_U *old), char *name, FUNC_INPARA_T *pin, FUNC_OUTPARA_T *pout);
int32_t Processor_OutData(LOGGER_T *logger, void *data, int32_t n);
int32_t Processor_NotifyClient(int32_t dwType, void *data, int32_t n);
int32_t Processor_SendMsg(int32_t msgType, void *pvData, uint32_t uiDataLen);
DATA_U Process_GetData(uint16_t devcode, uint16_t index, uint16_t data_id);

int32_t Processor_GetPointValue(INOUT DEV_DATA_T *pvData, IN int32_t num);

#endif // DATAPROCESS_H_INCLUDED
