//
// Created by root on 11/26/22.
//
#include "ntp_client.h"
#include <signal.h>
#include <sys/wait.h>
#include<fcntl.h>
#include "processor.h"
#include "persist.h"


static int32_t g_sockfd = -1;

BOOL ntpRunning = TRUE;
BOOL isClick = FALSE;
pthread_t TH_NTP;
BOOL createNtpOnceFlag = TRUE;

int32_t networkDetect() {
//     char ip[14] = "www.baidu.com";
    char ip[14] = "180.76.76.76";
//     char ip[15] = "183.2.172.185";
    int status;
    pid_t pid;

    int fd;
    fd = open("/dev/null", O_WRONLY | O_TRUNC | O_CREAT, 0644);
    if (fd < 0) {
        perror("open error\n");
        exit(1);
    }

    // 新建一个进程来执行ping命令
    if ((pid = vfork()) < 0) {
        printf("vfork error");
    }

    if (pid == 0) {
        // 执行ping命令
        dup2(fd, STDOUT_FILENO);
        dup2(fd, STDERR_FILENO);
        if (execlp("ping", "ping", "-c", "1", ip, (char *) 0) < 0)
        {
            printf("execlp error\n");
        }
    }
    waitpid(pid, &status, 0);   // 当指定等待的子进程已经停止运行或结束了，则waitpid()会立即返回

    // 相等说明正常
    if (status == 0) {
        // printf("网络已连接.\n");
        return OK;
    } else {
        printf("网络已断开.\n");
        return ERR;
    }
}


unsigned int getNightTime() {
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    tm->tm_hour = 23;
    tm->tm_min = 59;
    tm->tm_sec = 59;
    return mktime(tm);
}

char ntpTimeStr[32];

void getSystemTime() {
    time_t tt = time(0);
    //产生“YYYY-MM-DD hh:mm:ss”格式的字符串。
    strftime(ntpTimeStr, sizeof(ntpTimeStr), "%Y-%m-%d %H:%M:%S", localtime(&tt));
    ntpTimeStr[31] = '\n';
    // printf("%s\n", ntpTimeStr);
}


in_addr_t inet_host(const char *host) {
    in_addr_t saddr;
    struct hostent *hostent;

    if ((saddr = inet_addr(host)) == INADDR_NONE) {
        if ((hostent = gethostbyname(host)) == NULL)
            return INADDR_NONE;

        memmove(&saddr, hostent->h_addr, hostent->h_length);
    }

    return saddr;
}


int get_ntp_packet(void *buff, size_t *size) {
    struct ntphdr *ntp;
    struct timeval tv_local;

    if (!size || *size < NTP_HLEN)
        return -1;

    memset(buff, 0, *size);

    ntp = (struct ntphdr *) buff;
    ntp->ntp_li = NTP_LI;
    ntp->ntp_vn = NTP_VN;
    ntp->ntp_mode = NTP_MODE;
    ntp->ntp_stratum = NTP_STRATUM;
    ntp->ntp_poll = NTP_POLL;
    ntp->ntp_precision = NTP_PRECISION;

    gettimeofday(&tv_local, NULL);
    ntp->ntp_transts.intpart = htonl(tv_local.tv_sec + JAN_1970);
    ntp->ntp_transts.fracpart = htonl(USEC2FRAC(tv_local.tv_usec));

    *size = NTP_HLEN;

    return 0;
}

double get_offset(const struct ntphdr *ntp, const struct timeval *recvtv_local) {
    double t1, t2, t3, t4;

    t1 = NTP_LFIXED2DOUBLE(&ntp->ntp_orits);
    t2 = NTP_LFIXED2DOUBLE(&ntp->ntp_recvts);
    t3 = NTP_LFIXED2DOUBLE(&ntp->ntp_transts);
    t4 = recvtv_local->tv_sec + recvtv_local->tv_usec / 1000000.0;

    return ((t2 - t1) + (t3 - t4)) / 2;
}

/********************************************
* Function name ：getRemoteTime
* Description   : 获取远程ntp时间
* Parameter     ：ntpService:ntp服务器地址
* Return        ：
*********************************************/
int32_t getRemoteTime(char *ntpService, uint32_t ntpPort) {
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(ntpPort);
    servaddr.sin_addr.s_addr = inet_host(ntpService);

    if ((g_sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("socket error");
        return 1;
    }

    if (connect(g_sockfd, (struct sockaddr *) &servaddr, sizeof(struct sockaddr)) != 0) {
        perror("ntp service connect error");
        if (g_sockfd > 0)
            close(g_sockfd);
        return 1;
    }

    nbytes = BUFSIZE;
    if (get_ntp_packet(buf, &nbytes) != 0) {
        fprintf(stderr, "construct ntp request error \n");
        if (g_sockfd > 0)
            close(g_sockfd);
        return 1;
    }
    send(g_sockfd, buf, nbytes, 0);
    return 0;

}

/********************************************
* Function name ：getTime
* Description   : 三个ntp服务器获取时间，确保可获取到
* Parameter     ：
* Return        ：
*********************************************/
int32_t connectNtpService(int32_t isOnce) {
    int32_t err = OK;

    if (FALSE == isOnce) {
        char *ntpService = getNtpService();
        uint32_t ntpPort = getNtpPort();

        err = getRemoteTime(ntpService, ntpPort);
        if (OK == err) {
            printf("1-Successfully connecting to the NTP server: %s\n", ntpService);
            return SUCCESS_NTP;
        }
    }

    err = getRemoteTime(NTP_SERVER_Aliyun, NTP_PORT);
    if (OK == err) {
        printf("2-Successfully connecting to the NTP server: %s\n", NTP_SERVER_Aliyun);
        return SUCCESS_NTP;
    }

    err = getRemoteTime(NTP_SERVER_Microsoft, NTP_PORT);
    if (OK == err) {
        printf("Successfully connecting to the NTP server: %s\n", NTP_SERVER_Microsoft);
        return SUCCESS_NTP;
    }

    err = getRemoteTime(NTP_SERVER_Ntsc, NTP_PORT);
    if (OK == err) {
        printf("Successfully connecting to the NTP server: %s\n", NTP_SERVER_Ntsc);
        return SUCCESS_NTP;
    }
    return ERR_CONNECT_NTP_SERVICE;
}

/********************************************
* Function name ：waitTime
* Description   : 等待的时间
* Parameter     ：
* Return        ：
*********************************************/
BOOL waitTime() {
    sleep(3);
    time_t timeNight = getNightTime();

    //获取当前系统时间戳
    time_t timeNow = time(NULL);
    int32_t delayTime = timeNight - timeNow;
    if (delayTime < 0) {
        printf("NTP time configuration error.\n");
        return FALSE;
    }

    if (abs(delayTime) < 60) {
        return TRUE;
    }
    return FALSE;
    //sleep(delayTime);
}

// 填充NTP数据,需要来自于Web.
void fillDataWebConfigNtp(WEB_CONFIG_NTP *ntpConfig) {
    g_webConfigNtp.syn_time_mode = ntpConfig->syn_time_mode;
    strcpy(g_webConfigNtp.ntp_service, ntpConfig->ntp_service);
    g_webConfigNtp.ntp_port = ntpConfig->ntp_port;

    printf("************ receive NTP parameters ************\n");
    printf("syn time mode：%d\n", g_webConfigNtp.syn_time_mode);
    printf("ntp address：%s\n", g_webConfigNtp.ntp_service);
    printf("ntp port：%d\n", g_webConfigNtp.ntp_port);
    printf("*************************************************\n\n");
}


int32_t getSynTimeMode() {
    return g_webConfigNtp.syn_time_mode;
}

char *getNtpService() {
    // printf("ntp service?: %s\n", g_webConfigNtp.ntp_service);
    return g_webConfigNtp.ntp_service;
}

uint32_t getNtpPort() {
    // printf("ntp port?: %d\n", g_webConfigNtp.ntp_port);
    return g_webConfigNtp.ntp_port;
}


int32_t ntpService(int32_t isOnce) {
    int32_t errCode = OK;
    PERSIST_NODE_INFO_T runLog;
    time_t now;
    struct tm *timenow;
    char timedata[30] = {0};

    // 网络连通性检测
    uint8_t try_num = 0;
    while (try_num <= 5) {
        errCode = networkDetect();
        if (OK != errCode) {
            printf("NTP:Network connection failed, try again later.\n");
//             try_num += 1;
            sleep(1);
        } else {
            break;
        }
    }
    //注释原因：可能存在网络一开始断开，网络连接后，需要对时一次
//     if (try_num >= 5) {
//         return ERR_NETWORK_DISCONNECT;
//     }

    // 连接ntp服务器
    errCode = connectNtpService(isOnce);
    if (OK != errCode) {
        printf("Failed to connect to NTP server\n");
        return ERR_CONNECT_NTP_SERVICE;
    }
    FD_ZERO(&readfds);
    FD_SET(g_sockfd, &readfds);
    int maxfd1;
    maxfd1 = g_sockfd + 1;

    timeout.tv_sec = TIMEOUT;
    timeout.tv_usec = 0;
    int retval = select(maxfd1, &readfds, NULL, NULL, &timeout);
    if (retval > 0)
    {
        if (FD_ISSET(g_sockfd, &readfds))
        {
            if ((nbytes = recv(g_sockfd, buf, BUFSIZE, 0)) < 0)
            {
                perror("recv error");
                return ERR_GET_NTP_TIMER;
            }
            // 计算客户端时间与服务器端时间偏移量
            gettimeofday(&recvtv, NULL);
            double offset;
            offset = get_offset((struct ntphdr *) buf, &recvtv);
            // 更新系统时间
            gettimeofday(&tv, NULL);
//             tv.tv_sec += (int) offset + 28800;
            tv.tv_sec += (int) offset;
            tv.tv_usec += (int) offset - (int) offset;
//             sleep(1);
            //设置当前进程的系统时间
            if (settimeofday(&tv, NULL) != 0) {
                perror("set time of day error");
                return ERR_SET_TIME;
            }
            printf("NTP time acquisition success: %s\n", ctime((time_t *) &tv));
            getSystemTime();
            printf("System time calibration successful,System time: %s\n", ntpTimeStr);
            printf("Network connection\n");
            runLog.pcDescription = "Network connection";
            time(&now);
            timenow = localtime(&now);
            sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
            strcpy(runLog.date,timedata);
            strcpy( runLog.arrcDevName, "zero carbon gateway");
            Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
        }
        close(g_sockfd);
        return SUCCESS_NTP;
    }
    return -1;
//     close(g_sockfd);
//     return SUCCESS_NTP;
}

// 判断旧的参数是否存在
BOOL isNtpParamExist() {
    if ((g_webConfigNtp.ntp_service[0] == '\0') && (g_webConfigNtp.ntp_port == 0))
        return FALSE;
    return TRUE;
}


void recNtpParameters(WEB_CONFIG_NTP *ntpConfig) {
    fillDataWebConfigNtp(ntpConfig);
    isClick = TRUE;

    // 创建ntp线程
    if (TRUE == createNtpOnceFlag) {
        pthread_create(&TH_NTP, NULL, ntpThread, NULL);
        createNtpOnceFlag = FALSE;
    }
    // 判断ntp线程是否存在
    int32_t kill_ret = pthread_kill(TH_NTP, 0);
    if (ESRCH == kill_ret) {
        //printf("线程不存在 id = %lx \n", TH_NTP);
        pthread_create(&TH_NTP, NULL, ntpThread, NULL);

    } else if (0 == kill_ret) {
        //printf("线程存活 id = %lx \n", TH_NTP);
    }
}

/* ntp对时主函数 */
void *ntpThread(void *args) {
    int32_t errCode = OK;
    PERSIST_NODE_INFO_T runLog;
    time_t now;
    struct tm *timenow;
    char timedata[30] = {0};
    //
    struct timeval tmpTime;
    int ntpFlg = 0;//初始化下ntp对时失败，时间不准确，不予纪录，只有当ntp对时成功后再失败才记录
    //

    // 设置时区为为中国时间
//     setenv("TZ","Asia/Shanghai",1);
//
//     errCode = ntpService(TRUE);
//     if (errCode != OK) {
//         printf("Failed to calibrate time using NTP\n");
//         sleep(5);
//     }

    while (ntpRunning) {
//         int32_t synTimeMode = getSynTimeMode();
        /**/
        printf("*********start NTP time***********\n");

        tmpTime.tv_sec = 24 * 60 * 60;  //24h NTP对时一次
        tmpTime.tv_usec = 0;

        // 设置时区为为中国时间
        setenv("TZ","Asia/Shanghai", 1);
        errCode = ntpService(FALSE);//FALSE  TRUE
        if (errCode != OK) {
            printf("Failed to calibrate time using NTP\n");
            if(ntpFlg == 1)
            {
                runLog.pcDescription = "Network connection failed";
                time(&now);
                timenow = localtime(&now);
                sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                strcpy(runLog.date,timedata);
                strcpy( runLog.arrcDevName, "zero carbon gateway");
                Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
            }
//             sleep(5);
            continue;
        }
        ntpFlg = 1;
        runLog.pcDescription = "NTP time calibration successful";
        time(&now);// 获取当前系统时间，以秒为单位存储在变量now中
        timenow = localtime(&now);//将now转换为本地时间格式，并将结果存储在指针timenow指向的结构体中
        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
        strcpy(runLog.date,timedata);
        strcpy( runLog.arrcDevName, "zero carbon gateway");
        Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);

        /**/

        // 判断是否有参数
//         BOOL isExist = isNtpParamExist();
//         if (FALSE == isExist) {
//             // printf("如果没有获取到ntp参数，则跳过此次循环.\n");
//             sleep(5);
//             continue;
//         }

//         BOOL onTime = waitTime();
//         if ((1 == synTimeMode) && (TRUE == isClick || TRUE == onTime)) {
//             errCode = ntpService(FALSE);
//             if (errCode != OK) {
//                 printf("Failed to calibrate time using NTP\n");
//                 sleep(5);
//                 isClick = FALSE;
//                 onTime = FALSE;
//                 continue;
//             }
//             isClick = FALSE;
//             onTime = FALSE;
//         }
//         sleep(10);
        select(0, NULL, NULL, NULL, &tmpTime);
    }
    return NULL;
}

/********************************************
* Function name ：ntpClientThread
* Description   : ntp线程创建函数
* Parameter     ：
* Return        ：
*********************************************/
int32_t createNtpClientThread() {
    pthread_t thNtp;
    pthread_create(&thNtp, NULL, ntpThread, NULL);
    return 0;
}

void NTP_server()
{
    TIME_CFG_T *pstTimeCfg = NULL;
    int32_t recordNum = 0;

    sysCfg_Load(CFG_TYPE_TIME_CFG, (void **)(&pstTimeCfg), &recordNum);

    if (pstTimeCfg != NULL)
    {
        WEB_CONFIG_NTP ntpConfigTmp;
        ntpConfigTmp.syn_time_mode = pstTimeCfg->SynTimeMode;
        strcpy(ntpConfigTmp.ntp_service,pstTimeCfg->NTPAddr);
        ntpConfigTmp.ntp_port = pstTimeCfg->NTPPort;

        recNtpParameters(&ntpConfigTmp);
    }

    logger.timeSyncMode = pstTimeCfg->SynTimeMode;
    sysCfg_Free(pstTimeCfg);
}
