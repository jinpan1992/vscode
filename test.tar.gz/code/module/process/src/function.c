#include <stdlib.h>
#include "sgdev.h"
#include "function.h"
#include "send.h"
#include "logUtil.h"
#include "config.h"
#include "data_script.h"
#include "err.h"

//注册函数
int32_t InsertDpFunc(LOGGER_T *logger, int32_t (*func)(void *in, void *out, DEV_DATA_T *data, DATA_U *old), char *funcName)
{
    int32_t i = 0, res= -1, len =0;
    for (i = 0; i < DP_FUNC_MAX_NUM_D; ++i)
    {
        if (logger->dp_func[i].func == NULL)
        {
            len = sizeof(logger->dp_func[i].name) > strlen(funcName) ? strlen(funcName) : sizeof(logger->dp_func[i].name);
            strncpy(logger->dp_func[i].name, funcName, len);
//             printf("funcname = %s\n", funcName);
            logger->dp_func[i].func = func;
            logger->dp_func[i].id = i;
            //扫描测点属性点表,注册函数信号
            //插入成功
            res = OK;
            EMS_LOG(LL_INFO, MODULE_D, FALSE, "InsertDpProFunc:no.%d = %s\n", i, funcName);
            break;
        }
    }
    if (i >= DP_FUNC_MAX_NUM_D)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "InsertDpFunc: full\n");
//         exit(EXIT_FAILURE);
    }
    return res;
}

//add by jinpan 2023/2/2
int32_t InsertDpFuncNorth(LOGGER_T *logger,
                          int32_t (*func)(void *in, void *out, DEV_DATA_T *data, DATA_U *old),
                          char *funcName,
                          FUNC_INPARA_T *pin,
                          FUNC_OUTPARA_T *pout)
{
    int32_t i = 0, j = 0, k = 0, res= -1, len =0;
    uint32_t input_num = pin->in_argc;
    uint32_t output_num = pout->out_argc;
    uint8_t out_argc = output_num;
    uint8_t in_argc = input_num;

    for (i = 0; i < DP_FUNC_MAX_NUM_D; ++i)
    {
        if (logger->dp_func[i].func == NULL)
        {
            len = sizeof(logger->dp_func[i].name) > strlen(funcName) ? strlen(funcName) : sizeof(logger->dp_func[i].name);
            strncpy(logger->dp_func[i].name, funcName, len);
//             printf("funcname = %s\n", funcName);
            logger->dp_func[i].func = func;
            logger->dp_func[i].id = i;
            logger->dp_func[i].paras_num = 1;
            logger->dp_func[i].paras = (FUNC_PARAS_T *)malloc(sizeof(FUNC_PARAS_T));
            logger->dp_func[i].paras->inputpara.inpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*input_num);
            logger->dp_func[i].paras->outputpara.outpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*output_num);
            memset(logger->dp_func[i].paras->inputpara.inpara, 0, sizeof(FUNC_PARA_T)*input_num);
            memset(logger->dp_func[i].paras->outputpara.outpara, 0, sizeof(FUNC_PARA_T)*input_num);
            logger->dp_func[i].paras->inputpara.in_argc = input_num;
            logger->dp_func[i].paras->outputpara.out_argc = output_num;
            for(j = 0;j < input_num; j++)
            {
                logger->dp_func[i].paras->inputpara.inpara[j].data_id = pin->inpara[j].data_id;
                logger->dp_func[i].paras->inputpara.inpara[j].dev_code = pin->inpara[j].dev_code;
                logger->dp_func[i].paras->inputpara.inpara[j].index = pin->inpara[j].index;
                const PROTOCOL_DATA_T *p = SDB_ND_GetProtocolData(pin->inpara[j].dev_code, pin->inpara[j].index, pin->inpara[j].data_id);//寻找dataName
                login_function(logger->dp_func[i].paras_num, logger, (char *)(p->data_name), i,
                               pin->inpara[j].dev_code, pin->inpara[j].index, -1, 0, &(logger->dp_func[i].paras->inputpara.inpara), &in_argc);
            }
            logger->dp_func[i].paras->outputpara.out_argc = output_num;
            for(k = 0; k < output_num; k++)
            {
                logger->dp_func[i].paras->outputpara.outpara[k].data_id = pout->outpara[k].data_id;
                logger->dp_func[i].paras->outputpara.outpara[k].dev_code = pout->outpara[k].dev_code;
                logger->dp_func[i].paras->outputpara.outpara[k].index = pout->outpara[k].index;

                const PROTOCOL_DATA_T *q = SDB_ND_GetProtocolData(pout->outpara[k].dev_code, pout->outpara[k].index, pout->outpara[k].data_id);

                login_function_outpara(logger, (char *)(q->data_name), pout->outpara[k].dev_code, pout->outpara[k].index, -1, &(logger->dp_func[i].paras->outputpara.outpara), &out_argc);
            }
            //扫描测点属性点表,注册函数信号
            //插入成功
            res = OK;
            EMS_LOG(LL_INFO, MODULE_D, FALSE, "InsertDpProFuncNorth:no.%d = %s\n", i, funcName);
            break;
        }
//         free(logger->dp_func[i].paras->outputpara.outpara);
//         free(logger->dp_func[i].paras->inputpara.inpara);
//         free(logger->dp_func[i].paras);
    }
    if (i >= DP_FUNC_MAX_NUM_D)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "InsertDpFuncNorth: full\n");
//         exit(EXIT_FAILURE);
    }
    return res;
}

//查找函数
int32_t GetDpFunc(DP_FUNC_T *dp_func, int32_t (*func)(void *in, void *out, DEV_DATA_T *data, DATA_U *old))
{
    uint32_t i = 0;
    for (i = 0; i < DP_FUNC_MAX_NUM_D; ++i) //DP_FUNC_MAX_NUM_D
    {
        if (dp_func[i].func == func)
        {
            return i;
        }
    }
    return 0;
}

int16_t GetFuncIdByNames(DP_FUNC_T *dp_func, char *funcName)
{
    uint32_t ret = INVALID_VALUE, i = 0;
    for (i = 0; i < DP_FUNC_MAX_NUM_D; i++)
    {
        if (0 == strcmp(funcName, dp_func[i].name))
        {
            ret = i;
            break;
        }
    }

    return ret;
}

int32_t GetOutpara(IN LOGGER_T *logger, IN char *funcName, INOUT FUNC_OUTPARA_T *out, IN uint16_t id)
{
    int32_t ret = OK;

    uint16_t i = 0;
    uint8_t funcId = GetFuncIdByNames(logger->dp_func, funcName);
    uint16_t tmp_out_argc = logger->dp_func[funcId].paras->outputpara.out_argc;

    if (id > tmp_out_argc)
    {
        printf("id=%d > out_argc=%d  error", id, tmp_out_argc);
        ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
        return ret;
    }

    for (i = 0; i < tmp_out_argc; i++)
    {
        if (i + 1 == id)
        {
            out->outpara[0].dev_code = logger->dp_func[funcId].paras->outputpara.outpara[i].dev_code;
            out->outpara[0].index = logger->dp_func[funcId].paras->outputpara.outpara[i].index;
            out->outpara[0].data_id = logger->dp_func[funcId].paras->outputpara.outpara[i].data_id;
            out->outpara[0].dev_name = logger->dp_func[funcId].paras->outputpara.outpara[i].dev_name;
            break;
        }
    }

    return ret;
}

//完成注册函数到测点属性表
//函数数据结构建立
uint16_t login_function(uint32_t paras_id, LOGGER_T *logger, char *dataName, uint16_t func_sign,
                        int32_t dev_code, int32_t index, int32_t dev_name, BOOL untrip,
                        FUNC_PARA_T **inpara, uint8_t *in_argc)
{
    uint32_t i = 0, j = 0, k = 0, m = 0;
    uint32_t ret = 0;
    uint16_t findtestlistid = 0;
    uint8_t in_argc_tmp = *in_argc;
    FUNC_PARA_T *tem_inpara = NULL;
    uint8_t dataType;

    for (i = 0; i < logger->dev_num; i++)//logger->dev_num
    {
        if ((logger->sgdev[i].dev_name == dev_name)||(dev_name < 0))
        {
            if ((logger->sgdev[i].dev_code == dev_code)||(dev_code < 0))
            {
                for (j = 0; j < logger->sgdev[i].point_num; j++)
                {
                    if (0 == strcmp(dataName,logger->sgdev[i].point_attr[j].data_name))
                    {
                        findtestlistid = logger->sgdev[i].point_attr[j].data_id;
                        dataType = logger->sgdev[i].point_attr[j].data_type;

                        ret = 0;
                        for (k = 1; k < MAX_SIGN; ++k)
                        {
                            if (logger->sgdev[i].point_attr[j].sscript_sign[k].func_sign == 0)
                            {
                                logger->sgdev[i].point_attr[j].sscript_sign[k].func_sign = func_sign+1;
                                logger->sgdev[i].point_attr[j].sscript_sign[k].paras_id = paras_id;
                                logger->sgdev[i].point_attr[j].sscript_sign[k].untrip = untrip;
                                ret = 1;
                                break;
                            }
                        }
                        if (!ret)
                        {
                            EMS_LOG(LL_DEBUG, MODULE_D, FALSE, "sgdev[%d].point_attr[%d].sscript_sign[%d] is full !\n", i, j, k);
                        }
                        if (index < 0)
                        {
                            tem_inpara = realloc(*inpara,sizeof(FUNC_PARA_T)*(logger->sgdev[i].num + in_argc_tmp));
                            if(tem_inpara != NULL)
                            {
                                *inpara = tem_inpara;
                            }
                            else
                            {
                                EMS_LOG(LL_INFO, MODULE_D, FALSE, "realloc fail.\n");
                            }
                            for (m = 0; m < logger->sgdev[i].num; ++m)
                            {
                                (*inpara)[in_argc_tmp+m].data_id = findtestlistid;
                                (*inpara)[in_argc_tmp+m].dev_code = logger->sgdev[i].dev_code;
                                (*inpara)[in_argc_tmp+m].index = m + 1;
                                (*inpara)[in_argc_tmp+m].dev_name = logger->sgdev[i].dev_name;
                                (*inpara)[in_argc_tmp+m].dataType = dataType;
                            }
                            *in_argc += logger->sgdev[i].num;
                        }
                        else if ((index == 0)||(index <= logger->sgdev[i].num) || (index == 65535))
                        {
                            tem_inpara = realloc(*inpara,sizeof(FUNC_PARA_T)*(in_argc_tmp + 1));
                            if (tem_inpara != NULL)
                            {
                                *inpara = tem_inpara;
                            }
                            else
                            {
                                EMS_LOG(LL_INFO, MODULE_D, FALSE, "realloc fail.\n");
                            }
                            (*inpara)[in_argc_tmp].data_id = findtestlistid;
                            (*inpara)[in_argc_tmp].dev_code = logger->sgdev[i].dev_code;
                            (*inpara)[in_argc_tmp].index = index;
                            (*inpara)[in_argc_tmp].dev_name = logger->sgdev[i].dev_name;
                            (*inpara)[in_argc_tmp+m].dataType = dataType;
                            *in_argc += 1;
                            in_argc_tmp += 1;
                        }
                        break;
                    }
                }
                if ((ret) && (dev_code >= 0))
                {
                    break;
                }
            }
        }
    }
    return findtestlistid;
}

uint16_t login_function_outpara(LOGGER_T *logger, char *string, int32_t dev_code, int32_t index, int32_t dev_name, FUNC_PARA_T **outpara, uint8_t *out_argc)
{
    uint32_t i = 0, j = 0, m = 0, ret = 0;
    uint16_t findtestlistid = 0;
    uint8_t out_argc_tmp = *out_argc;
    FUNC_PARA_T *tem_outpara = NULL;

    for (i = 0 ;i < logger->dev_num; i++)
    {
        if ((logger->sgdev[i].dev_name == dev_name)||(dev_name < 0))
        {
            if ((logger->sgdev[i].dev_code == dev_code)||(dev_code < 0))
            {
                for (j = 0; j < logger->sgdev[i].point_num; j++)
                {
                    if (0 == strcmp(string, logger->sgdev[i].point_attr[j].data_name))
                    {
                        findtestlistid = logger->sgdev[i].point_attr[j].data_id;
                        ret = 1;

                        if (index < 0)
                        {
                            tem_outpara = realloc(*outpara, sizeof(FUNC_PARA_T) * (logger->sgdev[i].num + out_argc_tmp));
                            if (tem_outpara != NULL)
                            {
                                *outpara = tem_outpara;
                            }
                            else
                            {
                                EMS_LOG(LL_INFO, MODULE_D, FALSE, "realloc fail.\n");
                            }
                            for (m = 0; m < logger->sgdev[i].num; ++m)
                            {
                                (*outpara)[out_argc_tmp+m].data_id = findtestlistid;
                                (*outpara)[out_argc_tmp+m].dev_code = logger->sgdev[i].dev_code;
                                (*outpara)[out_argc_tmp+m].index = m+1;
                                (*outpara)[out_argc_tmp+m].dev_name = logger->sgdev[i].dev_name;
                            }
                            *out_argc += logger->sgdev[i].num;
                        }
                        else if ((index == 0)||(index < logger->sgdev[i].num) || (index  == logger->sgdev[i].num) || (index == 65535))
                        {
                            tem_outpara = realloc(*outpara,sizeof(FUNC_PARA_T)*(out_argc_tmp + 1));
                            if (tem_outpara != NULL)
                            {
                                *outpara = tem_outpara;
                            }
                            else
                            {
                                EMS_LOG(LL_INFO, MODULE_D, FALSE, "realloc fail.\n");
                            }

                            (*outpara)[out_argc_tmp].data_id = findtestlistid;
                            (*outpara)[out_argc_tmp].dev_code = logger->sgdev[i].dev_code;
                            (*outpara)[out_argc_tmp].index = index;
                            (*outpara)[out_argc_tmp].dev_name = logger->sgdev[i].dev_name;
                            *out_argc += 1;
                            out_argc_tmp += 1;
                        }
                        break;
                    }
                }
                if ((ret)&&(dev_code >= 0))
                {
                    break;
                }
            }
        }
    }
    return findtestlistid;
}

int32_t ClearDpFunc(IN LOGGER_T *logger)
{
    int32_t i = 0;
    for (i = 0; i < DP_FUNC_MAX_NUM_D; i++)
    {
        DP_FUNC_T *funcTmp = logger->dp_func + i;
        if (funcTmp->paras != NULL)
        {
            if (funcTmp->paras->inputpara.inpara != NULL)
            {
                HCFREE(funcTmp->paras->inputpara.inpara);
                funcTmp->paras->inputpara.inpara = NULL;
            }

            if (funcTmp->paras->outputpara.outpara != NULL)
            {
                HCFREE(funcTmp->paras->outputpara.outpara);
                funcTmp->paras->outputpara.outpara = NULL;
            }

            HCFREE(funcTmp->paras);
            funcTmp->paras = NULL;
        }
    }

    return OK;
}
