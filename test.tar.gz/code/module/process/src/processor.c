#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/prctl.h>
#include "processor.h"
#include "queues.h"
#include "config.h"
#include "data_script.h"
#include "logUtil.h"
#include "sdb.h"
#include "dido.h"
#include "persist.h"
#include "stimer.h"
#include "send.h"
#include "data_script.h"
#include "file_operate.h"
#include "mapping.h"
#include "MsgProc.h"
#include "ntp_client.h"
#include "calculate.h"
#include "hotPlug.h"

LOGGER_T logger;

typedef struct
{
    MODULE_STATE_E eState;
}DP_HANDLE_T;

static DP_HANDLE_T *g_pDPHandle = NULL;

static BOOL checkProcessorPrecondition()
{
    BOOL ret = FALSE;

    if (DirExist(DATAPROCESS_XML_NAME) && SDB_GetState() >= MODULE_STATE_READY)
    {
        ret = TRUE;
    }

    return ret;
}

//设置同步time
static void SetSysCmd(LOGGER_T *logger)
{
    system("hwclock -s");
}

//设置同步UTC
void SetSysUTCCmd(LOGGER_T *logger)
{
    //char invUTCArr[256] = {"export TZ="};
    //strcat(invUTCArr,(const char *)logger->time_zone);
    //printf("invUTCArr = %s\n",invUTCArr);
    //system ( invUTCArr);
    //system("hwclock -s");
}

//ntpsever对时
void SetNtpTime(LOGGER_T *logger)
{
    struct tm* local;
    time_t t;
    t = time(NULL);
    if (t==(time_t)-1)
    {
        fprintf(stderr,"time error:%s\n",strerror(errno));
    }
    EMS_LOG(LL_INFO, MODULE_D, false, "ntp set time start !\n");
    local = localtime(&t);

    EMS_LOG(LL_DEBUG, MODULE_D, false, "Year = %d, Month = %d, Date = %d\n", local->tm_year + 1900, local->tm_mon + 1, local->tm_mday);
    EMS_LOG(LL_DEBUG, MODULE_D, false, "Hour = %d,Minute = %d, Second = %d\n", local->tm_hour, local->tm_min, local->tm_sec);

    char time_sync[256] = {"ntpdate "};
    if (logger->ntp_serverEn == 1)
    {
        if (sizeof(time_sync) > strlen(logger->ntp_server) + strlen(time_sync) + 1)
        {
            sprintf(time_sync,"%s &",(const char *)logger->ntp_server);
            EMS_LOG(LL_DEBUG, MODULE_D, false, "time_sync = %s\n",time_sync);
            system(time_sync);
            system("hwclock");
        }
    }
    EMS_LOG(LL_INFO, MODULE_D, false, "ntp set time end !\n");
    local = localtime(&t);
    EMS_LOG(LL_DEBUG, MODULE_D, false, "Year = %d,Month = %d, Date = %d\n", local->tm_year + 1900,local->tm_mon + 1, local->tm_mday);
    EMS_LOG(LL_DEBUG, MODULE_D, false, "Hour = %d,Minute = %d, Second = %d\n", local->tm_hour, local->tm_min, local->tm_sec);
}

//定时重启
void RebootTimers(LOGGER_T *logger)
{
    time_t t;
    uint8_t rb_hour = 0;
    uint8_t rb_minute = 0;
    struct tm* local = 0;
    uint32_t tot_local_t= 0;
    uint32_t tot_rb_t = 0;
    t = time(NULL);
    if (t == (time_t)-1)
    {
        fprintf(stderr,"time error:%s\n", strerror(errno));
    }

    if (logger->reboot_time[1] == ':')
    {
        rb_hour = logger->reboot_time[0] - 0x30;
        rb_minute = (logger->reboot_time[2] - 0x30) * 10 + logger->reboot_time[3] - 0x30;
    }
    else if (logger->reboot_time[2] == ':')
    {
        rb_hour = (logger->reboot_time[0] - 0x30) * 10 + logger->reboot_time[1] - 0x30;
        rb_minute = (logger->reboot_time[3] - 0x30) * 10 + logger->reboot_time[4] - 0x30;
    }
    local = localtime(&t);
    tot_rb_t    = 3600 * rb_hour +  60 * rb_minute ;
    tot_local_t = 3600 * local->tm_hour +  60 * local->tm_min + local->tm_sec;

    if (tot_rb_t == tot_local_t)
    {
        EMS_LOG(LL_INFO, MODULE_D, false, "reboot.\n");
        system("reboot");
    }
}

//初始化设备模型
static int32_t InitHandle(LOGGER_T *logger)
{
    int32_t res = 0, i = 0;

    memset(&(logger->dev_Ver), 0, sizeof(PLATFORMVER_T));
    memset(logger->Eth_info, 0, 2 * sizeof(ETH_INFO_T));
    logger->sgdev = NULL;
    for (i = 0; i < 65536; ++i)
    {
        logger->map[i] = NULL;
    }
    logger->dev_num = 0;
    memset(logger->fifobuf, 0, sizeof(DEV_DATA_T) * 4096);
    logger->fifobuflen = 0;
    pthread_mutex_init(&(logger->fifo_rwlock), NULL);

    memset(logger->outbuf, 0, DATAOUT_MAX_NUM * sizeof(OUTDATA_T));
    logger->obufcnt = 0;

    logger->stimer.clock_sign = NULL;
    logger->stimer.end = NULL;
    logger->stimer.clock_sign_num = 0;

    memcpy(logger->stimer.fifopath, "/tmp/stimer_fifo", strlen("/tmp/stimer_fifo"));
    InitQueueS_D(&(logger->dp_sign), DP_FUNC_MAX_NUM_D);
    res = sem_init(&(logger->dp_sem), 0, 0);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "Semaphore dp_sem Initialization failed\n");
        exit(EXIT_FAILURE);
    }

    for (i = 0; i < DP_FUNC_MAX_NUM_D; ++i)
    {
        memset(logger->dp_func[i].name, 0, sizeof(logger->dp_func[i].name));
        logger->dp_func[i].id = 0;
        logger->dp_func[i].func = NULL;
    }

    logger->reboot_time_EN  = 0;

    memset(logger->loggerSN,0,16);
    logger->SNflag = 0;

    res = sem_init(&(logger->dp_func_sem), 0, 0);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "Semaphore dp_func_sem Initialization failed\n");
        exit(EXIT_FAILURE);
    }

    pthread_cond_init(&logger->fifo_cond, NULL);

    memset(&(logger->dido_ctl), 0, sizeof(DIDO_CTL_T));
    memset(logger->adc_ctl, 0, ADC_NUM * sizeof(ADC_CTL_T));
    memset(logger->dp_func, 0, DP_FUNC_MAX_NUM_D * sizeof(DP_FUNC_T));

    if(logger->SNflag == 0xAA)
    {
        SetloggerSN(APPVERDATA_XML_NAME, logger);
    }

    return 0;
}

int32_t InitSgdev(LOGGER_T *logger)
{
    int32_t ret = OK;
    uint16_t  i = 0;
    uint16_t dev_num = 0, total_dev_num = 0;
    SGDEV_T *tmp_sgdev = NULL;
    DEV_INFO_T *dev = NULL;

    do
    {
        SDB_ND_Load();
        total_dev_num = SDB_ND_GetNum();
        dev_num = SDB_ND_GetKinds();
        if (total_dev_num == 0 || dev_num == 0)
        {
            EMS_LOG(LL_ERROR, MODULE_D, false, "SDB has no dev!\n");
            ret = ERROR_T(ERR_DEFAULT_INTERNAL_ERROR);
        }

        logger->dev_num = dev_num;
        logger->total_num = total_dev_num;
        logger->sgdev = (SGDEV_T *)calloc(logger->dev_num, sizeof(SGDEV_T));
        if (logger->sgdev == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_D, false, "malloc logger->sgdev error!\n");
            ret = ERROR_T(ERR_DEFAULT_NO_MEM);
            break;
        }

        tmp_sgdev = (SGDEV_T *)calloc(total_dev_num, sizeof(SGDEV_T));
        if (tmp_sgdev == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_D, false, "malloc tmp_sgdev error!\n");
            ret = ERROR_T(ERR_DEFAULT_NO_MEM);
            break;
        }

        DEV_INFO_EXT_T *pDevList = SDB_ND_GetList();
        for (i = 0; i < total_dev_num; i++)
        {
            FillSgdevInfo(pDevList + i, tmp_sgdev + i);
        }

        BindToLogger(logger, tmp_sgdev);
    }while(0);

    if (ret != OK)
    {
        HCFREE(logger->sgdev);
        HCFREE(dev);
    }

    HCFREE(tmp_sgdev);

    return ret;
}

void CreatGdataMap(SGDEV_T *sgdev)
{
    uint32_t i = 0, j = 0;
    uint32_t maxDevId = 0;

    POINT_ATTRIBUTE_T *point_attr = sgdev->point_attr;
    DEV_DATA_T *gdata_temp = NULL;

    for (i = 0; i < sgdev->point_num; ++i)
    {
        maxDevId = maxDevId < point_attr[i].data_id ? point_attr[i].data_id : maxDevId;
    }

    sgdev->map = (uint32_t *)calloc(maxDevId + 1, sizeof(uint32_t));

    gdata_temp = (DEV_DATA_T *)calloc(sgdev->point_num + 1, sizeof(DEV_DATA_T));

    for (i = 0; i < (sgdev->point_num); ++i)
    {
        for(j = 1; j < (maxDevId + 1); j++)
        {
            if(j == point_attr[i].data_id)
            {
                sgdev->map[j] = i;
                gdata_temp[i].dev_code = sgdev->dev_code;
                gdata_temp[i].data_id = j;
                gdata_temp[i].data_type = point_attr[i].data_type;
            }
        }
    }
    sgdev->gdata_info = gdata_temp;
}

void creat_sgdev_gdata(SGDEV_T *sgdev)
{
    uint16_t i = 0;
    SGDEV_DATA_T **Gdata_temp = NULL;
    if (sgdev->num <= 0)
    {
        return;
    }

    uint16_t len = (sgdev->point_num + 1) * sgdev->num;
    Gdata_temp = (SGDEV_DATA_T **) malloc (sizeof(SGDEV_DATA_T *) * len);

    len = sgdev->num;
    for (i = 0; i < (sgdev->point_num + 1); i++)
    {
        Gdata_temp[i] = (SGDEV_DATA_T *)malloc (sizeof(SGDEV_DATA_T) * len);
        if (Gdata_temp[i] == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_D, false, "malloc protocol_data error.\n");
            exit(EXIT_FAILURE);
        }

        memset(Gdata_temp[i], 0, sizeof(SGDEV_DATA_T) * len);
    }

    sgdev->gdata = Gdata_temp;
}

void CreatSgdevMap(LOGGER_T *logger)
{
    uint16_t i = 0;
    for (i = 0; i < logger->dev_num; i++)
    {
        CreatGdataMap(&logger->sgdev[i]);
        creat_sgdev_gdata(&logger->sgdev[i]);
        logger->map[logger->sgdev[i].dev_code] = &logger->sgdev[i];
    }
    logger->total_num = TotalInvNum(logger);//统计设备数量
}

int32_t Processor_CreateDevModel()
{
    int32_t ret = OK;

    if (logger.sgdev != NULL)
    {
        return ERROR_T(ERR_DEFAULT_ALREADY_INIT);
    }

    ret = InitSgdev(&logger);
    if (ret == OK)
    {
        CreatSgdevMap(&logger);
    }

    return ret;
}

int32_t Processor_DestroyDevModel()
{
    int32_t i = 0, j = 0;

    for (i = 0; i < logger.dev_num; i++)
    {
        SGDEV_T *sgdevTmp = logger.sgdev + i;
        if (sgdevTmp != NULL)
        {
            HCFREE(sgdevTmp->map);

            HCFREE(sgdevTmp->gdata_info);

            if (sgdevTmp->gdata != NULL)
            {
                for (j = 0; ((j < sgdevTmp->point_num + 1) && (sgdevTmp->gdata + j != NULL)); j++)
                {
                    SGDEV_DATA_T *sgdevDataTmp = *(sgdevTmp->gdata + j);

                    HCFREE(sgdevDataTmp);
                }

                HCFREE(sgdevTmp->gdata);
            }

            HCFREE(sgdevTmp->point_attr);
        }

    }

    HCFREE(logger.sgdev);
    logger.dev_num = 0;

    memset(logger.map, 0, 65535 * sizeof(SGDEV_T *));
    SDB_ND_UnLoad();

    return OK;
}
/**
 * @brief  数据处理模块的初始化
 * @param
 *
 * @return
 */
void InitDataProcessPara(void)
{
    //初始化处理设备
    Processor_CreateDevModel();

    /* 注册处理函数*/
    InitPlantProcessFunc(&logger);

    // Script_Init();

    //add by jinpan 2022/2/28
//     Control_Init();

    //设备处理模型配置
    if (0 != SGDevConfig(DATAPROCESS_XML_NAME, &logger))
    {
        exit(EXIT_FAILURE);
    }

    SetSysCmd(&logger);
    SetVersion(&logger);
    SetSN(&logger);
    InsertTime();

    DidoInitByDefault(); //默认状态为L

    if (logger.hisDstoreperiod != 0)
    {
        if (DirExist("/media/record"))
        {
            strcpy(logger.storePath, "/media/record");
            logger.hisDExpiredMin = 30 * 24 * 60;
        }
        else
        {
            strcpy(logger.storePath, "/home/SGComm/record");
            logger.hisDExpiredMin = 15 * 24 * 60;
        }

        if (!DirExist(logger.storePath))
            mkdir(logger.storePath, 0777);

        int32_t ret = unlink("/home/record");
        ret = symlink(logger.storePath, "/home/record");
        printf("symlink ret:%d errno:%d\n", ret, errno);

        Persister_Init(logger.storePath, sizeof(logger.storePath));

        PERSIST_CONFIG_T stConfig;
        stConfig.eHisType = HIS_DATA;
        stConfig.uiWriteIntervalSec = logger.hisDstoreperiod;
        stConfig.uiExpireTimeMin = logger.hisDExpiredMin;
        stConfig.eRule = RULE_BY_TIME;
        Persister_Set(&stConfig);
        Persister_Run(HIS_DATA);

        stConfig.eHisType = HIS_RECORD;
        stConfig.uiWriteIntervalSec = logger.hisDstoreperiod;
        stConfig.uiExpireTimeMin = logger.hisDExpiredMin;
        stConfig.eRule = RULE_BY_TIME;
        Persister_Set(&stConfig);
        Persister_Run(HIS_RECORD);
    }
}

int32_t DataProcessFun(LOGGER_T *logger)
{
    DP_FUNC_T *dp_func = logger->dp_func;

    uint32_t i = 0, j = 0;
    uint32_t p_len = logger->fifobuflen/sizeof(DEV_DATA_T);
    DEV_DATA_T *dev_data = logger->fifobuf;
    SGDEV_T *sgdev = NULL;
    SGDEV_DATA_T **Gdata = NULL;
    uint16_t index = 0, data_id = 0;
    uint8_t clientID = 0;
    uint32_t cmdnum = 0, para_id = 0, sendnum = 0;
    int32_t ret = 0, data_num = 0;
    uint16_t tmp_out_argc = 0;

    for (i = 0; i < p_len; ++i)
    {
        sgdev = logger->map[dev_data[i].dev_code];
        data_id = dev_data[i].data_id;
        index = dev_data[i].index;
        clientID = dev_data[i].moduleID;

        if (sgdev == NULL || sgdev->gdata == NULL || sgdev->map == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_D, false, "sgdev == NULL\n");
            break;
        }
        if (index > sgdev->num)
        {
            EMS_LOG(LL_ERROR, MODULE_D, false, "index > sgdev->num\n");
            break;
        }

        Gdata = sgdev->gdata;
        data_num = sgdev->map[data_id];

        if (data_num > (sgdev->point_num -1))
        {
            EMS_LOG(LL_DEBUG, MODULE_D, false, "data_id = %d, data_num = %d, sgdev->point_num = %d ,sgdev->map[sgdev->point_num - 1] = %d ", data_id, data_num, sgdev->point_num, sgdev->map[sgdev->point_num - 1]);
            break;
        }

        //备份旧数据
        DATA_U old_data = Gdata[data_num][index-1].stValueInfo.data;
        Gdata[data_num][index-1].stValueInfo = dev_data[i].value;

//         if (old_data.s32 != dev_data[i].value.data.s32)
        {
            //发送到输出模块
            OutData(logger, dev_data[i].dev_code, index, data_id, clientID, dev_data[i].data_type, dev_data[i].value.data, dev_data[i].cmd);
        }

        for (j = 0; j < MAX_SIGN; ++j)
        {
            cmdnum = sgdev->point_attr[data_num].sscript_sign[j].func_sign;
            para_id = sgdev->point_attr[data_num].sscript_sign[j].paras_id;

            if (sgdev->point_attr[data_num].sscript_sign[j].untrip)
            {
                printf("%s dev_code:%d dataName:%d untrip.\n", __func__, dev_data[i].dev_code, data_id);
                continue;
            }

            if ((cmdnum < DP_FUNC_MAX_NUM_D)&&(cmdnum > 0))
            {
                //处理信号入列,一起执行：
                //执行时候做标记，上一次已经执行过的，不再连续执行，
                //但是隔了其他处理函数的，还是要重复处理
                //if (cmd_rev != cmd)//连续函数只执行一次
                {
                    sendnum = cmdnum -1;
                    GetOutparamValue(logger, &(dp_func[sendnum].paras[para_id - 1].outputpara));
                    tmp_out_argc = dp_func[sendnum].paras[para_id - 1].outputpara.out_argc;
                    FUNC_OUTPARA_T *tmp_outputpara = (FUNC_OUTPARA_T *)calloc(1, sizeof(FUNC_OUTPARA_T));
                    if (tmp_outputpara == NULL)
                    {
                        EMS_LOG(LL_ERROR, MODULE_D, false, "malloc tmp_outputpara error\n");
                        exit(EXIT_FAILURE);
                    }
                    if (tmp_out_argc > 0)
                    {
                        tmp_outputpara->outpara = (FUNC_PARA_T *)calloc(tmp_out_argc, sizeof(FUNC_PARA_T));
                        if (tmp_outputpara->outpara == NULL )
                        {
                            EMS_LOG(LL_ERROR, MODULE_D, false, "malloc tmp_outputpara->outpara error\n");
                            exit(EXIT_FAILURE);
                        }

                        memcpy(tmp_outputpara->outpara, dp_func[sendnum].paras[para_id - 1].outputpara.outpara, tmp_out_argc*sizeof(FUNC_PARA_T));
                    }
                    tmp_outputpara->out_argc = 0;
                    ret = (dp_func[sendnum].func)(&(dp_func[sendnum].paras[para_id - 1].inputpara),
                                                  tmp_outputpara,
                                                  &(dev_data[i]),
                                                  &old_data
                                                 );//数据处理
                    if (ret > -1)
                    {
                        //处理成功发送到缓冲区
                        uint16_t oindex = 0, func_dataid = 0, fucn_dev_code = 0, out_argc = 0, clientid = 0, k = 0;
                        int16_t func_index = -1;
                        //out_argc = dp_func[sendnum].paras[para_id - 1].outputpara.out_argc;
                        out_argc = tmp_outputpara->out_argc;
                        for (k = 0; k < out_argc; k++)
                        {
                            func_index = tmp_outputpara->outpara[k].index;
                            fucn_dev_code = tmp_outputpara->outpara[k].dev_code;
                            func_dataid = tmp_outputpara->outpara[k].data_id;
                            oindex = func_index == -1 ? index : func_index;

                            //发送到输出模块
                            if (fucn_dev_code == CEMS_DEV_CODE)
                            {
                                clientid = MODULE_C;//1;MODULE_C
                            }
                            else
                            {
                                clientid = MODULE_T;//2;
                            }

                            OutData(logger, fucn_dev_code, oindex, func_dataid, clientid,
                                    tmp_outputpara->outpara[k].dataType, tmp_outputpara->outpara[k].data, dev_data[i].cmd);

                            SGDEV_T *sgdev = logger->map[fucn_dev_code];
                            if (sgdev != NULL)
                                sgdev->gdata[sgdev->map[func_dataid]][oindex-1].stValueInfo.data = tmp_outputpara->outpara[k].data;
                        }
                    }
                    HCFREE(tmp_outputpara->outpara);
                    HCFREE(tmp_outputpara);
                }
            }
        }
    }
    memset(logger->fifobuf, 0, sizeof(DEV_DATA_T)*4096);
    logger->fifobuflen = 0;
//     DpSend(logger);
//     memset(logger->outbuf, 0, DATAOUT_MAX_NUM * sizeof(OUTDATA_T));

    return 0;
}

//2023/2/6
int32_t Process_OutData(LOGGER_T *logger, void *data, int32_t n)
{
    uint16_t i = 0;
    int32_t out_argc = 0;
    uint16_t oindex = 0;
    uint16_t func_dataid = 0;
    uint16_t fucn_dev_code = 0;
    uint16_t clientid = 0;
    int16_t func_index = -1;
    uint16_t index = 0;

    FUNC_OUTPARA_T *pout = (FUNC_OUTPARA_T *)data;
    out_argc = n;

    //lock
    pthread_mutex_lock (&(logger->fifo_rwlock));
    for (i = 0; i < out_argc; i++)
    {
        func_index = pout->outpara[i].index;
        fucn_dev_code = pout->outpara[i].dev_code;
        func_dataid = pout->outpara[i].data_id;
        oindex = func_index == -1 ? index : func_index;

        //发送到输出模块
        if (fucn_dev_code == CEMS_DEV_CODE)
        {
            clientid = MODULE_C;//1;MODULE_C
        }
        else
        {
            clientid = MODULE_T;//2;
        }

        OutData(logger, fucn_dev_code, oindex, func_dataid, clientid, pout->outpara[i].dataType, pout->outpara[i].data, 0x03);
        //todo
        SGDEV_T *sgdev = logger->map[fucn_dev_code];
        sgdev->gdata[sgdev->map[func_dataid]][oindex-1].stValueInfo.data = pout->outpara[i].data;
        sgdev->gdata[sgdev->map[func_dataid]][oindex-1].stValueInfo.ucDataType = pout->outpara[i].dataType;
    }
    DpSend(logger);
    memset(logger->outbuf, 0, DATAOUT_MAX_NUM * sizeof(OUTDATA_T));

    //unlock
    pthread_mutex_unlock (&(logger->fifo_rwlock));

    return 0;
}

static void *DataThread(void *arg)
{
    LOGGER_T *logger =(LOGGER_T *)arg;

    DEV_DATA_T *data;
    int32_t dwDataNum = 0, i = 0, j = 0;

    prctl(PR_SET_NAME, "PROCESS_DATA_THREAD");
    while (!logger->dataThreadIsExit)
    {
        if (Q_EMPTY(cmdqInQ) && (!Q_EMPTY(dataInQ)))
        {
            Q_WAIT(dataInQ);
            dwDataNum = Q_NUMS(dataInQ);//计算队列中元素个数，一次性读取全部
            if (dwDataNum > 0)
            {
                data = (DEV_DATA_T *)calloc(dwDataNum, sizeof(DEV_DATA_T));
                if (data == NULL)
                {
                    continue;
                }

                Q_OUT_N(dataInQ, data, dwDataNum);

                pthread_mutex_lock (&(logger->fifo_rwlock));

                int32_t dwFifoDataNum = 0;
                for (i = 0; i < dwDataNum; i++)
                {
                    int32_t dwValueNum = 0;
                    RECORD_KEY_T stKey, **ppstValue = NULL;
                    DEV_DATA_T *pTmp = &data[i];

                    stKey.devCode = data[i].dev_code;
                    stKey.devIndex = data[i].index;
                    stKey.dataId = data[i].data_id;

                    ppstValue = S2NPoint_GetValue(&stKey, &dwValueNum);
                    for (j = 0; j < dwValueNum; j++)
                    {
                        pTmp->dev_code = ppstValue[j]->devCode;
                        pTmp->index = ppstValue[j]->devIndex;
                        pTmp->data_id = ppstValue[j]->dataId;

                        memcpy(&logger->fifobuf[dwFifoDataNum], pTmp, sizeof(DEV_DATA_T));
                        ++dwFifoDataNum;
                    }
                }

                logger->fifobuflen = dwFifoDataNum * sizeof(DEV_DATA_T);
                pthread_mutex_unlock (&(logger->fifo_rwlock));
                HCFREE(data);

                sem_post(&(logger->dp_sem));
            }

        }
        else
        {
            sleep(1);
            continue;
        }
    }

    printf("%s PROCESS_DATA_THREAD exit.\n", __func__);
    return NULL;
}

static void *CmdThread(void *arg)
{
    LOGGER_T *logger =(LOGGER_T *)arg;

    DEV_DATA_T *datacmd;
    uint32_t cmd_len = 0;
    uint32_t num = 0, i = 0;

    prctl(PR_SET_NAME, "PROCESS_CMD_THREAD");
    while (!logger->cmdThreadIsExit)
    {
        Q_WAIT(cmdqInQ);
        num = Q_NUMS(cmdqInQ);//计算队列中元素个数，一次性读取全部
        if (num > 0)
        {
            datacmd = (DEV_DATA_T *)malloc(sizeof(DEV_DATA_T) * num);
            if (datacmd == NULL)
            {
                continue;
            }
            memset((DEV_DATA_T *)datacmd, 0, sizeof(DEV_DATA_T) * num);
            Q_OUT_N(cmdqInQ, datacmd, num);
            cmd_len = num * sizeof(DEV_DATA_T);

            pthread_mutex_lock (&(logger->fifo_rwlock));
            for (i = 0; i < num; i++)
            {
                memcpy(&logger->fifobuf[i], &datacmd[i], sizeof(DEV_DATA_T));
            }
//             SDB_SetRegisterValue(datacmd, num);
            logger->fifobuflen = cmd_len;
            pthread_mutex_unlock (&(logger->fifo_rwlock));
            sem_post(&(logger->dp_sem));
            HCFREE(datacmd);
        }
    }
    printf("%s PROCESS_CMD_THREAD exit.\n", __func__);
    return NULL;
}

static void *ProcFunc(void *arg)
{
    LOGGER_T *logger =(LOGGER_T *)arg;

    prctl(PR_SET_NAME, "PROC_THREAD");
    while (!logger->procThreadIsExit)
    {
        sem_wait(&(logger->dp_sem));
        if (logger->isPauseProc)
        {
            continue;
        }

        pthread_mutex_lock (&(logger->fifo_rwlock));
        DataProcessFun(logger);
        pthread_mutex_unlock (&(logger->fifo_rwlock));
        DpFuncDone(logger, logger->dp_func, &(logger->dp_sign));
        DpSend(logger);
        memset(logger->outbuf, 0, DATAOUT_MAX_NUM * sizeof(OUTDATA_T));
    }

    return NULL;
}

int32_t createDPThread()
{
    int32_t res = OK;
    pthread_attr_t dp_thread_attr;

    res = pthread_attr_init(&dp_thread_attr);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "Attribute creation failed\n");
        exit(EXIT_FAILURE);
    }

    size_t stacksize = 512*1024;       //512KB 栈空间
    res = pthread_attr_setstacksize(&dp_thread_attr, stacksize);

    res = pthread_attr_setdetachstate(&dp_thread_attr, PTHREAD_CREATE_JOINABLE);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "Setting detached attribute failed\n");
        exit(EXIT_FAILURE);
    }

    res = pthread_create(&(logger.stimer.timer_thread), &dp_thread_attr, DpTimer, (void *)&logger); //定时扫描线程
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "thread DpTimer creation failed.\n");
        exit(EXIT_FAILURE);
    }

    res = pthread_create(&(logger.proc_thread), &dp_thread_attr, ProcFunc, (void *)&logger); //定时扫描线程
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "thread proc creation failed.\n");
        exit(EXIT_FAILURE);
    }

    (void)pthread_attr_destroy(&dp_thread_attr);

    return res;
}

int32_t stopDPThread()
{
    if (logger.stimer.timer_thread)
    {
        logger.stimer.isExit = TRUE;
        pthread_cancel(logger.stimer.timer_thread);
        pthread_join(logger.stimer.timer_thread, NULL);
        EMS_LOG(LL_WARNING, MODULE_D, FALSE, "logger.stimer.timer_thread join.\n");
    }

    if (logger.proc_thread)
    {
        logger.procThreadIsExit = TRUE;
        sem_post(&logger.dp_sem);
        pthread_join(logger.proc_thread, NULL);
        printf("logger.proc_thread join.\n");
    }

    return OK;
}

//启动定时扫描和数据处理线程
int32_t Processor_StartRecv()
{
    int32_t res = OK;
    pthread_attr_t dp_thread_attr;

    res = pthread_attr_init(&dp_thread_attr);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "Attribute creation failed\n");
        exit(EXIT_FAILURE);
    }

    size_t stacksize = 512*1024;       //512KB 栈空间
    res = pthread_attr_setstacksize(&dp_thread_attr, stacksize);

    res = pthread_attr_setdetachstate(&dp_thread_attr, PTHREAD_CREATE_JOINABLE);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "Setting detached attribute failed\n");
        exit(EXIT_FAILURE);
    }

    logger.dataThreadIsExit = FALSE;
    res = pthread_create(&logger.data_thread, &dp_thread_attr, DataThread, (void *)&logger);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "thread DataThread creation failed\n");
        exit(EXIT_FAILURE);
    }

    logger.cmdThreadIsExit = FALSE;
    res = pthread_create(&logger.cmd_thread, &dp_thread_attr, CmdThread, (void *)&logger);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, false, "thread CmdThread creation failed\n");
        exit(EXIT_FAILURE);
    }

    (void)pthread_attr_destroy(&dp_thread_attr);

    logger.isPauseProc = FALSE;

    return res;
}

int32_t Processor_StopRecv()
{
    if (logger.cmd_thread)
    {
        logger.cmdThreadIsExit = TRUE;
        Q_POST(cmdqInQ);
        pthread_join(logger.cmd_thread, NULL);
        EMS_LOG(LL_WARNING, MODULE_D, FALSE, "logger.cmd_thread join.\n");
    }

    if (logger.data_thread)
    {
        logger.dataThreadIsExit = TRUE;
        Q_POST(dataInQ);
        pthread_join(logger.data_thread, NULL);
        EMS_LOG(LL_WARNING, MODULE_D, FALSE, "logger.data_thread join.\n");
    }

    logger.isPauseProc = TRUE;
    return OK;
}

int32_t Processor_Start()
{
    int32_t ret = OK;

    InitDataProcessPara();

    Processor_StartRecv();

    createDPThread();

    //add by jin 2023/3/13
//     createCalThread();//系统参数总计算

//     /******NTP Server Init**********/
    NTP_server();
//     /****************/


    g_pDPHandle->eState = MODULE_STATE_RUNNING;

    return ret;
}

uintptr_t Processor_Create()
{
    if (g_pDPHandle != NULL)
    {
        return (uintptr_t)(&g_pDPHandle);
    }

    g_pDPHandle = calloc(1, sizeof(DP_HANDLE_T));
    g_pDPHandle->eState = MODULE_STATE_INIT;

    /* 初始化handle */
    InitHandle(&logger);

    MsgProc_Start();

    /* 热插拔事件监听 */
    HotPlug_StartListen();

    g_pDPHandle->eState = MODULE_STATE_READY;

    if (checkProcessorPrecondition() == TRUE)
    {
        printf("***969\n");
        Processor_Start();
    }

    return (uintptr_t)(&logger);
}

int32_t Processor_Destroy(uintptr_t handle)
{
    MsgProc_Stop();

    HotPlug_StopListen();

    Processor_StopRecv();

    stopDPThread();

    Processor_DestroyDevModel();

    ClearAllClock(&logger.stimer);

    ClearDpFunc(&logger);

    DidoDestroy();

    Persister_Stop(HIS_DATA);

    Persister_Stop(HIS_RECORD);

    Persister_UnInit();

    HCFREE(g_pDPHandle);

    printf("%s Done.\n", __func__);

    return 0;
}

int32_t Processor_Get(int32_t dwProperty, void **ppvRet, int32_t *pdwRetLen)
{
    int32_t ret = ERR;

    switch(dwProperty)
    {
        case DP_PROPERTY_GET_STATE:
        {
            *(int32_t*)ppvRet = g_pDPHandle->eState;
            break;
        }
        case DP_PROPERTY_GET_ALGO_PARAM:
        {
            ALOGR_T *pstAlogrParam = NULL;
            int32_t recordNum = 0;

            sysCfg_Load(CFG_TYPE_ALGOR, (void **)(&pstAlogrParam), &recordNum);    // 从数据库查找数据

            if (pstAlogrParam != NULL && recordNum != 0)
            {
                ALOGR_T *tmp = calloc(recordNum, sizeof(ALOGR_T));
                int32_t i = 0, dwEnableCount = 0;
                for (i = 0; i < recordNum; i++)
                {
                    if (pstAlogrParam[i].Enable)
                    {
                        memcpy(tmp + dwEnableCount, pstAlogrParam + i, sizeof(ALOGR_T));
                        dwEnableCount++;
                    }
                }

                *pdwRetLen = dwEnableCount * sizeof(ALOGR_T);
                *ppvRet = tmp;
            }

            sysCfg_Free(pstAlogrParam);
            break;
        }
        case DP_PROPERTY_GET_IO:
        {
            IO_PARAM_T *pstIOParam = NULL;
            int32_t recordNum = 0;

            sysCfg_Load(CFG_TYPE_IO, (void **)(&pstIOParam), &recordNum);    // 从数据库查找数据

            if (pstIOParam != NULL && recordNum != 0)
            {
                IO_PARAM_T *tmp = calloc(recordNum, sizeof(IO_PARAM_T));

                *pdwRetLen = recordNum * sizeof(IO_PARAM_T);
                memcpy(tmp, pstIOParam, recordNum * sizeof(IO_PARAM_T));
                *ppvRet = tmp;
            }

            sysCfg_Free(pstIOParam);
            break;
        }
        default:
            break;
    }

    return ret;
}

int32_t Processor_Register(MODULE_ID_E eModuleId, MODULE_OPERATOR_T *pOperate)
{
    logger.cus[eModuleId].pstOperate = pOperate;
    logger.cus[eModuleId].is_registered = TRUE;
    logger.cus[eModuleId].eModuleId = eModuleId;

    return OK;
}

int32_t Processor_InsertDpFunc(int32_t (*func)(void *in, void *out, DEV_DATA_T *data, DATA_U *old), char *name)
{
    int32_t ret = OK;

    ret = ret + InsertDpFunc(&logger, func, name);

    return ret;
}

int32_t Processor_InsertDpFuncNorth(int32_t (*func)(void *in, void *out, DEV_DATA_T *data, DATA_U *old), char *name, FUNC_INPARA_T *pin, FUNC_OUTPARA_T *pout)
{
    int32_t ret = OK;

    ret = ret + InsertDpFuncNorth(&logger, func, name, pin, pout);

    return ret;
}

int32_t Processor_NotifyClient(int32_t dwType, void *data, int32_t n)
{
    int32_t ret = OK;
    int32_t i = 0;

    for (i = 0; i < MODULE_MAX; i++)
    {
        MODULE_OPERATOR_T *pOperate = logger.cus[i].pstOperate;
        if (pOperate != NULL)
        {
            ret = pOperate->set(dwType, data, n);
        }
    }

    return ret;
}

int32_t Processor_SendMsg(int32_t msgType, void *pvData, uint32_t uiDataLen)
{
    int32_t ret = OK;
    SG_MSG_T stMsg = {0, 0, 0, NULL};

    if (pvData == NULL || uiDataLen == 0)
    {
        return ERROR_T(uiDataLen);
    }

    stMsg.udwMsgType = msgType;
    stMsg.udwlen = uiDataLen;
    stMsg.pData = calloc(uiDataLen, sizeof(uint8_t));
    memcpy(stMsg.pData, pvData, sizeof(uint8_t) * uiDataLen);

    IMC_Send(&stMsg);

    return ret;
}

int32_t Processor_GetPointValue(INOUT DEV_DATA_T *pvData, IN int32_t num)
{
    int32_t ret = OK, i = 0;

    do
    {
        if (pvData == NULL || num == 0)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        DEV_DATA_T *pTmp = pvData;
        for (i = 0; i < num && pTmp != NULL; i++)
        {
            int16_t devIndex = pTmp->index;
            uint16_t devCode = pTmp->dev_code;
            uint16_t dataId = pTmp->data_id;

            SGDEV_T *sgdev = logger.map[devCode];

            if (sgdev != NULL)
            {
                pTmp->value.data = sgdev->gdata[sgdev->map[dataId]][devIndex-1].stValueInfo.data;
                pTmp->value.ucDataType = sgdev->gdata[sgdev->map[dataId]][devIndex-1].stValueInfo.ucDataType;
            }

            pTmp++;
        }
    }while(0);

    return ret;
}

DATA_U Process_GetData(uint16_t devcode, uint16_t index, uint16_t data_id)//devcode index data_id data_u
{
    uint16_t oindex = 0;
    uint16_t func_dataid = 0;
    uint16_t fucn_dev_code = 0;
    uint16_t clientid = 0;
    int16_t func_index = -1;
    DATA_U getData;

    func_index = index;
    fucn_dev_code = devcode;
    func_dataid = data_id;
    oindex = func_index == -1 ? index : func_index;

    //发送到输出模块
    if (fucn_dev_code == CEMS_DEV_CODE)
    {
        clientid = MODULE_C;//1;MODULE_C
    }
    else
    {
        clientid = MODULE_T;//2;
    }
    //todo
    SGDEV_T *sgdev = logger.map[fucn_dev_code];
    getData = sgdev->gdata[sgdev->map[func_dataid]][oindex-1].stValueInfo.data;

    return getData;
}
