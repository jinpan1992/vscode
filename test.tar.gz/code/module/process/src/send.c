#include <stdlib.h>
#include "send.h"
#include "processor.h"
#include "logUtil.h"
#include "commonTest.h"
#include "config.h"
#include "mapping.h"

void SendBufToQueue(uint16_t moduleflag, DEV_DATA_T* buf, uint16_t buf_num)
{
    if (moduleflag == MODULE_C)
    {
        if (!Q_FULL(dataOutQ))
        {
            Q_INSERT_WAIT_N(dataOutQ, buf, buf_num);
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_D, FALSE, "dataOutQ is full!\n");
        }
    }
    else if (moduleflag == MODULE_T)
    {
        if (!Q_FULL(cmdqOutQ))
        {
            Q_INSERT_WAIT_N(cmdqOutQ, buf, buf_num);
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_D, FALSE, "cmdqOutQ is full!\n");
        }
    }
}

void OutData(LOGGER_T *logger, uint16_t outdevcode, uint8_t outindex, uint16_t outid, uint8_t outclientID, uint8_t dataType, DATA_U data, int32_t cmd)
// void OutData(LOGGER_T *logger, DEV_DATA_T *pDevData)
{
    if (logger->obufcnt < DATAOUT_MAX_NUM)
    {
        logger->outbuf[logger->obufcnt].dev_code = outdevcode;
        logger->outbuf[logger->obufcnt].index = outindex;
        logger->outbuf[logger->obufcnt].data_id = outid;
        logger->outbuf[logger->obufcnt].clientID = outclientID;
        logger->outbuf[logger->obufcnt].value.data = data;
        logger->outbuf[logger->obufcnt].value.ucDataType = dataType;
        logger->outbuf[logger->obufcnt].cmd = cmd;
        logger->obufcnt += 1;
    }
    else
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "err! outid  ！\n");
    }

}

int DpSend(LOGGER_T *logger)
{
    DEV_DATA_T send_buf[4096];
    uint16_t outid_len = logger->obufcnt;
    uint32_t i = 0, same_count = 0, diff_count = 0, diff_flag = 0, start_ptr = 0;

    if (outid_len > 0)
    {
        for (i = 0; i < outid_len; ++i)
        {
            uint16_t dev_code = logger->outbuf[i].dev_code;     //设备类型编码
            uint16_t index = logger->outbuf[i].index;           //设备索引
            uint16_t data_id = logger->outbuf[i].data_id;       //测点编码
            uint8_t clientID = logger->outbuf[i].clientID;

            SGDEV_T *sgdev = logger->map[dev_code];
            uint32_t point_attr_ptr = sgdev->map[data_id];

            if (clientID == MODULE_T)
            {
                RECORD_KEY_T stKey, *pstValue = NULL;
                stKey.devCode = dev_code;
                stKey.devIndex = index;
                stKey.dataId = data_id;
                pstValue = N2SPoint_GetValue(&stKey);
                dev_code = pstValue->devCode;
                index = pstValue->devIndex;
                data_id = pstValue->dataId;
            }

            send_buf[i].dev_code = dev_code;
            send_buf[i].data_id = data_id;
            send_buf[i].index = index;
            send_buf[i].moduleID = clientID;
            send_buf[i].data_type = logger->outbuf[i].value.ucDataType; //sgdev->gdata_info[point_attr_ptr].data_type;
            send_buf[i].wr_type = sgdev->gdata_info[point_attr_ptr].wr_type;
//             send_buf[i].value.data = sgdev->gdata[point_attr_ptr][index-1].data;
            send_buf[i].value.data = logger->outbuf[i].value.data;
            send_buf[i].cmd = logger->outbuf[i].cmd;

            if (dev_code == CEMS_DEV_CODE)
            {
                SDB_SetRegisterValue(&send_buf[i], 1);
            }
            EMS_LOG(LL_DEBUG, MODULE_D, FALSE, "==DpSend==dev_code=%d,data_id=%d,index=%d,i=%d,send_buf[i].data.s32=%d \n",
                    dev_code,data_id,index,i,send_buf[i].value.data.s32);
        }

        if (outid_len == 1)
        {
            SendBufToQueue(send_buf[0].moduleID, send_buf, outid_len);
        }
        else
        {
            for (i = 0; i < outid_len; i++)
            {
                if (((i+1)< outid_len) && (send_buf[i].moduleID == send_buf[i+1].moduleID))
                {
                    same_count ++;
                }
                else if ((i+1)< outid_len)
                {
                    diff_count ++;
                }
                else if (((i+1)==outid_len) && (send_buf[i].moduleID != send_buf[i-1].moduleID))  //最后一个
                {
                    diff_count ++;
                }

                if ((diff_count == 0)&&same_count == (outid_len-1) && (diff_flag == 0))
                {
                    SendBufToQueue(send_buf[0].moduleID, send_buf, outid_len);
                    same_count = 0;
                }
                else if ((diff_count > 0) || (diff_flag >0))
                {
                    if ((diff_flag == 0)&&(same_count > 0))
                    {
                        SendBufToQueue(send_buf[i].moduleID, send_buf+start_ptr, same_count+1);
                    }
                    else
                    {
                        SendBufToQueue(send_buf[i].moduleID, send_buf+start_ptr, 1);
                    }
                    start_ptr = i+1;
                    diff_count = 0;
                    same_count = 0;
                    diff_flag ++;
                }
            }
        }
        logger->obufcnt = 0;//处理完成
    }
    return 0;
}
