#include <sys/prctl.h>
#include <stddef.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "MsgProc.h"
#include "logUtil.h"
#include "file_operate.h"
#include "persist.h"
#include "processor.h"
#include "ntp_client.h"
#include "hotPlug.h"

Q_DEFINE(SG_MSG_T, msgQ, Queue_NUM);

typedef struct{
    uintptr_t ipcHandle;
    pthread_t msgthread;
    BOOL msgThreadIsExit;
}MSGPROC_HANDLE_T;

MSGPROC_HANDLE_T *g_pMsgProcHandle;

static int32_t procUpgrade(SG_MSG_T *pstMsg)
{
    int32_t ret = OK;

    int sockfd;
    sockfd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sockfd < 0)
    {
        ret = errno;
        printf("func socket() err:  %d\n", ret);
        return ret;
    }

    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(5800);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    ret = connect(sockfd, (struct sockaddr*) (&servaddr), sizeof(servaddr));
    if (ret < 0)
    {
        printf("%s connect fail.err:%d, ret:%d. \n", __func__, errno, ret);
        if (ret == -1 && errno == ETIMEDOUT)
        {
            close(sockfd);
            return ret;
        } else
        {
            printf("func connect() err:  %d\n", ret);
        }
    }

    int32_t datalen = pstMsg->udwlen - 1;
    uint8_t *netdata = calloc(datalen + 4, sizeof(uint8_t));
    if (netdata == NULL)
    {
        return ret;
    }

    int32_t netlen = htonl(datalen);
    memcpy(netdata, &netlen, 4);
    memcpy(netdata + 4, pstMsg->pData + 1, datalen);

    printf("%s:%s \n", __func__, netdata + 4);
    ret = write(sockfd, netdata, sizeof(uint8_t) * (datalen + 4));
    if (ret > 0)
    {
        ret = OK;
    }

    close(sockfd);

    HCFREE(netdata);

    return ret;
}
static BOOL checkSysMaintain(uint32_t sysMaintainType)
{
    BOOL ret = FALSE;

    switch (sysMaintainType)
    {
        case SYS_MAINTAIN_RESTORE_FACTORY_DATA:
            //没有南向设备
        {
            //TODO
        }
            break;
        case SYS_MAINTAIN_REBOOT:
        {
            //TODO
            break;
        }
        case SYS_MAINTAIN_UPGRADE:
            //不能有实时控制,控制模式是手动（定时充放电也是手动），需要提示；如果是自动，不允许操作
        {
            ret = TRUE;
        }
            break;
        default:
            ret = TRUE;
            break;
    }
    return ret;
}

static BOOL procSysMaintain(SG_MSG_T *pstMsg)
{
    BOOL ret = FALSE;

    if (pstMsg->pData == NULL)
    {
        printf("%s no message data.\n", __func__);
        return ret;
    }

    switch (*pstMsg->pData)
    {
        case SYS_MAINTAIN_RESTORE_FACTORY_DATA:
            //删除配置文件
        {
            EmptyDir("./cfg");
            EmptyDir("./conf");
            system("reboot");
        }
            break;
        case SYS_MAINTAIN_REBOOT:
        {
            system("reboot");
        }
            break;
        case SYS_MAINTAIN_UPGRADE:
        {
            procUpgrade(pstMsg);
        }
            break;
        case SYS_MAINTAIN_DELETE_HISDATA:
        {
            printf("%s SYS_MAINTAIN_DELETE_HISDATA.\n", __func__);
            Persister_Stop(HIS_DATA);
            Persister_DeleteFile(HIS_DATA);
            Persister_Run(HIS_DATA);
        }
            break;
        case SYS_MAINTAIN_DELETE_RUNRECORD:
        {
            printf("%s SYS_MAINTAIN_DELETE_RUNRECORD.\n", __func__);
            Persister_Stop(HIS_RECORD);
            Persister_DeleteFile(HIS_RECORD);
            Persister_Run(HIS_RECORD);
        }
            break;
        default:
            break;
    }

    IPC_SendMsg(g_pMsgProcHandle->ipcHandle, IPC_CLIENT_WEB, "done", strlen("done"));

    return ret;
}

static int32_t recvMsgFromInternal(uintptr_t user, void *pData)
{
    int32_t ret = OK;
    SG_MSG_T stDestMsg = *(SG_MSG_T *)pData;
    int32_t eType = stDestMsg.udwMsgType;
    if (MODULE_ID(eType) != MODULE_D && MODULE_ID(eType) != MODULE_SDB && MODULE_ID(eType) != MODULE_IPC)
    {
        return ret;
    }

    printf("processor recv inter msg:0x%x. \n", eType);

    switch(eType)
    {
        case MSG_IPC_RT_FAULT_WARNING:
        case MSG_SDB_UPDATED:
        case MSG_PROCESSOR_HOT_PLUG:
        {
            Q_INSERT_WAIT(msgQ, stDestMsg);
            break;
        }
        default:
            break;
    }

    return ret;
}

static int32_t recvMsgFromIPC(enum ipc_client_type eType, void *pvData, uint32_t len)
{
    int32_t ret = OK;

    if (eType == IPC_CLIENT_WEB)
    {
        SG_MSG_T stDestMsg = {0, 0, 0, NULL};
        SG_MSG_T *pstWebMsg = (SG_MSG_T *)pvData;

        memcpy(&stDestMsg, pstWebMsg, sizeof(SG_MSG_T));

        printf("%s[web] type:0x%x udwlen:%d pData:%p ", __func__, pstWebMsg->udwMsgType, pstWebMsg->udwlen, pstWebMsg->pData);

        if (pstWebMsg->udwlen > 0)
        {
            stDestMsg.pData = calloc(pstWebMsg->udwlen, sizeof(uint8_t));
            int32_t offset = offsetof(SG_MSG_T, pData);
            memcpy(stDestMsg.pData, (uint8_t*)pstWebMsg + offset, sizeof(uint8_t) * pstWebMsg->udwlen);

            printf("pData:%p v:%d.", stDestMsg.pData, *(stDestMsg.pData));
        }

        printf("\n");

        if (pstWebMsg->udwMsgType == MSG_IPC_SYSTEM_MAINTAIN)
        {
            if (checkSysMaintain(*stDestMsg.pData) == FALSE)
            {
                ret = ERROR_T(ERR_DEFAULT_OPERATOR_NOT_ALLOW);
            }
        }

        if (ret == OK)
            Q_INSERT_WAIT(msgQ, stDestMsg);
    }
    else
    {
        printf("recv IPC DEBUG msg. \n");
    }

    return ret;
}

static void *msgProc(void *arg)
{
    MSGPROC_HANDLE_T *pHandle =(MSGPROC_HANDLE_T *)arg;

    while (!pHandle->msgThreadIsExit)
    {
        SG_MSG_T stMsg = {0, 0, 0, NULL};
        Q_OUT_WAIT(msgQ, stMsg);
        {
            printf("%s type:0x%x pData:%p\n", __func__, stMsg.udwMsgType, stMsg.pData);
            switch (stMsg.udwMsgType)
            {
                case MSG_IPC_SYSTEM_MAINTAIN:
                {
                    printf("%s pData:%p v:%d\n", __func__, stMsg.pData, *(stMsg.pData));
                    procSysMaintain(&stMsg);
                    HCFREE(stMsg.pData);
                    break;
                }
                case MSG_IPC_SERIAL_SETTING:
                case MSG_IPC_DEV_UPDATE:
                {
                    //TODO
                    int32_t state = 0, len = 0;
                    Processor_Get(DP_PROPERTY_GET_STATE, (void**)&state, &len);
                    if (state == MODULE_STATE_RUNNING)
                    {
                        Processor_StopRecv();
                        Processor_DestroyDevModel();
                        Persister_UnInit();
                    }

                    IMC_Send(&stMsg);
                    break;
                }
                case MSG_SDB_UPDATED:
                {
                    //TODO
                    int32_t state = 0, len = 0;
                    Processor_Get(DP_PROPERTY_GET_STATE, (void**)&state, &len);
                    if (state == MODULE_STATE_RUNNING)
                    {
                        Processor_CreateDevModel();
                        Processor_StartRecv();

                        if (logger.hisDstoreperiod != 0 && DirExist(logger.storePath))
                        {
                            Persister_Init(logger.storePath, sizeof(logger.storePath));

                            PERSIST_CONFIG_T stConfig;
                            stConfig.eHisType = HIS_DATA;
                            stConfig.uiWriteIntervalSec = logger.hisDstoreperiod;
                            stConfig.uiExpireTimeMin = logger.hisDExpiredMin;
                            Persister_Set(&stConfig);
                            Persister_Run(HIS_DATA);


                            stConfig.eHisType = HIS_RECORD;
                            stConfig.uiWriteIntervalSec = logger.hisDstoreperiod;
                            stConfig.uiExpireTimeMin = logger.hisDExpiredMin;
                            Persister_Set(&stConfig);
                            Persister_Run(HIS_RECORD);
                        }
                    }
                    else if (state < MODULE_STATE_RUNNING)
                    {
                        Processor_Start();
                    }

                    Processor_NotifyClient(MSG_SDB_UPDATED, NULL, 0);

                    break;
                }
                case MSG_IPC_CALIBRATION_INFO: // NTP的web参数入口
                {
                    TIME_CFG_T *pstTimeCfg = NULL;
                    int32_t recordNum = 0;

                    sysCfg_Load(CFG_TYPE_TIME_CFG, (void **)(&pstTimeCfg), &recordNum);

                    if (pstTimeCfg != NULL)
                    {
                        WEB_CONFIG_NTP ntpConfigTmp;
                        ntpConfigTmp.syn_time_mode = pstTimeCfg->SynTimeMode;
                        strcpy(ntpConfigTmp.ntp_service,pstTimeCfg->NTPAddr);
                        ntpConfigTmp.ntp_port = pstTimeCfg->NTPPort;

                        recNtpParameters(&ntpConfigTmp);
                    }

                    logger.timeSyncMode = pstTimeCfg->SynTimeMode;
                    sysCfg_Free(pstTimeCfg);

                    break;
                }
                case MSG_IPC_TRANSMIT_PROTOCOL_SETTING:   // TODO web的数据入口
                {
                    NORTH_PARAM_T *northParam = NULL;
                    int32_t recordNum = 0;

                    sysCfg_Load(CFG_TYPE_NORTH_PARAM, (void **)(&northParam), &recordNum);    // 从数据库查找数据

                    if (northParam != NULL)
                    {
                        SG_MSG_T stMsgMqtt;
                        stMsgMqtt.udwMsgType = MSG_IPC_TRANSMIT_PROTOCOL_SETTING;
                        stMsgMqtt.pData = (uint8_t*)northParam;
                        IMC_Send(&stMsgMqtt);   // 触发mqtt接收web参数的地方:transmitMsgCB
                    }

                    sysCfg_Free(northParam);
                    break;
                }
                case MSG_IPC_ALGO_PARAM_UPDATE:
                {
                    ALOGR_T *tmp = NULL;
                    int32_t dwRetLen = 0;
                    Processor_Get(DP_PROPERTY_GET_ALGO_PARAM, (void**)&tmp, &dwRetLen);
                    Processor_NotifyClient(MSG_IPC_ALGO_PARAM_UPDATE, tmp, dwRetLen);

                    HCFREE(tmp);
                    break;
                }
                case MSG_IPC_PROTECT_STORAGE_PARAM_UPDATE:
                {
                    PROTECTSTORAGE_T *pstProtectStorageParam = NULL;
                    int32_t recordNum = 0;

                    sysCfg_Load(CFG_TYPE_PROTECT_STORAGE, (void **)(&pstProtectStorageParam), &recordNum);    // 从数据库查找数据

                    if (pstProtectStorageParam != NULL)
                    {
                        Processor_NotifyClient(MSG_IPC_PROTECT_STORAGE_PARAM_UPDATE, pstProtectStorageParam, recordNum * sizeof(PROTECTSTORAGE_T));
                    }

                    sysCfg_Free(pstProtectStorageParam);
                    break;
                }
                case MSG_IPC_PROTECT_NET_PARAM_UPDATE:
                {
                    PROTECTNET_T *pstProtectNetParam = NULL;
                    int32_t recordNum = 0;

                    sysCfg_Load(CFG_TYPE_PROTECT_NET, (void **)(&pstProtectNetParam), &recordNum);    // 从数据库查找数据

                    if (pstProtectNetParam != NULL)
                    {
                        Processor_NotifyClient(MSG_IPC_PROTECT_NET_PARAM_UPDATE, pstProtectNetParam, recordNum * sizeof(PROTECTNET_T));
                    }

                    sysCfg_Free(pstProtectNetParam);
                    break;
                }
                case MSG_IPC_RUN_PARAM_UPDATE:
                {
                    RUN_PARAM_T *pstRunParam = NULL;
                    int32_t recordNum = 0;

                    sysCfg_Load(CFG_TYPE_RUN_CTRL, (void **)(&pstRunParam), &recordNum);    // 从数据库查找数据

                    if (pstRunParam != NULL)
                    {
                        Processor_NotifyClient(MSG_IPC_RUN_PARAM_UPDATE, pstRunParam, recordNum * sizeof(RUN_PARAM_T));
                    }

                    sysCfg_Free(pstRunParam);
                    break;
                }
                case MSG_IPC_DEV_MAPPING:
                {
                    int32_t state = 0, len = 0;
                    Processor_Get(DP_PROPERTY_GET_STATE, (void**)&state, &len);
                    if (state == MODULE_STATE_RUNNING)
                    {
                        Processor_StopRecv();
                        Processor_DestroyDevModel();

                        Persister_Stop(HIS_DATA);
                        Persister_DeleteFile(HIS_DATA);
                        Persister_UnInit();


                        Processor_CreateDevModel();
                        Processor_StartRecv();

                        if (logger.hisDstoreperiod != 0 && DirExist(logger.storePath))
                        {
                            Persister_Init(logger.storePath, sizeof(logger.storePath));

                            PERSIST_CONFIG_T stConfig;
                            stConfig.eHisType = HIS_DATA;
                            stConfig.uiWriteIntervalSec = logger.hisDstoreperiod;
                            stConfig.uiExpireTimeMin = logger.hisDExpiredMin;
                            Persister_Set(&stConfig);
                            Persister_Run(HIS_DATA);

                            prctl(PR_SET_NAME, "PROCESS_MSG_THREAD");
                            stConfig.eHisType = HIS_RECORD;
                            stConfig.uiWriteIntervalSec = logger.hisDstoreperiod;
                            stConfig.uiExpireTimeMin = logger.hisDExpiredMin;
                            Persister_Set(&stConfig);
                            Persister_Run(HIS_RECORD);
                        }
                    }
                    else if (state < MODULE_STATE_RUNNING)
                    {
                        Processor_Start();
                    }
                    IMC_Send(&stMsg);

                    break;
                }
                case MSG_IPC_DEV_CTRL:
                {
                    IMC_Send(&stMsg);
                    break;
                }
                case MSG_IPC_RT_FAULT_WARNING:
                {
                    uint32_t totalLen = offsetof(SG_MSG_T, pData) + stMsg.udwlen;
                    SG_MSG_T *pMsg = calloc(totalLen, sizeof(uint8_t));
                    pMsg->udwMsgType = stMsg.udwMsgType;
                    pMsg->udwlen = stMsg.udwlen;

                    uint8_t *p = (uint8_t*)pMsg + offsetof(SG_MSG_T, pData);
                    memcpy(p, stMsg.pData, sizeof(uint8_t) * stMsg.udwlen);

                    IPC_SendMsg(g_pMsgProcHandle->ipcHandle, IPC_CLIENT_WEB, pMsg, totalLen);

                    HCFREE(stMsg.pData);
                    HCFREE(pMsg);
                    break;
                }
                case MSG_IPC_IO:
                {
                    IO_PARAM_T *tmp = NULL;
                    int32_t dwRetLen = 0;

                    Processor_Get(DP_PROPERTY_GET_IO, (void**)&tmp, &dwRetLen);
                    Processor_NotifyClient(MSG_IPC_IO, tmp, dwRetLen);

                    HCFREE(tmp);
                    break;
                }
                case MSG_PROCESSOR_HOT_PLUG:
                {
                    int32_t ret = OK;
                    HOT_CHANGE_INFO_T *tmp = (HOT_CHANGE_INFO_T *)stMsg.pData;
                    if (tmp->eChangeType == HOT_PLUG_ADD)
                    {
                        memset(logger.storePath, 0, sizeof(logger.storePath));
                        sprintf(logger.storePath, "%s/record", tmp->deviceFullName);
                        logger.hisDExpiredMin = 30 * 24 * 60;
                    }

                    if (tmp->eChangeType == HOT_PLUG_REMOVE)
                    {
                        memset(logger.storePath, 0, sizeof(logger.storePath));
                        strncpy(logger.storePath, "/home/SGComm/record", sizeof(logger.storePath));
                        logger.hisDExpiredMin = 24 * 60;
                    }

                    if (!DirExist(logger.storePath))
                        mkdir(logger.storePath, 0777);

                    ret = unlink("/home/record");
                    ret = symlink(logger.storePath, "/home/record");
                    printf("symlink ret:%d errno:%d (L%d)\n", ret, errno, __LINE__);

                    Persister_UnInit();

                    if (logger.hisDstoreperiod != 0 && DirExist(logger.storePath))
                    {
                        Persister_Init(logger.storePath, sizeof(logger.storePath));

                        PERSIST_CONFIG_T stConfig;
                        stConfig.eHisType = HIS_DATA;
                        stConfig.uiWriteIntervalSec = logger.hisDstoreperiod;
                        stConfig.uiExpireTimeMin = logger.hisDExpiredMin;
                        Persister_Set(&stConfig);
                        Persister_Run(HIS_DATA);

                        stConfig.eHisType = HIS_RECORD;
                        stConfig.uiWriteIntervalSec = logger.hisDstoreperiod;
                        stConfig.uiExpireTimeMin = logger.hisDExpiredMin;
                        Persister_Set(&stConfig);
                        Persister_Run(HIS_RECORD);
                    }

                    break;
                }
                default:
                    break;
            }

        }

    }

    printf("%s PROCESS_MSG_THREAD exit.\n", __func__);

    return NULL;
}

int32_t MsgProc_Start()
{
    int32_t ret = OK;

    Q_INIT(msgQ, Queue_NUM);

    g_pMsgProcHandle = malloc(sizeof(MSGPROC_HANDLE_T));
    memset(g_pMsgProcHandle, 0, sizeof(MSGPROC_HANDLE_T));

    //注册内部模块间的消息接受函数
    IMC_RegisterCB((uintptr_t)(g_pMsgProcHandle), recvMsgFromInternal);

    //启动IPC 消息
    g_pMsgProcHandle->ipcHandle = IPC_Init(recvMsgFromIPC);
    IPC_Start(g_pMsgProcHandle->ipcHandle);

    //开启消息处理线程
    pthread_attr_t dp_thread_attr;
    ret = pthread_attr_init(&dp_thread_attr);
    if (ret != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, FALSE, "Attribute creation failed\n");
        return ERR;
    }

    size_t stacksize = 512 * 1024;       //512KB 栈空间
    ret = pthread_attr_setstacksize(&dp_thread_attr, stacksize);

    ret = pthread_attr_setdetachstate(&dp_thread_attr, PTHREAD_CREATE_JOINABLE);
    if (ret != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, FALSE, "Setting detached attribute failed\n");
        return ERR;
    }

    g_pMsgProcHandle->msgThreadIsExit = FALSE;
    ret = pthread_create(&(g_pMsgProcHandle->msgthread), &dp_thread_attr, msgProc, (void *)g_pMsgProcHandle); //消息处理线程
    if (ret != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, FALSE, "thread DpTimer creation failed.\n");
        return ERR;
    }

    (void)pthread_attr_destroy(&dp_thread_attr);

    return ret;
}

int32_t MsgProc_Stop()
{
    if (g_pMsgProcHandle->msgthread)
    {
        g_pMsgProcHandle->msgThreadIsExit = TRUE;
        Q_POST(msgQ);
        pthread_join(g_pMsgProcHandle->msgthread, NULL);
        printf("MsgProc join.\n");
    }

    IPC_UnInit(g_pMsgProcHandle->ipcHandle);

    Q_DESTROY(msgQ);

    HCFREE(g_pMsgProcHandle);
    return OK;
}
