#include <stdlib.h>
#include <stdbool.h>
#include <sys/prctl.h>
#include "stimer.h"
#include "sgdev.h"
#include "queues.h"
#include "logUtil.h"
#include "data_script.h"

//4个时钟的最小剩余时间
uint32_t TimerInit(CLOCK_SIGN_T *clock_sign, uint32_t clock_sign_num)
{
    uint8_t i = 0;
    int32_t ret = 3000000;//max 50min
    int32_t tmp = 0;
    CLOCK_SIGN_T *clock_sign_p = clock_sign;

    for (i = 0; i < clock_sign_num; ++i)
    {
        tmp = clock_sign_p->start_delay + clock_sign_p->timing;
        if (tmp <ret)
        {
            ret = tmp;
        }
        clock_sign_p = clock_sign_p->next;
    }

    return ret;
}

//遍历闹钟，更新定时器超时时间
uint32_t TimerUpdate(CLOCK_SIGN_T *clock_sign, uint32_t clock_sign_num, uint32_t tempval_rev)
{
    uint8_t i = 0;
    int32_t ret = 0, tmp = 0;

    ret = 3000000;      //max 50min
    CLOCK_SIGN_T *clock_sign_p = clock_sign;

    for (i = 0; i < clock_sign_num; ++i)
    {
        tmp = clock_sign_p->tim_cur - tempval_rev;
        if (tmp <= 0)
        {
            clock_sign_p->tim_cur = clock_sign_p->timing;
        }
        // else
        // {
        //   clock_sign_p->tim_cur = tmp;//定时时间到
        // }
        if (clock_sign_p->tim_cur < ret)
        {
            ret = clock_sign_p->tim_cur;
        }
        //定时时间到
        clock_sign_p->tim_cur = tmp;
        clock_sign_p = clock_sign_p->next;

    }
    return ret;
}

//插入闹钟
int32_t InsertClock(STIMER_T *stimer, CLOCK_SIGN_T *clock_sign)
{
    if (stimer->clock_sign != NULL)
    {
        stimer->end->next = clock_sign;
    }
    else
    {
        stimer->clock_sign = clock_sign;
    }

    stimer->end = clock_sign;
    clock_sign->next = NULL;
    stimer->clock_sign_num += 1;
    clock_sign->id = stimer->clock_sign_num;

    return stimer->clock_sign_num;
}

//删除闹钟
int32_t DeleteClock(STIMER_T *stimer, uint8_t id)
{
    uint32_t i = 0;

    CLOCK_SIGN_T *clock_sign_p = stimer->clock_sign;
    CLOCK_SIGN_T *clock_sign_prev = stimer->clock_sign;

    for (i = 0; i < stimer->clock_sign_num; ++i)
    {
        if (clock_sign_p == NULL)
        {
            return -1;
        }

        if (clock_sign_p->id == id)
        {
            if (clock_sign_p == stimer->end )//最后一个
            {
                stimer->end = clock_sign_prev;
            }
            clock_sign_prev->next = clock_sign_p->next;

            free(clock_sign_p);
            stimer->clock_sign_num -=1;
            return 0;
        }
        clock_sign_prev = clock_sign_p;
        clock_sign_p = clock_sign_p->next;
    }
    return -1;
}

//修改闹钟定时时间
int32_t ModifyClock(STIMER_T *stimer, uint8_t id, int32_t timing)
{
    uint32_t i = 0;

    CLOCK_SIGN_T *clock_sign_p = stimer->clock_sign;

    for (i = 0; i < stimer->clock_sign_num; ++i)
    {
        if (clock_sign_p->id == id)
        {
            clock_sign_p->tim_cur += (timing-clock_sign_p->timing);
            clock_sign_p->timing = timing;
            return 0;
        }
        clock_sign_p = clock_sign_p->next;
    }
    return -1;
}


//定时器命令管道接收处理函数
int32_t TimerCmd(uint8_t *cmd, STIMER_T *stimer)
{
    CLOCK_CMD_T *clock_cmd = (CLOCK_CMD_T *)cmd;

    if (clock_cmd->cmd == E_CLOCK_CMD_UP)
    {
        return 0;
    }
    else if (clock_cmd->cmd == E_CLOCK_CMD_INSERT)
    {
        InsertClock(stimer,clock_cmd->in_clock);
        return 0;
    }
    else if (clock_cmd->cmd == E_CLOCK_CMD_MODIFY)
    {
        ModifyClock(stimer,clock_cmd->opt_id,clock_cmd->timeout);//超时算法
    }
    return -1;
}

//定时扫描,触发定时信号,推入队列
void *DpTimer(void *arg)
{
    LOGGER_T *logger =(LOGGER_T*)arg;
    CLOCK_SIGN_T *clock_sign = logger->stimer.clock_sign;

    uint32_t i = 0, j = 0;
    uint8_t isfunc = 0;
    struct timeval tempval;
    int32_t tempval_rev = 0;

    tempval_rev = TimerInit(clock_sign, logger->stimer.clock_sign_num);
    tempval.tv_sec  = tempval_rev/1000;
    tempval.tv_usec = tempval_rev%1000;

    prctl(PR_SET_NAME, "DATAPRO_TIME_THREAD");
    while(!logger->stimer.isExit)
    {
        select(0, NULL, NULL, NULL, &tempval);

        clock_sign = logger->stimer.clock_sign;
        for (i = 0; i < logger->stimer.clock_sign_num; i++)
        {
            if (clock_sign->tim_cur <= 0)
            {
                clock_sign->tim_cur = clock_sign->timing;

                for (j= 0; j< MAX_SIGN; ++j)
                {
                    if (clock_sign->func_sign[j] != 0)
                    {
                        PendQueueS_D(&(logger->dp_sign), clock_sign->func_sign[j]);//处理信号入列

                        isfunc = 1;
                    }
                }
                if (clock_sign->cycle == 0)
                {
                    DeleteClock(&(logger->stimer), clock_sign->id);
                }
            }
            clock_sign = clock_sign->next;
        }
        tempval_rev = TimerUpdate(logger->stimer.clock_sign, logger->stimer.clock_sign_num, tempval_rev);
        tempval.tv_sec = tempval_rev/1000;
        tempval.tv_usec = 1000 * (tempval_rev%1000);

        if (isfunc)
        {
            sem_post(&(logger->dp_sem));
        }
    }
    printf("%s DATAPRO_TIME_THREAD exit.\n", __func__);
    return NULL;
}

//删除所有闹钟
int32_t ClearAllClock(STIMER_T *stimer)
{
    int32_t i = 0;

    CLOCK_SIGN_T *clock_sign_cur = stimer->clock_sign;
    CLOCK_SIGN_T *clock_sign_tmp = NULL;
    for (i = 0; i < stimer->clock_sign_num; i++)
    {
        if (clock_sign_cur != NULL)
        {
            clock_sign_tmp = clock_sign_cur;
            clock_sign_cur = clock_sign_cur->next;
            HCFREE(clock_sign_tmp);
        }
    }

    return OK;
}
