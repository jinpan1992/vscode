#include <libxml/parser.h>
#include <libxml/xpath.h>
#include "sgdev.h"
#include "config.h"
#include "collect.h"
#include "logUtil.h"
#include "script_interface.h"
#include "stimer.h"
#include "sdb.h"
#include "data_script.h"
#include "sysCfg.h"

char *didotype_name[] =
{
    "NONE",
    "NO",
    "NC",
};

char *adc_name[] =
{
    "NONE",
    "4-20mA",
    "0-5V",
};

char *sgdevicetype_name[] =
{
    "NONE",
    "INV",
    "PVS",
    "BATTERY",
    "METERE",
    "EM",
    "GENERATRIX",
    "FEEDER",
    "BREAKER",
    "TRANSFORMER",
    "CHARGING",
    "HC_METER",
};

static uint16_t GetIdFromDidotype(char *element)
{
    uint32_t i = 0;
    for (i = 0; i < DIDO_TYPE_MAX; ++i)
    {
        if (0 == strcmp(element,didotype_name[i]))
        {
            return i;
        }
    }
    return 0;
}

static uint16_t GetIdFromAdctype(char *element)
{
    uint32_t i = 0;
    for (i = 0; i < 2; ++i)
    {
        if (0 == strcmp(element,adc_name[i]))
        {
            return i;
        }
    }
    return 0;
}

int readtxtfile(char *filename, char *outbuf)
{
    FILE *fp=NULL;
    int ch,i = 0;

    fp = fopen("/proc/sys/kernel/osrelease","r");
    if (NULL==fp)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "%s don't exist !!!\n", filename);
        return -1;   //cmt NULL -> -1
    }

    ch = getc(fp);
    while (ch!=EOF)
    {
        //putchar(ch);
        sprintf(&outbuf[i++],"%c", ch);
        ch = getc(fp);
    }

    fclose(fp);

    i -= 1;
    fp = fopen("/proc/sys/kernel/version","r");
    if (NULL==fp)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "%s don't exist !!!\n", filename);
        return -1;   //cmt NULL -> -1
    }

    ch = getc(fp);
    while (ch!=EOF)
    {
        //putchar(ch);
        sprintf(&outbuf[i++],"%c", ch);
        ch = getc(fp);
    }
    sprintf(&outbuf[i-1],"%c", '\0');
    fclose(fp);
    return 0;
}

//获取设备大类型号
uint16_t GetTypeFromSgdevicetype(char *element)
{
    uint32_t i = 0;
    for (i = 0; i < DEVICE_CATEGORY_MAX; ++i)
    {
        if (0 == strcmp(element, sgdevicetype_name[i]))
        {
            return i;
        }
    }
    return 0;
}

int32_t BindToLogger(LOGGER_T *logger, SGDEV_T *sgdev_p)
{
    uint16_t dev_num = 0, total_dev_num = 0, i = 0, j = 0;

    dev_num = logger->dev_num;
    total_dev_num = logger->total_num;

    SGDEV_T *tmp_sgdev_p = (SGDEV_T *)calloc(dev_num, sizeof(SGDEV_T));
    if (tmp_sgdev_p == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc tmp_sgdev_p error!\n");
        exit(EXIT_FAILURE);
    }

    for (i = 0; i < total_dev_num; i++)
    {
        for (j = 0; j < dev_num; j++)
        {
            if (tmp_sgdev_p[j].dev_code == 0)
            {
                tmp_sgdev_p[j] = sgdev_p[i];
                break;
            }
            else if (tmp_sgdev_p[j].dev_code == sgdev_p[i].dev_code)
            {
                tmp_sgdev_p[j].num ++;
                break;
            }
            else
            {
                continue;
            }
        }

    }

    for (j = 0; j < dev_num; j++)
    {
        logger->sgdev[j] = tmp_sgdev_p[j];
    }

    HCFREE(tmp_sgdev_p);

    return 0;
}

int32_t FillSgdevInfo(DEV_INFO_EXT_T *pDIExt, SGDEV_T *pSGDev)
{
    int32_t table_num = 0, i = 0, j = 0, k = 0;
    uint16_t point_num = 0, total_point_num = 0;

    table_num = pDIExt->dwPtlNum;
    strcpy(pSGDev->DevName,pDIExt->stDevUID.devName);
//     strcpy(pSGDev->name, dev_info->name);
//     sgdev_p->dev_name = GetTypeFromSgdevicetype(sgdev_p->name);
    pSGDev->dev_code = pDIExt->stDevUID.devCode;

    for (i = 0; i < pDIExt->dwPtlNum; i++)
    {
        total_point_num += pDIExt->pProtocol[i].ptl_data_num;
    }
    pSGDev->point_num = total_point_num;
    pSGDev->num = 1;

    pSGDev->point_attr = (POINT_ATTRIBUTE_T *)calloc(total_point_num, sizeof(POINT_ATTRIBUTE_T));
    if (pSGDev->point_attr == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc pSGDev->point_attr error!\n");
        return ERROR_T(ERR_DEFAULT_NO_MEM);
    }

    for (i = 0; i < table_num; i++)
    {
        PROTOCOL_T *pPtl = pDIExt->pProtocol + i;
        if (pPtl == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_D, FALSE, " new_protocol NULL .\n");
            continue;
        }

        point_num = pPtl->ptl_data_num;
        for (j = 0; j < point_num; j++)
        {
            PROTOCOL_DATA_T *protocol_data = pPtl->protocol_data + j;
            pSGDev->point_attr[k].dev_code = pPtl->dev_code;
            strcpy(pSGDev->point_attr[k].data_name, protocol_data->data_name);
            pSGDev->point_attr[k].data_id = protocol_data->data_id;
            pSGDev->point_attr[k].data_address = protocol_data->address;
            pSGDev->point_attr[k].data_len = protocol_data->data_len;
            pSGDev->point_attr[k].data_type = protocol_data->data_type;
            pSGDev->point_attr[k].data_sign = protocol_data->data_sign;

            k++;
        }
    }

    return OK;
}

//解析Dataprocess_Config.xml
int SGDevConfig(char *configfilePATH, LOGGER_T *logger)
{
    xmlDocPtr doc;
    xmlNodePtr curNode, Node1, Node2, Node3;
    xmlChar *szKey;
    xmlNodeSetPtr nodeset;
    xmlXPathObjectPtr result;
    xmlXPathContextPtr context;
    char *szDocName;
    xmlChar *xpath;

    uint16_t di_NO = 0, do_NO = 0, di_ptr = 0, do_ptr = 0;

    EMS_LOG(LL_INFO, MODULE_D, FALSE, "parse DataProcessConfig.xml.\n");

    szDocName = configfilePATH;
    doc = xmlReadFile(szDocName,"UTF-8",XML_PARSE_RECOVER);
    /*检查解析文档是否成功，如果不成功，libxml将指一个注册的错误并停止。
    一个常见错误是不适当的编码。XML标准文档除了用UTF-8或UTF-16外还可用其它编码保存。
    如果文档是这样，libxml将自动地为你转换到UTF-8。更多关于XML编码信息包含在XML标准中.*/
    if (NULL == doc)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "Document not parsed successfully\n");
        return -1;
    }

    context = xmlXPathNewContext(doc);

    //查找stimer
    xpath = (xmlChar *)"/root/timer/clock";
    result = xmlXPathEvalExpression(xpath, context);
    if (result)
    {
        nodeset = result->nodesetval;
        if (nodeset->nodeNr)//计算有多少个闹钟
        {
            int32_t i = 0;
            CLOCK_SIGN_T *clock_sign = NULL;
            if (nodeset->nodeNr > MAX_CLOCK_NUM)
            {
                nodeset->nodeNr = MAX_CLOCK_NUM;
            }
            for (i = 0; i < nodeset->nodeNr; ++i)
            {
                clock_sign = (CLOCK_SIGN_T *)malloc (sizeof(CLOCK_SIGN_T));
                memset(clock_sign,0,sizeof(CLOCK_SIGN_T));
                InsertClock(&(logger->stimer),clock_sign);
            }
            printf("clock_sign_num = %d \n", nodeset->nodeNr);
        }
        else
        {
            logger->stimer.clock_sign = (CLOCK_SIGN_T *)malloc (sizeof(CLOCK_SIGN_T));
            memset(logger->stimer.clock_sign, 0, sizeof(CLOCK_SIGN_T));

        }
    }
    CLOCK_SIGN_T *clock_sign_p = logger->stimer.clock_sign;

    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);

    //读取root节点
    curNode = xmlDocGetRootElement(doc);
    if(curNode == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "parsed xml file failed!.\n");
        return -1;
    }
    //解析root下子节点
    if (xmlStrcmp(curNode->name, BAD_CAST "root"))
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "document of the wrong type, root node != root");
        xmlFreeDoc(doc);
        return -1;
    }
    curNode = curNode->xmlChildrenNode;
    xmlNodePtr propNodePtr = curNode;
    Node1 = curNode;

    while (Node1 != NULL)
    {
        if ((!xmlStrcmp(Node1->name, (const xmlChar *)"Name")))
        {
            xmlChar *szKey;
            szKey = xmlNodeGetContent(Node1);
            strcpy((char *)logger->name, (char *)szKey);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"sys_info")))
        {
            Node2 = Node1->xmlChildrenNode;
            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"Kernel")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    strcpy((char *)logger->kernel_Ver, (char *)szKey);
                    xmlFree(szKey);
                }
                Node2 = Node2->next;
            }
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"hd_info")))
        {
            Node2 = Node1->xmlChildrenNode;
            while (Node2 != NULL)
            {
//                 uint16_t Ethernet_num = 0;
//                 Ethernet_num= GetNetPortCount(ETH_FILE_PATH);
//                 FillNetPortInfo(ETH_FILE_PATH, logger->Eth_info, Ethernet_num);

                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"eeprom")))
                {
                    Node3 = Node2->xmlChildrenNode;
                    while (Node3 != NULL)
                    {
                        if ((!xmlStrcmp(Node3->name, (const xmlChar *)"path")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            logger->eepromWrFlag = strtoul((const char *)szKey, NULL, 0);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"address")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            logger->eepromaddress = strtoul((const char *)szKey, NULL, 0);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"size")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            logger->eepromsize = strtoul((const char *)szKey, NULL, 0);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"recordsize")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            logger->eepromrecordsize  = strtoul((const char *)szKey, NULL, 0);
                            xmlFree(szKey);
                        }
                        Node3 = Node3->next;
                    }
                }
                Node2 = Node2->next;
            }
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"ADC")))
        {
            uint32_t adc_ptr = 0;
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                    adc_ptr = strtoul((char *)szAttr, NULL, 0);
                    if ((adc_ptr <= ADC_NUM) && (adc_ptr > 0))
                    {
                        logger->adc_ctl[adc_ptr-1].id = adc_ptr;
                    }
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }
            Node2 = Node1->xmlChildrenNode;
            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"type")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    if (adc_ptr > 0 && adc_ptr <= ADC_NUM)
                    {
                        logger->adc_ctl[adc_ptr-1].type = GetIdFromAdctype((char *)szKey);
                        if (logger->adc_ctl[adc_ptr-1].type == 1)
                        {
                            logger->adc_ctl[adc_ptr-1].zero = 4;
                        }
                        else
                        {
                            logger->adc_ctl[adc_ptr-1].zero = 0;
                        }
                    }
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"slope")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    if (adc_ptr > 0 && adc_ptr <= ADC_NUM)
                    {
                        logger->adc_ctl[adc_ptr-1].cof = atof((char *)szKey);
                    }
                    xmlFree(szKey);
                }
                Node2 = Node2->next;
            }
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"DINO")))
        {
            szKey = xmlNodeGetContent(Node1);
            di_NO = strtoul((char *)szKey, NULL, 0);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"DONO")))
        {
            szKey = xmlNodeGetContent(Node1);
            do_NO = strtoul((char *)szKey, NULL, 0);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"DI")))
        {
            di_ptr = 0;
            //查找属性
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");

                    di_ptr = strtoul((char *)szAttr, NULL, 0);
                    if ((di_ptr <= DI_NUM)&&(di_ptr > 0))
                    {
                        logger->dido_ctl.di_node[di_ptr-1].id = di_ptr;
                    }
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }

            Node2 = Node1->xmlChildrenNode;
            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"type")))
                {
                    szKey = xmlNodeGetContent(Node2);

                    if ((di_ptr <= DI_NUM)&&(di_ptr > 0))
                    {
                        logger->dido_ctl.di_node[di_ptr-1].type = GetIdFromDidotype((char *)szKey);

                        if (logger->dido_ctl.di_node[di_ptr-1].type == 1)
                        {
                            logger->dido_ctl.smu_di_active_state |= (0x00000001<<(di_ptr-1));
                        }
                        else
                        {
                            logger->dido_ctl.smu_di_active_state &= ~(0x00000001<<(di_ptr-1));
                        }
                    }
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"func_sign")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    if ((di_ptr <= DI_NUM)&&(di_ptr > 0))
                    {
                        logger->dido_ctl.di_node[di_ptr-1].func_sign = GetFuncIdByNames(logger->dp_func,(char *)szKey);
                    }
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"outputdo")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    if ((di_ptr <= DI_NUM)&&(di_ptr > 0))
                    {
                        logger->dido_ctl.di_node[di_ptr-1].output_do = strtoul((char *)szKey, NULL, 0);
                    }
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"inputdelay")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    if ((di_ptr <= DI_NUM)&&(di_ptr > 0))
                    {
                        logger->dido_ctl.di_node[di_ptr-1].inputdelay = strtoul((char *)szKey, NULL, 0);
                    }
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"outputdelay")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    if ((di_ptr <= DI_NUM)&&(di_ptr > 0))
                    {
                        logger->dido_ctl.di_node[di_ptr-1].outputdelay = strtoul((char *)szKey, NULL, 0);
                    }
                    xmlFree(szKey);
                }
                Node2 = Node2->next;
            }
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"DO")))
        {
            do_ptr = 0;
            //查找属性
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");

                    do_ptr = strtoul((char *)szAttr, NULL, 0);
                    if ((do_ptr <= DO_NUM)&&(do_ptr > 0))
                    {
                        logger->dido_ctl.do_node[do_ptr-1].id = do_ptr;
                    }
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }

            Node2 = Node1->xmlChildrenNode;
            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"type")))
                {
                    szKey = xmlNodeGetContent(Node2);

                    if ((do_ptr <= DO_NUM)&&(do_ptr > 0))
                    {
                        logger->dido_ctl.do_node[do_ptr-1].type = GetIdFromDidotype((char *)szKey);

                        if (logger->dido_ctl.do_node[do_ptr-1].type == 1)
                        {
                            logger->dido_ctl.smu_do_active_state |= (0x00000001<<(do_ptr-1));
                        }
                        else
                        {
                            logger->dido_ctl.smu_do_active_state &= ~(0x00000001<<(do_ptr-1));
                        }
                    }
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"func_sign")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    if ((do_ptr <= DO_NUM)&&(do_ptr > 0))
                    {
                        logger->dido_ctl.do_node[do_ptr-1].func_sign = GetFuncIdByNames(logger->dp_func,(char *)szKey);
                    }
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"inputdelay")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    if ((do_ptr <= DO_NUM)&&(do_ptr > 0))
                    {
                        logger->dido_ctl.do_node[do_ptr-1].inputdelay = strtoul((char *)szKey, NULL, 0);
                    }
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"outputdelay")))
                {
                    szKey = xmlNodeGetContent(Node2);
                    if ((do_ptr <= DO_NUM)&&(do_ptr > 0))
                    {
                        logger->dido_ctl.do_node[do_ptr-1].outputdelay = strtoul((char *)szKey, NULL, 0);
                    }
                    xmlFree(szKey);
                }
                Node2 = Node2->next;
            }
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"process_mode")))
        {
            szKey = xmlNodeGetContent(Node1);
            logger->process_mode = strtoul((char *)szKey, NULL, 0);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"hisEstoreperiod")))
        {
            szKey = xmlNodeGetContent(Node1);
            logger->hisEstoreperiod = strtoul((char *)szKey, NULL, 0);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"hisDstoreperiod")))
        {
            szKey = xmlNodeGetContent(Node1);
            logger->hisDstoreperiod = strtoul((char *)szKey, NULL, 0);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"time_zone")))
        {
            szKey = xmlNodeGetContent(Node1);
            strcpy((char *)logger->time_zone,(char *)szKey);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"DST")))
        {
            szKey = xmlNodeGetContent(Node1);
            logger->DST = strtoul((char *)szKey, NULL, 0);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"ntp_server")))
        {
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "enabled"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "enabled");
                    logger->ntp_serverEn = strtoul((const char *)szAttr, NULL, 0);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }
            szKey = xmlNodeGetContent(Node1);
            strcpy((char *)logger->ntp_server,(char *)szKey);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"Device_time_sync")))
        {
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "enabled"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "enabled");
                    logger->time_syncEn = strtoul((const char *)szAttr, NULL, 0);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }
            szKey = xmlNodeGetContent(Node1);
            GetTimeInfo(szKey, logger->time_sync);
            //strcpy((char *)logger->time_sync,(char *)szKey);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"reboot_time")))
        {
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "enabled"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "enabled");
                    logger->reboot_time_EN = strtoul((const char *)szAttr, NULL, 0);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }

            szKey = xmlNodeGetContent(Node1);
            strcpy((char *)logger->reboot_time,(char *)szKey);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"language")))
        {
            szKey = xmlNodeGetContent(Node1);
            strcpy((char *)logger->language,(char *)szKey);
            xmlFree(szKey);
        }
        else if (!xmlStrcmp(Node1->name, (const xmlChar *)"func"))
        {
            uint16_t func_sign = 0;
            char     dataname[128] = {0};
            FUNC_PARAS_T *paras;
            uint8_t in_argc = 0;  //输入参数个数
            uint8_t out_argc = 0; //输出参数个数

            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "name"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "name");
                    func_sign = GetFuncIdByNames(logger->dp_func,(char *)szAttr);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }

            if (0 == logger->dp_func[func_sign].paras_num)
            {
                paras = (FUNC_PARAS_T *)malloc(sizeof(FUNC_PARAS_T));

                if (paras == NULL)
                {
                    EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc paras error\n");
                    exit(EXIT_FAILURE);
                }

                memset(paras, 0, sizeof(FUNC_PARAS_T));
                logger->dp_func[func_sign].paras = paras;
                logger->dp_func[func_sign].paras_num = 1;

            }
            else
            {
                logger->dp_func[func_sign].paras = (FUNC_PARAS_T *)realloc(logger->dp_func[func_sign].paras,(logger->dp_func[func_sign].paras_num + 1)*sizeof(FUNC_PARAS_T));
                if (logger->dp_func[func_sign].paras == NULL)
                {
                    EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc paras error\n");
                    exit(EXIT_FAILURE);
                }
                paras = &(logger->dp_func[func_sign].paras[logger->dp_func[func_sign].paras_num]);
                logger->dp_func[func_sign].paras_num += 1;
            }

            Node2 = Node1->xmlChildrenNode;
            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"inpara")))
                {
                    int32_t  funcDevId = -1;
                    int32_t  funcDevCode = -1;
                    int32_t funcDevName = -1;
                    BOOL untrip = FALSE;
                    if (!in_argc)
                    {
                        paras->inputpara.inpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T));
                        if (paras->inputpara.inpara == NULL )
                        {
                            EMS_LOG(LL_ERROR, MODULE_D, FALSE, "inpara malloc paras error.\n");
                            exit(EXIT_FAILURE);
                        }

                        memset(paras->inputpara.inpara, 0, sizeof(FUNC_PARA_T));
                    }
                    propNodePtr = Node2;
                    xmlAttrPtr attrPtr = propNodePtr->properties;
                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                            strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //逆变器类型
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevCode"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevCode");
                            funcDevCode = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //对应逆变器顺序号
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevId"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevId");
                            funcDevId = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Untrip"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Untrip");
                            untrip = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //设备类型、逆变器还是汇流箱
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Name"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Name");
                            funcDevName = GetTypeFromSgdevicetype((char *)szAttr);
                            xmlFree(szAttr);
                        }
                        attrPtr = attrPtr->next;
                    }
                    //对应测点名称
                    szKey = xmlNodeGetContent(Node2);
                    strcpy((char *)dataname,(char *)szKey);
                    login_function(logger->dp_func[func_sign].paras_num, logger, dataname, func_sign,
                                   funcDevCode, funcDevId, funcDevName, untrip,
                                   &paras->inputpara.inpara, &in_argc);
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"outpara")))
                {
                    int32_t  funcDevId = -1;
                    int32_t  funcDevCode = -1;
                    int32_t funcDevName = -1;
                    if (!out_argc)
                    {
                        paras->outputpara.outpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T));
                        if (paras->outputpara.outpara == NULL )
                        {
                            EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc inpara error\n");
                            exit(EXIT_FAILURE);
                        }

                        memset(paras->outputpara.outpara, 0, sizeof(FUNC_PARA_T));
                    }
                    propNodePtr = Node2;
                    xmlAttrPtr attrPtr = propNodePtr->properties;
                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                            strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //逆变器类型
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevCode"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevCode");
                            funcDevCode = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //对应逆变器顺序号
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevId"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevId");
                            funcDevId = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //设备类型、逆变器还是汇流箱
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Name"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Name");
                            funcDevName = GetTypeFromSgdevicetype((char *)szAttr);
                            xmlFree(szAttr);
                        }
                        attrPtr = attrPtr->next;
                    }
                    //对应测点名称
                    szKey = xmlNodeGetContent(Node2);
                    strcpy((char *)dataname,(char *)szKey);
                    login_function_outpara(logger, dataname, funcDevCode, funcDevId,
                                           funcDevName, &paras->outputpara.outpara, &out_argc);
                    xmlFree(szKey);
                }
                Node2 = Node2->next;
            }
            paras->inputpara.in_argc = in_argc ;
            paras->outputpara.out_argc = out_argc ;
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"timer")))
        {
            char dataname[128] = {0};
            uint8_t clock_func_sign = 0;
            Node2 = Node1->xmlChildrenNode;

            FUNC_PARAS_T *clock_paras;
            uint8_t in_argc = 0;        //输入参数个数
            uint8_t out_argc = 0;       //输出参数个数

            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"clock")))
                {
                    //查找属性
                    propNodePtr = Node2;
                    xmlAttrPtr attrPtr = propNodePtr->properties;
                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                            clock_sign_p->id = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        attrPtr = attrPtr->next;
                    }
                    Node3 = Node2->xmlChildrenNode;

                    while(Node3 != NULL)
                    {
                        if ((!xmlStrcmp(Node3->name, (const xmlChar *)"cycle")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            clock_sign_p->cycle = strtoul((char *)szKey, NULL, 0);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"start_delay")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            clock_sign_p->start_delay = strtoul((char *)szKey, NULL, 0);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"timing")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            clock_sign_p->timing = strtoul((char *)szKey, NULL, 0);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"tim_cur")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            clock_sign_p->tim_cur = strtoul((char *)szKey, NULL, 0);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"func_sign")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            char element[128]={0};

                            sscanf((char *)szKey,"%[^,]",element);
                            clock_sign_p->func_sign[0] = GetFuncIdByNames(logger->dp_func,element);
                            xmlFree(szKey);

                            clock_func_sign = clock_sign_p->func_sign[0];

                            if (0 == logger->dp_func[clock_func_sign].paras_num)
                            {
                                clock_paras = (FUNC_PARAS_T *)malloc(sizeof(FUNC_PARAS_T));

                                if (clock_paras == NULL)
                                {
                                    EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc clock_paras error\n");
                                    exit(EXIT_FAILURE);
                                }

                                memset(clock_paras, 0, sizeof(FUNC_PARAS_T));
                                logger->dp_func[clock_func_sign].paras = clock_paras;
                                logger->dp_func[clock_func_sign].paras_num = 1;
                            }
                            else
                            {
                                logger->dp_func[clock_func_sign].paras = (FUNC_PARAS_T *)realloc(logger->dp_func[clock_func_sign].paras,(logger->dp_func[clock_func_sign].paras_num + 1)*sizeof(FUNC_PARAS_T));
                                if (logger->dp_func[clock_func_sign].paras == NULL)
                                {
                                    EMS_LOG(LL_ERROR, MODULE_D, FALSE, "paras malloc paras error.\n");
                                    exit(EXIT_FAILURE);
                                }
                                clock_paras = &(logger->dp_func[clock_func_sign].paras[logger->dp_func[clock_func_sign].paras_num]);
                                logger->dp_func[clock_func_sign].paras_num += 1;
                            }
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"inpara")))
                        {
                            int32_t  funcDevCode = -1, funcDevId = -1, funcDevName = -1;
                            BOOL untrip = FALSE;

                            if (!in_argc)
                            {
                                clock_paras->inputpara.inpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T));
                                if (clock_paras->inputpara.inpara == NULL )
                                {
                                    EMS_LOG(LL_ERROR, MODULE_D, FALSE, "inpara malloc paras error.\n");
                                    exit(EXIT_FAILURE);
                                }

                                memset(clock_paras->inputpara.inpara, 0, sizeof(FUNC_PARA_T));
                            }

                            propNodePtr = Node3;
                            xmlAttrPtr attrPtr = propNodePtr->properties;

                            while (attrPtr != NULL)
                            {
                                if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                                    strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevCode"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevCode");
                                    funcDevCode = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevId"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevId");
                                    funcDevId = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Untrip"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Untrip");
                                    untrip = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Name"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Name");
                                    funcDevName = GetTypeFromSgdevicetype((char *)szAttr);
                                    xmlFree(szAttr);
                                }
                                attrPtr = attrPtr->next;
                            }

                            //对应测点名称
                            szKey = xmlNodeGetContent(Node3);
                            strcpy((char *)dataname,(char *)szKey);
                            login_function(logger->dp_func[clock_func_sign].paras_num,
                                           logger, dataname, clock_func_sign, funcDevCode,
                                           funcDevId, funcDevName, untrip, &clock_paras->inputpara.inpara, &in_argc);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"outpara")))
                        {
                            int32_t  funcDevCode = -1, funcDevId = -1, funcDevName = -1;

                            if (!out_argc)
                            {
                                clock_paras->outputpara.outpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T));
                                if (clock_paras->outputpara.outpara == NULL )
                                {
                                    EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc inpara error\n");
                                    exit(EXIT_FAILURE);
                                }
                                memset(clock_paras->outputpara.outpara, 0, sizeof(FUNC_PARA_T));
                            }

                            propNodePtr = Node3;
                            xmlAttrPtr attrPtr = propNodePtr->properties;

                            while (attrPtr != NULL)
                            {
                                if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                                    strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevCode"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevCode");
                                    funcDevCode = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevId"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevId");
                                    funcDevId = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Name"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Name");
                                    funcDevName = GetTypeFromSgdevicetype((char *)szAttr);
                                    xmlFree(szAttr);
                                }
                                attrPtr = attrPtr->next;
                            }

                            //对应测点名称
                            szKey = xmlNodeGetContent(Node3);
                            strcpy((char *)dataname,(char *)szKey);
                            printf("login_function_outpara: %s\n", dataname);
                            login_function_outpara(logger, dataname, funcDevCode, funcDevId, funcDevName, &clock_paras->outputpara.outpara, &out_argc);
                            xmlFree(szKey);
                        }
                        Node3 = Node3->next;
                    }
                    clock_sign_p = clock_sign_p->next;
                }
                Node2 = Node2->next;
            }
            clock_paras->inputpara.in_argc = in_argc ;
            clock_paras->outputpara.out_argc = out_argc ;
        }
        else if (!xmlStrcmp(Node1->name, (const xmlChar *)"dpInit"))
        {
            uint16_t func_sign = 0;
            char dataname[128] = {0};

            FUNC_PARAS_T *paras = NULL;
            uint8_t in_argc = 0;    //输入参数个数
            uint8_t out_argc = 0;   //输出参数个数

            logger->dp_Init_num += 1;

            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                    strtoul((const char *)szAttr, NULL, 0);
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "name"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "name");
                    func_sign = GetFuncIdByNames(logger->dp_func,(char *)szAttr);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }

            if (0 == logger->dp_func[func_sign].paras_num)
            {
                paras = (FUNC_PARAS_T *)malloc(sizeof(FUNC_PARAS_T));

                if(paras == NULL)
                {
                    EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc paras error\n");
                    exit(EXIT_FAILURE);
                }

                memset(paras, 0, sizeof(FUNC_PARAS_T));
                logger->dp_func[func_sign].paras = paras;
                logger->dp_func[func_sign].paras_num = 1;
            }
            else
            {
                logger->dp_func[func_sign].paras = (FUNC_PARAS_T *)realloc(logger->dp_func[func_sign].paras,(logger->dp_func[func_sign].paras_num + 1)*sizeof(FUNC_PARAS_T));
                if (logger->dp_func[func_sign].paras == NULL)
                {
                    EMS_LOG(LL_INFO, MODULE_D, FALSE, "malloc paras error.\n");
                    exit(EXIT_FAILURE);
                }
                paras = &(logger->dp_func[func_sign].paras[logger->dp_func[func_sign].paras_num]);
                logger->dp_func[func_sign].paras_num += 1;
            }

            Node2 = Node1->xmlChildrenNode;
            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"inpara")))
                {
                    int32_t  funcDevId = -1;
                    int32_t  funcDevCode = -1;
                    int32_t funcDevName = -1;
                    BOOL untrip = FALSE;
                    if (!in_argc)
                    {
                        paras->inputpara.inpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T));
                        if(paras->inputpara.inpara == NULL )
                        {
                            EMS_LOG(LL_INFO, MODULE_D, FALSE, "inpara malloc paras error.\n");
                            exit(EXIT_FAILURE);
                        }

                        memset(paras->inputpara. inpara, 0, sizeof(FUNC_PARA_T));
                    }
                    propNodePtr = Node2;
                    xmlAttrPtr attrPtr = propNodePtr->properties;
                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                            strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //逆变器类型
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevCode"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevCode");
                            funcDevCode = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //对应逆变器顺序号
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevId"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevId");
                            funcDevId = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Untrip"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Untrip");
                            untrip = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //设备类型、逆变器还是汇流箱
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Name"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Name");
                            funcDevName = GetTypeFromSgdevicetype((char *)szAttr);
                            xmlFree(szAttr);
                        }
                        attrPtr = attrPtr->next;
                    }
                    //对应测点名称
                    szKey = xmlNodeGetContent(Node2);
                    strcpy((char *)dataname, (char *)szKey);
                    login_function(logger->dp_func[func_sign].paras_num, logger, dataname, func_sign, funcDevCode, funcDevId, funcDevName, untrip, &paras->inputpara.inpara, &in_argc);
                    xmlFree(szKey);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"outpara")))
                {
                    int32_t  funcDevId = -1;
                    int32_t  funcDevCode = -1;
                    int32_t funcDevName = -1;
                    if (!out_argc)
                    {
                        paras->outputpara.outpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T));
                        if(paras->outputpara.outpara == NULL )
                        {
                            EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc outpara error\n");
                            exit(EXIT_FAILURE);
                        }

                        memset(paras->outputpara.outpara, 0, sizeof(FUNC_PARA_T));
                    }
                    propNodePtr = Node2;
                    xmlAttrPtr attrPtr = propNodePtr->properties;
                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                            strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //逆变器类型
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevCode"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevCode");
                            funcDevCode = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //对应逆变器顺序号
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevId"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevId");
                            funcDevId = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        //设备类型、逆变器还是汇流箱
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Name"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Name");
                            funcDevName = GetTypeFromSgdevicetype((char *)szAttr);
                            xmlFree(szAttr);
                        }
                        attrPtr = attrPtr->next;
                    }
                    //对应测点名称
                    szKey = xmlNodeGetContent(Node2);
                    strcpy((char *)dataname, (char *)szKey);
                    login_function_outpara(logger, dataname, funcDevCode, funcDevId, funcDevName, &paras->outputpara.outpara, &out_argc);
                    xmlFree(szKey);
                }
                Node2 = Node2->next;
            }
            paras->inputpara.in_argc = in_argc ;
            paras->outputpara.out_argc = out_argc ;
        }
        Node1 = Node1->next;
    }

    xmlFreeDoc(doc);
    xmlCleanupParser();

    if (di_NO == 1)
    {
        logger->dido_ctl.smu_di_active_state ^= 0xffffffff;
    }
    if (do_NO == 1)
    {
        logger->dido_ctl.smu_do_active_state ^= 0xffffffff;
    }

    return 0;
}

int SetloggerSN(char *configfilePATH, LOGGER_T *logger)
{
    xmlDocPtr doc;
    xmlNodePtr curNode;
    xmlNodeSetPtr nodeset;
    xmlXPathObjectPtr result;
    xmlXPathContextPtr context;
    char *szDocName;
    szDocName = configfilePATH;
    doc = xmlReadFile(szDocName,"UTF-8",XML_PARSE_RECOVER); //解析文件
    if (NULL == doc)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "Document not parsed successfully\n");
        return -1;
    }
    context = xmlXPathNewContext(doc);
    xmlChar *xpath = (xmlChar *)"/root";
    result = xmlXPathEvalExpression(xpath, context);
    if (result)
    {
        nodeset = result->nodesetval;
        int32_t i = 0;
        for (i = 0; i < nodeset->nodeNr; ++i)
        {
            curNode = nodeset->nodeTab[i];
            curNode = curNode->xmlChildrenNode;
            while (curNode != NULL)
            {
                if (!xmlStrcmp(curNode->name, (const xmlChar *)"SN"))
                {
                    xmlNodeSetContent(curNode, (const xmlChar *)logger->loggerSN);
                }
                curNode = curNode->next;
            }
        }
    }
    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlSaveFile(szDocName, doc);
    xmlFreeDoc(doc);
    system("sync");
    SDB_SetSN(logger->loggerSN);

    return 0;
}

int SetloggerIP(char *configfilePATH, LOGGER_T *logger)
{
    xmlDocPtr doc;
    xmlNodePtr Node1;
    xmlNodeSetPtr nodeset;
    xmlXPathObjectPtr result;
    xmlXPathContextPtr context;
    char *szDocName;

    szDocName = configfilePATH;
    doc = xmlReadFile(szDocName,"UTF-8",XML_PARSE_RECOVER);
    if (NULL == doc)
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "Document not parsed successfully\n");
        return -1;
    }
    context = xmlXPathNewContext(doc);
    xmlChar *xpath = (xmlChar*)"/root/EthernetPortPara/Ethernet";
    result = xmlXPathEvalExpression(xpath, context);
    if (result)
    {
        nodeset = result->nodesetval;
        int32_t i = 0;
        for (i = 0; i < nodeset->nodeNr; ++i)
        {
            Node1 = nodeset->nodeTab[i]->xmlChildrenNode;
            while (Node1 != NULL)
            {
                if (!xmlStrcmp(Node1->name, (const xmlChar *)"IP"))
                {
                    char buf[128] = {0};
                    sprintf(buf,"%d.%d.%d.%d",logger->Eth_info[i].IPAddress[0],logger->Eth_info[i].IPAddress[1],logger->Eth_info[i].IPAddress[2],logger->Eth_info[i].IPAddress[3]);
                    xmlNodeSetContent(Node1, (const xmlChar *)buf);
                }
                else if (!xmlStrcmp(Node1->name, (const xmlChar *)"subnetmask"))
                {
                    char buf[128] = {0};
                    sprintf(buf,"%d.%d.%d.%d",logger->Eth_info[i].SubMask[0],logger->Eth_info[i].SubMask[1],logger->Eth_info[i].SubMask[2],logger->Eth_info[i].SubMask[3]);
                    xmlNodeSetContent(Node1, (const xmlChar *)buf);
                }
                else if (!xmlStrcmp(Node1->name, (const xmlChar *)"Gateway"))
                {
                    char buf[128] = {0};
                    sprintf(buf,"%d.%d.%d.%d",logger->Eth_info[i].GateWay[0],logger->Eth_info[i].GateWay[1],logger->Eth_info[i].GateWay[2],logger->Eth_info[i].GateWay[3]);
                    xmlNodeSetContent(Node1, (const xmlChar *)buf);
                }
                else if (!xmlStrcmp(Node1->name, (const xmlChar *)"DNSAddress1"))
                {
                    char buf[128] = {0};
                    sprintf(buf,"%d.%d.%d.%d",logger->Eth_info[i].DNS1[0],logger->Eth_info[i].DNS1[1],logger->Eth_info[i].DNS1[2],logger->Eth_info[i].DNS1[3]);

                    xmlNodeSetContent(Node1, (const xmlChar *)buf);
                }
                else if (!xmlStrcmp(Node1->name, (const xmlChar *)"DNSAddress2"))
                {
                    char buf[128] = {0};
                    sprintf(buf,"%d.%d.%d.%d",logger->Eth_info[i].DNS2[0],logger->Eth_info[i].DNS2[1],logger->Eth_info[i].DNS2[2],logger->Eth_info[i].DNS2[3]);
                    xmlNodeSetContent(Node1, (const xmlChar *)buf);
                }
                else if (!xmlStrcmp(Node1->name, (const xmlChar *)"DHCP"))
                {
                    char buf[128] = {0};
                    if (logger->Eth_info[i].DHCP == 1)
                    {
                        strcpy(buf,"ON");
                    }
                    else
                    {
                        strcpy(buf,"OFF");
                    }
                    xmlNodeSetContent(Node1, (const xmlChar *)buf);
                }
                Node1 = Node1->next;
            }
        }
    }
    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlSaveFile(szDocName, doc);
    xmlFreeDoc(doc);
    system("sync");
    return 0;
}
