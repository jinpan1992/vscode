#include <errno.h>
#include "data_script.h"
#include "feeddog.h"
#include "config.h"
#include "send.h"
#include "processor.h"
#include "logUtil.h"
#include "calc.h"
#include "queues.h"
#include "IMC.h"
#include "ShareRTDB.h"

char *platform_name[] =
{
    "协议号",
    "协议版本",
    "软件版本号1",
    "软件版本号2",
    "软件版本号3",
    "软件版本号4",
    "软件版本号5",
    "软件版本号6",
    "软件版本号7",
    "软件版本号8",
    "软件版本号9",
    "机器型号1",
    "机器型号2",
    "机器型号3",
    "机器型号4",
    "机器型号5",
    "机器型号6",
    "机器型号7",
    "机器型号8",
    "机器版本号1",
    "机器版本号2",
    "机器版本号3",
    "机器版本号4",
    "机器版本号5",
    "机器版本号6",
    "机器版本号7",
    "机器版本号8",
    "机器版本号9",
    "机器版本号10",
    "SN1",
    "SN2",
    "SN3",
    "SN4",
    "SN5",
    "SN6",
    "SN7",
    "SN8",
    "SN9",
    "SN10",
    "系统时间年",
    "系统时间月",
    "系统时间日",
    "系统时间时",
    "系统时间分",
    "系统时间秒",
    "IP11",
    "IP12",
    "IP13",
    "IP14",
    "subnetmask11",
    "subnetmask12",
    "subnetmask13",
    "subnetmask14",
    "Gatway11",
    "Gatway12",
    "Gatway13",
    "Gatway14",
    "DNS11",
    "DNS12",
    "DNS13",
    "DNS14",
    "IP21",
    "IP22",
    "IP23",
    "IP24",
    "subnetmask21",
    "subnetmask22",
    "subnetmask23",
    "subnetmask24",
    "Gatway21",
    "Gatway22",
    "Gatway23",
    "Gatway24",
    "DNS21",
    "DNS22",
    "DNS23",
    "DNS24",
};

//获取dataid
int32_t Getplatformnamedataid(uint32_t platformname, uint32_t num)
{
    int32_t tmp_dataid = 0;

//     tmp_dataid = SDB_GetDataIdByName(CEMS_DEV_CODE, platform_name[num-1]);

    tmp_dataid = SDB_ND_GetDataId(CEMS_DEV_CODE, 1, platform_name[num-1]);

    return tmp_dataid;
}

void SendRebootSignal(void)
{
    SwWatchdogFeed(SIGUSERREBOOT);
}

int32_t SetIPToLogger(LOGGER_T *logger, uint16_t dataid, DATA_U data, uint16_t num)
{
    int32_t tmp_dataid = 0;
    tmp_dataid = Getplatformnamedataid(CEMS_DEV_CODE, num +46);

    if (tmp_dataid != dataid)
    {
        return -1;
    }

    uint32_t i = 0;
    int32_t j = 0;

    j = num -16;
    if (j < 0)
    {
        j = num;
        i = 0;
    }
    else
    {
        i = 1;
    }

    if (j < 4)
    {
        logger->Eth_info[i].IPAddress[j] = data.u32;
    }
    else if ((j>3)&&(j<8))
    {
        logger->Eth_info[i].SubMask[j-4] = data.u32;
    }
    else if ((j>7)&&(j<12))
    {
        logger->Eth_info[i].GateWay[j-8] = data.u32;
    }
    else
    {
        logger->Eth_info[i].DNS1[j-12] = data.u32;
    }

    return 0;
}

//统计设备数量
uint16_t TotalInvNum(LOGGER_T *logger)
{
    uint16_t i = 0;
    uint16_t ret = 0;
    for (i = 0; i < logger->dev_num; i++)
    {
        ret += logger->sgdev[i].num;
    }

    return ret;
}

//计算回调函数入参值
void CalculateInData(LOGGER_T *logger, FUNC_INPARA_T *inputpara)
{
    uint16_t i = 0;
    uint16_t m = 0;
    uint16_t data_id;   //测点id
    uint16_t dev_code;  //测点所属的设备类型
    uint16_t index;     //测点所属的设备类型
    uint16_t dev_name;  //测点所属的设备名称

    for (m = 0 ; m < inputpara->in_argc; m++)
    {
        data_id = inputpara->inpara[m].data_id;
        dev_code = inputpara->inpara[m].dev_code;
        dev_name = inputpara->inpara[m].dev_name ;
        index = inputpara->inpara[m].index ;
        for (i = 0 ; i < logger->dev_num; i++)
        {
            SGDEV_T *sgdev = NULL;
            sgdev = &(logger->sgdev[i]);
            if ((logger->sgdev[i].dev_name == dev_name) && (logger->sgdev[i].dev_code == dev_code))
            {
                inputpara->inpara[m].data = logger->sgdev[i].gdata[sgdev->map[data_id]][index].stValueInfo.data;
            }
        }
    }
}

//计算回调函数出参值，给输出
void CalculateOutData(LOGGER_T *logger, FUNC_OUTPARA_T *outputpara)
{
    uint16_t i = 0;
    uint16_t m = 0;
    uint16_t data_id;   //测点id
    uint16_t dev_code;  //测点所属的设备类型
    uint16_t index;     //测点所属的设备类型
    uint16_t dev_name;  //测点所属的设备名称

    for (m = 0; m < outputpara->out_argc; m++)
    {
        data_id = outputpara->outpara[m].data_id;
        dev_code = outputpara->outpara[m].dev_code;
        dev_name = outputpara->outpara[m].dev_name ;
        index = outputpara->outpara[m].index;

        for (i = 0; i < logger->dev_num; i++)
        {
            SGDEV_T *sgdev = NULL;
            sgdev = &(logger->sgdev[i]);
            if ((logger->sgdev[i].dev_name == dev_name) && (logger->sgdev[i].dev_code == dev_code))
            {
                logger->sgdev[i].gdata[sgdev->map[data_id]][index-1].stValueInfo.data = outputpara->outpara[m].data;
            }
        }

    }

}

void CalculateIPOutData(LOGGER_T *logger, FUNC_OUTPARA_T *outputpara)
{
    uint16_t m = 0;
    uint32_t i = 0;
    int32_t j = 0;

    for (m = 0; m < outputpara->out_argc; m++)
    {
        j = m -16;
        if (j < 0)
        {
            j = m;
            i = 0;
        }
        else
        {
            i = 1;
        }

        if (j < 4)
        {
            outputpara->outpara[m].data.u32 = logger->Eth_info[i].IPAddress[j];
        }
        else if ((j>3)&&(j<8))
        {
            outputpara->outpara[m].data.u32 = logger->Eth_info[i].SubMask[j-4];
        }
        else if ((j>7)&&(j<12))
        {
            outputpara->outpara[m].data.u32 = logger->Eth_info[i].GateWay[j-8];
        }
        else
        {
            outputpara->outpara[m].data.u32 = logger->Eth_info[i].DNS1[j-12];
        }

        CalculateOutData(logger, outputpara);
    }
}

void GetOutparamValue(LOGGER_T *logger, FUNC_OUTPARA_T *out)
{
    uint16_t func_dataid = 0, fucn_dev_code = 0, out_argc = 0, point_attr_ptr = 0, k = 0;
    int16_t func_index = 0;
    out_argc = out->out_argc;
    for (k = 0; k < out_argc; ++k)
    {
        func_index = out->outpara[k].index;
        fucn_dev_code = out->outpara[k].dev_code;
        func_dataid = out->outpara[k].data_id;

        SGDEV_T *sgdev = logger->map[fucn_dev_code];
        point_attr_ptr = sgdev->map[func_dataid];
        out->outpara[k].data.u32 = sgdev->gdata[point_attr_ptr][func_index-1].stValueInfo.data.u32;
    }
}

void GetTimeInfo(xmlChar *szKey, uint16_t *buf)
{
    char TimeAddress[6][128]={{0},{0}};
    sscanf((char *)szKey,"%[^ ]-%[^ ]-%[^ ] %[^:]:%[^:]:%[^:]",
        TimeAddress[0],
        TimeAddress[1],
        TimeAddress[2],
        TimeAddress[3],
        TimeAddress[4],
        TimeAddress[5]
    );
    buf[0] = strtoul(TimeAddress[0], NULL, 0);
    buf[1] = strtoul(TimeAddress[1], NULL, 0);
    buf[2] = strtoul(TimeAddress[2], NULL, 0);
    buf[3] = strtoul(TimeAddress[3], NULL, 0);
    buf[4] = strtoul(TimeAddress[4], NULL, 0);
    buf[5] = strtoul(TimeAddress[5], NULL, 0);
}

//定时任务
int32_t DpFuncDone(LOGGER_T *logger, DP_FUNC_T *dp_func, DP_SIGN_T *dp_sign)
{
    uint8_t cmd = 0, cmd_rev = 0;
    int32_t j = 0, k = 0;
    uint16_t tmp_out_argc = 0;

    while (PostQueueS_D(dp_sign, &cmd, 1) == 0)
    {
        int32_t ret = 0;

        if (cmd == 0xFF)
        {
            EMS_LOG(LL_ERROR, MODULE_D, FALSE, "timer arrived but has no timer func.\n");
            continue;
        }
        if (cmd_rev != cmd)//连续函数只执行一次
        {
            GetOutparamValue(logger, &(dp_func[cmd].paras[j].outputpara));
            tmp_out_argc = dp_func[cmd].paras[j].outputpara.out_argc;
            FUNC_OUTPARA_T *tmp_outputpara = (FUNC_OUTPARA_T *)calloc(1, sizeof(FUNC_OUTPARA_T));
            if (tmp_outputpara == NULL)
            {
                EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc tmp_outputpara error\n");
                exit(EXIT_FAILURE);
            }
            if (tmp_out_argc > 0)
            {
                tmp_outputpara->outpara = (FUNC_PARA_T *)calloc(tmp_out_argc, sizeof(FUNC_PARA_T));
                if (tmp_outputpara->outpara == NULL)
                {
                    EMS_LOG(LL_ERROR, MODULE_D, FALSE, "malloc tmp_outputpara->outpara error\n");
                    exit(EXIT_FAILURE);
                }

                memcpy(tmp_outputpara->outpara, dp_func[cmd].paras[j].outputpara.outpara, tmp_out_argc*sizeof(FUNC_PARA_T));
            }
            tmp_outputpara->out_argc = 0;
            ret = (dp_func[cmd].func)(&dp_func[cmd].paras[j].inputpara, tmp_outputpara, NULL, NULL);//数据处理

            if (ret > -1)
            {
                //处理成功发送到缓冲区
                for (k = 0; k < tmp_outputpara->out_argc; k++)
                {
                    uint16_t fucn_dev_code = 0, clientid = 0;
                    fucn_dev_code = tmp_outputpara->outpara[k].dev_code;

                    if (fucn_dev_code == CEMS_DEV_CODE)
                    {
                        SGDEV_T *sgdev = logger->map[fucn_dev_code];
                        int32_t dataNum = sgdev->map[tmp_outputpara->outpara[k].data_id];
                        sgdev->gdata[dataNum][tmp_outputpara->outpara[k].index - 1].stValueInfo.data = tmp_outputpara->outpara[k].data;
                        clientid = 1;
                    }
                    else
                    {
                        clientid = 2;
                    }
                    OutData(logger, tmp_outputpara->outpara[k].dev_code,
                            tmp_outputpara->outpara[k].index,
                            tmp_outputpara->outpara[k].data_id, clientid,
                            tmp_outputpara->outpara[k].dataType, tmp_outputpara->outpara[k].data,
                            0x03
                           );
                }
            }
            HCFREE(tmp_outputpara->outpara);
            HCFREE(tmp_outputpara);

        }
        else
        {
            (dp_func[cmd].func)(logger,NULL,NULL,NULL);//数据处理
        }
        cmd_rev = cmd;
    }
    return 0;
}

/*****************************************************************************************/
int32_t Time_handle(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{
//     InsertTimeDataq();

//     Processor_Set(SETTYPE_SOUTH_CALIBRATION, NULL, 0);
//     BOOL setTime = TRUE;
    SG_MSG_T stMsg = {MSG_COLLECT_SOUTH_CALIBRATION, 0, 0, NULL};
    IMC_Send(&stMsg);

    return 0;
}

int32_t CallbackSetSN(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{
    uint16_t i = 0;
    LOGGER_T *templogger = NULL;
    templogger = &logger;
    FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
    FUNC_OUTPARA_T *pout = (FUNC_OUTPARA_T *)out;
    char *name = "CallbackSetSN";

    for (i = 0; i < pin->in_argc; ++i)
    {
        if (pin->inpara[i].data_id == data->data_id)
        {
            GetOutpara(templogger, name, pout, i+1);
            templogger->loggerSN[i] = data->value.data.u32;
            pout->outpara[0].data.u32 = data->value.data.u32;
            break;
        }
    }

    CalculateOutData(templogger, pout);
    SetloggerSN(APPVERDATA_XML_NAME, templogger);

    return 0;
}

int32_t SetDHCP(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{
    uint16_t i = 0;
    int32_t ret = 0;
    LOGGER_T *templogger = NULL;
    templogger = &logger;
    ETH_INFO_T *pEthInfo = templogger->Eth_info;
    FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
    FUNC_OUTPARA_T *pout = (FUNC_OUTPARA_T *)out;
    int32_t tmp_dataid = 0;
    char *name = "SetDHCP";

    for (i = 0; i < pin->in_argc; ++i)
    {
        tmp_dataid = Getplatformnamedataid(CEMS_DEV_CODE, i+46);
        if (tmp_dataid == data->data_id)
        {
            GetOutpara(templogger, name, pout, i+1);
            ret = SetIPToLogger(templogger, data->data_id, data->value.data, i);
            pout->outpara[0].data.u32 = data->value.data.u32;
            pout->out_argc = 1;
            break;
        }
    }
    if (ret == -1)
    {
        return -1;
    }

    for (i = 0; i < 2; i ++)
    {
        if (pEthInfo[i].DHCP != 1)
        {
            NetIpSet(i,(char *)pEthInfo[i].IPAddress);
            NetSubmaskSet(i,(char *)pEthInfo[i].IPAddress,(char *)pEthInfo[i].SubMask);
        }
    }

    NetRouteSet(0,(char *)pEthInfo[0].GateWay);
    NetDnsSet((char *)pEthInfo[0].DNS1, (char *)pEthInfo[0].DNS2, (char *)pEthInfo[1].DNS1, (char *)pEthInfo[1].DNS2);

    SetloggerIP(ETH_FILE_PATH, templogger);

    CalculateOutData(templogger, pout);

//     BOOL resetIp = TRUE;
//     Processor_Set(SETTYPE_RESET_IP, &resetIp, sizeof(BOOL));

//     IMC_Send(MSG_TRANSIMIT_RESET_IP, &resetIp, sizeof(BOOL));

    SG_MSG_T stMsg = {MSG_TRANSIMIT_RESET_IP, 0, 0, NULL};
    IMC_Send(&stMsg);

    return 0;
}

int32_t SetTime(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{
    uint16_t i = 0;
    char pcTimeArr[128] = {0};
    FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
    FUNC_OUTPARA_T *pout = (FUNC_OUTPARA_T *)out;
    LOGGER_T *templogger = &logger;
    char *name = "SetTime";
    struct tm* local;
    time_t t;

    if (logger.timeSyncMode != 2)  //如果不是Modbus 对时（上位机对时）
    {
        printf("time sync mode:%d is not allowed.\n", logger.timeSyncMode);
        return -1;
    }

    for (i = 0; i < pin->in_argc; ++i)
    {
        if (pin->inpara[i].data_id == data->data_id)
        {
            GetOutpara(templogger, name, pout, i+1);
            logger.time_sync[i] = data->value.data.u32;
            pout->outpara[0].data.u32 = data->value.data.u32;
            pout->out_argc = 1;
            break;
        }
    }

    t = time(NULL);
    if (t == (time_t)-1)
    {
        printf("time error:%s\n", strerror(errno));
    }

    local = localtime(&t);
    if (i == 0)
    {
        sprintf (pcTimeArr,"date -s  \"%04d-%02d-%02d %02d:%02d:%02d\"",
             data->value.data.u32,local->tm_mon + 1,local->tm_mday,local->tm_hour,local->tm_min,local->tm_sec);
    }
    else if (i == 1)
    {
        sprintf (pcTimeArr,"date -s  \"%04d-%02d-%02d %02d:%02d:%02d\"",
             local->tm_year + 1900,data->value.data.u32,local->tm_mday,local->tm_hour,local->tm_min,local->tm_sec);
    }
    else if (i == 2)
    {
        sprintf (pcTimeArr,"date -s  \"%04d-%02d-%02d %02d:%02d:%02d\"",
             local->tm_year + 1900,local->tm_mon + 1,data->value.data.u32,local->tm_hour,local->tm_min,local->tm_sec);
    }
    else if (i == 3)
    {
        sprintf (pcTimeArr,"date -s  \"%04d-%02d-%02d %02d:%02d:%02d\"",
             local->tm_year + 1900,local->tm_mon + 1,local->tm_mday,data->value.data.u32,local->tm_min,local->tm_sec);
    }
    else if (i == 4)
    {
        sprintf (pcTimeArr,"date -s  \"%04d-%02d-%02d %02d:%02d:%02d\"",
             local->tm_year + 1900,local->tm_mon + 1,local->tm_mday,local->tm_hour,data->value.data.u32,local->tm_sec);
    }
    else
    {
        sprintf (pcTimeArr,"date -s  \"%04d-%02d-%02d %02d:%02d:%02d\"",
             local->tm_year + 1900,local->tm_mon + 1,local->tm_mday,local->tm_hour,local->tm_min,data->value.data.u32);
    }

    system(pcTimeArr);
    system("hwclock -w");

    CalculateOutData(templogger, pout);

    SG_MSG_T stMsg = {MSG_COLLECT_SOUTH_CALIBRATION, 0, 0, NULL};
    IMC_Send(&stMsg);

    printf("%s pcTimeArr:%s done.\n", __func__, pcTimeArr);
    return 0;
}

//初始化平台处理函数
int32_t InitPlantProcessFunc(LOGGER_T *logger)
{
    int32_t res = 0;

    #if 0
    res = res + InsertDpFunc(logger, cmttrammit, "cmttrammit");
    res = res + InsertDpFunc(logger, cmtcallback, "cmtcallback");
    #endif

    res = res + InsertDpFunc(logger, CallbackSetSN, "CallbackSetSN");
    res = res + InsertDpFunc(logger, SetTime, "SetTime");
    res = res + InsertDpFunc(logger, SetDHCP, "SetDHCP");
    res = res + InsertDpFunc(logger, Time_handle, "Time_handle");

    return res;
}

void InsertVerDataq(PLATFORMVER_T *ver)
{
    uint32_t i = 0, conut = 0, len = 0;
    uint32_t tmp = 0;
    int32_t dataId = 0;
    DEV_DATA_T platform_wdata[32];

    memset(platform_wdata, 0, 32 * sizeof(DEV_DATA_T));

    dataId = Getplatformnamedataid(CEMS_DEV_CODE, 1);
    if (dataId == INVALID_VALUE)
    {
        return;
    }
    platform_wdata[0].dev_code = CEMS_DEV_CODE;
    platform_wdata[0].data_id = dataId;
    platform_wdata[0].index = 1;
    platform_wdata[0].moduleID = 1;
    platform_wdata[0].value.data.u32 = ver->protocalNo;
    platform_wdata[0].data_type = U_INT_T;

    dataId = Getplatformnamedataid(CEMS_DEV_CODE, 2);
    if (dataId == INVALID_VALUE)
    {
        return;
    }
    platform_wdata[1].dev_code = CEMS_DEV_CODE;
    platform_wdata[1].data_id = dataId;
    platform_wdata[1].index = 1;
    platform_wdata[1].moduleID = 1;
    platform_wdata[1].value.data.u32 = CharToInt(tmp, ver->protocalVer, 3);
    platform_wdata[1].data_type = U_INT_T;

    for (i = 2; i < 11; i++)
    {
        dataId = Getplatformnamedataid(CEMS_DEV_CODE, i + 1);
        if (dataId == INVALID_VALUE)
        {
            return;
        }
        platform_wdata[i].dev_code = CEMS_DEV_CODE;
        platform_wdata[i].data_id = dataId;
        platform_wdata[i].index = 1;
        platform_wdata[i].moduleID = 1;
    }
    len = strlen(ver->softWareVer);
    for (i = 11 -len; i < 11 ; i++)
    {
        platform_wdata[i].value.data.u32 = ver->softWareVer[conut];
        platform_wdata[i].data_type = U_INT_T;
        conut ++;
    }

    for (i = 11; i < 19; i++)
    {
        dataId = Getplatformnamedataid(CEMS_DEV_CODE, i + 1);
        if (dataId == INVALID_VALUE)
        {
            return;
        }
        platform_wdata[i].dev_code = CEMS_DEV_CODE;
        platform_wdata[i].data_id = dataId;
        platform_wdata[i].index = 1;
        platform_wdata[i].moduleID = 1;
    }
    len = strlen(ver->machineModel);
    conut = 0;
    for (i = 19 -len; i < 19; i++)
    {
        platform_wdata[i].value.data.u32 = ver->machineModel[conut];
        platform_wdata[i].data_type = U_INT_T;
        conut ++;
    }

    for (i = 19; i < 29; i++)
    {
        dataId = Getplatformnamedataid(CEMS_DEV_CODE, i + 1);
        if (dataId == INVALID_VALUE)
        {
            return;
        }
        platform_wdata[i].dev_code = CEMS_DEV_CODE;
        platform_wdata[i].data_id = dataId;
        platform_wdata[i].index = 1;
        platform_wdata[i].moduleID = 1;

    }
    len = strlen(ver->machineVer);
    conut = 0;
    for (i = 29 -len; i < 29; i++)
    {
        platform_wdata[i].value.data.u32 = ver->machineVer[conut];
        platform_wdata[i].data_type = U_INT_T;
        conut ++;
    }

    conut = 0;
    POINT_T point[29];
    memset(&point, 0, sizeof(POINT_T) * 29);
    for (conut = 0; conut < 29; conut++)
    {
        point[conut].iPointId = platform_wdata[conut].data_id;
        point[conut].dPointValue = platform_wdata[conut].value.data.u32;
        point[conut].ucDataType = U_INT_T;
        point[conut].unDataValue.u32 = platform_wdata[conut].value.data.u32;
    }
    ShareRTDB_Update(CEMS_DEV_CODE, 1, point, 29);

    if (!Q_FULL(dataOutQ))
    {
        Q_INSERT_WAIT_N(dataOutQ, platform_wdata, 29);
    }
    else
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "dataOutQ is full!\n");
    }

    return;
}

void InsertSNDataq(char *loggersn)
{
    int32_t i = 0, dataId = 0;
    DEV_DATA_T platform_wdata[16];

    memset(platform_wdata, 0, 16*sizeof(DEV_DATA_T));

    for (i = 0; i < 10; i++)
    {
        dataId = Getplatformnamedataid(CEMS_DEV_CODE, i + 30);
        if (dataId == INVALID_VALUE)
        {
            return;
        }
        platform_wdata[i].dev_code = CEMS_DEV_CODE;
        platform_wdata[i].data_id = dataId;
        platform_wdata[i].index = 1;
        platform_wdata[i].moduleID = 1;
        platform_wdata[i].value.data.u32 = loggersn[i];
        platform_wdata[i].data_type = U_INT_T;
    }

    i = 0;
    POINT_T point[10];
    memset(&point, 0, sizeof(POINT_T) * 10);
    for (i = 0; i < 10; i++)
    {
        point[i].iPointId = platform_wdata[i].data_id;
        point[i].ucDataType = U_INT_T;
        point[i].dPointValue = platform_wdata[i].value.data.u32;
        point[i].unDataValue.u32 = platform_wdata[i].value.data.u32;
    }
    ShareRTDB_Update(CEMS_DEV_CODE, 1, point, 10);

    if (!Q_FULL(dataOutQ))
    {
        Q_INSERT_WAIT_N(dataOutQ, platform_wdata, 10);
    }
    else
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "dataOutQ is full!\n");
    }
}

void InsertIPDataq(ETH_INFO_T *Eth_info)
{
    uint32_t i = 0, num = 0;
    int32_t j = 0, dataId = 0;
    DEV_DATA_T platform_wdata[48];

    memset(platform_wdata, 0, 48*sizeof(DEV_DATA_T));

    for (i = 0; i < 32; i++)
    {
        dataId = Getplatformnamedataid(CEMS_DEV_CODE, i + 46);
        if (dataId == INVALID_VALUE)
        {
            return;
        }
        platform_wdata[i].dev_code = CEMS_DEV_CODE;
        platform_wdata[i].data_id = dataId;
        platform_wdata[i].index = 1;
        platform_wdata[i].moduleID = 1;

        j = i -16;
        if (j < 0)
        {
            j = i;
            num = 0;
        }
        else
        {
            num = 1;
        }

        if (j < 4)
        {
            platform_wdata[i].value.data.u32 = Eth_info[num].IPAddress[j];
        }
        else if ((j>3)&&(j<8))
        {
            platform_wdata[i].value.data.u32 = Eth_info[num].SubMask[j-4];
        }
        else if ((j>7)&&(j<12))
        {
            platform_wdata[i].value.data.u32 = Eth_info[num].GateWay[j-8];
        }
        else
        {
            platform_wdata[i].value.data.u32 = Eth_info[num].DNS1[j-12];
        }

        platform_wdata[i].data_type = U_INT_T;
    }

    if (!Q_FULL(dataOutQ))
    {
        Q_INSERT_WAIT_N(dataOutQ, platform_wdata, 32);
    }
    else
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "dataOutQ is full!\n");
    }
}

void InsertTime()
{
    int32_t i = 0, dataId = 0;
    DEV_DATA_T timeData[6];
    memset(&timeData, 0, sizeof(DEV_DATA_T) * 6);

    struct tm* local;
    time_t t = time(NULL);
    if (t == (time_t)-1)
    {
        printf("time error:%s\n", strerror(errno));
    }

    local = localtime(&t);

    timeData[0].value.data.u32 = local->tm_year + 1900;
    timeData[1].value.data.u32 = local->tm_mon + 1;
    timeData[2].value.data.u32 = local->tm_mday;
    timeData[3].value.data.u32 = local->tm_hour;
    timeData[4].value.data.u32 = local->tm_min;
    timeData[5].value.data.u32 = local->tm_sec;

    for (i = 0; i < 6; i++)
    {
        dataId = SDB_ND_GetDataId(CEMS_DEV_CODE, 1, platform_name[39 + i]);
        if (dataId == INVALID_VALUE)
        {
            return;
        }
        timeData[i].dev_code = CEMS_DEV_CODE;
        timeData[i].data_id = dataId;
        timeData[i].index = 1;
        timeData[i].data_type = U_INT_T;
    }

    if (!Q_FULL(dataOutQ))
    {
        Q_INSERT_WAIT_N(dataOutQ, timeData, 6);
    }
    else
    {
        EMS_LOG(LL_ERROR, MODULE_D, FALSE, "dataOutQ is full!\n");
    }
}

void SetVersion(LOGGER_T *logger)
{
    PLATFORMVER_T *ver;
    ver = &logger->dev_Ver;
    SDB_GetVer(CEMS_DEV_CODE, ver);

    InsertVerDataq(ver);
    return ;
}

void SetSN(LOGGER_T *logger)
{
    SDB_GetSN(CEMS_DEV_CODE, logger->loggerSN);

    InsertSNDataq(logger->loggerSN);
    return ;
}
