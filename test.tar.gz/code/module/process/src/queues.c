/**********************************************************************************
**单向环形队列
**采用信号量作为读写锁
**队列数据结构为函数信号
***********************************************************************************
///InitQueueS_D 队列初始化
//IsQueueSempty_D 判断队列空否
//PostQueueS_D 出列
//DelQueueS_D 删除队列成员
//PendQueueS_D 入列
***********************************************************************************/
#include <stdlib.h>
#include <stdbool.h>
#include "sgdev.h"
#include "logUtil.h"


void InitQueueS_D(DP_SIGN_T *Q,uint16_t Q_size)
{
    uint16_t i= 0;
    int32_t res = 0;
    Q->size = Q_size;

    for (i = 0; i < Q_size; ++i)
    {
        Q->cmd[i] = 0;
    }

    Q->front = Q->rear = 0;

    res = sem_init(&(Q->rwlock), 0, 1);
    if (res != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_D, false, "QueueS lock Initialization failed\n");
        exit(EXIT_FAILURE);
    }
}

int32_t IsQueueSempty_D(DP_SIGN_T *Q)
{
    int32_t ret = 0;

    sem_wait(&(Q->rwlock));
    if (Q->front == Q->rear)
    {
        ret = 0;
        EMS_LOG(LL_ERROR, MODULE_D, false, "QueueS is empty\n");
    }
    else
    {
        ret = -1;
    }
    sem_post(&(Q->rwlock));
    return ret;
}
/********************************************************************************
 * Function       : PostQueueS_D
 * Author         : maxm
 * Date           : 2021.08.07
 * Description    : 出列
 * Calls          : None
 * Input          : Q:待操作队列,flag:0-不出列,仅查询,1出列
 * Output         : None
 * Return         : -1:队列空,0:成功
 *********************************************************************************/
int32_t PostQueueS_D (DP_SIGN_T *Q, uint8_t *cmd, uint32_t flag)
//int32_t PostQueueS_D(DP_SIGN_T *Q)
{
    int32_t ret = 0;
    sem_wait(&(Q->rwlock));
    if (Q->front == Q->rear)
    {
        //队列已空
        ret = -1;
        //fprintf (stderr, "PostQueueS_D: QueueS is empty\n");
    }
    else
    {
        *cmd = Q->cmd[Q->front]; //出列数据赋值
        if (flag)
        {
            // printf("出列!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            // printf("Q->rear = %d,Q->front = %d\n",Q->rear,Q->front);
            Q->cmd[Q->front] = 0;
            Q->front = (Q->front+1) % Q->size;
        }
    }
    sem_post(&(Q->rwlock));
    return ret;
}


int32_t DelQueueS_D (DP_SIGN_T *Q)
{
    int32_t ret = 0;
    sem_wait(&(Q->rwlock));
    if (Q->front == Q->rear)
    {
        //队列已空
        ret = -1;
        EMS_LOG(LL_ERROR, MODULE_D, false, "DelQueueS_D: QueueS is empty\n");
    }
    else
    {
        Q->cmd[Q->front] = 0;
        Q->front = (Q->front+1) % Q->size;
    }
    sem_post(&(Q->rwlock));
    return ret;
}
/********************************************************************************
 * Function       : PendQueueS_D
 * Author         : maxm
 * Date           : 2021.08.07
 * Description    : 入列
 * Calls          : None
 * Input          : Q:待操作队列,cmd:待入列元素
 * Output         : None
 * Return         : 0:成功,-1失败
 *********************************************************************************/
int32_t PendQueueS_D(DP_SIGN_T *Q, uint8_t cmd)
{
    int32_t ret = 0;
    sem_wait(&(Q->rwlock));
    if ((Q->rear+1) % Q->size == Q->front)
    {
        //队列已满
        ret = -1;
        EMS_LOG(LL_ERROR, MODULE_D, false, "DelQueueS_D: QueueS is full\n");
    }
    else
    {
        // printf("入队列--------------------------------------->\n");
        // printf("Q->rear = %d,Q->front = %d\n",Q->rear,Q->front);
        Q->cmd[Q->rear] = cmd;//入列
        Q->rear = (Q->rear+1) % Q->size;
    }
    sem_post(&(Q->rwlock));
    return ret;
}


