#ifndef COLLECT_H_INCLUDED
#define COLLECT_H_INCLUDED

#include <stdio.h>
#include <stdint.h>
#include "common.h"
#include "SGQueue.h"
#include "err.h"

typedef struct collector_handle_st COLLECTOR_HANDLE_T;

Q_EXTERN(DEV_DATA_T, dataInQ);
Q_EXTERN(DEV_DATA_T, cmdqInQ);
Q_EXTERN(DEV_DATA_T, cmdqOutQ);

uintptr_t Collector_Create();
int32_t Collector_Start();
int32_t Collector_Destroy(uintptr_t handle);
uintptr_t GetMasterHander(IN uint16_t devcode, IN uint16_t index);

#endif // COLLECT_H_INCLUDED
