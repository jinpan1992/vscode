#ifndef PROTOCOL_CFG_H_INCLUDED
#define PROTOCOL_CFG_H_INCLUDED


#include "protocol.h"
#include "common.h"


extern MB_SLAVER_T g_mbSlaver[];

void *CollectMasterInput(void *arg);
void InitCollectPara(void);

void MbmInit(MB_SLAVER_T *mb_slaver);
void MBM_ComRevCtl(MB_SLAVER_T *mb_slaver);                     //通信控制策略
void MBM_ComSendCtl(MB_SLAVER_T *mb_slaver);
void MBM_CurCmdCtl(MB_SLAVER_T *mb_slaver, MODBUS_CMD_T *cmd_t);



#endif // PROTOCOL_CFG_H_INCLUDED
