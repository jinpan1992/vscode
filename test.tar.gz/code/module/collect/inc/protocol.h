#ifndef PROTOCOL_H_INCLUDED
#define PROTOCOL_H_INCLUDED

#include <semaphore.h>
#include <stdint.h>
#include "common.h"
#include "sdb.h"
#include <sys/time.h>

#define MAX_FIFO_DATA_NUM 4096       //管道传输的最大数据量

#define MAXSLAVERS 200              //最大从设备数

#define MAXSLAVERDEVS 64            //某类型从设备最大挂载数

#define MODBUSCMDNUM 1000            //报文队列长度 要修改这个长度，故障录波的长度也要改 FAULTINVMAX

#define COMREE_CNT 5                //通信异常计数上限

#define MAX_COM_NUM 200              //最大搜索端口

#define FAULT_DATA_ID_OFFSET       2   //故障录波偏移 max_data_id+2

#define COMM_STATE_DATA_ID_OFFSET  1   //通信状态偏移 max_data_id+1

#define Meter_A_V       0x35343433   //A相电压
#define Meter_B_V       0x35343533   //B相电压
#define Meter_C_V       0x35343633   //C相电压
#define Meter_V         0x35343233   //电压数据块
#define Meter_A_I       0x35353433   //A相电流
#define Meter_B_I       0x35353533   //B相电流
#define Meter_C_I       0x35353633   //C相电流
#define Meter_I         0x35353233   //电流数据块
#define Meter_SZY_P     0x35363333   //瞬时总有功功率
#define Meter_SZYA_P    0x35363433   //瞬时A相有功功率
#define Meter_SZYB_P    0x35363533   //瞬时B相有功功率
#define Meter_SZYC_P    0x35363633   //瞬时C相有功功率
#define Meter_Y_P       0x35363233   //瞬时有功功率数据块
#define Meter_SZW_P     0x35373333    //瞬时总无功功率
#define Meter_SZWA_P    0x35373433    //瞬时A相无功功率
#define Meter_SZWB_P    0x35373533    //瞬时B相无功功率
#define Meter_SZWC_P    0x35373633    //瞬时C相无功功率
#define Meter_W_P       0x35373233    //瞬时无功功率数据块
#define Meter_SZS_P     0x35383333    //瞬时总视在功率
#define Meter_SZSA_P    0x35383433    //瞬时A相视在功率
#define Meter_SZSB_P    0x35383533    //瞬时B相视在功率
#define Meter_SZSC_P    0x35383633    //瞬时C相视在功率
#define Meter_S_P       0x35383233    //瞬时视在功率数据块
#define Meter_Z_PY      0x35393333    //总功率因数
#define Meter_A_PY      0x35393433    //A相功率因数
#define Meter_B_PY      0x35393533    //B相功率因数
#define Meter_C_PY      0x35393633    //C相功率因数
#define Meter_PY        0x35393233    //功率因数数据块

typedef enum
{
    HIGH_SCAN_PRIO = 0,
    LOW_SCAN_PRIO,
    MAX_SCAN_PRIO,
}SCAN_PRIORITY_E;


typedef enum
{
    MBM_NONCYC = 0,    //不循环发送
    MBM_CYC ,          //循环发送
}CYC_TYPE_E;

//modbus slave 接收数据协议解析
typedef struct modbus_protocol_t
{
    uint16_t tranction;         //事务序列号
    uint16_t protocolType;      //协议类型
    uint8_t id;                 //站号
    uint8_t cmd;                //功能码
    uint32_t address;           //寄存器地址
    uint16_t len;               //数据长度
    uint8_t *data;              //数据指针
    uint8_t valid;              //有效性
    uint8_t err;                //错误码
}MODBUS_PROTOCOL_T;

//数据处理循环队列实现
//先进先出队列
typedef struct datapro_func_t
{
    MODBUS_CMD_T cmd[MODBUSCMDNUM];     //数据指针 长度为7
    uint16_t front;                     //头指针
    uint16_t rear;                      //尾指针
    uint16_t size;                      //队列长度
    sem_t rwlock;
}DATAPRO_FUN_T;

//modbus从设备对象 modbus slaver dev
typedef struct mb_slaver_st
{
    char name[32];                      //设备类型名称 SGINV
    uint16_t index;                     //设备索引，一种类型设备编序
    uint8_t  meter_addr[6];             //电表地址
    uint16_t PT_Pare;
    uint16_t CT_Pare;
    uint8_t Meter_dire;                 //电表方向
    char dev_sn[32];                    //设备序列号
    char position[128];                 //设备位置信息
    uint16_t dev_code;                  //设备类型编码
    char dev_name[32];                  //设备名称

    uint8_t dev_type;
    uint8_t dev_adress[32];
    uint8_t dev_breaker;                //设备丛属关系
    uint8_t slaverid_modify;            //设备地址能否改变
    uint16_t cslave_id;                 //通信站号,设备地址
    uint8_t com;                        //从站所在的主站端口
    uint32_t com_type;                  //挂载通信口类型//uart或者can...
    DATA_U *data;                       //[DATA_TOTEL]; 设备数据
    PROTOCOL_T *protocol[MAX_PROTOCOL_NUM];    //通信协议
    int32_t protocol_num;               //通信协议个数
    int32_t (*scanfunc)(struct mb_slaver_st *, int32_t indexnum, void *pMbmMaster, uintptr_t fd, uint8_t *scan_prio);                //扫描发送处理函数
    int32_t (*scancmdfunc)(struct mb_slaver_st *, void *pMbmMaster, uintptr_t fd);                                                   //扫描命令发送处理函
    int32_t (*readscanfunc)(struct mb_slaver_st *, uintptr_t fd,uint8_t *, uint16_t, uint8_t scan_prio);                        //接收处理函数

    DATAPRO_FUN_T scan[MAX_SCAN_PRIO];                                                                             //扫描发送队列
    DATAPRO_FUN_T scancmd;                                                                                         //扫描命令发送队列
    DATAPRO_FUN_T curcmd;                                                                                          //即时命令发送队列
    MODBUS_CMD_T send_scan;
    ALARM_CLOCK_T scan_clock;                                                                                      //扫描闹钟

    void (*CollectMasterInit)(struct mb_slaver_st *mb_slaver);
    void (*MBMComRevCtl)(struct mb_slaver_st *mb_slaver);
    void (*MBMComSendCtl)(struct mb_slaver_st *mb_slaver);
    void (*MBMCurCmdCtl)(struct mb_slaver_st *mb_slaver, MODBUS_CMD_T *cmd_t);

    uint8_t timing_flag;                                                                        //对时标志
    uint8_t offline;                                                                            //不在线标志
    uint8_t comm_recover;                                                                       //通信恢复标志
    uint8_t callback;                                                                           //收发计数
    uint8_t callcnt;                                                                            //发计数
    uint8_t backcnt;                                                                            //收计数
    uint8_t valid;                                                                              //数据有效性
    uint8_t cmd_flag;
    uint8_t comm_state;                                                                         //通信状态
    uint16_t data_num;                                                                          //设备的测点个数
    uint16_t max_data_id;                                                                       //最大测点号
    uint16_t min_data_id;                                                                       //最小测点号
    int32_t canid_send;
    int32_t canid_rev;
    int32_t heart_type;                                                                         //是否开启心跳
    int32_t heart_time;                                                                         //心跳时间
    uint32_t *map_id;                                                                           //data_id的映射
    struct mb_slaver_st *next;                                                                  //链表指针
}MB_SLAVER_T;

//modbus slaver dev tab
typedef struct mb_slaver_tab_st
{
    MB_SLAVER_T *head;
    MB_SLAVER_T *end;
    int32_t num;                        //当前在哪个设备号
}MB_SLAVER_TAB_T;

typedef struct mb_dev_code_st
{
    uint16_t dev_code;              //设备编码
    //uint16_t dev_num;             该类型编码的设备台数
    uint16_t data_num;              //该类型编码包含的测点数
    uint16_t max_data_id;           //最大测点数
    uint16_t min_data_id;           //最小测点数
    char dev_name[32];              //设备名称
    uint32_t *map_id;               //每种类型设备建立一张map
    struct mb_dev_code_st *next;    //链表指针
}MB_DEV_CODE_T;


//dev code tab
typedef struct mb_dev_code_tab_st
{
    MB_DEV_CODE_T *head;
    MB_DEV_CODE_T *end;
    uint16_t num;       //设备类型个数
}MB_DEV_CODE_TAB_T;     //设备类型编码链表

//modbus comport dev
typedef struct mb_comm_dev_st
{
    MB_SLAVER_T *dev;               //链表指针
    struct mb_comm_dev_st *next;    //链表指针
}MB_COMM_DEV_T;

//modbusmaster
typedef struct mb_master_st
{
    uintptr_t fd;                                              //文件句柄
    int32_t index;
    int32_t num;
    uint8_t cmd_flag;
    uint8_t cmd_send_flag;
    uint16_t CommSign;

    COMPORT_T comport;

    sem_t bus_lock;                                            //lock of comm bus

    pthread_t scan_thread;
    pthread_t connect_thread;
    pthread_t input_thread;

    MB_COMM_DEV_T *head;                                       //链表指针
    MB_COMM_DEV_T *end;                                        //链表指针
    MB_COMM_DEV_T *cmdptr;                                     //链表指针
    MB_SLAVER_T *scan;
    MB_SLAVER_T *cmd;

    pthread_mutex_t mutex;                                     //命令互斥锁
    pthread_mutex_t revcmd_mutex;                              //互斥锁

    DATAPRO_FUN_T Radcmd;                                      //即时命令发送队列
    DATAPRO_FUN_T send_cmd;                                    //send quence

    struct mb_master_st *next;

    BOOL scanThreadIsExit;
    BOOL inputThreadIsExit;
    BOOL connectThreadIsExit;
}MB_MASTER_T;

//modbus comport tab
typedef struct mb_master_tab_st
{
    MB_MASTER_T *head;
    MB_MASTER_T *end;
    int32_t num;
    sem_t canBusLock;
}MB_MASTER_TAB_T;

//dev information
typedef struct cmd_info_st
{
    MB_SLAVER_T *slaver;
    MB_MASTER_T *master;
    uint32_t address_start;
    uint32_t address_end;
    uint32_t address_min;
    uint32_t address_max;
    uint16_t *ptl_update;
    uint8_t cmd_flag;
    uint8_t wr_type;
    uint8_t clientID;
}CMD_INFO_T;

//invert dev cmd data process moden
//4x点表收集
typedef struct ptl_4X_cmd_st
{
    PROTOCOL_T *protocol;
    uint16_t *ptl_update;
    CMD_INFO_T cmd_info[MAXSLAVERS];    //can和com口
    uint32_t address_start;
    uint32_t address_end;
    uint32_t address_min;
    uint32_t address_max;
    uint8_t cmd_flag;
    uint8_t slaver_num;
    MB_MASTER_T  *master[MAX_COM_NUM];  //每个4x协议的主站链表
    uint8_t master_num;
    uint8_t clientID;
}PTL_4X_CMD_T;

//管道接收数据属性表
typedef struct cmd_data_st
{
    PTL_4X_CMD_T *ptl_4X_cmd;   //only pointer
    uint32_t address;           //所属点表地址
    uint16_t data_id;           //数据ID号
    char data_name[128];        //数据名称
}CMD_DATA_T;


typedef struct code_data_st
{
    uint16_t dev_code;
    CMD_DATA_T *data;
    uint16_t data_num;
    uint16_t max_data_id;
    uint16_t min_data_id;
    uint32_t *map_id;
}CODE_DATA_T;

//管道设备对象属性
typedef struct modbus_dev_st
{
    PTL_4X_CMD_T *ptl_4X_cmd;   //4x总表
    int32_t ptl_4X_cmd_num;     //4x总表个数
    PROTOCOL_T *set_ptl;        //剔除重复4x使用
    //CMD_DATA_T data[DATA_TOTEL];
    CODE_DATA_T *code_data;     //每个数据的4X点表
    uint16_t dev_code_num;

}MODBUS_DEV_T;

extern MB_SLAVER_TAB_T mb_slaver_tab;               //modbus slaver devs tab
extern MB_MASTER_TAB_T mb_master_tab;               //modbus master tab
extern MB_DEV_CODE_TAB_T mb_dev_code_tab;
extern MODBUS_DEV_T modbus_dev;                     //inverter cmd processer

int32_t CollectMasterRevPro(MB_SLAVER_T *comm, uintptr_t fd,uint8_t *inbuf, uint16_t inlen , uint8_t scan_prio);
int32_t CollectMasterScanCmdSend(MB_SLAVER_T* mb_slaver, void *pMbmMaster, uintptr_t fd);
int32_t CollectMasterScanSend(MB_SLAVER_T* mb_slaver, int32_t indexnum, void *pMbmMaster, uintptr_t fd, uint8_t* scan_prio);


int32_t CollectInputInterfaceInit(void);

void CreatDevCodeTab(MB_DEV_CODE_TAB_T *tab);
void CreatDevTab(MB_SLAVER_TAB_T *tab);

int32_t DelDev(MB_SLAVER_TAB_T *tab,int16_t index,char * name);
int32_t InsertProtocolToDev(MB_SLAVER_TAB_T *tab, uint32_t mum, uint16_t dev_code, char *name, uint8_t com, PROTOCOL_T *protocol);
int32_t CreatMbMasterTab(MB_MASTER_TAB_T *tab);
int32_t InsertMbMaster(MB_MASTER_TAB_T *tab, COMPORT_T *comport, int32_t mbmasterid);
int32_t InsertDevToMbMaster(MB_MASTER_TAB_T *port_tab, MB_SLAVER_TAB_T *dev_tab, int32_t mbmasterid, char * name, int16_t mbslaverid, uint16_t dev_code);
void ModifiedMbMaster(MB_MASTER_TAB_T *tab, int32_t mbmasterid, int32_t timeout);
int32_t CreateCmd(MB_MASTER_TAB_T *mbm_tab, DEV_DATA_T *inbuf, uint16_t inlen);

void CreatCollectPthread(MB_MASTER_TAB_T *mbm_tab);

void CreatMbscan(MB_SLAVER_T *slaver, uint8_t protocol_no, uint8_t cycflag, uint8_t scan_prio);
void CreatMbCmdScan(MB_SLAVER_T *slaver, uint8_t protocol_no);
void CreateCurCmdScan(MB_SLAVER_T *mb_slaver, MODBUS_CMD_T *cmd_t, uint8_t scan_prio);

int32_t IsMbscanEmpty(MB_SLAVER_T *slaver, uint8_t scan_prio);
int32_t IsMbcmdscanEmpty(MB_SLAVER_T *slaver);
void ClearMBCmd(MB_SLAVER_T *mb_slaver);
void ClearMasterAllCmd(MB_MASTER_T *mb_master);

void CreateTabAndRegFun(void);

int32_t GetQueueS(DATAPRO_FUN_T *Q, MODBUS_CMD_T *cmd_t);
int32_t PendQueueS(DATAPRO_FUN_T *Q, MODBUS_CMD_T *cmd_t);
int32_t PostQueueS (DATAPRO_FUN_T *Q, MODBUS_CMD_T *cmd_t, uint32_t flag);
int32_t DelQueueS (DATAPRO_FUN_T *Q);

int GrammarAnalysis(int32_t id, uint8_t *rbuf, uint8_t buflen);

void GenerateDevCodeTab(void);

int32_t ProModbusRevDataFromDlt645(int32_t id, uint8_t *pbuf, uint8_t buflen);
void SendMeterDataToServerProcess(uint16_t meteraddr, uint32_t *pbuf, uint8_t datalen, uint8_t index);
void SaveDLT645_07_Meter(uint8_t *pbuf, MB_SLAVER_T *mb_slaver);
void SaveCJT188_Meter(uint8_t *pbuf,MB_SLAVER_T *mb_slaver);
void CreatMeterScan(uint8_t meterAddr[6], uint16_t com_id, PROTOCOL_T *protocol, MODBUS_CMD_T *cmd_t, uint8_t cycflag);
void CreatTcpMeterScan(uint8_t *meterAddr, uint16_t com_id, PROTOCOL_T *protocol, MODBUS_CMD_T *cmd_t, uint8_t cycflag);

int32_t DevConnect (uint32_t commtype, MB_MASTER_T *mb_master, MB_SLAVER_T *curMbSlaver);
int32_t InsertDevToMbSlaver(MB_SLAVER_TAB_T *tab, DEV_INFO_T *dev);
void InsertCommStateQ(uint16_t dev_code, uint16_t index, int32_t flag);



#endif // PROTOCOL_H_INCLUDED
