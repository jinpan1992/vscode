#include <stdlib.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <stdbool.h>
#include <sys/prctl.h>
#include <math.h>
#include "protocol.h"
#include "protocol_cfg.h"
#include "can.h"
#include "SGQueue.h"
#include "collect.h"
#include "modbus.h"
#include "modbus_tcp.h"
#include "calc.h"
#include "logUtil.h"
#include "uart.h"
#include "sys.h"
#include "commonTest.h"
#include "config.h"
#include "sdb.h"
#include "dlt645uart.h"
#include "iec_master_service.h"
#include "cjt188uart.h"
#include "sms4.h"
#include "ShareRTDB.h"

#define SAYYES 0
#define SAYNO -1
int flag = 0;
extern PLAT_STATISTICS_T g_PlatStic;
extern PLAT_SR_T g_PlatSR[TEST_NUM];


typedef struct uartreattime_t
{
    struct timeval respT;
    struct timeval sendT;
}UARTREATTIME_T;

 UARTREATTIME_T uartreattime;
 static int send_485 = 0,recv_485 = 0;

MODBUS_DEV_T modbus_dev;
MB_SLAVER_TAB_T mb_slaver_tab;          //mb slaver dev
MB_MASTER_TAB_T mb_master_tab;          //mb master
MB_DEV_CODE_TAB_T mb_dev_code_tab;      //mb slaver code
//DEV_DATA_T fifo_wdata[MAX_FIFO_DATA_NUM];

int32_t HeartSet (uintptr_t fd, MB_SLAVER_T *curMbSlaver)
{
    char *heart_name = "心跳计数";
    MODBUS_CMD_T tmpCmd = {0};
    int32_t i = 0, j = 0;

    for (i = 0; i < curMbSlaver->protocol_num; i++)
    {
        PROTOCOL_T *tmp_protocol = curMbSlaver->protocol[i];
        for (j = 0; j < tmp_protocol->ptl_data_num; j++)
        {
            if (0 == strcmp(heart_name, tmp_protocol->protocol_data[j].data_name))
            {
                tmpCmd.address = tmp_protocol->protocol_data[j].address - 1;
                tmpCmd.cmd = 16;
                tmpCmd.registerCount = 1;
                tmpCmd.id = curMbSlaver->cslave_id;
                tmpCmd.data[0] = 0;
                tmpCmd.data[1] = 1;
                if (curMbSlaver->heart_type == 1)
                {
                    ModbusSet(fd, SET_TYPE_HEART_ENABLE, &curMbSlaver->heart_time);
                    ModbusSet(fd, SET_TYPE_HEART_DATA, &tmpCmd);
                }
            }
        }
    }

    return 0;
}

int32_t DevConnect (uint32_t commtype, MB_MASTER_T *mb_master, MB_SLAVER_T *curMbSlaver)
{
    START_INFO_T start_info;
    int32_t ret = INVALID_VALUE;
    if (commtype == UART)
    {
        if (curMbSlaver->protocol[0]->ptl_type == MODBUS)
        {
            start_info.uartId = mb_master->comport.uartid;
            start_info.baud = mb_master->comport.uartbaudrate;
            start_info.data_bit = mb_master->comport.uartdatabit;
            strncpy(start_info.stop_bit, mb_master->comport.uartstopbit, sizeof(start_info.stop_bit));
            strcpy(&start_info.parity, &mb_master->comport.uartparity);
            start_info.type = MODBUS_BACKEND_TYPE_RTU;
            start_info.role = MODBUS_ROLE_MASTER;
            mb_master->fd = ModbusOpen(start_info);
        }

        if (curMbSlaver->protocol[0]->ptl_type == DLT645)
        {
            start_info.uartId = mb_master->comport.uartid;
            start_info.baud = mb_master->comport.uartbaudrate;
            start_info.data_bit = mb_master->comport.uartdatabit;
            strcpy(&start_info.parity, &mb_master->comport.uartparity);
            mb_master->fd = DltOpen(start_info);
            SetDltOpt(mb_master->fd,start_info.baud, start_info.data_bit, "1",start_info.parity);
        }

        if (curMbSlaver->protocol[0]->ptl_type == CJT188)
        {
            start_info.uartId = mb_master->comport.uartid;
            start_info.baud = mb_master->comport.uartbaudrate;
            start_info.data_bit = mb_master->comport.uartdatabit;
            start_info.metertype = curMbSlaver->dev_type;
            strcpy(start_info.stop_bit, mb_master->comport.uartstopbit);

            uint8_t temp[7] = {0};
            CharToHex(temp, (char*)curMbSlaver->dev_adress, heat_dev_adress * 2);
            memcpy(start_info.devAddr, temp, heat_dev_adress);

            strcpy(&start_info.parity, &mb_master->comport.uartparity);
            mb_master->fd = Cjt188Open(start_info);
        }

    }
    else if (commtype == CAN)
    {
        uint32_t canbaudrate = mb_master->comport.canbaudrate;

        mb_master->fd = CanOpen(CAN_NAME, curMbSlaver->canid_send, curMbSlaver->canid_rev, canbaudrate, mb_master->comport.canframe);
    }
    else if (commtype == NET)
    {
        sprintf(start_info.sIp, "%d.%d.%d.%d", mb_master->comport.ip[0], mb_master->comport.ip[1], mb_master->comport.ip[2], mb_master->comport.ip[3]);
        start_info.iPort = mb_master->comport.netport;
        start_info.type = MODBUS_BACKEND_TYPE_TCP;
        start_info.role = MODBUS_ROLE_MASTER;
        mb_master->fd = ModbusOpen(start_info);

        if (mb_master->fd != INVALID_VALUE)
        {
            HeartSet(mb_master->fd, curMbSlaver);
        }
    }
    else if (commtype == SG_METER)
    {
        start_info.uartId = mb_master->comport.uartid;
        start_info.baud = mb_master->comport.uartbaudrate;
        start_info.data_bit = mb_master->comport.uartdatabit;
        strcpy(&start_info.parity, &mb_master->comport.uartparity);
        mb_master->fd = DltOpen(start_info);
        SetDltOpt(mb_master->fd,start_info.baud, start_info.data_bit, "1",start_info.parity);
    }
    else if(commtype == CJT_188 )
    {
        start_info.uartId = mb_master->comport.uartid;
        start_info.baud = mb_master->comport.uartbaudrate;
        start_info.data_bit = mb_master->comport.uartdatabit;
        start_info.metertype = curMbSlaver->dev_type;
        strcpy(start_info.stop_bit, mb_master->comport.uartstopbit);

        uint8_t temp[7] = {0};
        CharToHex(temp, (char*)curMbSlaver->dev_adress, heat_dev_adress * 2);
        memcpy(start_info.devAddr, temp, heat_dev_adress);

        strcpy(&start_info.parity, &mb_master->comport.uartparity);
        mb_master->fd = Cjt188Open(start_info);

    }

    ret = (mb_master->fd == INVALID_VALUE) ? INVALID_VALUE : 0;

    return ret;
}

/**********************************************************************************
**单向环形队列
**采用信号量作为读写锁
**队列数据结构为modbus主站发送报文
***********************************************************************************
//InitQueueS 队列初始化
//IsQueueSempty 判断队列空否
//PostQueueS 出列
//DelQueueS 删除队列成员
***********************************************************************************/
static void InitQueueS(DATAPRO_FUN_T *Q, uint16_t Q_size)
{
    int32_t res = 0;
    Q->size = Q_size;

    memset(Q->cmd, 0, sizeof(MODBUS_CMD_T)*Q_size);

    Q->front = Q->rear = 0;

    res = sem_init(&(Q->rwlock), 0, 1);
    if (res != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_C, FALSE, "QueueS lock initialization failed.\n");
        exit(EXIT_FAILURE);
    }
}

static int32_t IsQueueSempty(DATAPRO_FUN_T *Q)
{
    int32_t ret = 0;

    sem_wait(&(Q->rwlock));
    if (Q->front == Q->rear)
    {
        ret = 0;
    }
    else
    {
        ret = -1;
    }
    sem_post(&(Q->rwlock));

    return ret;
}

/********************************************************************************
 * Function       : PostQueueS
 * Author         : maxm
 * Date           : 2021.08.07
 * Description    : 出列
 * Calls          : None
 * Input          : Q:待操作队列,flag:0-不出列,仅查询,1出列
 * Output         : None
 * Return         : -1:队列空,0:成功
 *********************************************************************************/
int32_t PostQueueS (DATAPRO_FUN_T *Q, MODBUS_CMD_T *cmd_t, uint32_t flag)
{
    int32_t ret = 0;

    sem_wait(&(Q->rwlock));

    if (Q->front == Q->rear)
    {
        //队列已空
        ret = -1;
    }
    else
    {
        if (flag == 1)
        {
            memcpy(cmd_t,&(Q->cmd[Q->front]),sizeof(MODBUS_CMD_T));
            memset(&(Q->cmd[Q->front]),0,sizeof(MODBUS_CMD_T));
            Q->front = (Q->front+1) % Q->size;
        }
        else
        {
            //非循环报文，10次删除
            if (Q->cmd[Q->front].cmd == 0x03 && Q->cmd[Q->front].cyc == MBM_NONCYC)
            {
                if (Q->cmd[Q->front].send_cnt < COMREE_CNT)
                {
                    memcpy(cmd_t, &(Q->cmd[Q->front]), sizeof(MODBUS_CMD_T));
                    Q->cmd[Q->front].send_cnt++;
                }
                else
                {
                    EMS_LOG(LL_DEBUG, MODULE_C, false, "remove cmd！\n");
                    int i = 0;
                    for (i = 0; i < 6; i++)
                    {
                        EMS_LOG(LL_DEBUG, MODULE_C, false, "0x%0x", Q->cmd[Q->front].data[i]);
                    }

                    memset(&(Q->cmd[Q->front]), 0, sizeof(MODBUS_CMD_T));
                    Q->front = (Q->front+1) % Q->size;

                    //判断队列是否为空，如不为空，发下条队列命令
                    if (Q->front == Q->rear)
                    {
                        ret = -1;
                    }
                    else
                    {
                        memcpy(cmd_t, &(Q->cmd[Q->front]), sizeof(MODBUS_CMD_T));
                        Q->cmd[Q->front].send_cnt++;
                    }
                }
            }
            else
            {
                memcpy(cmd_t, &(Q->cmd[Q->front]), sizeof(MODBUS_CMD_T));
            }
        }
    }
    sem_post(&(Q->rwlock));

    return ret;
}


int32_t GetQueueS(DATAPRO_FUN_T *Q, MODBUS_CMD_T *cmd_t)
{
    int32_t ret = 0;

    sem_wait(&(Q->rwlock));
    if (Q->front == Q->rear)
    {
        ret = -1;
    }
    else
    {
        memcpy(cmd_t, &(Q->cmd[Q->front]), sizeof(MODBUS_CMD_T));
    }
    sem_post(&(Q->rwlock));
    return ret;
}


int32_t DelQueueS (DATAPRO_FUN_T *Q)
{
    int32_t ret = 0;

    sem_wait(&(Q->rwlock));
    if (Q->front == Q->rear)
    {
        ret = -1;
    }
    else
    {
        memset(&(Q->cmd[Q->front]), 0, sizeof(MODBUS_CMD_T));
        Q->front = (Q->front+1) % Q->size;
    }
    sem_post(&(Q->rwlock));
    return ret;
}

/********************************************************************************
 * Function       : PendQueueS
 * Author         :
 * Date           : 2021.08.07
 * Description    : 入列
 * Calls          : None
 * Input          : Q:待操作队列,cmd_t:待入列元素
 * Output         : None
 * Return         : 0:成功,-1失败
 *********************************************************************************/
int32_t PendQueueS(DATAPRO_FUN_T *Q, MODBUS_CMD_T *cmd_t)
{
    // uint16_t i= 0;
    int32_t ret = 0;
    sem_wait(&(Q->rwlock));
    if ((Q->rear+1) % Q->size == Q->front)
    {
        EMS_LOG(LL_INFO, MODULE_C, false, "full!rear = %d, size = %d\n", Q->rear, Q->size);
        ret = -1;
    }
    else
    {
        cmd_t->send_cnt = 0;
        memcpy(&(Q->cmd[Q->rear]), cmd_t, sizeof(MODBUS_CMD_T));//入列
        Q->rear = (Q->rear+1) % Q->size;

        /*int i=0;
        printf("pend queue: ");
        for(i=0; i< cmd_t->buf_len;i++)
        {
           printf("0x%0x ", cmd_t->data[i]);
         }
        printf("\n"); */
    }
    sem_post(&(Q->rwlock));
    return ret;
}

void ClearMasterAllCmd(MB_MASTER_T *mb_master)
{
    MB_COMM_DEV_T *p_dev = mb_master->head;
    MB_SLAVER_T *mb_slaver;
    int j;

    EMS_LOG(LL_DEBUG, MODULE_C, false, "(com%d) clear all cmd.\n", mb_master->comport.uartid);
    for (j = 0; j < mb_master->num; ++j)
    {
        mb_slaver = p_dev->dev;
        ClearMBCmd(mb_slaver);
        p_dev = p_dev->next;
    }
    while(DelQueueS(&(mb_master->Radcmd)) == 0);
    while(DelQueueS(&(mb_master->send_cmd)) == 0);

}

void CreateTabAndRegFun(void)
{
    //建立主站和从站链表
    CreatDevTab(&mb_slaver_tab);
    CreatMbMasterTab(&mb_master_tab);
    CreatDevCodeTab(&mb_dev_code_tab);
}

/***********************************************************************************************
** modbus master data moden setup
** mb master tab,mb slaver(dev of mb master)tab
** some oprations: creat,insert,delet,config
** 单向循环链表
**************************************************************u**********************************/

//建立链表头结点
void CreatDevTab(MB_SLAVER_TAB_T *tab)
{
    tab->head = NULL;
    tab->end = NULL;
    tab->num = 0;
}

//创建设备类型编码链表
void CreatDevCodeTab(MB_DEV_CODE_TAB_T *tab)
{
    tab->head = NULL;
    tab->end = NULL;
    tab->num = 0;
}

//插入设备类型编码
int32_t InsertToDevCodeTab(MB_DEV_CODE_TAB_T *tab,  MB_SLAVER_T *mb_slaver)
{
    MB_DEV_CODE_T *new_mb_dev_code = (MB_DEV_CODE_T *)malloc(sizeof(MB_DEV_CODE_T));
    if (new_mb_dev_code == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, FALSE, "malloc new_mb_dev_code failed !\n");
        exit(EXIT_FAILURE);
        return -1;
    }

    new_mb_dev_code->dev_code = mb_slaver->dev_code;
    strcpy(new_mb_dev_code->dev_name, mb_slaver->dev_name);
    new_mb_dev_code->max_data_id = mb_slaver->max_data_id;
    new_mb_dev_code->min_data_id = mb_slaver->min_data_id;
    new_mb_dev_code->data_num = mb_slaver->data_num;   /*类型数据的测点数*/
    new_mb_dev_code->next = NULL;

    new_mb_dev_code->map_id = (uint32_t *)malloc((mb_slaver->max_data_id + 1) * sizeof(uint32_t));
    if (new_mb_dev_code->map_id == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, FALSE, "malloc new_mb_dev_code->map_id error !\n");
        exit(EXIT_FAILURE);
    }
    else
    {
        int32_t i = 0, j = 0;
        uint32_t map_index = 0;
        for (i = 0; i < mb_slaver->protocol_num; i++)
        {
            PROTOCOL_T *protocol = mb_slaver->protocol[i];
            for (j = 0; j< protocol->ptl_data_num; j++)
            {
                new_mb_dev_code->map_id[protocol->protocol_data[j].data_id] = map_index;
                map_index++;
            }
        }
    }

    /*测点
    int j;
    PROTOCOL_DATA_T *ptl_data = (PROTOCOL_DATA_T *)malloc((mb_slaver->data_num+1) * sizeof(PROTOCOL_DATA_T));
    uint16_t num = 0;
    for(j=0; j< mb_slaver->protocol_num; j++)
    {
       memcpy((ptl_data + num +1), mb_slaver->protocol[j]->protocol_data, mb_slaver->protocol[j]->ptl_data_num);
       num += mb_slaver->protocol[j]->ptl_data_num;
    }
    new_mb_dev_code->ptl_data = ptl_data;*/

    if (tab->head == NULL)
    {
        tab->head = new_mb_dev_code;
    }
    if (tab->end != NULL)
    {
        tab->end->next = new_mb_dev_code;
    }
    tab->end = new_mb_dev_code;
    tab->num += 1;

    return tab->num;
}

//判断该设备类型编码在链表中是否已存在
int IsDevCodeInTab(MB_DEV_CODE_TAB_T *tab, uint16_t dev_code)
{
    int i = 0, res = -1;

    if (tab->num < 1)
    {
        return -1;
    }

    MB_DEV_CODE_T *mb_dev_code = tab->head;

    for (i = 0; i < tab->num; i++)
    {
        if (dev_code == mb_dev_code->dev_code)
        {
            res = 0;
            break;
        }
        mb_dev_code = mb_dev_code->next;
    }
    return res;
}

//遍历从站链表，生成设备类型编码链表
void GenerateDevCodeTab(void)
{
    MB_SLAVER_T *mb_slaver = mb_slaver_tab.head;
    int32_t i, j;

    for (i = 0; i < mb_slaver_tab.num; ++i)
    {
        EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "mb_slaver->dev_code = %d\n", mb_slaver->dev_code);
        if (IsDevCodeInTab(&mb_dev_code_tab, mb_slaver->dev_code) == -1)   //如果同一种设备类型未插入
        {
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Insert dev_code = %d\n", mb_slaver->dev_code);
            InsertToDevCodeTab(&mb_dev_code_tab, mb_slaver);
        }
        mb_slaver = mb_slaver->next;
    }

    EMS_LOG(LL_DEBUG, MODULE_C, false, "tab_num = %d\n", mb_dev_code_tab.num);
    MB_DEV_CODE_T *mb_dev_code = mb_dev_code_tab.head;
    for (i = 0; i < mb_dev_code_tab.num; i++)
    {
        EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "i = %d, dev_code = %d, name = %s, max_data_id = %d, min_data_id = %d\n", i, mb_dev_code->dev_code, mb_dev_code->dev_name, mb_dev_code->max_data_id, mb_dev_code->min_data_id);

        mb_slaver = mb_slaver_tab.head;
        for (j = 0; j < mb_slaver_tab.num; j++)
        {
            if (mb_slaver->dev_code == mb_dev_code->dev_code)
            {
                mb_slaver->map_id = mb_dev_code->map_id;
            }
            mb_slaver = mb_slaver->next;
        }
        mb_dev_code = mb_dev_code->next;
    }
}

//删除mb从设备
int32_t DelDev(MB_SLAVER_TAB_T *tab,int16_t index,char *name)
{
    MB_SLAVER_T *mb_slaver,*mb_slaver_last;
    int32_t i = 0;

    mb_slaver = tab->head;
    mb_slaver_last = mb_slaver;

    if (tab->num == 0)
    {
        return 0;
    }

    for (i = 0; i < tab->num; ++i)
    {
        if ((0 == strcmp(mb_slaver->name, name))&&(index == mb_slaver->index))
        {
            if (mb_slaver == tab->head)
            {
                tab->head = mb_slaver->next;
            }

            if (mb_slaver->next == NULL)
            {
                if (mb_slaver == tab->head)
                {
                    tab->end = NULL;
                }
                else
                {
                    tab->end = mb_slaver_last;
                }
            }

            mb_slaver_last->next = mb_slaver->next;

            free(mb_slaver);
            tab->num--;
            return 0;
        }
        mb_slaver_last = mb_slaver;
        mb_slaver = mb_slaver->next;
    }
    return -1;
}

//通信协议注册到该协议对应的所有从站设备
int32_t InsertProtocolToDev(MB_SLAVER_TAB_T *tab, uint32_t mum, uint16_t dev_code, char *name, uint8_t com, PROTOCOL_T *protocol)
{
    MB_SLAVER_T *mb_slaver;
    int32_t i = 0;
    int32_t j = 0;

    mb_slaver = tab->head;

    for (i = 0; i < tab->num; ++i)
    {
        if ((mb_slaver->dev_code == dev_code) && (0 == strcmp(mb_slaver->dev_name, name)) && (com == mb_slaver->com))
        {
            if (mb_slaver->protocol_num < MAX_PROTOCOL_NUM)
            {
                for (j = 0; j < mum; ++j)
                {
                    mb_slaver->protocol[j] = &protocol[j];
                }
            }
            else
            {
                EMS_LOG(LL_INFO, MODULE_C, false, "%s protocol:%d > MAX_PROTOCOL_NUM\n", name, mb_slaver->protocol_num);
            }
            mb_slaver->protocol_num = mum;
        }
        mb_slaver = mb_slaver->next;
    }
    return 0;
}

//建立mb主站链表
int32_t CreatMbMasterTab(MB_MASTER_TAB_T *tab)
{
    tab->head = NULL;
    tab->end = NULL;
    tab->num = 0;

    return 0;
}

//插入一个mb主站
int32_t InsertMbMaster(MB_MASTER_TAB_T *tab, COMPORT_T *comport, int32_t mbmasterid)
{
    int32_t res;
    MB_MASTER_T *new_mb_master;
    new_mb_master = (MB_MASTER_T *)malloc(sizeof(MB_MASTER_T));

    if (new_mb_master == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc new_mb_master error\n");
        exit(EXIT_FAILURE);
        return -1;
    }

    memset(new_mb_master, 0, sizeof(MB_MASTER_T));

    new_mb_master->fd = INVALID_VALUE;
    new_mb_master->index = mbmasterid;
    memcpy(&(new_mb_master->comport), comport, sizeof(COMPORT_T));
    new_mb_master->num = 0;
    new_mb_master->cmd_flag = 0;
    new_mb_master->cmd_send_flag = 0;
    new_mb_master->CommSign = 0;

    new_mb_master->head = NULL;
    new_mb_master->end = NULL;
    new_mb_master->cmdptr = NULL;
    new_mb_master->scan = NULL;
    new_mb_master->cmd = NULL;
    InitQueueS(&(new_mb_master->Radcmd),MODBUSCMDNUM);//命令队列初始化

    res = sem_init(&(new_mb_master->bus_lock), 0, 1);
    if (res != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "Semaphore bus_lock initialization failed\n");
        exit(EXIT_FAILURE);
    }

    //创建快速互次锁（没有得到锁的线程阻塞）
    res = pthread_mutex_init(&(new_mb_master->mutex), NULL);
    if (res != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "mutex init failed\n");
        exit(EXIT_FAILURE);
    }

    res = pthread_mutex_init(&(new_mb_master->revcmd_mutex), NULL);
    if (res != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "mutex init failed\n");
        exit(EXIT_FAILURE);
    }

    InitQueueS(&(new_mb_master->send_cmd),MODBUSCMDNUM);//命令队列初始化

    if (tab->head == NULL)
    {
        tab->head = new_mb_master;
    }

    if (tab->end != NULL)
    {
        tab->end->next = new_mb_master;
    }

    tab->end = new_mb_master;

    tab->num += 1;


    return 0;
}

void ModifiedMbMaster(MB_MASTER_TAB_T *tab, int32_t mbmasterid, int32_t timeout)
{
    int32_t i = 0;
    MB_MASTER_T *mb_master = tab->head;
    for (i = 0; (i < tab->num) && (mb_master!=NULL); ++i)
    {
        if (mb_master->index == mbmasterid)
        {
            //mb_master->comport.timeout = timeout;
            return ;
        }
        mb_master = mb_master->next;
    }
    return;
}

int32_t InsertDevToMbSlaver(MB_SLAVER_TAB_T *tab, DEV_INFO_T *dev)
{
    int32_t j = 0;
    MB_SLAVER_T *new_mb_slaver = NULL;

    if (tab->num >= MAXSLAVERS)
    {
        EMS_LOG(LL_ERROR, MODULE_C, FALSE, "insert dev failed ! max slavers. tab->num = %d\n", tab->num);
        return 0;
    }

    new_mb_slaver = (MB_SLAVER_T *)calloc(1, sizeof(MB_SLAVER_T));
    if (new_mb_slaver == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, FALSE, "malloc mb_slaver failed !\n");
        exit(EXIT_FAILURE);
        return -1;
    }

    //优化，所有类型设备共用一套通信策略
    memcpy(new_mb_slaver, &g_mbSlaver[0], sizeof(MB_SLAVER_T));

    InitQueueS(&(new_mb_slaver->scancmd), MODBUSCMDNUM);        //命令队列初始化

    for (j = 0; j < MAX_SCAN_PRIO; j++)
    {
        InitQueueS(&(new_mb_slaver->scan[j]), MODBUSCMDNUM);     //扫描队列初始化
    }

    InitQueueS(&(new_mb_slaver->curcmd), MODBUSCMDNUM);          //命令队列初始化

    new_mb_slaver->index = dev->index;
    strcpy(new_mb_slaver->dev_sn, dev->dev_sn);
    strcpy(new_mb_slaver->position, dev->position);
    new_mb_slaver->dev_code = dev->dev_code;
    memcpy(new_mb_slaver->dev_name,  dev->dev_name, 32);
    new_mb_slaver->dev_type = dev->ucSubType;

    for (j = 0; j < 32; j++)
    {
        new_mb_slaver->dev_adress[j] = dev->dev_address[j];
    }

    strcpy(new_mb_slaver->name,  dev->name);
    new_mb_slaver->dev_breaker = dev->dev_breaker;
    new_mb_slaver->slaverid_modify = dev->slaverid_modify;
    new_mb_slaver->com = dev->com;
    new_mb_slaver->com_type = dev->com_type;
    new_mb_slaver->cslave_id = dev->cslave_id;
    new_mb_slaver->protocol_num = dev->dwPtlNum;

    for (j = 0; j < dev->dwPtlNum && j < MAX_PROTOCOL_NUM; j++)
    {
        new_mb_slaver->protocol[j] = dev->protocol[j];
    }

    new_mb_slaver->scan_clock.start_delay = dev->scan_clock.start_delay;
    new_mb_slaver->scan_clock.timing = dev->scan_clock.timing;
    new_mb_slaver->scan_clock.timeout = dev->scan_clock.timeout;
    new_mb_slaver->scan_clock.tim_cur = dev->scan_clock.tim_cur;

    for (j = 0; j < 6; j++)
    {
        new_mb_slaver->meter_addr[j] = dev->meter_addr[j];
    }

    new_mb_slaver->PT_Pare = dev->PT_Pare;
    new_mb_slaver->CT_Pare = dev->CT_Pare;
    new_mb_slaver->Meter_dire = dev->Meter_dire;
    new_mb_slaver->comm_state = 0;
    new_mb_slaver->timing_flag = 1;

    new_mb_slaver->canid_send = dev->canid_send;
    new_mb_slaver->canid_rev = dev->canid_rev;
    new_mb_slaver->heart_time = dev->heart_time;
    new_mb_slaver->heart_type = dev->heart_type;

    new_mb_slaver->data = &(dev->pValue->data);
    new_mb_slaver->map_id = dev->map_id;

    new_mb_slaver->next = NULL;

    if (tab->head == NULL)
    {
        tab->head = new_mb_slaver;
    }
    if (tab->end != NULL)
    {
        tab->end->next = new_mb_slaver;
    }
    tab->end = new_mb_slaver;
    tab->num += 1;

    return tab->num;
}

//从从设备链表里选择名字为name的设备加入绑定到fd的主站里
int32_t InsertDevToMbMaster(MB_MASTER_TAB_T *port_tab, MB_SLAVER_TAB_T *dev_tab, int32_t mbmasterid, char * name, int16_t mbslaverid, uint16_t dev_code)
{
    int32_t i = 0, j = 0;
    MB_COMM_DEV_T *node_new;
    MB_MASTER_T *mbm;
    MB_SLAVER_T *dev;

    node_new = (MB_COMM_DEV_T *)malloc (sizeof(MB_COMM_DEV_T));
    if (node_new == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc node_new error\n");
        exit(EXIT_FAILURE);
        return -1;
    }

    mbm = port_tab->head;
    dev = dev_tab->head;

    for (i = 0; i < port_tab->num; ++i)
    {
        if (mbm->index == mbmasterid)
        {
            for (j = 0; j < dev_tab->num; ++j)
            {
                if ((0 == strcmp(dev->dev_name, name))&&(dev->index == mbslaverid)&&(dev->dev_code == dev_code))
                {
                    node_new->dev = dev;

                    if (mbm->head == NULL)
                    {
                        mbm->head = node_new;
                    }
                    node_new->next = mbm->head;

                    if (mbm->end != NULL)
                    {
                        mbm->end->next = node_new;
                    }

                    mbm->end = node_new;

                    mbm->num++;

                    mbm->cmdptr = mbm->head;

                    return 0;
                }
                dev = dev->next;
            }
        }
        mbm = mbm->next;
    }

    if (node_new != NULL)
    {
        free(node_new);
    }
    return -1;
}

/*********************************************************************************
**协议栈接收处理数据结构初始化
*********************************************************************************
**Dev_4Xptl_MapCreat modbus协议栈输入数据处理模块索引初始化
**modbus_dev_init modbus协议栈输入数据处理模块数据结构初始化
**********************************************************************************/
static int Dev_4Xptl_MapCreat(PROTOCOL_T *ptl)
{
    uint32_t data_id;
    PROTOCOL_DATA_T *ptl_dat = ptl->protocol_data;
    int32_t i = 0, j = 0, k = 0;
    uint32_t ptl_dat_num = ptl->ptl_data_num;

    //建立每个数据的4x_pt
    for (k = 0; k < modbus_dev.dev_code_num; k++)
    {
        if (ptl->dev_code == modbus_dev.code_data[k].dev_code)
        {
            break;
        }
    }

    if (k == modbus_dev.dev_code_num)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "cannot match the 4x_ptl_cmd!\n");
        return -1;
    }

    //同种类型的设备，最后的协议
    uint32_t *map_id = modbus_dev.code_data[k].map_id;
    uint32_t id_index = 0;
    for (i = 0; i < ptl_dat_num; i++)
    {
        data_id = ptl_dat[i].data_id;

        if (map_id == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "map_id null!\n");
            exit(EXIT_FAILURE);
        }
        id_index = map_id[data_id];

        modbus_dev.code_data[k].data[id_index].address = ptl_dat[i].address;
        modbus_dev.code_data[k].data[id_index].data_id = ptl_dat[i].data_id;
        strcpy(modbus_dev.code_data[k].data[id_index].data_name, ptl_dat[i].data_name);

        //未赋值4x情况下,根据参数遍历整个4x点表
        for (j = 0; j < modbus_dev.ptl_4X_cmd_num; ++j)
        {
            if ((modbus_dev.ptl_4X_cmd+j)->protocol == ptl)
            {
                modbus_dev.code_data[k].data[id_index].ptl_4X_cmd = modbus_dev.ptl_4X_cmd + j;
                break;
            }
        }
    }

    return 0;
}

//modbus协议栈输入数据处理模块数据结构初始化
//扫描所有的4x协议点表,全部注册
//扫描所有的数据名称,注册4x协议点表内数据所有信息,生成相应的索引
int32_t CollectInputInterfaceInit(void)
{
    int32_t ret = OK;
    int32_t i = 0, j = 0, k = 0, m = 0;
    PTL_4X_CMD_T *ptl_4X_cmd_t;
    MB_SLAVER_T *mb_slaver_tmp;
    int32_t protocolnum = mb_slaver_tab.num;

    modbus_dev.code_data = (CODE_DATA_T *)malloc(mb_dev_code_tab.num * sizeof(CODE_DATA_T));
    if (modbus_dev.code_data == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc modbus_dev.dev_data error !\n");
        return ERROR_T(ERR_DEFAULT_NO_MEM);
    }

    //设备类型编码个数
    modbus_dev.dev_code_num = mb_dev_code_tab.num;

    //填充每种设备类型编码的数据结构
    MB_DEV_CODE_T *mb_dev_code = mb_dev_code_tab.head;
    for (i = 0; i< mb_dev_code_tab.num; i++)
    {
        modbus_dev.code_data[i].map_id = mb_dev_code->map_id;
        modbus_dev.code_data[i].dev_code = mb_dev_code->dev_code;
        modbus_dev.code_data[i].data_num = mb_dev_code->data_num;
        modbus_dev.code_data[i].max_data_id = mb_dev_code->max_data_id;
        modbus_dev.code_data[i].min_data_id = mb_dev_code->min_data_id;
        modbus_dev.code_data[i].data = (CMD_DATA_T *)malloc((mb_dev_code->data_num + 1)* sizeof(CMD_DATA_T));
        if (modbus_dev.code_data[i].data == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "malloc modbus_dev.code_data.data error !\n");
            exit(EXIT_FAILURE);
        }
        else
        {
            //注意 测点 data_id从1开始
            for (j = 0; j< (modbus_dev.code_data[i].data_num + 1); j++)
            {
                modbus_dev.code_data[i].data[j].ptl_4X_cmd = NULL;
                modbus_dev.code_data[i].data[j].address = INVALID_VALUE;
            }
        }
        mb_dev_code = mb_dev_code->next;
    }

    //剔除重复的4X协议5x协议
    uint16_t tot_num = 0;//TODO 所有类型设备的协议protocol总数量
    MB_DEV_CODE_T *mb_dev_code_tmp = mb_dev_code_tab.head;
    for (i = 0; i< mb_dev_code_tab.num; i++)
    {
        mb_slaver_tmp = mb_slaver_tab.head;
        for (j = 0; j < protocolnum; j++)
        {
            if ((mb_slaver_tmp->dev_code == mb_dev_code_tmp->dev_code)
                && (0 == strcmp(mb_slaver_tmp->dev_name, mb_dev_code_tmp->dev_name))
               )
            {
                tot_num += mb_slaver_tmp->protocol_num;
            }
            mb_slaver_tmp = mb_slaver_tmp->next;
        }
        mb_dev_code_tmp = mb_dev_code_tmp->next;
    }

    PROTOCOL_T *set_ptl = (PROTOCOL_T *)malloc(tot_num * (sizeof(PROTOCOL_T)));
    if (set_ptl == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc 4x set_ptl error !\n");
        exit(EXIT_FAILURE);
    }
    modbus_dev.set_ptl = set_ptl;
    memset(modbus_dev.set_ptl, 0, tot_num *(sizeof(PROTOCOL_T)));

    uint32_t ptl_4X_cmd_num = 0;
    MB_DEV_CODE_T *tmp_dev_code = mb_dev_code_tab.head;
    for (i = 0; i< mb_dev_code_tab.num; i++)
    {
        MB_SLAVER_T *mb_slaver_tmp1 = mb_slaver_tab.head;
        for (j = 0; j < protocolnum; j++)
        {
            if ( (mb_slaver_tmp1->dev_code == tmp_dev_code->dev_code)
                && (0 == strcmp(mb_slaver_tmp1->dev_name, tmp_dev_code->dev_name))
               )
            {
                //剔除一台设备点表中相同的协议
                PROTOCOL_T *protocol = mb_slaver_tmp1->protocol[0];
                for (k = 0; (mb_slaver_tmp1->protocol[k] != NULL) && (k < mb_slaver_tmp1->protocol_num); k++)
                {
                    for(m = 0; m < ptl_4X_cmd_num; m++)
                    {
                        if((set_ptl[m].dev_code == protocol[k].dev_code)
                            && (set_ptl[m].address == protocol[k].address)
                            && (set_ptl[m].len == protocol[k].len)
                            && (set_ptl[m].cmd == protocol[k].cmd)
                          )
                        {
                            break;
                        }
                    }

                    if(m == ptl_4X_cmd_num && m < tot_num)
                    {
                        set_ptl[m] = protocol[k];
                        ptl_4X_cmd_num++;
//                         printf("%s set_ptl[%d].address:%d devcode:%d ptl_4X_cmd_num:%d (L%d)\n",
//                                 __func__, m, set_ptl[m].address, set_ptl[m].dev_code, ptl_4X_cmd_num, __LINE__);
                    }
                }
            }

            mb_slaver_tmp1 = mb_slaver_tmp1->next;
        }
        tmp_dev_code = tmp_dev_code->next;
    }

    //不重复的4x协议,结构数据赋值
    modbus_dev.ptl_4X_cmd_num = ptl_4X_cmd_num;
    ptl_4X_cmd_t = (PTL_4X_CMD_T *)malloc(ptl_4X_cmd_num*(sizeof(PTL_4X_CMD_T)));
    if (ptl_4X_cmd_t == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc ptl_4X_cmd_t error!\n");
        exit(EXIT_FAILURE);
    }
    memset(ptl_4X_cmd_t, 0, ptl_4X_cmd_num * sizeof(PTL_4X_CMD_T));

    modbus_dev.ptl_4X_cmd = ptl_4X_cmd_t;
    for (j = 0; j < ptl_4X_cmd_num; j++)
    {
        ptl_4X_cmd_t[j].cmd_flag = 0;
        ptl_4X_cmd_t[j].protocol = &set_ptl[j];
        ptl_4X_cmd_t[j].ptl_update = (uint16_t *)malloc(set_ptl[j].ptl_data_num * sizeof(uint16_t));
        if (ptl_4X_cmd_t[j].ptl_update == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "malloc ptl_update error!\n");
            exit(EXIT_FAILURE);
        }
        memset(ptl_4X_cmd_t[j].ptl_update, 0, set_ptl[j].ptl_data_num * sizeof(uint16_t));

        ptl_4X_cmd_t[j].address_start = ptl_4X_cmd_t[j].address_min = set_ptl[j].min_address;   //协议最大地址
        ptl_4X_cmd_t[j].address_end = ptl_4X_cmd_t[j].address_max = set_ptl[j].max_address;     //协议最小地址
        ptl_4X_cmd_t[j].master_num = 0;
        ptl_4X_cmd_t[j].clientID = 0;

        for (m = 0; m < MAX_COM_NUM; m++)
        {
            ptl_4X_cmd_t[j].master[m] = NULL;
        }

        for (k = 0; k < MAXSLAVERS; k++)
        {
            ptl_4X_cmd_t[j].cmd_info[k].slaver = NULL;
            ptl_4X_cmd_t[j].cmd_info[k].master = NULL;
            ptl_4X_cmd_t[j].cmd_info[k].cmd_flag = 0;
            ptl_4X_cmd_t[j].cmd_info[k].wr_type = 0;
            ptl_4X_cmd_t[j].cmd_info[k].ptl_update = NULL;
            ptl_4X_cmd_t[j].cmd_info[k].address_start = set_ptl[j].min_address;   //协议最大地址
            ptl_4X_cmd_t[j].cmd_info[k].address_end = set_ptl[j].max_address;     //协议最小地址
            ptl_4X_cmd_t[j].cmd_info[k].address_min = set_ptl[j].min_address;     //协议最小地址
            ptl_4X_cmd_t[j].cmd_info[k].address_max = set_ptl[j].max_address;     //协议最大地址
            ptl_4X_cmd_t[j].cmd_info[k].clientID = 0;
        }
    }

    //每个4x协议的主从站赋值
    for (i = 0; i < ptl_4X_cmd_num; ++i)
    {
        MB_SLAVER_T *mb_slaver = mb_slaver_tab.head;
        for (j = 0; j < mb_slaver_tab.num; ++j)
        {
            for (k = 0; (mb_slaver->protocol[k] != NULL) && (k < mb_slaver->protocol_num); k++)
            {
                if((ptl_4X_cmd_t[i].protocol->dev_code == mb_slaver->protocol[k]->dev_code)
                    && (ptl_4X_cmd_t[i].protocol->address == mb_slaver->protocol[k]->address)
                    && (ptl_4X_cmd_t[i].protocol->len == mb_slaver->protocol[k]->len)
                    && (ptl_4X_cmd_t[i].protocol->cmd == mb_slaver->protocol[k]->cmd)
                  )
                {
                    ptl_4X_cmd_t[i].cmd_info[(mb_slaver->index - 1) % MAXSLAVERS].slaver = mb_slaver;
                    if (mb_slaver->index > ptl_4X_cmd_t[i].slaver_num)
                    {
                        ptl_4X_cmd_t[i].slaver_num = mb_slaver->index;
                    }

                    ptl_4X_cmd_t[i].cmd_info[(mb_slaver->index - 1) % MAXSLAVERS].ptl_update = (uint16_t *)malloc((mb_slaver->protocol[k]->ptl_data_num) * sizeof(uint16_t));
                    if ((ptl_4X_cmd_t+i)->cmd_info[(mb_slaver->index - 1) % MAXSLAVERS].ptl_update == NULL)
                    {
                        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc (ptl_4X_cmd_t+i)->cmd_info.ptl_update error !\n");
                        exit(EXIT_FAILURE);
                    }
                    memset((ptl_4X_cmd_t+i)->cmd_info[(mb_slaver->index - 1) % MAXSLAVERS].ptl_update, 0, (mb_slaver->protocol[k]->ptl_data_num)*(sizeof(uint16_t)));

                    //注册该数据的modbus主站号
                    uint8_t t = 0, m = 0;
                    MB_MASTER_T *mb_master = mb_master_tab.head;
                    for (t = 0; t < mb_master_tab.num; ++t)
                    {
                        MB_COMM_DEV_T *mb_comm_dev = mb_master->head;
                        int32_t find_ret = 0;
                        for (m = 0; m < mb_master->num; ++m)
                        {
                            if ((mb_comm_dev->dev != NULL)&&(mb_comm_dev->dev == mb_slaver))
                            {
                                (ptl_4X_cmd_t+i)->cmd_info[(mb_slaver->index - 1) % MAXSLAVERS].master = mb_master;
                                find_ret = 1;
                                break;
                            }
                            mb_comm_dev = mb_comm_dev->next;
                        }

                        if (find_ret)
                        {
                            break;
                        }
                        mb_master = mb_master->next;
                    }
                }
            }
            mb_slaver = mb_slaver->next;
        }
    }

    //创建每个4x包含的测点数据的4x
    for (i = 0; i < ptl_4X_cmd_num; ++i)
    {
        Dev_4Xptl_MapCreat(&set_ptl[i]);    //生成数据属性结构
    }

    //创建每个4x的主站链表
    for (i = 0; i< ptl_4X_cmd_num; i++)
    {
        ptl_4X_cmd_t[i].master_num = 0;
        for (j = 0; j < ptl_4X_cmd_t[i].slaver_num; j++)
        {
            CMD_INFO_T *cmd_info_tmp = &(ptl_4X_cmd_t+i)->cmd_info[j];

            for (k = 0; k < ptl_4X_cmd_t[i].master_num; k++)
            {
                if ((ptl_4X_cmd_t[i].master[k] != NULL)
                    && (cmd_info_tmp != NULL)
                    && (cmd_info_tmp->master->comport.uartid == ptl_4X_cmd_t[i].master[k]->comport.uartid)
                   )
                {
                    break;
                }
            }

            if ((k == (ptl_4X_cmd_t[i].master_num)) && (k < MAX_COM_NUM))
            {
                ptl_4X_cmd_t[i].master[k] = cmd_info_tmp->master;
                ptl_4X_cmd_t[i].master_num++;
                //EMS_LOG(LL_DEBUG, MODULE_C, false, "ptl_id = %d, master_num = %d\n", (ptl_4X_cmd_t+i)->protocol->ptl_id, (ptl_4X_cmd_t+i)->master_num);
            }
        }
    }

    return ret;
}

/****************************************************************************
**modbus协议报文特征逻辑分析
****************************************************************************/
int GrammarAnalysis(int32_t id,uint8_t *rbuf, uint8_t buflen)
{
    int32_t i = 0, length;
    for (i = 0; i < buflen; ++i)
    {
        if ((rbuf[i] == id)&&(8 <=  buflen-i))//报文起始
        {
            if ((rbuf[i+1] == 0x03)||(rbuf[i+1] == 0x04)||(rbuf[i+1] == 0x01))
            {
                if (rbuf[i+2] <=  buflen-5-i)
                {
                    length = rbuf[i+2]+5;
                    memcpy(rbuf,&rbuf[i],length);
                    return length;
                }
                else
                {
                    return -1;
                }
            }
            else if ((rbuf[i+1] == 0x06)||(rbuf[i+1] == 0x10)||(rbuf[i+1] == 0x05))
            {
                length = 8;
                memcpy(rbuf,&rbuf[i],length);
                return length;
            }
            else if ((rbuf[i+1] == 0x83)||(rbuf[i+1] == 0x84)||
                    (rbuf[i+1] == 0x81)||(rbuf[i+1] == 0x86)||
                    (rbuf[i+1] == 0x90)||(rbuf[i+1] == 0x85))
            {
                length = 5;
                memcpy(rbuf,&rbuf[i],length);
                return length;
            }
        }
    }
    return 0;
}

int32_t GetCurrentDevOfNo(uint16_t dev_code, uint16_t index, int32_t *dev_num)
{
    MB_SLAVER_T *mb_slaver = mb_slaver_tab.head;
    int32_t i = 0, count = 0;

    for (i = 0; i < mb_slaver_tab.num; ++i)
    {
        count ++;
        if ((dev_code == mb_slaver->dev_code)&&(index == mb_slaver->index))
        {
            *dev_num = count;
            break;
        }
        mb_slaver = mb_slaver->next;
    }

    return 0;
}

void InsertCommStateQ(uint16_t dev_code, uint16_t index, int32_t flag)
{
    int32_t tmp_value = 0, current_value = 0, devnum = 0;
    int32_t dwCommState = DEV_COMM_NORMAL;

    SDB_GetCommunicationState(&tmp_value);
    current_value = tmp_value;

    GetCurrentDevOfNo(dev_code, index, &devnum);

    if (flag == 0)   //通信异常
    {
        tmp_value |= 1<<devnum;
        dwCommState = DEV_COMM_FAULT;
    }
    else if (flag == 1)
    {
        tmp_value &= ~(1<<devnum);
    }

    if (current_value != tmp_value)
    {
        SDB_SetCommunicationState(&tmp_value);
    }

    POINT_T stPoint = {0, dwCommState, 1};
    ShareRTDB_Update(dev_code, index, &stPoint, 1);
}

void StartCount(MB_MASTER_T *mb_master)
{
    MB_SLAVER_T *tmp_slaver = mb_master->head->dev;

    if (0 == tmp_slaver->callback)
    {
        tmp_slaver->comm_state = 1;
        InsertCommStateQ(tmp_slaver->dev_code, tmp_slaver->index, 0);
    }
}

/*******************************************************************************************
//协议栈收发计数处理
*******************************************************************************************/
void CallCount(MB_MASTER_T *mb_master, MB_SLAVER_T *mb_slaver)
{

    mb_slaver->callback = mb_slaver->callback<COMREE_CNT?mb_slaver->callback+1:mb_slaver->callback;

    if (mb_slaver->callcnt<200)
    {
        mb_slaver->callcnt = mb_slaver->callcnt+1;
    }
    else
    {
        mb_slaver->callcnt = 100;
        mb_slaver->backcnt = (mb_slaver->backcnt)/2;
    }
    //通信异常处理
    if (COMREE_CNT == mb_slaver->callback)
    {
        if (mb_slaver->offline == 0)
        {
            mb_slaver->offline = 1;
            InsertCommStateQ(mb_slaver->dev_code, mb_slaver->index, 0);

            mb_slaver->comm_state = 1;
            if (mb_slaver->backcnt == 0)
            {
                if (mb_slaver->com_type == NET)
                {
                    ModbusClose(mb_master->fd);
                    mb_master->fd = INVALID_VALUE;
                }
                /*else if (mb_slaver->com_type == can)
                {
                    CanClose(mb_master->fd);
                    mb_master->fd = INVALID_VALUE;
                }*/
            }

        }
    }
    else
    {
        if ((mb_slaver->offline == 0)&&(mb_slaver->comm_state == 1))
        {
            mb_slaver->comm_recover = 1;  // 通信恢复
            InsertCommStateQ(mb_slaver->dev_code, mb_slaver->index, 1);

            mb_slaver->comm_state = 0;
            mb_slaver->timing_flag = 1;
        }
    }
}

//接受计数处理
void RevCount(MB_SLAVER_T *mb_slaver)
{
    if (mb_slaver->backcnt < 200)
    {
        mb_slaver->backcnt = mb_slaver->backcnt+1;
    }
    else
    {
        mb_slaver->backcnt = 100;
        mb_slaver->callcnt = (mb_slaver->callcnt)/2;
    }
}
//收发成功计数处理
void BakCount(MB_SLAVER_T *mb_slaver)
{
    mb_slaver->callback = 0;
    mb_slaver->callcnt = 0;
    mb_slaver->backcnt = 0;

    if ((mb_slaver->com_type != NET)&&(mb_slaver->comm_state == 1))
    {
        mb_slaver->offline = 0;
    }

    //mb_slaver->backcnt = mb_slaver->backcnt + 1;

    /*if (mb_slaver->backcnt<200)
    {
        mb_slaver->backcnt = mb_slaver->backcnt+1;
    }
    else
    {
        mb_slaver->backcnt = 100;
        mb_slaver->callcnt = (mb_slaver->backcnt)/2;
    }*/
}

/*********************************************************************
Function name:    static int32_t AnalyModbusTCPMasterRevData(int32_t id,uint8_t *rbuf, MODBUS_PROTOCOL_T *modbus_data)
Description:    TCP报文解析
Calls:            arg 客户端信息
Parameters:     uint8_t *rbuf:接受数据, uint8_t buflen:数据长度,MODBUS_PROTOCOL_T *modbus_data：解析后数据
Return:         -1：数据有误 0：接受正确
*********************************************************************/
static int32_t AnalyModbusTCPMasterRevData(int32_t id, uint8_t *rbuf, MODBUS_PROTOCOL_T *modbus_data)
{
    int32_t ret = 0;
    uint16_t allLength = 0;

    modbus_data->protocolType = rbuf[2] <<8 | rbuf[3];  //协议号
    if (0x00 != modbus_data->protocolType)             //不是modbusTCP协议，丢弃报文
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "this is not modbus, discard it.\n");
        ret = -1;
        return ret;
    }
    allLength = rbuf[4] << 8| rbuf[5];
    modbus_data->id = rbuf[6];
    modbus_data->cmd = rbuf[7];

    switch (modbus_data->cmd)
    {
        case 0x01:
        case 0x02:
        case 0x03:
        case 0x04:
        {
            modbus_data->len = rbuf[8];
            if ((allLength - 3) != modbus_data->len)
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "modbus data len is not same.\n");
                ret = -1;
                return ret;
            }
            modbus_data->data = &rbuf[9];
            break;
        }
        case 0x05:
        case 0x06:
        {
            modbus_data->len = 1;
            modbus_data->data = &rbuf[10];
            modbus_data->address = rbuf[8] << 8 | rbuf[9];
            uint32_t rev_register_data = (rbuf[10] << 8) | rbuf[11];
            if ((modbus_data->cmd == 0x06 && (rev_register_data < 1 || rev_register_data > 250))
                || (modbus_data->cmd == 0x05 && (rev_register_data != 0 && rev_register_data != 0xFF00))
            )
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "register len is wrong.\n");
                ret = -1;
                return ret;
            }
            break;
        }
        case 0x0f:
        case 0x10:
        {
            modbus_data->address = rbuf[8] << 8 | rbuf[9];
            modbus_data->len = ( rbuf[10] << 8 ) | rbuf[11];
            if ((modbus_data->len < 1) || (modbus_data->len > 250))
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "register len is wrong.\n");
                ret = -1;
                return ret;
            }

            break;
        }
    default:
                EMS_LOG(LL_ERROR, MODULE_C, false, "canot support func code:%d.\n", modbus_data->cmd);
                ret = -1;
                return ret;
        break;
    }
    return ret;
}

//主站回复数据解析
//目前支持 0x01 0x03 0x04 0x06 0x10 功能码,其余功能码不支持
static int32_t AnalyModbusRTUMasterRevData(int32_t id, uint8_t *rbuf, uint8_t buflen, MODBUS_PROTOCOL_T *modbus_data)
{
    int32_t ret = 0;

    modbus_data->id = rbuf[0];
    modbus_data->cmd = rbuf[1];

    switch (modbus_data->cmd)
    {
        case 0x03:
        case 0x04:
            modbus_data->len = rbuf[2];
            modbus_data->data = &rbuf[3];
            if ((modbus_data->len < 1)||(modbus_data->len > 250))
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "register len is wrong.\n");
                ret = -1;
            }
            break;
        case 0x01:
        case 0x02:
            modbus_data->len = rbuf[2];
            modbus_data->data = &rbuf[3];
            if ((modbus_data->len < 1)||(modbus_data->len > 250))
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "register len is wrong.\n");
                ret = -1;
            }
                break;
        case 0x06:
        case 0x05:
            modbus_data->address = (rbuf[2] << 8) | rbuf[3];
            modbus_data->len = 1;
            modbus_data->data = &rbuf[4];
            break;
        case 0x10:
            modbus_data->address = (rbuf[2] << 8) | rbuf[3];
            modbus_data->len = (rbuf[4] << 8) | rbuf[5];
            if ((modbus_data->len < 1)||(modbus_data->len > 250))
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "register len is wrong.\n");
                ret = -1;
            }
            break;
        case 0x81:
        case 0x83:
        case 0x84:
        case 0x85:
        case 0x86:
        case 0x90:
            break;
        default:
            ret = 1;
            break;
    }
    return ret;
}

static int32_t AnalyCollectMasterRevData(int32_t id, uint8_t *rbuf, uint8_t buflen, MODBUS_PROTOCOL_T *modbus_data)
{
    int32_t ret = 0;

    modbus_data->id = rbuf[0];
    modbus_data->cmd = rbuf[1];

    switch (modbus_data->cmd)
    {
        case 0x03:
        case 0x04:
            modbus_data->len = rbuf[2];
            modbus_data->data = &rbuf[3];
            if ((modbus_data->len < 1)||(modbus_data->len > 250))
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "register len is wrong.\n");
                ret = -1;
            }
            break;
        case 0x01:
        case 0x02:
            modbus_data->len = rbuf[2];
            modbus_data->data = &rbuf[3];
            if ((modbus_data->len < 1)||(modbus_data->len > 250))
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "register len is wrong.\n");
                ret = -1;
            }
                break;
        case 0x06:
        case 0x05:
            modbus_data->address = (rbuf[2] << 8) | rbuf[3];
            modbus_data->len = 1;
            modbus_data->data = &rbuf[4];
            break;
        case 0x10:
            modbus_data->address = (rbuf[2] << 8) | rbuf[3];
            modbus_data->len = (rbuf[4] << 8) | rbuf[5];
            if ((modbus_data->len < 1)||(modbus_data->len > 250))
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "register len is wrong.\n");
                ret = -1;
            }
            break;
        case 0x81:
        case 0x83:
        case 0x84:
        case 0x85:
        case 0x86:
        case 0x90:
            break;
        default:
            ret = 1;
            break;
    }
    return ret;
}

//判断回复报文是否合法
static int32_t ResponseIsOk(MODBUS_CMD_T *cmd_t, MODBUS_PROTOCOL_T *modbus_data)
{
    if ((modbus_data->cmd == 0x03) || (modbus_data->cmd == 0x04))
    {
        if ((cmd_t->registerCount != (modbus_data->len/2))||(cmd_t->id!=modbus_data->id)||(cmd_t->cmd!=modbus_data->cmd))
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "03/04 is not match.\n");
            return -1;
        }
    }
    else if ((modbus_data->cmd == 0x01) || (modbus_data->cmd == 0x02))
    {
        int32_t tmplen = ((cmd_t->registerCount) % 8 == 0) ? (cmd_t->registerCount / 8) : (cmd_t->registerCount / 8 + 1);
        if ((tmplen != modbus_data->len) || (cmd_t->id != modbus_data->id) || (cmd_t->cmd != modbus_data->cmd))
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "cmd:0x%2x is not match. tmplen:%d, len:%d\n", modbus_data->cmd, tmplen, modbus_data->len);
            return -1;
        }
    }
    else if ((modbus_data->cmd == 0x10)||(modbus_data->cmd == 0x06)||(modbus_data->cmd == 0x05))
    {
        if ((cmd_t->registerCount!=modbus_data->len)||(cmd_t->id!=modbus_data->id)|| (cmd_t->cmd!=modbus_data->cmd) || (cmd_t->address!=modbus_data->address))
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "05/06/10 is not match.\n");
            return -1;
        }
    }
    else if ((modbus_data->cmd == 0x86)||(modbus_data->cmd == 0x90)||(modbus_data->cmd == 0x81)||
            (modbus_data->cmd == 0x82)||(modbus_data->cmd == 0x83)||(modbus_data->cmd == 0x84)||(modbus_data->cmd == 0x85))
    {
        if (modbus_data->cmd == 0x86 || modbus_data->cmd == 0x90)
        {
            int i = 0;
            for (i = 0; i< cmd_t->buf_len;i++)
            {
                EMS_LOG(LL_DEBUG, MODULE_C, false, "0x%0x", cmd_t->data[i]);
            }
        }

        if ((cmd_t->id!=modbus_data->id)||((cmd_t->cmd + 0x80)!=modbus_data->cmd))
        {
            EMS_LOG(LL_DEBUG, MODULE_C, false, "cmd_t->cmd = 0x%0x, modbus_data->cmd = 0x%0x", cmd_t->cmd, modbus_data->cmd);
            EMS_LOG(LL_ERROR, MODULE_C, false, "86/90/81/83/84/85 is not match.\n");
            return -1;
        }
    }
    else
    {
        if ((cmd_t->registerCount!=modbus_data->len)||(cmd_t->id!=modbus_data->id)||(cmd_t->cmd!=modbus_data->cmd))
        {
            return -1;
        }
    }

    return 0;
}

// 0x030x04 process
//从缓冲区读数据,处理后存入全局变量数组
static int32_t Rev_0x030x04CmdPro(int32_t id, uint8_t cmd, uint8_t *data, MB_SLAVER_T *mb_slaver, uint32_t address, uint8_t inbuflen, PROTOCOL_DATA_T *protocol_data, uint32_t *map, uint8_t byte_seq, uint8_t word_seq)
{
    uint32_t i = 0, j = 0, idx = 0;
    uint8_t data_sign = 0, fifo_ptr = 0;
    int32_t ret = 0, tmp32 = 0, end_address = 0;
    uint16_t data_len = 0;
    uint8_t index = mb_slaver->index;
    DEV_DATA_T fifo_wdata[MAX_FIFO_DATA_NUM];
    POINT_T stPoint;

    end_address = address + inbuflen;
    memset(fifo_wdata, 0, MAX_FIFO_DATA_NUM * sizeof(DEV_DATA_T));
    memset(&stPoint, 0, sizeof(POINT_T));

    if (id != mb_slaver->cslave_id)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "id not match.\n");
        return -1;
    }
    for (i = address,j = 0; i < end_address; i++)
    {
        idx = map[i];

        if (idx == 0xffffffff)
        {
            j+=2;
            continue;
        }

        data_sign = protocol_data[idx].data_sign;
        data_len = protocol_data[idx].data_len;

        if (data_len == 2)
        {
            if (data_sign == SIGN_S)
            {
                tmp32 = GetS16(byte_seq, &data[j]);
            }
            else if (data_sign == SIGN_U)
            {
                tmp32 = GetU16(byte_seq, &data[j]);
            }

            j+=2;
        }
        else
        {
            if (data_sign == SIGN_S)
            {
                tmp32 = GetS32(word_seq, byte_seq, &data[j]);
            }
            else if (data_sign == SIGN_U)
            {
                tmp32 = GetU32(word_seq, byte_seq, &data[j]);
            }

            j += 4;
            i += 1;
        }

        uint8_t flag = 0;
        if (data_sign == SIGN_S)
        {
            if (protocol_data[idx].low_limit1 == 0 && protocol_data[idx].high_limit1 == 0)
            {
                if ((tmp32 >= protocol_data[idx].low_limit)&&(tmp32 <= protocol_data[idx].high_limit))
                {
                    flag = 1;
                }
            }
            else
            {
                if (((tmp32 >= protocol_data[idx].low_limit)&&(tmp32 <= protocol_data[idx].high_limit)) ||
                ((tmp32 >=protocol_data[idx].low_limit1)&&(tmp32 <= protocol_data[idx].high_limit1)))
                {
                    flag = 1;
                }
            }
        }
        else if (data_sign == SIGN_U)
        {
            if ((uint32_t)protocol_data[idx].low_limit1 == 0 && (uint32_t)protocol_data[idx].high_limit1 == 0)
            {
                if ((tmp32 >= (uint32_t)protocol_data[idx].low_limit)&&(tmp32 <= (uint32_t)protocol_data[idx].high_limit))
                {
                    flag = 1;
                }
            }
            else
            {
                if (((tmp32 >= (uint32_t)protocol_data[idx].low_limit)&&(tmp32 <= (uint32_t)protocol_data[idx].high_limit)) ||
                ((tmp32 >= (uint32_t)protocol_data[idx].low_limit1)&&(tmp32 <= (uint32_t)protocol_data[idx].high_limit1)))
                {
                    flag = 1;
                }
            }
        }

        int16_t data_id = protocol_data[idx].data_id;
        uint32_t id_index = mb_slaver->map_id[data_id];

        if (flag == 1)
        {
            //所有数据更新到sdb
            stPoint.dPointValue = mb_slaver->data[id_index].s32;

            if (protocol_data[idx].data_type == U_INT_T)
            {
                stPoint.ucDataType = U_INT_T;
                stPoint.dPointValue = stPoint.unDataValue.u32 = tmp32;
            }
            else if (protocol_data[idx].data_type == S_INT_T)
            {
                stPoint.ucDataType = S_INT_T;
                stPoint.dPointValue = stPoint.unDataValue.s32 = tmp32;
            }
            else if (protocol_data[idx].data_type == FLOAT_T)
            {
                stPoint.ucDataType = FLOAT_T;
                stPoint.dPointValue = stPoint.unDataValue.s32 = tmp32;
            }

            if (SDB_GetUseCoeffFlag() == TRUE
                && ((protocol_data[idx].coefficient > 0.0 && protocol_data[idx].coefficient < 1.0)
                    || (protocol_data[idx].unitCoefficient != 1.0))
               )
            {
                stPoint.ucDataType = FLOAT_T;
                stPoint.dPointValue = stPoint.unDataValue.f32 = tmp32 * protocol_data[idx].coefficient * protocol_data[idx].unitCoefficient;
            }

            stPoint.iPointId = protocol_data[idx].data_id;
            stPoint.uiTicks = GetTickCount();
            ShareRTDB_Update(mb_slaver->dev_code, index, &stPoint, 1);

            if (data_sign == SIGN_S)
            {
//                 if (mb_slaver->data[id_index].s32!= tmp32)//和上次数据相等则不更新
                {
                    mb_slaver->data[id_index].s32 = tmp32;
                }
//                 else
//                 {
//                     continue;
//                 }
            }
            else if (data_sign == SIGN_U)
            {
                //和上次数据相等则不更新
//                 if (mb_slaver->data[id_index].u32!= tmp32)
//                 {
                    mb_slaver->data[id_index].u32 = tmp32;
//                 }
//                 else
//                 {
//                     continue;
//                 }
            }

            //数据接收处理完成，从全局变量导入到输出缓冲区，准备输出
            if (data_sign == SIGN_U)
            {
                fifo_wdata[fifo_ptr].value.data.u32 = mb_slaver->data[id_index].u32;
                fifo_wdata[fifo_ptr].data_type = U_INT_T;
            }
            else if (data_sign == SIGN_S)
            {
                fifo_wdata[fifo_ptr].value.data.s32 = mb_slaver->data[id_index].s32;
                fifo_wdata[fifo_ptr].data_type = S_INT_T;
            }

            fifo_wdata[fifo_ptr].moduleID = MODULE_C;
            fifo_wdata[fifo_ptr].data_id = protocol_data[idx].data_id;
            fifo_wdata[fifo_ptr].index = index;
            fifo_wdata[fifo_ptr].dev_code = mb_slaver->dev_code;

            if (SDB_GetUseCoeffFlag() == TRUE)
            {
                fifo_wdata[fifo_ptr].data_type = stPoint.ucDataType;
                fifo_wdata[fifo_ptr].value.data.f32 = stPoint.unDataValue.f32;
            }

            EMS_LOG(LL_DEBUG, MODULE_C, false, "-Rev_0x030x04CmdPro-fifo_ptr=%d, index=%d, dev_code=%d, data_id=%d, data_type=%d data--u32=%u, s32=%d float=%f.\n",
                    fifo_ptr, fifo_wdata[fifo_ptr].index, fifo_wdata[fifo_ptr].dev_code, fifo_wdata[fifo_ptr].data_id,fifo_wdata[fifo_ptr].data_type,
                    fifo_wdata[fifo_ptr].value.data.u32, fifo_wdata[fifo_ptr].value.data.s32, fifo_wdata[fifo_ptr].value.data.f32);
            fifo_ptr ++;
        }
        else
        {
            ret = -1;
        }
    }

    if (!Q_FULL(dataInQ))
    {
        if (fifo_ptr > 0)
        {
            Q_INSERT_WAIT_N(dataInQ, fifo_wdata, fifo_ptr);
        }
    }
    else
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "dataInQ is full!.\n");
    }

    return ret;
}

//从缓冲区读数据,处理后存入全局变量数组
static int32_t Rev_0x01CmdPro(uint8_t *data,  MB_SLAVER_T *mb_slaver, uint32_t address, uint16_t inbuflen, PROTOCOL_DATA_T *protocol_data, uint32_t *map)
{
    uint32_t idx = 0;
    uint32_t i = 0, end_address;
    uint8_t fifo_ptr = 0;
    int32_t ret = 0;
    uint32_t data_idx = 0, data_offset = 0;
    uint8_t index = mb_slaver->index;
    DEV_DATA_T fifo_wdata[MAX_FIFO_DATA_NUM];

    memset(fifo_wdata, 0, MAX_FIFO_DATA_NUM*sizeof(DEV_DATA_T));
    end_address = address + inbuflen;

    for (i = address; i < end_address; i++)
    {
        uint32_t tmp32 = 0;

        idx = map[i];

        if (idx == 0xffffffff)
        {
            continue;
        }



        data_idx = (i-address)/8;
        data_offset = (i-address)%8;

        tmp32 = GetBitValue(data[data_idx], data_offset);
        /*
        uint8_t data_type = protocol_data[idx].data_type;
        for (k = 0; k < data_type; ++k)
        {
            tmp32|=((uint32_t)((data[data_idx+k]<<data_offset)|(data[data_idx+1+k]>>(8-data_offset)))<<(8*k));
        }*/

        int16_t data_id = protocol_data[idx].data_id;

        uint32_t id_index = mb_slaver->map_id[data_id];

        if (mb_slaver->data[id_index].u32!=tmp32)//和上次数据相等则不更新
        {
            mb_slaver->data[id_index].u32 = tmp32;

        }
        else
        {
            continue;
        }

        //数据接收处理完成，从全局变量导入到输出缓冲区，准备输出
        fifo_wdata[fifo_ptr].value.data.u32 = mb_slaver->data[id_index].u32;
        fifo_wdata[fifo_ptr].data_type = U_INT_T;
        fifo_wdata[fifo_ptr].moduleID = MODULE_C;
        fifo_wdata[fifo_ptr].data_id = protocol_data[idx].data_id;
        fifo_wdata[fifo_ptr].index = index;
        fifo_wdata[fifo_ptr].dev_code = mb_slaver->dev_code;

        EMS_LOG(LL_DEBUG, MODULE_C, false, "-Rev_0x01CmdPro-fifo_ptr=%d, fifo_wdata[fifo_ptr].index=%d, fifo_wdata[fifo_ptr].dev_code=%d, fifo_wdata[fifo_ptr].data_id=%d,	  fifo_wdata[fifo_ptr].data--u32=%d, s32%d float=%f  \n",
                fifo_ptr, fifo_wdata[fifo_ptr].index, fifo_wdata[fifo_ptr].dev_code, fifo_wdata[fifo_ptr].data_id,
                fifo_wdata[fifo_ptr].value.data.u32, fifo_wdata[fifo_ptr].value.data.s32, fifo_wdata[fifo_ptr].value.data.f32);

        fifo_ptr++;
    }

    if (fifo_ptr)
    {
        //完成报文接收处理，输出
        if (!Q_FULL(dataInQ))
        {
            SDB_SetRegisterValue(fifo_wdata, fifo_ptr);
            Q_INSERT_WAIT_N(dataInQ, fifo_wdata, fifo_ptr);
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "dataInQ is full!.\n");
        }

    }
    return ret;
}

//04 03 01命令接收报文处理
static int32_t SlaverRev(int32_t id, MB_SLAVER_T *mb_slaver, MODBUS_CMD_T *cmd_t, uint8_t *inbuf)
{
    int32_t ret;
    uint16_t i = 0;
    PROTOCOL_DATA_T *protocol_data_t;
    uint32_t *map_t = NULL;
    PROTOCOL_T *protocol_t = mb_slaver->protocol[0];

    for (i = 0; (protocol_t != NULL) && (i < mb_slaver->protocol_num); )             //maxm  10 最大协议数量
    {
        if ((mb_slaver->cslave_id == id)
            && (cmd_t->id == id)
            && (cmd_t->id == mb_slaver->cslave_id)
            && (cmd_t->cmd == protocol_t->cmd))  //站号和地址类型符合
        {
            if (((cmd_t->address + cmd_t->registerCount) < (protocol_t->address + protocol_t->len))
                && (cmd_t->address >= protocol_t->address -1))                      //地址符合范围
            {
                protocol_data_t = protocol_t->protocol_data;                     //找到协议点表
                map_t = protocol_t->map;
                ret = 0;
                break;
            }
            else
            {
                ret = -1;
            }
        }
        i++;
        protocol_t = mb_slaver->protocol[i];
    }

    if (protocol_t == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "protocol_t is  NULL\n");
        return -1;
    }
    if (i == mb_slaver->protocol_num)
    {
        return -1;
    }

    //接收数据处理,填入全局数组
    if ((cmd_t->cmd == 0x01) || (cmd_t->cmd == 0x02))
    {
        ret = Rev_0x01CmdPro(inbuf, mb_slaver, cmd_t->address, cmd_t->registerCount, protocol_data_t, map_t);
    }
    else
    {
        ret = Rev_0x030x04CmdPro(id, cmd_t->cmd, inbuf, mb_slaver, cmd_t->address, cmd_t->registerCount, protocol_data_t, map_t, protocol_t->byte_seq, protocol_t->word_seq);
    }
    return ret;
}

//判断命令是否为循环扫描命令
static int32_t QueueSIsCyc(MODBUS_CMD_T *cmd_t)
{
    if (cmd_t->cyc == 1)
    {
        return 0;
    }
    else
    {
        return -1;
    }
}

/******************************************************************************
 * Function       : CollectMasterRevPro
 * Author         : maxm
 * Date           : 2021.08.06
 * Description    : ModbusRTUMaster数据解析,处理,回复
 * Calls          : None
 * Input          : inbuf: 接收报文, inlen:接收报文长度,mb_slaver:通信句柄
 * Output         : None
 * Return         : None
 *******************************************************************************/
int32_t CollectMasterRevPro(MB_SLAVER_T *mb_slaver, uintptr_t fd,uint8_t *inbuf, uint16_t inlen, uint8_t scan_prio)
{
    MODBUS_PROTOCOL_T modbus_data = {0};
    int32_t ret = -1;
    MODBUS_CMD_T *cmd_t = &(mb_slaver->send_scan);
    int32_t id = mb_slaver->cslave_id;
    int32_t DLT645_find_data = 0;
    int32_t CJT188_find_data = 0;

    if (0 == strcmp(mb_slaver->name, "SG_METER") || mb_slaver->protocol[0]->ptl_type == DLT645)
    {
        RevCount(mb_slaver);
        DLT645_find_data = ProModbusRevDataFromDlt645(id, inbuf, inlen);
        if (DLT645_find_data < 1)
        {
            EMS_LOG(LL_ERROR, MODULE_C, FALSE, "SG_METER response fail\n");
            return -1;
        }

        BakCount(mb_slaver);
        if (DelQueueS(&(mb_slaver->scan[scan_prio])) == 0)              //查找扫描队列
        {
            SaveDLT645_07_Meter(&inbuf[DLT645_find_data - 1], mb_slaver);
            if (QueueSIsCyc(cmd_t) == SAYYES)                           //是否循环报文，循环报文就加入队列继续通信，不是就通信一次
            {
                PendQueueS(&(mb_slaver->scan[scan_prio]), cmd_t);       //入列
            }
            ret = 0;
        }
    }
    else if(0 == strcmp(mb_slaver->name,"CJT_188") || mb_slaver->protocol[0]->ptl_type == CJT188)
    {
        RevCount(mb_slaver);
        CJT188_find_data = Cjt188RespCheck(fd,inbuf,inlen);
        if (CJT188_find_data < 0)
        {
            EMS_LOG(LL_ERROR, MODULE_C, FALSE, "CJT_188 response fail\n");
            return -1;
        }
        BakCount(mb_slaver);
        if (DelQueueS(&(mb_slaver->scan[scan_prio])) == 0)              //查找扫描队列
        {
            SaveCJT188_Meter(inbuf, mb_slaver);
            if (QueueSIsCyc(cmd_t) == SAYYES)                           //是否循环报文，循环报文就加入队列继续通信，不是就通信一次
            {
                PendQueueS(&(mb_slaver->scan[scan_prio]), cmd_t);       //入列
            }
            ret = 0;
        }
    }

    else
    {
        RevCount(mb_slaver);
        if (mb_slaver->com_type == NET)
        {
            ret = AnalyModbusTCPMasterRevData(id, inbuf, &modbus_data);
        }
        else if (mb_slaver->com_type == UART)
        {
            ret = AnalyModbusRTUMasterRevData(id, inbuf, inlen, &modbus_data);
        }
        else
        {
            ret = AnalyCollectMasterRevData(id, inbuf, inlen, &modbus_data);
        }
        if (ret != 0)
        {
            return -1;
        }

        if (scan_prio >= MAX_SCAN_PRIO)
        {
            return -1;
        }

        ret = -1;
        if (ResponseIsOk(cmd_t, &modbus_data) == SAYYES)
        {
            BakCount(mb_slaver);

            switch (modbus_data.cmd)
            {
                case 0x03:
                case 0x04:
                case 0x01:
                case 0x02:
                    if (DelQueueS(&(mb_slaver->scan[scan_prio])) == 0)             //查找扫描队列
                    {
                        if (modbus_data.data == NULL)
                        {
                            EMS_LOG(LL_ERROR, MODULE_C, false, "modbus_data.data is  NULL\n");
                            return -1;
                        }
                        SlaverRev(id, mb_slaver, cmd_t, modbus_data.data);

                        if (QueueSIsCyc(cmd_t) == SAYYES)                        //是否循环报文，循环报文就加入队列继续通信，不是就通信一次
                        {
                            PendQueueS(&(mb_slaver->scan[scan_prio]), cmd_t);   //入列
                        }
                        ret = 0;
                    }
                    break;

                case 0x83:
                case 0x84:
                case 0x81:

                    if (DelQueueS(&(mb_slaver->scan[scan_prio])) == 0)      //查找扫描队列
                    {
                        if(QueueSIsCyc(cmd_t) == SAYYES)                     //是否循环报文，循环报文就加入队列继续通信，不是就通信一次
                        {
                            PendQueueS(&(mb_slaver->scan[scan_prio]), cmd_t);//入列
                        }
                        ret = 0;
                    }
                    break;
                case 0x05:
                case 0x06:
                case 0x10:
                case 0x0F:
//                     (mb_slaver->MBMCurCmdCtl)(mb_slaver, cmd_t);
                    if (DelQueueS(&(mb_slaver->scancmd)) == 0)
                    {
                        ret = 0;
                    }
                    break;
                case 0x86:
                case 0x90:
                case 0x85:
                    if (DelQueueS(&(mb_slaver->scancmd)) == 0)
                    {
                        ret = 0;
                    }
                    break;
                default:
                    break;
            }
        }
    }
    return ret;
}

//创建扫描命令
static int32_t CreatTcp_0x01_0x03_0x04(uint16_t com_id, PROTOCOL_T *protocol, MODBUS_CMD_T *cmd_t, uint8_t cycflag)
{
    //uint16_t crcdata = 0, k = 0;

    cmd_t->id = com_id;
    cmd_t->cmd = protocol->cmd;
    cmd_t->address = protocol->address - 1;
    cmd_t->registerCount = protocol->len;
    cmd_t->sending = 0;
    cmd_t->priority = 0;
    cmd_t->send_cnt = 0;
    cmd_t->cyc = cycflag;

    /*
    cmd_t->data[k++] = cmd_t->id;
    cmd_t->data[k++] = cmd_t->cmd;
    cmd_t->data[k++] = HIGHBYTE(cmd_t->address);
    cmd_t->data[k++] = LOWBYTE(cmd_t->address);
    cmd_t->data[k++] = HIGHBYTE(cmd_t->registerCount);
    cmd_t->data[k++] = LOWBYTE(cmd_t->registerCount);
*/
    cmd_t->buf_len = 6;

    return 0;
}

//创建扫描命令
static int32_t Creat_0x01_0x03_0x04(uint16_t com_id, PROTOCOL_T *protocol, MODBUS_CMD_T *cmd_t, uint8_t cycflag)
{
    //uint16_t crcdata = 0, k = 0;

    cmd_t->id = com_id;
    cmd_t->cmd = protocol->cmd;
    cmd_t->address = protocol->address - 1;
    cmd_t->registerCount = protocol->len;
    cmd_t->sending = 0;
    cmd_t->priority = 0;
    cmd_t->send_cnt = 0;
    cmd_t->cyc = cycflag;
    /*
    data[k++] = cmd_t->id;
    data[k++] = cmd_t->cmd;
    data[k++] = HIGHBYTE(cmd_t->address);
    data[k++] = LOWBYTE(cmd_t->address);
    data[k++] = HIGHBYTE(cmd_t->registerCount);
    data[k++] = LOWBYTE(cmd_t->registerCount);

    crcdata = GetCRC16(data, k);

    cmd_t->crcdata = crcdata;
    */
    cmd_t->buf_len = 8;

    return 0;
}

//创建16命令 整个点表
static int32_t Creat_0x10_All(MB_SLAVER_T *mb_slaver, PROTOCOL_T *protocol, MODBUS_CMD_T *cmd_t)
{
    uint16_t crcdata = 0, com_id = mb_slaver->cslave_id;
    int k = 0, j = 0, tmp32 =0;
    int16_t tmp16 = 0;
    PROTOCOL_DATA_T *protocol_data_t;
    uint32_t start_address, end_address;

    start_address = protocol->address-1;
    end_address = start_address + protocol->len;

    cmd_t->id = com_id;
    cmd_t->cmd = 0x10;
    cmd_t->address = start_address;
    cmd_t->registerCount = protocol->len;
    cmd_t->sending = 0;
    cmd_t->priority = 0;
    cmd_t->send_cnt = 0;

    cmd_t->data[0] = cmd_t->id;
    cmd_t->data[1] = cmd_t->cmd;
    cmd_t->data[2] = HIGHBYTE(cmd_t->address);
    cmd_t->data[3] = LOWBYTE(cmd_t->address);
    cmd_t->data[4] = 0;
    cmd_t->data[5] = cmd_t->registerCount;
    cmd_t->data[6] = 2*cmd_t->registerCount;

    k = 7;
    protocol_data_t = protocol->protocol_data;

    for (j = start_address; j < end_address; ++j)
    {
        //找到寄存器地址并且赋值
        uint16_t data_id;
        uint32_t *map, idx;
        uint8_t data_type;
        map = protocol->map;

        idx = map[j];
        if (idx == 0xffffffff)
        {
            cmd_t->data[k++] = 0xFF;
            cmd_t->data[k++] = 0xFF;
            continue;
        }

        data_type = protocol_data_t[idx].data_type;
        data_id = protocol_data_t[idx].data_id;

        uint32_t id_index = mb_slaver->map_id[data_id];


        tmp32 = mb_slaver->data[id_index].s32;

        if(data_type == 2)
        {
            tmp16 = (int16_t)tmp32;
            // cmd_t->data[k++] = (uint8_t)((tmp16>>8)&0xFF);
            // cmd_t->data[k++] = (uint8_t)(tmp16&0xFF);
            SetU16(protocol->byte_seq, &cmd_t->data[k], tmp16);
            k += 2;
        }
        else if(data_type == 4)
        {
            //cmd_t->data[k++] = (uint8_t)((tmp32>>8)&0xFF);
            //cmd_t->data[k++] = (uint8_t)(tmp32&0xFF);
            //cmd_t->data[k++] = (uint8_t)((tmp32>>24)&0xFF);
            //cmd_t->data[k++] = (uint8_t)((tmp32>>16)&0xFF);
            SetU32(protocol->word_seq, protocol->byte_seq, &cmd_t->data[k], tmp32);
            k += 4;
            j ++;
        }
    }

    crcdata = GetCRC16(cmd_t->data, k);

    cmd_t->data[k] = LOWBYTE(crcdata);
    cmd_t->data[k+1] = HIGHBYTE(crcdata);
    cmd_t->buf_len = k+2;

    return 0;
}

void Creat_0x05_0x0F(MB_SLAVER_T *mb_slaver, PROTOCOL_T *protocol, uint32_t address_start, uint32_t address_end, int32_t cmd)
{
    int32_t j = 0, k = 0;
    uint32_t start_address = address_start - 1;
    uint32_t end_address = address_end;
    PROTOCOL_DATA_T *protocol_data_t = protocol->protocol_data;
    uint32_t idx;
    uint32_t *map = protocol->map;
    MODBUS_CMD_T cmd_t = {0};
    uint16_t data_id = 0;
    int32_t tmp32 = 0;
    uint16_t crcdata= 0xffff;

    cmd_t.id = mb_slaver->cslave_id;
    cmd_t.cmd = cmd;
    cmd_t.address = start_address;

    for (j = start_address; j < end_address; ++j)
    {
        idx = map[j];

        data_id = protocol_data_t[idx].data_id;
        uint16_t id_index = mb_slaver->map_id[data_id];

        if (protocol_data_t[idx].data_sign == SIGN_U)
        {
            tmp32 = mb_slaver->data[id_index].u32;
        }
        else
        {
            tmp32 = mb_slaver->data[id_index].s32;
        }

        cmd_t.data[k] = tmp32;

        cmd_t.registerCount += 1;

        k += 1;
    }

    if (mb_slaver->com_type == NET)
    {
        cmd_t.buf_len = 7 + 2 * cmd_t.registerCount;
    }
    else
    {
        crcdata = GetCRC16(cmd_t.data, k);
        cmd_t.data[k] = LOWBYTE(crcdata);
        cmd_t.data[k + 1] = HIGHBYTE(crcdata);
        cmd_t.buf_len = k + 2;
    }

    PendQueueS(&(mb_slaver->scancmd), &cmd_t);
    EMS_LOG(LL_WARNING, MODULE_C, FALSE, "Creat_0x05_0x0F protocolType=%d, cmd=%d, address=%d, registerCount=%d, len=%d, data=%u\n",
        cmd_t.protocolType, cmd_t.cmd, cmd_t.address, cmd_t.registerCount, cmd_t.buf_len, cmd_t.data[0]
    );
}

//创建06/16命令
static int32_t Creat_0x06_0x10(MB_SLAVER_T *mb_slaver, MB_MASTER_T *mb_master, PROTOCOL_T *protocol,
                               uint16_t *ptl_update, uint32_t address_start, uint32_t address_end, uint8_t clientID, MODBUS_CMD_T *cmd_t)
{
    uint16_t crcdata = 0, com_id = 0;
    int k = 0, j = 0, tmp32 =0;
    int16_t tmp16 = 0;
    PROTOCOL_DATA_T *protocol_data_t = protocol->protocol_data;
    uint32_t start_address = 0, end_address = 0, start_addr_ptr = 0;
    uint8_t  start_flag = 0;

    printf("%s (L%d)\n", __func__, __LINE__);

    if (!start_flag)
    {
        start_addr_ptr = address_start;
        start_flag = 1;
    }
    start_address = start_addr_ptr-1;
    end_address = address_end;

    if (mb_slaver == NULL)
    {
        return -1;
    }
    else if ((mb_slaver != NULL)&&(mb_master == NULL))
    {
        com_id = mb_slaver->cslave_id;
    }
    else if (mb_master != NULL)
    {
        com_id = 0;
    }

    memset(cmd_t, 0, sizeof(MODBUS_CMD_T));

    cmd_t->id = com_id;
#if MB_CMD_TYPE
    if ((start_address+1) == end_address)
    {
        if (cmd_t->cmd == 0x03)
        {
            cmd_t->cmd = 0x06;
        }
    }
    else
    {
        cmd_t->cmd = 0x10;
    }
#else
    cmd_t->cmd = 0x10;
#endif

    //cmd_t->address = start_address;

    cmd_t->sending = 0;
    cmd_t->priority = 0;
    cmd_t->send_cnt = 0;

    //cmd_t->data[0] = cmd_t->id;
    //cmd_t->data[1] = cmd_t->cmd;
    //cmd_t->data[2] = HIGHBYTE(cmd_t->address);
    //cmd_t->data[3] = LOWBYTE(cmd_t->address);

    //找到寄存器地址并且赋值
    uint16_t data_id;
    uint32_t *map, idx;
    uint16_t ptl_data_num = protocol->ptl_data_num;
    uint16_t data_len;
    map = protocol->map;
    uint8_t cmd_exist = 0;
    for (j = start_address; j < end_address; ++j)
    {
        idx = map[j];
        if (idx >= ptl_data_num)
        {
            if (cmd_exist)
            {
                break;
            }
            else
            {
                start_addr_ptr += 1;
                continue;
            }
        }
        else
        {
            data_id = protocol_data_t[idx].data_id;
            data_len = protocol_data_t[idx].data_len;

            uint32_t id_index = mb_slaver->map_id[data_id];

            if (ptl_update[idx] == 1)
            {
                if (!cmd_exist)
                {
                    cmd_exist = 1;
                    cmd_t->address = start_addr_ptr - 1;
                    //cmd_t->data[2] = HIGHBYTE(cmd_t->address);
                    //cmd_t->data[3] = LOWBYTE(cmd_t->address);
                }

                if (protocol_data_t[idx].data_sign == SIGN_U)
                {
                    tmp32 = mb_slaver->data[id_index].u32;
                }
                else
                {
                    tmp32 = mb_slaver->data[id_index].s32;
                }

                if (data_len == 2)
                {
                    tmp16 = (int16_t)tmp32;

                    // cmd_t->data[k++] = (uint8_t)((tmp16>>8)&0xFF);
                    // cmd_t->data[k++] = (uint8_t)(tmp16&0xFF);
                    //cmd_t->data[0] = tmp16;
                    SetU16(protocol->byte_seq, &cmd_t->data[k], tmp16);

                    k += 2;
                    cmd_t->registerCount += 1;
                    start_addr_ptr += 1;
                }
                else if (data_len == 4)
                {
                    // cmd_t->data[k++] = (uint8_t)((tmp32>>8)&0xFF);
                    // cmd_t->data[k++] = (uint8_t)(tmp32&0xFF);
                    // cmd_t->data[k++] = (uint8_t)((tmp32>>24)&0xFF);
                    // cmd_t->data[k++] = (uint8_t)((tmp32>>16)&0xFF);
                    //cmd_t->data[0] = tmp32;
                    SetU32(protocol->word_seq, protocol->byte_seq, &cmd_t->data[k], tmp32);
                    k += 4;
                    j ++;
                    cmd_t->registerCount += 2;
                    start_addr_ptr += 2;
                }

                ptl_update[idx] = 0;
            }
            else
            {
                if (cmd_exist)
                {
                    break;
                }
                else
                {
                    start_addr_ptr += 1;
                    continue;
                }
            }

        }
    }

    if (!cmd_exist)
    {
        start_addr_ptr = 0;
        start_flag = 0;
        return -1;
    }

    if (cmd_t->cmd == 0x10)
    {
        //cmd_t->data[4] = 0;
        //cmd_t->data[5] = cmd_t->registerCount;
        //cmd_t->data[6] = 2*cmd_t->registerCount;
    }

    if (mb_slaver->com_type == NET)
    {
        cmd_t->buf_len = 7 + 2 * cmd_t->registerCount;
    }
    else
    {
        crcdata = GetCRC16(cmd_t->data, k);
        cmd_t->data[k] = LOWBYTE(crcdata);
        cmd_t->data[k+1] = HIGHBYTE(crcdata);
        cmd_t->buf_len = k+2;
    }

    return 0;
}

//主站03 04扫描命令发送
int32_t CollectMasterScanSend(MB_SLAVER_T *mb_slaver, int32_t indexnum, void *pMbmMaster, uintptr_t fd, uint8_t *scan_prio)
{
    MODBUS_CMD_T *cmd_t = &(mb_slaver->send_scan);
    MB_MASTER_T *mb_master = (MB_MASTER_T*)pMbmMaster;
    int i = 0;
    int ret = 0;
    (mb_slaver->MBMComSendCtl)(mb_slaver);

    for (i = 0; i< MAX_SCAN_PRIO; i++)
    {
        if (PostQueueS(&(mb_slaver->scan[i]), cmd_t, 0) == 0)  //队列为空
        {
            *scan_prio = i;
            break;
        }
    }

    if (i == MAX_SCAN_PRIO)
    {
        return -1;
    }

    if (mb_slaver->com_type == UART)
    {
        if (mb_slaver->protocol[0]->ptl_type == MODBUS)
        {
            ModbusSend((uintptr_t)fd, cmd_t);
        }

        if (mb_slaver->protocol[0]->ptl_type == DLT645)
        {
            CreatMeterSendCmd(mb_slaver->dev_adress, cmd_t);
            ret = DltSend (mb_master->fd, cmd_t->data, cmd_t->buf_len);
        }

        if (mb_slaver->protocol[0]->ptl_type == CJT188)
        {
            Cjt188Send(mb_master->fd, cmd_t);
        }

//         if(flag == 0)
//         {
//             flag = 1;
//             printf("485_Send= %d ret =%d\n",send_485,ret);
//             if(send_485 < 1000)
//             {
//                 send_485++;
//             }
//
//         }
    }
    else if (mb_slaver->com_type == CAN)
    {
        CanSend(fd, cmd_t);
    }
    else if (mb_slaver->com_type == NET)
    {
        //printf("=03040304=cmd_t->id=%d==cmd_t->cmd=%d===cmd_t->address=%d===registerCount=%d=====\n"
        //,cmd_t->id,cmd_t->cmd,cmd_t->address,cmd_t->registerCount);
        ModbusSend((uintptr_t)fd, cmd_t);
        __sync_add_and_fetch(&g_PlatStic.sendCmdFromSelfCntClctr, 1);
    }
    else if(mb_slaver->com_type == SG_METER)
    {
        CreatMeterSendCmd(mb_slaver->dev_adress, cmd_t);
        ret = DltSend (mb_master->fd, cmd_t->data, cmd_t->buf_len);
        if(flag == 0)
        {
            flag = 1;
            printf("485_Send= %d ret =%d\n",send_485,ret);
            if(send_485 < 1000)
            {
                send_485++;
            }

        }

    }
    else if(mb_slaver->com_type == CJT_188)
    {
        Cjt188Send(mb_master->fd, cmd_t);
    }
    else
    {
        return -1;
    }

    CallCount(mb_master, mb_slaver);			//通信计数处理

    return 0;
}

//主站06 10设置命令发送
int32_t CollectMasterScanCmdSend(MB_SLAVER_T *mb_slaver, void *pMbmMaster, uintptr_t fd)
{
    MODBUS_CMD_T *cmd_t = &(mb_slaver->send_scan);
    MB_MASTER_T *mb_master = (MB_MASTER_T*)pMbmMaster;

    (mb_slaver->MBMComSendCtl)(mb_slaver);

    if (mb_slaver->com_type == CAN)
    {
        return 1;
    }

    if (PostQueueS(&(mb_slaver->scancmd), cmd_t, 0) == 0)       //队列不为空
    {
        if (mb_slaver->com_type == UART)
        {
            ModbusSend(fd, cmd_t);
#ifdef SR_TEST
            int i;
            for(i = 0; i < TEST_NUM; i++)
            {
                if (g_PlatSR[i].u32Tag == cmd_t->u32Tag)
                {
                    gettimeofday(&g_PlatSR[i].sendT, NULL);
                    break;
                }
            }
#endif
        }
        else if (mb_slaver->com_type == NET)
        {
            ModbusSend(fd, cmd_t);
            //printf("=06100610=cmd_t->id=%d==cmd_t->cmd=%d===cmd_t->address=%d===registerCount=%d=====\n"
            //,cmd_t->id,cmd_t->cmd,cmd_t->address,cmd_t->registerCount);
            __sync_add_and_fetch(&g_PlatStic.sendCmdFromTrsmtCntClctr, 1);
#ifdef SR_TEST
            int i;
            for(i = 0; i < TEST_NUM; i++)
            {
                if (g_PlatSR[i].u32Tag == cmd_t->u32Tag)
                {
                    gettimeofday(&g_PlatSR[i].sendT, NULL);
                    break;
                }
            }
#endif
        }

        CallCount(mb_master, mb_slaver);

        return 0;
    }
    return 1;
}

void CreateSetReadCmd(MB_SLAVER_T *mb_slaver, PROTOCOL_T *protocol, uint16_t *ptl_update, uint16_t address_start, uint16_t address_end, uint8_t clientID, MODBUS_CMD_T *cmd_t)
{
    int j = 0;
    uint32_t start_address = address_start -1;
    uint32_t end_address = address_end;
    uint16_t idx;
    uint32_t *map = protocol->map;
    uint8_t read_flag = 0;

    for (j = start_address; j < end_address; ++j)
    {
        idx = map[j];

        if (ptl_update[idx] == 1)
        {
            ptl_update[idx] = 0;
            read_flag = 1;
        }
    }

    //该台设备，只要有一个测点需要读取，读整个csv点表
    if (read_flag == 1)
    {
        cmd_t->wr_type = 1;

        if (mb_slaver->com_type == NET)
        {
            CreatTcp_0x01_0x03_0x04(mb_slaver->cslave_id, protocol, cmd_t, MBM_NONCYC);     //TCP创建命令
        }
        else
        {
            Creat_0x01_0x03_0x04(mb_slaver->cslave_id, protocol, cmd_t, MBM_NONCYC);       //创建命令
        }
    }
}

//接收数据分析，有效数据形成扫描和即时命令入列
int32_t CreateCmd(MB_MASTER_TAB_T *mbm_tab, DEV_DATA_T *inbuf, uint16_t inlen)
{
    uint16_t len = 0, data_id = 0;
    uint32_t tmp_address[4096] = {0};
    uint8_t index = 0;
    DEV_DATA_T *mybuf;
    MODBUS_CMD_T cmd_t={0};
    uint32_t i = 0, j = 0, k = 0, ptl_4X_cmd_num = 0;
    PTL_4X_CMD_T *ptl_4X_cmd_t = NULL;
    CMD_INFO_T *cmd_info;
    uint32_t *map = NULL;
    MB_MASTER_T *mb_master = mbm_tab->head;
    uint16_t dev_code;
    char data_name[128] = {0};
    MB_SLAVER_T *mb_slaver = NULL;
    uint8_t wr_type = 0, clientID = 0;
    uint32_t address_start = 0, address_end = 0;
    uint16_t *ptl_update = NULL;
    uint8_t *cmd_flag = NULL;

    mybuf = (DEV_DATA_T *)inbuf;
    len = inlen / sizeof(DEV_DATA_T);

    //接收数据赋值给全局变量并且生成所有4x点表的接收数据寄存器范围
    for (i = 0; i < len; ++i)
    {
        data_id = mybuf[i].data_id;
        index = mybuf[i].index;
        dev_code = mybuf[i].dev_code;
        wr_type = mybuf[i].wr_type;
        clientID = mybuf[i].moduleID;

        int32_t code_index = 0;
        for (code_index = 0; code_index < modbus_dev.dev_code_num; code_index++)
        {
            if (dev_code == modbus_dev.code_data[code_index].dev_code)
            {
                break;
            }
        }

        if (code_index == modbus_dev.dev_code_num)
        {
            continue;
        }

        if ((data_id == modbus_dev.code_data[code_index].max_data_id + FAULT_DATA_ID_OFFSET)
            && (mybuf[i].value.data.u32 == 1)
           )
        {
            //故障录波处理
            //FaultCmdProcess(dev_code, index);
        }
        else
        {
            if (data_id > modbus_dev.code_data[code_index].max_data_id)
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "data_id(%d) > max_data_id(%d)\n", data_id, modbus_dev.code_data[code_index].max_data_id);
                continue;
            }

            uint32_t id_index = modbus_dev.code_data[code_index].map_id[data_id];

            tmp_address[i] = modbus_dev.code_data[code_index].data[id_index].address;  //求得各设备的相关协议最大和最小寄存器地址

            if (tmp_address[i] == INVALID_VALUE)
            {
                continue;
            }

            ptl_4X_cmd_t = modbus_dev.code_data[code_index].data[id_index].ptl_4X_cmd;
            if (ptl_4X_cmd_t == NULL)
            {
                continue;
            }

            if (index > ptl_4X_cmd_t->slaver_num)
            {
                EMS_LOG(LL_ERROR, MODULE_C, FALSE, "index(%d) > max(%d)\n", index, ptl_4X_cmd_t->slaver_num);
                continue;
            }

            strcpy(data_name, modbus_dev.code_data[code_index].data[id_index].data_name);

            map = ptl_4X_cmd_t->protocol->map;

            if (index == 0)
            {
                address_start = ptl_4X_cmd_t->address_start;
                address_end = ptl_4X_cmd_t->address_end;
                cmd_flag = &(ptl_4X_cmd_t->cmd_flag);
                ptl_update = ptl_4X_cmd_t->ptl_update;
                ptl_4X_cmd_t->clientID = clientID;

                //广播不能读取
                if (wr_type == 1)
                {
                    EMS_LOG(LL_ERROR, MODULE_C, FALSE, "Broadcast canot read.\n");
                    continue;
                }
            }
            else if ((index > 0) && (index <= ptl_4X_cmd_t->slaver_num))
            {
                cmd_info = &(ptl_4X_cmd_t->cmd_info[(index-1)]);
                address_start = cmd_info->address_start;
                address_end = cmd_info->address_end;
                cmd_flag = &(cmd_info->cmd_flag);
                ptl_update = cmd_info->ptl_update;
                cmd_info->wr_type = wr_type;
                cmd_info->clientID = clientID;
            }
            else
            {
                continue;
            }

            if (ptl_update == NULL)
            {
                EMS_LOG(LL_ERROR, MODULE_C, FALSE, "ptl_update is NULL\n");
                exit(EXIT_FAILURE);
            }

            if ((tmp_address[i] != INVALID_VALUE) && (ptl_4X_cmd_t != NULL) )
            {
                if (tmp_address[i] < address_start)
                {
                    address_start = tmp_address[i];
                }
                if (tmp_address[i] > address_end)
                {
                    address_end = tmp_address[i];
                }
            }

            if (address_start <= address_end)//有合法地址落入区间
            {
                *cmd_flag = 1;
                ptl_update[map[tmp_address[i] - 1]] = 1;
            }

            if (index > 0)
            {
                mb_slaver = ptl_4X_cmd_t->cmd_info[index - 1].slaver;
                mb_slaver->data[id_index] = mybuf[i].value.data;              //数据先存起来
            }
            else
            {
                for (j = 0; j < ptl_4X_cmd_t->slaver_num; j++)
                {
                    CMD_INFO_T cmd_info_tmp = ptl_4X_cmd_t->cmd_info[j];

                    if (cmd_info_tmp.slaver == NULL)
                    {
                        break;
                    }
                    else
                    {
                        cmd_info_tmp.slaver->data[id_index] = mybuf[i].value.data;
                    }
                }
            }
        }
    }

    address_start = tmp_address[0];
    address_end = tmp_address[len - 1];
    ptl_4X_cmd_num = modbus_dev.ptl_4X_cmd_num;
    ptl_4X_cmd_t = modbus_dev.ptl_4X_cmd;

    for (i = 0; i < ptl_4X_cmd_num; ++i)
    {
        memset(&cmd_t, 0, sizeof(MODBUS_CMD_T));

        if (ptl_4X_cmd_t[i].cmd_flag == 1)      //广播设置
        {
            ptl_4X_cmd_t[i].cmd_flag = 0;

            MB_SLAVER_T *slaver = ptl_4X_cmd_t[i].cmd_info[0].slaver;

            //遍历该协议点表的所有主站
            if (slaver != NULL)
            {
                EMS_LOG(LL_INFO, MODULE_C, FALSE, "master_num = %d\n", ptl_4X_cmd_t->master_num);

                if ((ptl_4X_cmd_t[i].master[0] != NULL) && (ptl_4X_cmd_t[i].protocol->cmd == 0x03))
                {
                    while(0 == Creat_0x06_0x10(slaver,
                                ptl_4X_cmd_t[i].master[0],
                                ptl_4X_cmd_t[i].protocol,
                                ptl_4X_cmd_t[i].ptl_update,
                                ptl_4X_cmd_t[i].address_start,
                                ptl_4X_cmd_t[i].address_end,
                                ptl_4X_cmd_t[i].clientID,
                                &cmd_t))
                    {
                        for (k = 0; k < ptl_4X_cmd_t[i].master_num; k++)
                        {
                            PendQueueS(&(ptl_4X_cmd_t[i].master[k]->Radcmd), &cmd_t);
                            ptl_4X_cmd_t[i].master[k]->cmd_flag = 1;
                        }
                    }
                }
                ptl_4X_cmd_t[i].address_start = ptl_4X_cmd_t[i].address_max;
                ptl_4X_cmd_t[i].address_end = ptl_4X_cmd_t[i].address_min;
            }
        }
        else                                     //单台设置
        {
            for (j = 0; j < ptl_4X_cmd_t[i].slaver_num; j++)
            {
                CMD_INFO_T *cmd_info_tmp = &(ptl_4X_cmd_t[i].cmd_info[j]);
                if ((address_start > cmd_info_tmp->address_max) || (address_start < cmd_info_tmp->address_min))
                {
                    continue;
                }

                int16_t address_tmp = address_end - cmd_info_tmp->address_max;
                if (address_tmp > 0)
                {
                    address_end = cmd_info_tmp->address_max;

                    if (cmd_info_tmp->cmd_flag == 1)
                    {
                        cmd_info_tmp->cmd_flag = 0;
                        //回读操作
                        if (cmd_info_tmp->wr_type == 1)
                        {
                            cmd_info_tmp->wr_type = 0;

                            if (ptl_4X_cmd_t->protocol->cmd == 0x03)
                            {
                                CreateSetReadCmd(cmd_info_tmp->slaver,
                                        ptl_4X_cmd_t->protocol,
                                        cmd_info_tmp->ptl_update,
                                        cmd_info_tmp->address_start,
                                        cmd_info_tmp->address_end,
                                        cmd_info_tmp->clientID,
                                        &cmd_t);

                                PendQueueS(&(cmd_info_tmp->slaver->scan[HIGH_SCAN_PRIO]), &cmd_t);
                            }
                        }
                        else  /*设置操作*/
                        {
                            if (ptl_4X_cmd_t->protocol->cmd == 0x01)
                            {
                                Creat_0x05_0x0F(cmd_info_tmp->slaver,
                                    ptl_4X_cmd_t[i].protocol,
                                    cmd_info_tmp->address_start,
                                    cmd_info_tmp->address_end,
                                    inbuf[0].cmd);
                            }
                            else
                            {
                                while(0 == Creat_0x06_0x10(cmd_info_tmp->slaver,
                                        NULL,
                                        ptl_4X_cmd_t[i].protocol,
                                        cmd_info_tmp->ptl_update,
                                        address_start,
                                        address_end,
                                        cmd_info_tmp->clientID,
                                        &cmd_t))
                                {
                                    //PendQueueS(&(cmd_info_tmp->slaver->curcmd), &cmd_t);

#ifdef SR_TEST
                                static uint16_t m = 0;
                                cmd_t.u32Tag = g_PlatSR[m].u32Tag;
                                gettimeofday(&g_PlatSR[m].createCmdT, NULL);
                                m++;
#endif
                                    PendQueueS(&(cmd_info_tmp->slaver->scancmd), &cmd_t);               //不入扫描命令队列
                                    __sync_add_and_fetch(&g_PlatStic.createCmdCntClctr, 1);

                                    for (j = 0; j < len; ++j)
                                    {
                                        uint16_t tmp_data_id = mybuf[j].data_id;
                                        uint16_t tmp_dev_code = mybuf[j].dev_code;

                                        int tmp_code_index = 0;
                                        for (tmp_code_index = 0; tmp_code_index < modbus_dev.dev_code_num; tmp_code_index++)
                                        {
                                            if (tmp_dev_code == modbus_dev.code_data[tmp_code_index].dev_code)
                                            {
                                                break;
                                            }
                                        }

                                        if (tmp_code_index == modbus_dev.dev_code_num)
                                        {
                                            continue;
                                        }

                                        uint32_t tmo_id_index = modbus_dev.code_data[tmp_code_index].map_id[tmp_data_id];
                                        memset(&mb_slaver->data[tmo_id_index], 0, sizeof(DATA_U));
                                    }

                                    break;
                                }
                            }
                        }

                        cmd_info_tmp->address_start = cmd_info_tmp->address_min;
                        cmd_info_tmp->address_end = cmd_info_tmp->address_max;
                        if (cmd_info_tmp->master == NULL)
                        {
                            EMS_LOG(LL_ERROR, MODULE_C, false, "cannot find 4x master!");
                        }
                        else
                        {
                            cmd_info_tmp->master->cmd_flag = 1;
                        }

                    }
                    address_start = cmd_info_tmp->address_max + 1;
                    address_end = address_tmp + cmd_info_tmp->address_max;
                    continue;
                }
                else
                {
                    if (cmd_info_tmp->cmd_flag == 1)
                    {
                        cmd_info_tmp->cmd_flag = 0;
                        //回读操作
                        if (cmd_info_tmp->wr_type == 1)
                        {
                            cmd_info_tmp->wr_type = 0;

                            if (ptl_4X_cmd_t[i].protocol->cmd == 0x03)
                            {
                                CreateSetReadCmd(cmd_info_tmp->slaver,
                                        ptl_4X_cmd_t[i].protocol,
                                        cmd_info_tmp->ptl_update,
                                        cmd_info_tmp->address_start,
                                        cmd_info_tmp->address_end,
                                        cmd_info_tmp->clientID,
                                        &cmd_t);

                                PendQueueS(&(cmd_info_tmp->slaver->scan[HIGH_SCAN_PRIO]), &cmd_t);
                            }

                        }
                        else  /*设置操作*/
                        {
                            if (ptl_4X_cmd_t[i].protocol->cmd == 0x01)
                            {
                                Creat_0x05_0x0F(cmd_info_tmp->slaver,
                                    ptl_4X_cmd_t[i].protocol,
                                    address_start,
                                    address_end,
                                    inbuf[0].cmd);
                            }
                            else
                            {
                                while(0 == Creat_0x06_0x10(cmd_info_tmp->slaver,
                                        NULL,
                                        ptl_4X_cmd_t[i].protocol,
                                        cmd_info_tmp->ptl_update,
                                        address_start,
                                        address_end,
                                        cmd_info_tmp->clientID,
                                        &cmd_t))
                                {
                                    //PendQueueS(&(cmd_info_tmp->slaver->curcmd), &cmd_t);
#ifdef SR_TEST
                                static uint16_t m = 0;
                                cmd_t.u32Tag = g_PlatSR[m].u32Tag;
                                gettimeofday(&g_PlatSR[m].createCmdT, NULL);
                                m++;
#endif
                                    PendQueueS(&(cmd_info_tmp->slaver->scancmd), &cmd_t);               //不入扫描命令队列
                                    __sync_add_and_fetch(&g_PlatStic.createCmdCntClctr, 1);

                                    for (j = 0; j < len; ++j)
                                    {
                                        uint16_t tmp_data_id = mybuf[j].data_id;
                                        uint16_t tmp_dev_code = mybuf[j].dev_code;

                                        int tmp_code_index = 0;
                                        for (tmp_code_index = 0; tmp_code_index< modbus_dev.dev_code_num; tmp_code_index++)
                                        {
                                            if (tmp_dev_code == modbus_dev.code_data[tmp_code_index].dev_code)
                                            {
                                                break;
                                            }
                                        }
                                        if (tmp_code_index == modbus_dev.dev_code_num)
                                        {
                                            EMS_LOG(LL_ERROR, MODULE_C, false, "cannot fine dev_code = %d\n", tmp_dev_code);
                                            continue;
                                        }

                                        uint32_t tmo_id_index = modbus_dev.code_data[tmp_code_index].map_id[tmp_data_id];
                                        memset(&mb_slaver->data[tmo_id_index], 0, sizeof(DATA_U));

                                    }

                                    break;
                                }
                            }
                        }

                        cmd_info_tmp->address_start = cmd_info_tmp->address_min;
                        cmd_info_tmp->address_end = cmd_info_tmp->address_max;
                        if (cmd_info_tmp->master == NULL)
                        {
                            EMS_LOG(LL_ERROR, MODULE_C, false, "cannot find 4x master!");
                        }
                        else
                        {
                            cmd_info_tmp->master->cmd_flag = 1;
                        }
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }

            }
        }
    }

    //post cmd send sem
    mb_master = mbm_tab->head;
    for (i = 0; i < mbm_tab->num; ++i)
    {
        if (mb_master->cmd_flag)
        {
            mb_master->cmd_flag = 0;

        }
        mb_master = mb_master->next;
    }
    return 0;
}

/*****************************************************************************************
**主站扫描和命令线程
*****************************************************************************************/

uint16_t Sign2MBM(MB_MASTER_T *mb_master)
{
    MB_COMM_DEV_T *p_dev = mb_master->head;
    MB_SLAVER_T *mb_slaver;
    int32_t j = 0;
    int32_t num = mb_master->num;
    float tmp1 = 0,tmp2 = 0;
    float CommSign = 0;
    DEV_DATA_T fifo_wdata[2];

    memset(fifo_wdata, 0, 2 * sizeof(DEV_DATA_T));

    for (j = 0; j < num; ++j)
    {
        mb_slaver = p_dev->dev;

        tmp1 += (float)(mb_slaver->callcnt);
        tmp2 += (float)(mb_slaver->backcnt);
        p_dev = p_dev->next;
    }

    if (tmp1>1)
    {
        CommSign = (tmp2/tmp1)*5.1;                             //5格信号 5.1向上溢出防抖

        if (mb_master->CommSign != (uint32_t)CommSign)
        {
            fifo_wdata[0].value.data.u32 = (uint32_t)CommSign;
            fifo_wdata[0].data_type = U_INT_T;
            fifo_wdata[0].moduleID = MODULE_C;
            fifo_wdata[0].index = 1;
            fifo_wdata[0].dev_code = 0x705;                      //采集器的设备类型编码
            fifo_wdata[0].data_id = mb_master->comport.uartid;   //最大测点号

            if (!Q_FULL(dataInQ))
            {
                Q_INSERT(dataInQ,fifo_wdata);
            }
            else
            {
                EMS_LOG(LL_INFO, MODULE_C, false, "Q is full!\n");
            }

        }

    }

    return ((uint16_t)CommSign);
}

//定时器初始化
static uint32_t TimerInit(MB_MASTER_T *mb_master)
{
    MB_COMM_DEV_T *p_dev = mb_master->head;
    MB_SLAVER_T *mb_slaver;
    int32_t j = 0;
    int32_t ret = 30000, tmp = 0;

    for (j = 0; j < mb_master->num; ++j)
    {
        mb_slaver = p_dev->dev;
        tmp = mb_slaver->scan_clock.start_delay + mb_slaver->scan_clock.timing;
        if (ret > tmp)
        {
            ret = tmp;
        }

        p_dev = p_dev->next;
    }
    return ret;
}

//查找待扫描设备
static uint32_t FindScanDev(uint32_t tempval_rev, MB_MASTER_T *mb_master)
{
    MB_SLAVER_T *mb_slaver;
    MB_COMM_DEV_T *p_dev, *p_dev_rev, *p_dev_cur = NULL;
    int32_t j = 0;
    int32_t ret = 0, tmp = 0;
    p_dev = mb_master->head;
    p_dev_rev = mb_master->head;

    //遍历主站，只要有高优先级队列不为空的，则返回该台设备 kj_modify
    for (j = 0; j < mb_master->num; j++)
    {
        mb_slaver = p_dev->dev;
        if (IsMbscanEmpty(mb_slaver, HIGH_SCAN_PRIO) == -1)      //不为空，说明有03读取
        {
            ret = mb_slaver->scan_clock.timeout;
            mb_master->scan = mb_slaver;
            return ret;
        }
        p_dev = p_dev->next;
    }

    for (j = 0; j < mb_master->num; ++j)
    {
        mb_slaver = p_dev->dev;
        tmp = mb_slaver->scan_clock.tim_cur - tempval_rev;
        mb_slaver->scan_clock.tim_cur = tmp;

        if (tmp <= 0)
        {
            if (p_dev_cur == NULL)
            {
                mb_slaver->scan_clock.tim_cur = mb_slaver->scan_clock.timing;
                p_dev_cur = p_dev;
                mb_master->scan = mb_slaver;
                //EMS_LOG(LL_DEBUG, MODULE_C, false, "FindScanDev:timing = %d, mb_slaver = %d\n",mb_slaver->scan_clock.timing, mb_slaver);

                //1->2->3->4 to 2->3->4->1 || 1->2->3->4 to 1->3->4->2
                mb_master->end->next = p_dev_cur;
                mb_master->end = p_dev_cur;
                if (p_dev_cur == mb_master->head)
                {
                    mb_master->head = p_dev_cur->next;
                }
                p_dev_rev->next = p_dev_cur->next;
                p_dev_cur->next = mb_master->head;

                p_dev = p_dev_rev;//current dev = last dev //continue to dec dev timout

                ret = mb_slaver->scan_clock.timeout;//dev timeout time
            }
        }
        p_dev_rev = p_dev;
        p_dev = p_dev->next;
    }
    //EMS_LOG(LL_DEBUG, MODULE_C, false, "ind dev = %d\n", p_dev->dev);

    return ret;
}

//定时器更新
static uint32_t TimerUpdate(uint32_t tempval_rev, MB_MASTER_T *mb_master, uint16_t scan_type)
{
    MB_SLAVER_T *mb_slaver;
    MB_COMM_DEV_T *p_dev;

    int32_t j = 0;
    int32_t ret = 60000, tmp = 0;

    p_dev = mb_master->head;

    for (j = 0; j < mb_master->num; ++j)
    {
        mb_slaver = p_dev->dev;
        tmp = mb_slaver->scan_clock.tim_cur - tempval_rev;
        mb_slaver->scan_clock.tim_cur = tmp;

        if (tmp <= 0)
        {
            ret = 0;
        }
        else
        {
            if (ret > tmp)
            {
                ret = tmp;
                if (scan_type)
                {
                    mb_slaver->scan_clock.tim_cur = 5;
                    ret = 5;
                }
            }
        }
        p_dev = p_dev->next;
    }
    return ret;
}

static void printLog(const uint8_t* inbuf, COMMDEV_TYPE_E commType)
{
    if ((commType== NET)||(commType== UART))
    {
        if ((inbuf[7] == ReadHoldingRegister || inbuf[7] == ReadInputRegister)||(inbuf[1] == ReadHoldingRegister || inbuf[1] == ReadInputRegister))
        {
            __sync_add_and_fetch(&g_PlatStic.recvRRespCntClctr, 1);
        }
        else if ((inbuf[7] == WriteSingleRegister || inbuf[7] == WriteMultipleRegister)|| (inbuf[1] == WriteSingleRegister || inbuf[1] == WriteMultipleRegister))
        {
            __sync_add_and_fetch(&g_PlatStic.recvWRespCntClctr, 1);
#ifdef SR_TEST
            int i;
            MODBUS_CMD_T *tmp_cmd = malloc(sizeof(MODBUS_CMD_T));
            PostQueueS(&(scan->scancmd), tmp_cmd, 0);
            for(i = 0; i < TEST_NUM; i++)
            {
                if (g_PlatSR[i].u32Tag == tmp_cmd->u32Tag)
                {
                    gettimeofday(&g_PlatSR[i].respT, NULL);
                    g_PlatSR[i].costMs = g_PlatSR[i].respT.tv_sec * 1000 + g_PlatSR[i].respT.tv_usec / 1000 -
                        g_PlatSR[i].startT.tv_sec * 1000 - g_PlatSR[i].startT.tv_usec / 1000;

                    printf("%s i:%d tag:%d startT:%0.3f, getCmdT:%0.3f, createT:%0.3f, sendT:%0.3f, respT:%0.3f, costMs:%d\n",
                            __func__, i, tmp_cmd->u32Tag,
                            g_PlatSR[i].startT.tv_sec + g_PlatSR[i].startT.tv_usec / 1000000.0,
                            g_PlatSR[i].getCmdT.tv_sec + g_PlatSR[i].getCmdT.tv_usec / 1000000.0,
                            g_PlatSR[i].createCmdT.tv_sec + g_PlatSR[i].createCmdT.tv_usec / 1000000.0,
                            g_PlatSR[i].sendT.tv_sec + g_PlatSR[i].sendT.tv_usec / 1000000.0,
                            g_PlatSR[i].respT.tv_sec + g_PlatSR[i].respT.tv_usec / 1000000.0,
                            g_PlatSR[i].costMs
                        );
                    break;
                }
            }
            free(tmp_cmd);
#endif
        }
    }
    return;
}

static void masterBusLock(IN const MB_MASTER_T* mb_master)
{
    MB_MASTER_T *cur_mb_master = (MB_MASTER_T *)mb_master;

    uint32_t commType = cur_mb_master->comport.commtype;
    if (commType == UART)
    {
        sem_wait(&(cur_mb_master->bus_lock));
    }

    if (commType == CAN)
    {
        sem_wait(&(mb_master_tab.canBusLock));
    }

    return ;
}

static void masterBusUnLock(IN const MB_MASTER_T* mb_master)
{
    MB_MASTER_T *cur_mb_master = (MB_MASTER_T *)mb_master;

    uint32_t commType = cur_mb_master->comport.commtype;
    if (commType == UART)
    {
        sem_post(&(cur_mb_master->bus_lock));
    }

    if (commType == CAN)
    {
        sem_post(&(mb_master_tab.canBusLock));
    }

    return ;
}

static uint32_t closePS(IN const MB_MASTER_T* mb_master)
{
    MB_MASTER_T *cur_mb_master = (MB_MASTER_T *)mb_master;

    uint32_t ret = 0;
    uint32_t commType = cur_mb_master->comport.commtype;
    uintptr_t protocalHandle = cur_mb_master->fd;
    if (commType == CAN)
    {
        ret = CanClose(protocalHandle);
    }
    else if (commType == SG_METER)
    {
        ret = DltClose(protocalHandle);
    }
    else
    {
        if (cur_mb_master->scan != NULL && cur_mb_master->scan->protocol[0]->ptl_type == MODBUS)
        {
            ret = ModbusClose(protocalHandle);
        }

        if (cur_mb_master->scan != NULL && cur_mb_master->scan->protocol[0]->ptl_type == DLT645)
        {
            ret = DltClose(protocalHandle);
        }
    }

    return ret;
}

static uint32_t receiveFromPS(IN const MB_MASTER_T* mb_master, INOUT uint8_t* inbuf, IN uint32_t len)
{
    MB_MASTER_T *cur_mb_master = (MB_MASTER_T *)mb_master;
    uint32_t responseLen = INVALID_VALUE;

    uint32_t commType = cur_mb_master->comport.commtype;
    uintptr_t protocalHandle = cur_mb_master->fd;
    if (commType == CAN)
    {
        responseLen = CanRecv(protocalHandle, inbuf, len);
    }
    else if (commType == SG_METER)
    {
        responseLen = DltRecv(protocalHandle, inbuf);
        if(flag == 1)
        {
            if(responseLen != -1)
            {
                printf("485_RECV = %d  Recvlen = %d！！！\n",recv_485,responseLen);
                if(recv_485 <1000)
                {
                    recv_485++;
                }
                flag = 0;
            }
        }
//react time test //20220803 huangjie
      /*
        static int total_time = 0;
        static int wrong_ = 0;
        int costMs = 0;
        if(flag == 1)
        {
            if(responseLen != -1)
            {
                printf("responseLen = %d接受数据！！！\n",responseLen);
                if(react_time_nmber <10000)
                {
                    gettimeofday(&uartreattime.respT,NULL);
                    costMs = (uartreattime.respT.tv_sec * 1000 +uartreattime.respT.tv_usec / 1000)-
                                (uartreattime.sendT.tv_sec * 1000 +uartreattime.sendT.tv_usec / 1000);
                    total_time = total_time +costMs;
                    printf("sendT:%0.3f,respT:%0.3f,costMs:%d,total_time:%d,react_time_nmber:%d\n",
                        uartreattime.sendT.tv_sec + uartreattime.sendT.tv_usec  / 1000000.0,
                        uartreattime.respT.tv_sec + uartreattime.respT.tv_usec / 1000000.0,
                        costMs,total_time,react_time_nmber);
                    react_time_nmber++;
                }
                flag = 0;



        }
}*/

    }
    else if(commType == CJT_188)
    {
        responseLen = Cjt188Recv(protocalHandle, inbuf);

        //printf("@@@@test\n");
    }
    else
    {
        if (mb_master->scan != NULL && mb_master->scan->protocol[0]->ptl_type == MODBUS)
        {
            responseLen = ModbusRecv(protocalHandle, inbuf);
        }

        if (mb_master->scan != NULL && mb_master->scan->protocol[0]->ptl_type == DLT645)
        {
            responseLen = DltRecv(protocalHandle, inbuf);
        }

        if (mb_master->scan != NULL && mb_master->scan->protocol[0]->ptl_type == CJT188)
        {
            responseLen = Cjt188Recv(protocalHandle, inbuf);
        }

//         if(flag == 1)
//         {
//             if(responseLen != -1)
//             {
//                 printf("485_RECV = %d  Recvlen = %d！！！\n",recv_485,responseLen);
//                 if(recv_485 <1000)
//                 {
//                     recv_485++;
//                 }
//                 flag = 0;
//             }
//         }
    }

    return responseLen;
}

static void travelOneLoopFunc(IN MB_MASTER_T *mb_master, IN MB_SLAVER_T* mb_slaver, IN const int32_t recvTimeout, OUT int16_t* pScanType)
{
    MB_MASTER_T *cur_mb_master = mb_master;
    MB_SLAVER_T *cur_mb_slaver = mb_slaver;

    int32_t ret = 0;
    uint8_t inbuf[260]= {0};
    int16_t inbuf_len = 0;

    BOOL rev_sucessed = FALSE;
    uint8_t scan_prio = HIGH_SCAN_PRIO;

    int32_t tempval_rev = recvTimeout;
    int32_t rev_timeout = 0;
    uint32_t commtype = mb_master->comport.commtype;

    uint32_t start_send = GetTickCount();

    if (tempval_rev == 0 && mb_slaver->protocol[0]->ptl_type == CJT188)
    {
        tempval_rev = 500;//热量表默认超时时间500ms
    }
    /*
    struct timeval tCur;
    gettimeofday(&tCur, NULL);
    long start_send = ((long)tCur.tv_sec) * 1000 + (long)tCur.tv_usec / 1000;
    */
    ret = (cur_mb_master->scan->scancmdfunc)(cur_mb_slaver, cur_mb_master, cur_mb_master->fd);                    //发送外部指令
    if (ret == 0)
    {
        *pScanType = 1;  //cmd
    }
    else
    {
        ret = (cur_mb_master->scan->scanfunc)(cur_mb_slaver, 0, cur_mb_master, cur_mb_master->fd, &scan_prio);   //发送内部采集指令
        *pScanType = 0;
    }

    while(1)
    {
        inbuf_len = receiveFromPS(cur_mb_master, inbuf, 255);
//         printf("inbuf_len=%d \n",inbuf_len);
        if (inbuf_len < 0)
        {
            NanoSleep(10);
        }
        else
        {
            printLog(inbuf, commtype);
            if ((cur_mb_master->scan->readscanfunc)(cur_mb_master->scan, cur_mb_master->fd, inbuf, inbuf_len, scan_prio) == 0)
            {
                rev_sucessed = TRUE;
            }
        }

        uint32_t end_rev = GetTickCount();
        /*
        gettimeofday(&tCur, NULL);
        long end_rev = ((long)tCur.tv_sec) * 1000 + (long)tCur.tv_usec / 1000;
        */
        rev_timeout = tempval_rev - (int32_t)(end_rev - start_send);

        if (rev_timeout < 0)
        {
            rev_timeout = 0;
            rev_sucessed = TRUE;
        }
        if (rev_sucessed)
        {
            break;
        }
    }

    return ;
}

//主站扫描线程
void *CollectMasterScan(void *arg)
{
    MB_MASTER_T *mb_master = (MB_MASTER_T*)arg;

    int32_t ret = 0;
    int32_t tempval_rev = 0;
    int32_t scan_time = TimerInit(mb_master);

    //printf("---------------主站%d Scan 线程启动，开始扫描.   tid=%d..\n", mb_master->index,GetTid());
    uint32_t commtype = mb_master->comport.commtype;
    int32_t tempval_scan = scan_time;
    int16_t scan_type = 0;
    struct timeval tempval;

    prctl(PR_SET_NAME, "CLCT_SCAN_THREAD");

    while(!mb_master->scanThreadIsExit)
    {
        if (mb_master->fd == INVALID_VALUE)
        {
            if (commtype == NET)
            {
                StartCount(mb_master);
            }
            sleep(1);
            continue;
        }

        tempval.tv_sec = tempval_scan / 1000;
        tempval.tv_usec = 1000 * (tempval_scan % 1000);

        select(0, NULL, NULL, NULL, &tempval);

        uint32_t start_send = GetTickCount();

//         struct timeval tCur;
//         static int32_t count = 0;
//         gettimeofday(&tCur, NULL);
//         long start_send2 = ((long)tCur.tv_sec) * 1000 + (long)tCur.tv_usec / 1000;

        pthread_mutex_lock(&(mb_master->mutex));
        tempval_rev = FindScanDev(tempval_scan, mb_master);
        MB_SLAVER_T *scan = mb_master->scan;
        pthread_mutex_unlock(&(mb_master->mutex));

        masterBusLock(mb_master);
        travelOneLoopFunc(mb_master, scan, tempval_rev, &scan_type);
        masterBusUnLock(mb_master);

        uint32_t end_rev = GetTickCount();

//         gettimeofday(&tCur, NULL);
//         long end_rev2 = ((long)tCur.tv_sec) * 1000 + (long)tCur.tv_usec / 1000;
//         printf("count:%d costMs:%ld\n", count, end_rev2 - start_send2);
//         count++;

        tempval_scan = (scan_type == 1) ? scan_time : (uint32_t)(end_rev - start_send);

        tempval_scan = TimerUpdate(tempval_scan, mb_master, scan_type);          //next scantime update

    }

    ret = closePS(mb_master);

    printf("%s CLCT_SCAN_THREAD(commtype:%d) exit(%d). \n", __func__, commtype, ret);
    pthread_exit(NULL);
}


uint8_t DLT645_DataCheck(uint8_t *buf, uint8_t buflen)
{
    uint16_t sum = 0;
    uint8_t i = 0;
    for (i = 0; i < buflen; i++)
    {
        sum = sum + buf[i];
    }
    while (sum > 0xFF)
    {
        sum = sum - 256;
    }
    return (sum & 0xFF);
}

void CreatTcpMeterScan(uint8_t *meterAddr, uint16_t com_id, PROTOCOL_T *protocol, MODBUS_CMD_T *cmd_t, uint8_t cycflag)
{
    uint16_t k = 0;
    uint32_t meterCmd;

    meterCmd = 0;
    cmd_t->id = com_id;
    cmd_t->cmd = protocol->cmd;

    cmd_t->address = 0;
    cmd_t->registerCount = 1;
    cmd_t->sending = 0;
    cmd_t->priority = 0;
    cmd_t->send_cnt = 0;
    cmd_t->cyc = cycflag;
    meterCmd = protocol->dlt645_07cmd;
    cmd_t->data[k++] = 0x68;
    cmd_t->data[k++] = meterAddr[5];
    cmd_t->data[k++] = meterAddr[4];
    cmd_t->data[k++] = meterAddr[3];
    cmd_t->data[k++] = meterAddr[2];
    cmd_t->data[k++] = meterAddr[1];
    cmd_t->data[k++] = meterAddr[0];
    cmd_t->data[k++] = 0x68;
    cmd_t->data[k++] = 0x11;
    cmd_t->data[k++] = 0x04;

    cmd_t->data[k++] =  (meterCmd & 0xFF) + 0x33;
    cmd_t->data[k++] = ((meterCmd >> 8) & 0xFF) + 0x33;
    cmd_t->data[k++] = ((meterCmd >>16) & 0xFF) + 0x33;
    cmd_t->data[k++] = ((meterCmd >>24) & 0xFF) + 0x33;
    cmd_t->data[k++] = DLT645_DataCheck(cmd_t->data, 14);
    cmd_t->data[k++] = 0x16;
    cmd_t->buf_len = k;
}

void CreatMeterScan(uint8_t *meterAddr, uint16_t com_id, PROTOCOL_T *protocol, MODBUS_CMD_T *cmd_t, uint8_t cycflag)
{
    cmd_t->id = com_id;
    cmd_t->cmd = protocol->cmd;
    cmd_t->ctrlcmd = protocol->ctrlcmd;
    cmd_t->address = protocol->protocol_data[0].datacode;
    cmd_t->registerCount = 0;
    cmd_t->sending = 0;
    cmd_t->priority = 0;
    cmd_t->send_cnt = 0;
    cmd_t->cyc = cycflag;
}

void SendMeterDataToServerProcessActiveP(MB_SLAVER_T *mb_slaver, uint32_t *pbuf, uint32_t type)
{
    uint8_t fifo_ptr = 0;
    uint16_t i = 0, j = 0;
    DEV_DATA_T fifo_wdata[MAX_FIFO_DATA_NUM];

    memset(fifo_wdata, 0, MAX_FIFO_DATA_NUM * sizeof(DEV_DATA_T));
    for (i = 0; i < mb_slaver->protocol_num; i++)
    {
        if (mb_slaver->protocol[i]->dlt645_Re_cmd == type)
        {
            for (j = 0; j < mb_slaver->protocol[i]->ptl_data_num; j++)
            {
                PROTOCOL_DATA_T *protocol_data = &(mb_slaver->protocol[i]->protocol_data[j]);

                fifo_wdata[fifo_ptr].dev_code = mb_slaver->dev_code;
                fifo_wdata[fifo_ptr].index = mb_slaver->index;
                fifo_wdata[fifo_ptr].data_id = protocol_data->data_id;
                fifo_wdata[fifo_ptr].moduleID = MODULE_C;

                if (protocol_data->data_sign == SIGN_U)
                {
                    fifo_wdata[fifo_ptr].data_type = U_INT_T;
                    fifo_wdata[fifo_ptr].value.data.u32 = pbuf[j];
                    //fifo_wdata[fifo_ptr].data.u32 = 1;
                }
                else if (protocol_data->data_sign == SIGN_S)
                {
                    fifo_wdata[fifo_ptr].data_type = S_INT_T;
                    fifo_wdata[fifo_ptr].value.data.s32 = pbuf[j];
                    //fifo_wdata[fifo_ptr].data.s32 = 1;
                }
                else
                {
                    fifo_wdata[fifo_ptr].data_type = FLOAT_T;
                    //fifo_wdata[fifo_ptr].data.f32 = pbuf[j];
                    fifo_wdata[fifo_ptr].value.data.f32 = ((float32_t)pbuf[j]/100);
                }

                fifo_ptr++;
            }

            if (!Q_FULL(dataInQ))
            {
                if (fifo_ptr > 0)
                {
                    SDB_SetRegisterValue(fifo_wdata, fifo_ptr);

                    Q_INSERT_WAIT_N(dataInQ, fifo_wdata, fifo_ptr);
                }
            }
            else
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "Q is full!\n");
            }

            break;
        }
    }
}

void SaveCJT188_Meter(uint8_t *pbuf,MB_SLAVER_T *mb_slaver)
{
    uint8_t i=0, k=0;
    uint32_t type = (pbuf[11] << 8)|pbuf[12];
    uint32_t  tempNum[20] = {0};     //每一个类型对应值
    //uint8_t j = 0;
    switch(type)
    {
        case 0x1f90:
            i=20;//第20个数据为数据域,从数据域开始转10进制
            for(k=0;k<pbuf[10]-6-3;k++)//数据长度为目前总数据长度-填充的时间戳长度(6)-数据标识符(2)-控制码(1)。
            {
                pbuf[i]=((pbuf[i]>>4)*10)+(pbuf[i]&0xF);//转10进制
                i++;
            }
            tempNum[0] =(float32_t)(pbuf[23]*1000000+pbuf[22]*10000+pbuf[21]*100+pbuf[20]);
            tempNum[1] =(float32_t)(pbuf[28]*1000000+pbuf[27]*10000+pbuf[26]*100+pbuf[25]);
            tempNum[2] =(float32_t)(pbuf[33]*1000000+pbuf[32]*10000+pbuf[31]*100+pbuf[30]);
            tempNum[3] =(float32_t)(pbuf[38]*1000000+pbuf[37]*10000+pbuf[36]*100+pbuf[35]);
            tempNum[4] =(float32_t)(pbuf[43]*1000000+pbuf[42]*10000+pbuf[41]*100+pbuf[40]);
            tempNum[5] =(float32_t)(pbuf[47]*10000+pbuf[46]*100+pbuf[45]);
            tempNum[6] =(float32_t)(pbuf[50]*10000+pbuf[49]*100+pbuf[48]);
            tempNum[7] =(float32_t)(pbuf[53]*10000+pbuf[52]*100+pbuf[51]);
            tempNum[8] =(float32_t)(pbuf[57]*1000000+pbuf[56]*10000+pbuf[55]*100+pbuf[54]);
            tempNum[9] =(float32_t)(pbuf[60]*10000+pbuf[59]*100+pbuf[58]);
            tempNum[10] =(float32_t)(pbuf[61]*100+pbuf[62]);
            break;
           //for (j = 0; j < mb_slaver->protocol[0]->ptl_data_num; j++)
           //{
                /*switch(mb_slaver->protocol[0]->protocol_data[j].data_len)
                {
                    case 0x01:
                        tempNum[j] = (float32_t)pbuf[i];
                        i=i+1;
                        break;
                    case 0x03:
                        tempNum[j] = (float32_t)(pbuf[i+2]*10000+pbuf[i+1]*100+pbuf[i])/100;
                        //printf("pbuf[i+2]=%d pbuf[i+1]=%d pbuf[i]=%d j=%d\n",pbuf[i+2],pbuf[i+1],pbuf[i],j);
                        //printf("pbuf[i+2]*10000+pbuf[i+1]*100+pbuf[i]=%d",pbuf[i+2]*10000+pbuf[i+1]*100+pbuf[i]);
                        //printf("\n");
                        i=i+3;
                        break;
                    case 0x04:
                        tempNum[j] = (float32_t)(pbuf[i+3]*1000000+pbuf[i+2]*10000+pbuf[i+1]*100+pbuf[i])/100;
                        i=i+4;
                        break;
                    case 0x05://5个字节其中一个字节是单位
                        tempNum[j] = (float32_t)(pbuf[i+3]*1000000 + pbuf[i+2]*10000 + pbuf[i+1]*100+pbuf[i])/100;
                        //printf("pbuf[%d+3]=%d pbuf[i+2]=%d pbuf[i+1]=%d pbuf[i]=%d j=%d\n",i,pbuf[i+3],pbuf[i+2],pbuf[i+1],pbuf[i],j);
                        //printf("pbuf[i+3]*1000000 +pbuf[i+2]*10000+pbuf[i+1]*100+pbuf[i]=%d",pbuf[i+2]*10000+pbuf[i+1]*100+pbuf[i]);
                        //("\n");
                        i=i+5;
                        break;
                }*/

            //}
    }
    /*for (j = 0; j < mb_slaver->protocol[0]->ptl_data_num; j++)
    {
        printf("tempNum[%d]=%d",j,tempNum[j]);
    }
    printf("\n");*/
    SendMeterDataToServerProcessActiveP(mb_slaver, tempNum, type);
}

void SaveDLT645_07_Meter(uint8_t *pbuf,MB_SLAVER_T *mb_slaver)
{
    uint32_t type = (pbuf[13] << 24)|(pbuf[12] << 16)|(pbuf[11] << 8)|pbuf[10]; //数据标识
    uint8_t  u8temp1 = 0, u8temp2 = 0, u8temp3 = 0, u8temp4 = 0;
    uint16_t u16temp = 0;
    uint32_t u32temp = 0;
    uint32_t tempNum[7] = {0};     //每一个类型对应值

    EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "meter_type = 0x%0x\n", type);

    switch(type)
    {
        case Meter_A_V:    // 单位为0.1V
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_A_V\n");
            u8temp1 = pbuf[15] - 0x33;
            u8temp2 = pbuf[14] - 0x33;
            u16temp = ((u8temp1 >> 4) * 10 + (u8temp1 & 0x0F)) * 100;
            u16temp = (u16temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F)));
            tempNum[0] = u16temp ;
            break;

        case Meter_B_V:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_B_V\n");
            u8temp1 = pbuf[15] - 0x33;
            u8temp2 = pbuf[14] - 0x33;
            u16temp = ((u8temp1 >> 4) * 10 + (u8temp1 & 0x0F)) * 100;
            u16temp = (u16temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F)));
            tempNum[0] = u16temp ;
            break;

        case Meter_C_V:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_C_V\n");
            u8temp1 = pbuf[15] - 0x33;
            u8temp2 = pbuf[14] - 0x33;
            u16temp = ((u8temp1 >> 4) * 10 + (u8temp1 & 0x0F)) * 100;
            u16temp = (u16temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F)));
            tempNum[0] = u16temp ;
            break;

        case Meter_V:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_C_V\n");
            u8temp1 = pbuf[15] - 0x33;
            u8temp2 = pbuf[14] - 0x33;
            u16temp = ((u8temp1 >> 4) * 10 + (u8temp1 & 0x0F)) * 100;
            u16temp = (u16temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F)));
            tempNum[0] = u16temp ;
            break;

        case Meter_A_I:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, " Meter_A_I\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_B_I:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_B_I\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_C_I:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_C_I\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_I:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_I\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_SZY_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZY_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_SZYA_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZYA_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_SZYB_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZYB_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_SZYC_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZYC_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_Y_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_Y_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_SZW_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZW_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_SZWA_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZWA_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_SZWB_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZWB_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_SZWC_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZWC_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_W_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_W_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

         case Meter_SZS_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZS_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

         case Meter_SZSA_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZSA_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

         case Meter_SZSB_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZSB_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

         case Meter_SZSC_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_SZSC_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

         case Meter_S_P:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_S_P\n");
            u8temp1 = pbuf[16] - 0x33;
            u8temp2 = pbuf[15] - 0x33;
            u8temp3 = pbuf[14] - 0x33;
            u8temp4 = u8temp1&0x7F;
            u32temp = ((u8temp4 >> 4) * 10 + (u8temp4 & 0x0F))*10000;
            u32temp = u32temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F))*100;
            u32temp = u32temp + ((u8temp3 >> 4) * 10 + (u8temp3 & 0x0F));
            u16temp = (u32temp+5)/10;
            tempNum[0] = u16temp;
            break;

        case Meter_Z_PY:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_A_V\n");
            u8temp1 = pbuf[15] - 0x33;
            u8temp2 = pbuf[14] - 0x33;
            u16temp = ((u8temp1 >> 4) * 10 + (u8temp1 & 0x0F)) * 100;
            u16temp = (u16temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F)));
            tempNum[0] = u16temp ;
            break;

        case Meter_A_PY:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_A_V\n");
            u8temp1 = pbuf[15] - 0x33;
            u8temp2 = pbuf[14] - 0x33;
            u16temp = ((u8temp1 >> 4) * 10 + (u8temp1 & 0x0F)) * 100;
            u16temp = (u16temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F)));
            tempNum[0] = u16temp ;
            break;

        case Meter_B_PY:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_A_V\n");
            u8temp1 = pbuf[15] - 0x33;
            u8temp2 = pbuf[14] - 0x33;
            u16temp = ((u8temp1 >> 4) * 10 + (u8temp1 & 0x0F)) * 100;
            u16temp = (u16temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F)));
            tempNum[0] = u16temp ;
            break;

        case Meter_C_PY:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_A_V\n");
            u8temp1 = pbuf[15] - 0x33;
            u8temp2 = pbuf[14] - 0x33;
            u16temp = ((u8temp1 >> 4) * 10 + (u8temp1 & 0x0F)) * 100;
            u16temp = (u16temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F)));
            tempNum[0] = u16temp ;
            break;

        case Meter_PY:
            EMS_LOG(LL_DEBUG, MODULE_C, FALSE, "Meter_A_V\n");
            u8temp1 = pbuf[15] - 0x33;
            u8temp2 = pbuf[14] - 0x33;
            u16temp = ((u8temp1 >> 4) * 10 + (u8temp1 & 0x0F)) * 100;
            u16temp = (u16temp + ((u8temp2 >> 4) * 10 + (u8temp2 & 0x0F)));
            tempNum[0] = u16temp ;
            break;


        default:
            break;
    }

    SendMeterDataToServerProcessActiveP(mb_slaver, tempNum, type);
}

int32_t ProModbusRevDataFromDlt645(int32_t id,uint8_t *pbuf, uint8_t buflen)
{
    int32_t ret = -1;
    uint8_t DltNum = 0;
    uint8_t Dltcheck = 0;
    uint16_t i = 0;
    if (pbuf[buflen - 1] == 0x16) //0x16 结束符
    {
        //0x68 帧起始符，寻找帧起始符; 0xFE 是前导字节
        if ((pbuf[0] == 0xFE) && ((pbuf[1] == 0xFE) || (pbuf[1] == 0x68)))
        {
            for (i = 1; i < buflen; i++)
            {
                if (pbuf[i] == 0x68)
                {
                    DltNum = i+1;
                    break;
                }
                else
                {
                }
            }
        }
        else if ((pbuf[0] == 0x68) && (pbuf[7] == 0x68))
        {
            DltNum = 1;
        }
        else
        {
        }
        if (DltNum > 0)
        {
            Dltcheck = DLT645_DataCheck(&pbuf[DltNum-1], buflen - 1- DltNum);
            if (Dltcheck != pbuf[buflen - 2]) //CS 校验
            {
                EMS_LOG(LL_ERROR, MODULE_C, FALSE, " meter CS fail.\n");
                ret = -1 ;
            }
            else
            {
                ret = DltNum;
            }
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_C, FALSE, " meter_2\n");
            ret = -1;
        }
    }
    else
    {
        EMS_LOG(LL_ERROR, MODULE_C, FALSE, " meter_3\n");
        ret = -1;
    }
    return ret;
}

//启动扫描和命令线程
void CreatCollectPthread(MB_MASTER_TAB_T *mbm_tab)
{
    int32_t i = 0, j = 0, res;
    int32_t ptl_type = -1;
    pthread_attr_t thread_attr;
    MB_MASTER_T *mb_master = mbm_tab->head;

    res = pthread_attr_init(&thread_attr);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_C, false, "Attribute creation failed\n");
        exit(EXIT_FAILURE);
    }

    size_t stacksize = 512*1024;                                                       //256KB 栈空间
    res = pthread_attr_setstacksize(&thread_attr, stacksize);

    res = pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);  //线程分离属性，线程结束后释放资源
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_C, false, "Setting detached attribute failed\n");
        exit(EXIT_FAILURE);
    }

    //单独建立搜索定时线程，用于检索各个端口的搜索参数
    for (i = 0; i < mbm_tab->num; ++i)
    {
        MB_COMM_DEV_T *mb_comm_dev = mb_master->head;
        for (j = 0; j < mb_master->num; ++j)
        {
            MB_SLAVER_T *mb_slaver = mb_comm_dev->dev;
            ptl_type = SDB_GetDevPtlType(mb_slaver->dev_code, mb_slaver->index);

            mb_comm_dev = mb_comm_dev->next;
        }
        //判断主站下挂从站设备，如果为空，则不创建命令和扫描线程
        if (mb_master->num != 0)
        {
            if (ptl_type == IEC104)
            {
                IEC104MasterHandler *masterHandler = (IEC104MasterHandler*)mb_master->fd;
                res = pthread_create(&(mb_master->scan_thread), &thread_attr, IECMasterThread, (void *)masterHandler);
                if (res != 0)
                {
                    EMS_LOG(LL_ERROR, MODULE_C, false, "Thread IECMasterThread creation failed\n");
                    exit(EXIT_FAILURE);
                }
            }
            else
            {
                res = pthread_create(&(mb_master->scan_thread), &thread_attr, CollectMasterScan, (void *)mb_master);
                if (res != 0)
                {
                    EMS_LOG(LL_ERROR, MODULE_C, false, "Thread CollectMasterScan creation failed\n");
                    exit(EXIT_FAILURE);
                }
            }

        }
        mb_master = mb_master->next;
    }

    (void)pthread_attr_destroy(&thread_attr);
}

//创建扫描命令
void CreatMbscan(MB_SLAVER_T *mb_slaver, uint8_t protocol_no, uint8_t cycflag, uint8_t scan_prio)
{
    MODBUS_CMD_T cmd_t = {0};

    if (0 == strcmp(mb_slaver->name, "SG_METER") || mb_slaver->protocol[0]->ptl_type == DLT645)
    {
        if (mb_slaver->com_type == NET)
        {
            CreatTcpMeterScan(mb_slaver->dev_adress, mb_slaver->cslave_id, mb_slaver->protocol[protocol_no], &cmd_t, cycflag);//TCP创建命令
        }
        else
        {
            CreatMeterScan(mb_slaver->dev_adress, mb_slaver->cslave_id, mb_slaver->protocol[protocol_no], &cmd_t, cycflag);//创建命令
        }
    }
    else if(0 == strcmp(mb_slaver->name, "CJT_188") || mb_slaver->protocol[0]->ptl_type == CJT188)
    {
        CreatMeterScan(mb_slaver->dev_adress, mb_slaver->cslave_id, mb_slaver->protocol[protocol_no], &cmd_t, cycflag);//创建命令
    }
    else
    {
        if (mb_slaver->com_type == NET)
        {
            CreatTcp_0x01_0x03_0x04(mb_slaver->cslave_id, mb_slaver->protocol[protocol_no], &cmd_t, cycflag);//TCP创建命令
        }
        else
        {
            Creat_0x01_0x03_0x04(mb_slaver->cslave_id, mb_slaver->protocol[protocol_no], &cmd_t, cycflag);//创建命令
        }
    }

    PendQueueS(&(mb_slaver->scan[scan_prio]), &cmd_t);//入列
}

//创建设置扫描命令
void CreatMbCmdScan(MB_SLAVER_T *mb_slaver, uint8_t protocol_no)
{
    MODBUS_CMD_T cmd_t={0};
    Creat_0x10_All(mb_slaver,mb_slaver->protocol[protocol_no],&cmd_t);//创建命令
    PendQueueS(&(mb_slaver->scancmd), &cmd_t);//入列
}

//创建立即命令
void CreateCurCmdScan(MB_SLAVER_T *mb_slaver, MODBUS_CMD_T *cmd_t , uint8_t scan_prio)
{
    uint16_t crcdata = 0, i = 0;
    MODBUS_CMD_T cmd;

    memcpy(&cmd, cmd_t,sizeof(MODBUS_CMD_T));
    cmd.cmd = 0x03;
    if (cmd_t->cmd == 0x10)
    {
        cmd.registerCount = cmd_t->registerCount;
    }
    else if (cmd_t->cmd == 0x06)
    {
        cmd.registerCount = 1;
    }
    else
    {
        return;
    }

    cmd.data[0] = cmd.id;
    cmd.data[1] = cmd.cmd ;
    cmd.data[4] = HIGHBYTE(cmd.registerCount);
    cmd.data[5] = LOWBYTE(cmd.registerCount);
    crcdata = GetCRC16(cmd.data, 6);
    cmd.data[6] = LOWBYTE(crcdata);
    cmd.data[7] = HIGHBYTE(crcdata);
    cmd.buf_len = 8;

    for (i=0; i<cmd.buf_len; i++)
    {
        EMS_LOG(LL_DEBUG, MODULE_C, false, "0x%0x ", cmd.data[i]);
    }

    int ret = PendQueueS(&(mb_slaver->scan[scan_prio]), &cmd);
    if (ret!=0)
    {
    }

}

int32_t IsMbscanEmpty(MB_SLAVER_T *mb_slaver, uint8_t scan_prio)//扫描队列是否为空
{
    return(IsQueueSempty(&(mb_slaver->scan[scan_prio])));
}

int32_t IsMbcmdscanEmpty(MB_SLAVER_T *mb_slaver)//扫描命令队列是否为空
{
    return(IsQueueSempty(&(mb_slaver->scancmd)));
}

void ClearMBCmd(MB_SLAVER_T *mb_slaver)//clear all cmd
{
    int32_t i = 0;
    for (i = 0; i < MAX_SCAN_PRIO; i++)
    {
        while(DelQueueS(&(mb_slaver->scan[i])) == 0)
        {}
    }
    while(DelQueueS(&(mb_slaver->scancmd)) == 0)
    {}
    while(DelQueueS(&(mb_slaver->curcmd)) == 0)
    {}
}
