#include <pthread.h>
#include <stdbool.h>
#include <sys/prctl.h>
#include <stdlib.h>
#include <errno.h>
#include "protocol.h"
#include "protocol_cfg.h"
#include "common.h"
#include "collect.h"
#include "logUtil.h"
#include "modbus.h"
#include "uart.h"
#include "sdb.h"
#include "iec_master_service.h"
#include "config.h"
#include "IMC.h"
#include "file_operate.h"

#define TIME_NUM  6

Q_DEFINE(SG_MSG_T, collectMsgQ, Queue_NUM);

struct collector_handle_st
{
    uint32_t state;
    pthread_t mainThread;
    BOOL isMainThreadExit;
};

typedef struct
{
    int32_t dataId; //南向设备dataId
    char  devName[MAX_DEV_NAME_LEN];  //南向设备别名
    int32_t ctrlValue; //控制值，开机、关机、待机
}DEV_CTRL_T; //设备控制，开机、关机、待机

COLLECTOR_HANDLE_T *g_pCollectHandle = NULL;

char *time_name[] =
{
    "系统时钟：年",
    "系统时钟：月",
    "系统时钟：日",
    "系统时钟：时",
    "系统时钟：分",
    "系统时钟：秒",
};

int32_t stopThread()
{
    MB_MASTER_T *mb_master = mb_master_tab.head;
    MB_MASTER_T *mb_master_tmp = mb_master;
    int32_t i = 0;

    for (i = 0; i < mb_master_tab.num; ++i)
    {
        if (mb_master_tmp->num != 0)
        {
            if (mb_master_tmp->scan_thread)
            {
                mb_master_tmp->scanThreadIsExit = TRUE;
                pthread_join(mb_master_tmp->scan_thread, NULL);
                printf("mb_master->scan_thread join.\n");
            }
        }
        mb_master_tmp = mb_master_tmp->next;
    }

    if (mb_master != NULL && mb_master->input_thread)
    {
        mb_master->inputThreadIsExit = TRUE;
        Q_POST(cmdqOutQ);
        pthread_join(mb_master->input_thread, NULL);
        printf("mb_master->input_thread join.\n");
    }

    if (mb_master != NULL &&  mb_master->connect_thread)
    {
        mb_master->connectThreadIsExit = TRUE;
        pthread_join(mb_master->connect_thread, NULL);
        printf("mb_master->connect_thread join.\n");
    }

    return OK;
}

int32_t freeMBMaster()
{
    MB_MASTER_T *mb_master = mb_master_tab.head;
    MB_MASTER_T *mb_master_cur = mb_master;
    MB_MASTER_T *mb_master_tmp = NULL;
    int32_t i = 0;
    for (i = 0; i < mb_master_tab.num; i++)
    {
        if (mb_master_cur != NULL)
        {
            mb_master_tmp = mb_master_cur;
            mb_master_cur = mb_master_cur->next;

            HCFREE(mb_master_tmp);
        }
    }

    memset(&mb_master_tab, 0, sizeof(MB_MASTER_TAB_T));
    return OK;
}

int32_t freeSlaver()
{
    MB_SLAVER_T *mb_slaver = mb_slaver_tab.head;
    MB_SLAVER_T *mb_slaver_cur = NULL;
    MB_SLAVER_T *mb_slaver_tmp = NULL;
    int32_t i = 0;

    mb_slaver_cur = mb_slaver;
    mb_slaver_tmp = NULL;
    for (i = 0; i < mb_slaver_tab.num; i++)
    {
        if (mb_slaver_cur != NULL)
        {
            mb_slaver_tmp = mb_slaver_cur;
            mb_slaver_cur = mb_slaver_cur->next;

            //SDB will free.
//             HCFREE(mb_slaver_tmp->data);
//
//             for (j = 0; j < mb_slaver_tmp->protocol_num; j++)
//             {
//                 if (mb_slaver_tmp->protocol[j] != NULL)
//                 {
//                     if (mb_slaver_tmp->protocol[j]->protocol_data != NULL)
//                     {
//                         HCFREE(mb_slaver_tmp->protocol[j]->protocol_data->appendix);
//
//                         HCFREE(mb_slaver_tmp->protocol[j]->protocol_data);
//                         mb_slaver_tmp->protocol[j]->protocol_data = NULL;
//                     }
//
//                     HCFREE(mb_slaver_tmp->protocol[j]->map);
//                 }
//                 HCFREE(mb_slaver_tmp->protocol[j]);
//             }

            HCFREE(mb_slaver_tmp);
        }
    }

    memset(&mb_slaver_tab, 0, sizeof(MB_SLAVER_TAB_T));
    return OK;
}

int32_t freeDevCodeList()
{
    MB_DEV_CODE_T *devcodetable = mb_dev_code_tab.head;
    MB_DEV_CODE_T *devcodetable1 = NULL;

    int32_t i = 0;
    for (i = 0; i < mb_dev_code_tab.num; i++)
    {
        devcodetable1 = devcodetable->next;
        HCFREE(devcodetable->map_id);
        HCFREE(devcodetable);
        devcodetable = devcodetable1;
    }

    memset(&mb_dev_code_tab, 0, sizeof(MB_DEV_CODE_TAB_T));

    return OK;
}

int32_t freeModbusDev()
{
    MODBUS_DEV_T *tmp_modbus_dev = &modbus_dev;
    int32_t i = 0, j = 0;

    if (tmp_modbus_dev != NULL)
    {
        HCFREE(tmp_modbus_dev->set_ptl);

        PTL_4X_CMD_T *tmp_ptl_4X_cmd = tmp_modbus_dev->ptl_4X_cmd;
        for (i = 0; i < tmp_modbus_dev->ptl_4X_cmd_num; i++)
        {
            HCFREE(tmp_ptl_4X_cmd[i].ptl_update);

            for (j = 0; j < MAXSLAVERS; j++)
            {
                HCFREE(tmp_ptl_4X_cmd[i].cmd_info[j % MAXSLAVERS].ptl_update);
            }
        }

        HCFREE(tmp_modbus_dev->ptl_4X_cmd);

        for (j = 0; j < tmp_modbus_dev->dev_code_num; j++)
        {
            HCFREE(tmp_modbus_dev->code_data[j].data);
        }

        HCFREE(tmp_modbus_dev->code_data);
    }

    memset(tmp_modbus_dev, 0, sizeof(MODBUS_DEV_T));

    return OK;
}

static void InsertTimeDataq()
{
    struct tm* local;
    time_t t;
    uint32_t i = 0, j = 0, k = 0;
    uint16_t total_dev_num = 0, conut = 0, num = 0;
    DEV_DATA_T *time_wdata = NULL;
    MB_SLAVER_T *mb_slaver = mb_slaver_tab.head;

    total_dev_num = mb_slaver_tab.num;
    time_wdata = (DEV_DATA_T *)malloc(sizeof(DEV_DATA_T) * TIME_NUM*total_dev_num);
    if (time_wdata == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc time_wdata error !\n");
        exit(EXIT_FAILURE);
    }
    memset(time_wdata, 0, TIME_NUM*total_dev_num*sizeof(DEV_DATA_T));

    t = time(NULL);
    if (t==(time_t)-1)
    {
        fprintf(stderr,"time error:%s\n",strerror(errno));
    }

    local = localtime(&t);

    for (k = 0; k < total_dev_num; k++)
    {
        for (i = 0; i < TIME_NUM; i++)
        {
            SDB_GetNumOfPointName(mb_slaver->dev_code, mb_slaver->index, time_name[i], &conut);
            for (j = 0; j < conut; j++)
            {
                SDB_GetPointInfoByName(mb_slaver->dev_code, &time_wdata[num], time_name[i], j+1);
                if (i == 0)
                {
                    time_wdata[num].value.data.u32 = local->tm_year + 1900;
                }
                else if (i == 1)
                {
                    time_wdata[num].value.data.u32 = local->tm_mon + 1;
                }
                else if (i == 2)
                {
                    time_wdata[num].value.data.u32 = local->tm_mday;
                }
                else if (i == 3)
                {
                    time_wdata[num].value.data.u32 = local->tm_hour;
                }
                else if (i == 4)
                {
                    time_wdata[num].value.data.u32 = local->tm_min;
                }
                else
                {
                    time_wdata[num].value.data.u32 = local->tm_sec;
                }

                num ++;
            }

        }
        mb_slaver = mb_slaver->next;
    }
//     if (num > 0)
//     {
//         if (!Q_FULL(cmdqInQ))
//         {
//             Q_INSERT_WAIT_N(cmdqInQ, time_wdata, num);
//         }
//         else
//         {
//             EMS_LOG(LL_ERROR, MODULE_C, false, "cmdqInQ is full!\n");
//         }
//     }

    HCFREE(time_wdata);
}

static int32_t collectMsgCB(uintptr_t user, void *pvData)
{
    int32_t ret = OK;

    SG_MSG_T stDestMsg = *(SG_MSG_T *)pvData;
    int32_t eType = stDestMsg.udwMsgType;

    if (MODULE_ID(eType) != MODULE_C && MODULE_ID(eType) != MODULE_IPC && MODULE_ID(eType) != MODULE_SDB)
    {
        return ret;
    }

    printf("collect recv internal msg:0x%x. \n", eType);

    switch(eType)
    {
        case MSG_COLLECT_SOUTH_CALIBRATION:
        {
            InsertTimeDataq();
            break;
        }
        case MSG_IPC_DEV_CTRL:
        case MSG_IPC_SERIAL_SETTING:
        case MSG_IPC_DEV_UPDATE:
        case MSG_SDB_UPDATED:
        {
            Q_INSERT_WAIT(collectMsgQ, stDestMsg);
            break;
        }
        default:
            break;
    }

    return ret;
}

static BOOL checkCollectorPrecondition()
{
    BOOL ret = FALSE;

    if (DirExist(MASTER_XML_NAME) && SDB_GetState() == MODULE_STATE_RUNNING)
    {
        ret = TRUE;
    }

    return ret;
}
//和校验
/*static uint32_t SumCheck(uint8_t *inbuf,uint32_t len)
{
    int i = 0;
    uint32_t check_data = 0;
    for (i = 0; i < len; ++i)
    {
        check_data += (*(inbuf++));
    }
    return check_data;
}*/

uintptr_t GetMasterHander(IN uint16_t devcode, IN uint16_t index)
{
    int32_t i = 0, j = 0;
    MB_MASTER_T *mb_master = mb_master_tab.head;
    uintptr_t res = 0;

    for (i = 0; i < mb_master_tab.num; ++i)
    {
        MB_COMM_DEV_T *mb_comm_dev = mb_master->head;
        for (j = 0; j < mb_master->num; ++j)
        {
            MB_SLAVER_T *mb_slaver = mb_comm_dev->dev;
            if ((devcode == mb_slaver->dev_code) && (index == mb_slaver->index))
            {
                res = mb_master->fd;
                break;
            }

            mb_comm_dev = mb_comm_dev->next;
        }
        mb_master = mb_master->next;
    }

    return res;
}

void InsertTimeToDev(IN uint16_t devcode, IN uint16_t index)
{
    struct tm* local;
    time_t t;
    uint32_t i = 0, j = 0;
    uint16_t conut = 0, num = 0;
    DEV_DATA_T *time_wdata = NULL;


    time_wdata = (DEV_DATA_T *)malloc(sizeof(DEV_DATA_T) * TIME_NUM);
    if (time_wdata == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc time_wdata error !\n");
        exit(EXIT_FAILURE);
    }
    memset(time_wdata, 0, TIME_NUM*sizeof(DEV_DATA_T));

    t = time(NULL);
    if (t==(time_t)-1)
    {
        fprintf(stderr,"time error:%s\n",strerror(errno));
    }

    local = localtime(&t);

    for (i = 0; i < TIME_NUM; i++)
    {
        SDB_GetNumOfPointName(devcode, index, time_name[i], &conut);
        for (j = 0; j < conut; j++)
        {
            SDB_GetPointInfoByName(devcode, &time_wdata[num], time_name[i], j+1);
            if (i == 0)
            {
                time_wdata[num].value.data.u32 = local->tm_year + 1900;
            }
            else if (i == 1)
            {
                time_wdata[num].value.data.u32 = local->tm_mon + 1;
            }
            else if (i == 2)
            {
                time_wdata[num].value.data.u32 = local->tm_mday;
            }
            else if (i == 3)
            {
                time_wdata[num].value.data.u32 = local->tm_hour;
            }
            else if (i == 4)
            {
                time_wdata[num].value.data.u32 = local->tm_min;
            }
            else
            {
                time_wdata[num].value.data.u32 = local->tm_sec;
            }

            num ++;
        }

    }
    if (num > 0)
    {
        if (!Q_FULL(cmdqInQ))
        {
            Q_INSERT_WAIT_N(cmdqInQ, time_wdata, num);
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "cmdqInQ is full!\n");
        }
    }

    HCFREE(time_wdata);
}

void InsertTimeToIEC(MB_MASTER_T *mb_master, MB_SLAVER_T *mb_slaver)
{
    struct tm* local;
    time_t t;
    uint32_t i = 0, j = 0, m = 0;
    uint16_t total_dev_num = 0;
    DEV_DATA_T *time_wdata = NULL;

    total_dev_num = SDB_GetDevNum();

    time_wdata = (DEV_DATA_T *)malloc(sizeof(DEV_DATA_T) * 6*total_dev_num);
    if (time_wdata == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc time_wdata error !\n");
        exit(EXIT_FAILURE);
    }
    memset(time_wdata, 0, 6*total_dev_num*sizeof(DEV_DATA_T));

    t = time(NULL);
    if (t==(time_t)-1)
    {
        fprintf(stderr,"time error:%s\n",strerror(errno));
    }

    local = localtime(&t);

    for (i = 0; i < 6; i++)
    {
        if (mb_slaver->dev_code != CEMS_DEV_CODE)
        {
            for (j = 0; j < mb_slaver->protocol_num; j++)
            {
                PROTOCOL_T *tmp_protocol = mb_slaver->protocol[j];
                for (m = 0; m < tmp_protocol->ptl_data_num; m++)
                {
                    if (0 == strcmp(time_name[i], tmp_protocol->protocol_data[m].data_name))
                    {
                        time_wdata[i].dev_code = tmp_protocol->dev_code;
                        time_wdata[i].data_id = tmp_protocol->protocol_data[m].data_id;
                        time_wdata[i].index = mb_slaver->index;
                        time_wdata[i].moduleID = MODULE_T;
                        if (i == 0)
                        {
                            time_wdata[i].value.data.u32 = local->tm_year + 1900;
                        }
                        else if (i == 1)
                        {
                            time_wdata[i].value.data.u32 = local->tm_mon + 1;
                        }
                        else if (i == 2)
                        {
                            time_wdata[i].value.data.u32 = local->tm_mday;
                        }
                        else if (i == 3)
                        {
                            time_wdata[i].value.data.u32 = local->tm_hour;
                        }
                        else if (i == 4)
                        {
                            time_wdata[i].value.data.u32 = local->tm_min;
                        }
                        else
                        {
                            time_wdata[i].value.data.u32 = local->tm_sec;
                        }
                        IEC104MasterHandler *masterHandler = (IEC104MasterHandler*)mb_master->fd;
                        IECMasterService_SendCommand(masterHandler, &time_wdata[i]);
                    }
                }
            }
        }
    }

    HCFREE(time_wdata);
}

//启动CollectConnect
void *CollectConnect(void *arg)
{
    MB_MASTER_T *mb_master = mb_master_tab.head;
//     MB_MASTER_T *mb_master = arg;

    MB_SLAVER_T *mb_slaver = mb_slaver_tab.head;
    int32_t i = 0, j = 0, ret = 0, res = 0;

    prctl(PR_SET_NAME, "CLCT_CONNECT_THREAD");
    while(!mb_master->connectThreadIsExit)
    {
        for (i = 0; i < mb_master_tab.num; ++i)
        {
            if ((mb_master->fd == INVALID_VALUE) && (mb_master->head != NULL))
            {
                for (j = 0; j < mb_slaver_tab.num; ++j)
                {
                    if ((0 == strcmp(mb_master->head->dev->dev_name, mb_slaver->dev_name))
                            &&(mb_master->head->dev->index ==  mb_slaver->index))
                    {
                        pthread_mutex_lock(&(mb_master->mutex));
                        ret = DevConnect(mb_master->comport.commtype, mb_master, mb_slaver);
                        if (ret == 0)
                        {
                            mb_slaver->callback = mb_slaver->offline = 0;
                        }
                        pthread_mutex_unlock(&(mb_master->mutex));
                    }
                    if (j == mb_slaver_tab.num-1)
                    {
                        mb_slaver = mb_slaver_tab.head;
                    }
                    else
                    {
                        mb_slaver = mb_slaver->next;
                    }
                }
            }
            else
            {
                for (j = 0; j < mb_master->num; ++j)
                {
                    MB_COMM_DEV_T *tmp_com_dev = mb_master->head;
                    MB_SLAVER_T *tmp_mb_slaver = tmp_com_dev->dev;
                    if (tmp_mb_slaver->protocol[0]->ptl_type == IEC104)
                    {
                        IEC104MasterHandler *masterHandler = (IEC104MasterHandler*)mb_master->fd;
                        res = IECMasterService_IsConnect(masterHandler);
                        if (res == 0)
                        {
                            InsertCommStateQ(tmp_mb_slaver->dev_code, tmp_mb_slaver->index, 0);
                            tmp_mb_slaver->comm_state = 1;
                        }
                        else
                        {
                            if (tmp_mb_slaver->comm_state == 1)
                            {
                                InsertCommStateQ(tmp_mb_slaver->dev_code, tmp_mb_slaver->index, 1);
                                tmp_mb_slaver->comm_state = 0;
                                tmp_mb_slaver->timing_flag = 1;
                            }
                            if (tmp_mb_slaver->timing_flag == 1)
                            {
                                InsertTimeToIEC(mb_master, tmp_mb_slaver);
                                tmp_mb_slaver->timing_flag = 0;
                            }
                        }
                    }
                    else
                    {
                        if (tmp_mb_slaver->timing_flag == 1)
                        {
//                             InsertTimeToDev(tmp_mb_slaver->dev_code, tmp_mb_slaver->index);
                            tmp_mb_slaver->timing_flag = 0;
                        }
                    }
                    tmp_com_dev = tmp_com_dev->next;
                }
            }
            if (i == mb_master_tab.num - 1)
            {
                mb_master = mb_master_tab.head;
            }
            else
            {
                mb_master = mb_master->next;
            }
        }

        sleep(1);
    }

    printf("%s CLCT_CONNECT_THREAD exit.\n", __func__);
    return NULL;
}

int32_t IEC104MasterInit(void)
{
    int32_t i = 0, j = 0, ret = OK;
    int32_t ptl_type = -1;
    MB_MASTER_T *mb_master = mb_master_tab.head;

    static char ip_address[16];

    IEC104MasterConfig *master_config = (IEC104MasterConfig *)malloc(sizeof(IEC104MasterConfig));
    if (master_config == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc master_config error!\n");
       return ERROR_T(ERR_DEFAULT_NO_MEM);
    }
    memset(master_config, 0, (sizeof(IEC104MasterConfig)));

    for (i = 0; i < mb_master_tab.num; ++i)
    {
        MB_COMM_DEV_T *mb_comm_dev = mb_master->head;
        for (j = 0; j < mb_master->num; ++j)
        {
            MB_SLAVER_T *mb_slaver = mb_comm_dev->dev;
            ptl_type = SDB_GetDevPtlType(mb_slaver->dev_code, mb_slaver->index);

            if (ptl_type == IEC104)
            {
                master_config->yx_minAddr = 0x0001;
                master_config->yx_maxAddr = 0x4000;
                master_config->yc_minAddr = 0x4001;
                master_config->yc_maxAddr = 0x6000;
                master_config->yk_minAddr = 0x6001;
                master_config->yk_maxAddr = 0x6200;
                master_config->yt_minAddr = 0x6201;
                master_config->yt_maxAddr = 0x6400;
                master_config->ym_minAddr = 0x6401;
                master_config->ym_maxAddr = 0x7000;
                master_config->deviceCode = mb_slaver->dev_code;
                master_config->index = mb_slaver->index;
                master_config->port = mb_master->comport.netport;
                sprintf(ip_address, "%d.%d.%d.%d", mb_master->comport.ip[0], mb_master->comport.ip[1], mb_master->comport.ip[2], mb_master->comport.ip[3]);
                master_config->serverIp = ip_address;

                IEC104MasterHandler *master_hander = NULL;
                master_hander = (IEC104MasterHandler *)malloc(sizeof(IEC104MasterHandler));
                if (master_hander == NULL)
                {
                    EMS_LOG(LL_ERROR, MODULE_C, false, "malloc master_hander error!\n");
                    exit(EXIT_FAILURE);
                }
                memset(master_hander, 0, (sizeof(IEC104MasterHandler)));
                master_hander = IECMasterService_Init(master_config);
                if (master_hander == NULL)
                {
                    EMS_LOG(LL_ERROR, MODULE_C, false, "IECMasterService_Init return master_hander error!\n");
                    exit(EXIT_FAILURE);
                }
                mb_master->fd = (uintptr_t)master_hander;
            }
            mb_comm_dev = mb_comm_dev->next;
        }
        mb_master = mb_master->next;
    }

    return ret;
}

static void* collectMsgProcThread(void *arg)
{
    COLLECTOR_HANDLE_T *pCollectHandle = arg;
    SG_MSG_T stMsg;

    prctl(PR_SET_NAME, "COLLECT_MSG_THREAD");
    while(!pCollectHandle->isMainThreadExit)
    {
        Q_OUT_WAIT(collectMsgQ, stMsg);
        {
            printf("collect proc msg:0x%x \n", stMsg.udwMsgType);
            switch (stMsg.udwMsgType)
            {
                case MSG_IPC_SERIAL_SETTING:
                case MSG_IPC_DEV_UPDATE:
                {
                    if (g_pCollectHandle->state == MODULE_STATE_RUNNING)
                    {
                        g_pCollectHandle->state = MODULE_STATE_READY;
                        stopThread();

                        freeMBMaster();

                        freeSlaver();

                        freeDevCodeList();

                        freeModbusDev();
                        g_pCollectHandle->state = MODULE_STATE_INIT;
                    }

                    SDB_Destory();

                    SDB_Init();
                    break;
                }
                case MSG_SDB_UPDATED:
                {
                    Collector_Start();
                    break;
                }
                case MSG_IPC_DEV_CTRL:
                {
                    if (stMsg.udwlen > 0)
                    {
                        DEV_CTRL_T *pDevCtrl = (DEV_CTRL_T *)stMsg.pData;
                        if (pDevCtrl != NULL)
                        {
                            DEV_INFO_T stDevInfo;
                            memset(&stDevInfo, 0, sizeof(DEV_INFO_T));
                            SDB_GetDevInfoByName(pDevCtrl->devName, &stDevInfo);

                            DEV_DATA_T stDevData;
                            memset(&stDevData, 0, sizeof(DEV_DATA_T));
                            stDevData.dev_code = stDevInfo.dev_code;
                            stDevData.index = stDevInfo.index;
                            stDevData.data_id = pDevCtrl->dataId;
                            stDevData.data_type = S_INT_T;
                            stDevData.value.data.s32 = pDevCtrl->ctrlValue;

                            Q_INSERT_WAIT_N(cmdqOutQ, &stDevData, 1);

                            printf("%s MSG_IPC_DEV_CTRL %s->%s (%d,%d,%d->%d)\n",
                                   __func__, pDevCtrl->devName, stDevInfo.dev_name, stDevInfo.dev_code, stDevInfo.index, pDevCtrl->dataId, pDevCtrl->ctrlValue);
                        }
                    }
                    break;
                }
                default:
                    break;
            }

        }

        HCFREE(stMsg.pData);
    }
    return NULL;
}

void ModbusMasterInit(void)
{
    int32_t i = 0;
    MB_SLAVER_T *mb_slaver = mb_slaver_tab.head;

    for (i = 0; i < mb_slaver_tab.num; ++i)
    {
        (mb_slaver->CollectMasterInit)(mb_slaver);/* modbus主站初始化*/
        mb_slaver = mb_slaver->next;
    }
}

void CreateMBMThread(void)
{
    int32_t res = 0;

    MB_MASTER_T *mb_master = mb_master_tab.head;

    pthread_attr_t thread_attr;
    size_t stacksize;

//     IEC104MasterInit();

    res = pthread_attr_init(&thread_attr);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_C, false, "Attribute creation failed\n");
        exit(EXIT_FAILURE);
    }

    stacksize = 512*1024;       //512KB 栈空间
    res = pthread_attr_setstacksize(&thread_attr, stacksize);

    res = pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_C, false, "Setting detached attribute failed\n");
        exit(EXIT_FAILURE);
    }

    res = pthread_create(&(mb_master->connect_thread), &thread_attr, CollectConnect, mb_master);
    if (res != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "Thread CollectConnect creation failed.\n");
        exit(EXIT_FAILURE);
    }

    ModbusMasterInit();

    CreatCollectPthread(&mb_master_tab); /*线程启动*/

    res = pthread_create(&(mb_master->input_thread), &thread_attr, CollectMasterInput, mb_master); /* 对输入协议栈点数据进行处理*/
    if (res != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "Thread CollectMasterInput creation failed.\n");
        exit(EXIT_FAILURE);
    }

    (void)pthread_attr_destroy(&thread_attr);
}

int32_t Collector_Start()
{
    int32_t ret = OK;

    InitCollectPara();
    CreateMBMThread();

    g_pCollectHandle->state = MODULE_STATE_RUNNING;

    return ret;
}

uintptr_t Collector_Create()
{
    if (g_pCollectHandle != NULL)
    {
        return (uintptr_t)g_pCollectHandle;
    }

    g_pCollectHandle = malloc(sizeof(COLLECTOR_HANDLE_T));
    memset(g_pCollectHandle, 0, sizeof(COLLECTOR_HANDLE_T));
    g_pCollectHandle->state = MODULE_STATE_INIT;

    Q_INIT(collectMsgQ, Queue_NUM);

    IMC_RegisterCB((uintptr_t)g_pCollectHandle, collectMsgCB);

    //开启模块消息处理线程
    pthread_attr_t thread_attr;
    int32_t res = pthread_attr_init(&thread_attr);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_C, false, "Attribute creation failed\n");
        exit(EXIT_FAILURE);
    }

    size_t stacksize = 512*1024;       //512KB 栈空间
    res = pthread_attr_setstacksize(&thread_attr, stacksize);
    res = pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
    if (res != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_C, false, "Setting detached attribute failed\n");
        exit(EXIT_FAILURE);
    }

    res = pthread_create(&(g_pCollectHandle->mainThread), &thread_attr, collectMsgProcThread, g_pCollectHandle);
    if (res != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "Collect Main Thread creation failed.\n");
        exit(EXIT_FAILURE);
    }

    (void)pthread_attr_destroy(&thread_attr);

    g_pCollectHandle->state = MODULE_STATE_READY;
    if (checkCollectorPrecondition())
    {
        Collector_Start();
    }

    return (uintptr_t)g_pCollectHandle;
}

int32_t Collector_Destroy(uintptr_t handle)
{
    stopThread();

    freeMBMaster();

    freeSlaver();

    freeDevCodeList();

    freeModbusDev();

    if (g_pCollectHandle->mainThread)
    {
        g_pCollectHandle->isMainThreadExit = TRUE;
        Q_POST(collectMsgQ);
        pthread_join(g_pCollectHandle->mainThread, NULL);
        printf("Collect Msg Thread join.\n");
    }

    g_pCollectHandle->state = MODULE_STATE_NONE;

    HCFREE(g_pCollectHandle);

    printf("%s done.\n", __func__);
    return 0;
}
