/************************************
**协议栈接口
*************************************
**定义初始化协议栈装载报文
**定义协议栈输出数据处理
**定义协议栈通信策略：主要是扫描报文的收发顺序逻辑
************************************/
#include <stdlib.h>
#include <sys/prctl.h>
#include "protocol.h"
#include "protocol_cfg.h"
#include "common.h"
#include "collect.h"
#include "logUtil.h"
#include "commonTest.h"
#include "iec_master_service.h"

extern PLAT_STATISTICS_T g_PlatStic;
PLAT_SR_T g_PlatSR[TEST_NUM];

//协议栈启动初始化
void MbmInit(MB_SLAVER_T *mb_slaver)
{
    int32_t i = 0;

    for (i = 0; i < mb_slaver->protocol_num; i++)
    {
        if (mb_slaver->protocol[i]->cmd == 0x04 || mb_slaver->protocol[i]->cmd == 0x01 || mb_slaver->protocol[i]->cmd == 0x02)
        {
            CreatMbscan(mb_slaver, i, MBM_CYC, LOW_SCAN_PRIO);
        }
        else if (mb_slaver->protocol[i]->cmd == 0x03)
        {
            //非循环读
            if (mb_slaver->protocol[i]->cyc_enable == FALSE)
            {
                CreatMbscan(mb_slaver, i, MBM_NONCYC, LOW_SCAN_PRIO);
            }
            //循环读
            else if (mb_slaver->protocol[i]->cyc_enable == TRUE)
            {
                CreatMbscan(mb_slaver, i, MBM_CYC, LOW_SCAN_PRIO);
            }
        }
    }
}

//通信接收返回后调用
void MBM_ComRevCtl(MB_SLAVER_T *mb_slaver)//通信接收控制策略
{

}

//通信发送前调用(通信恢复后再读设置)
void MBM_ComSendCtl(MB_SLAVER_T *mb_slaver)//通信发送控制策略
{
    int i = 0;
    if (mb_slaver->comm_recover == 1)
    {
        for (i = 0; i< mb_slaver->protocol_num; i++)
        {
            if ((mb_slaver->protocol[i]->cmd == 0x03) && (mb_slaver->protocol[i]->cyc_enable == 0))
            {
                CreatMbscan(mb_slaver, i ,MBM_NONCYC, LOW_SCAN_PRIO);
            }
        }
        mb_slaver->comm_recover = 0;
    }
}

//设置命令发送后调用
void MBM_CurCmdCtl(MB_SLAVER_T *mb_slaver, MODBUS_CMD_T *cmd_t)//通信发送控制策略
{
    uint32_t address = cmd_t->address +1;
    int i = 0;

    for (i = 0; i < mb_slaver->protocol_num; i++)
    {
        if (mb_slaver->protocol[i]->cmd == 0x03)                                    //设置后读取
        {
            if ((address >= mb_slaver->protocol[i]->min_address) && (address <= mb_slaver->protocol[i]->max_address))
            {
                CreatMbscan(mb_slaver, i, MBM_NONCYC, HIGH_SCAN_PRIO);
                break;
            }
        }
    }
}

int32_t MasterSendCommand(IN MB_MASTER_T *mb_master, IN int32_t ptl_type, IN DEV_DATA_T *tcpbuf, IN  uint32_t sendnum)
{
    uintptr_t masterlHandle = 0;
    int32_t ret = 0, inbuf_len = 0, i = 0;

    if (ptl_type == IEC104)
    {
        for (i = 0; i < sendnum; i++)
        {
            masterlHandle = GetMasterHander(tcpbuf[i].dev_code, tcpbuf[i].index);
            IEC104MasterHandler *masterHandler = (IEC104MasterHandler*)masterlHandle;
            ret = IECMasterService_SendCommand(masterHandler, &tcpbuf[i]);
            if (ret!= 0)
            {
                EMS_LOG(LL_ERROR, MODULE_C, FALSE, "IECMasterService_SendCommand error!\n");
            }
        }
    }
    else
    {
        inbuf_len = sendnum*sizeof(DEV_DATA_T);
        pthread_mutex_lock(&(mb_master->revcmd_mutex));
        ret = CreateCmd(&mb_master_tab, tcpbuf, inbuf_len); //分析接收数据并且创建命令报文
        if (ret!= 0)
        {
            EMS_LOG(LL_ERROR, MODULE_C, FALSE, "CreateCmd error!\n");
        }
        pthread_mutex_unlock(&(mb_master->revcmd_mutex));
    }

    return ret;
}

static int32_t coeffiCoversion(INOUT DEV_DATA_T *tcpbuf, IN  uint32_t sendnum)
{
    int32_t ret = OK;
    int32_t i = 0, j = 0, num = 0;

    for (i = 0; i < sendnum; i++)
    {
        int32_t devCode = tcpbuf[i].dev_code;
        int32_t dataId = tcpbuf[i].data_id;
        float32_t coeffi = 1.0;
        float32_t unitCoeffi = 1.0;
        int32_t destDataType = U_INT_T;

        PROTOCOL_DATA_T *ptlData = NULL;
        num = SDB_GetDevPointAttr(devCode, &ptlData);

        for (j = 0; j < num; j++)
        {
            if (dataId == ptlData[j].data_id)
            {
                coeffi = ptlData[j].coefficient;
                unitCoeffi = ptlData[j].unitCoefficient;
                destDataType = ptlData[j].data_type;
                break;
            }
        }

        DATA_U tmp = tcpbuf[i].value.data;
        if (destDataType == U_INT_T)
        {
            if (tcpbuf[i].data_type == FLOAT_T)
            {
                tcpbuf[i].value.data.u32 = tmp.f32 / (coeffi * unitCoeffi);
            }
            else
            {
                tcpbuf[i].value.data.u32 = tmp.u32 / (coeffi * unitCoeffi);
            }
        }

        if (destDataType == S_INT_T)
        {
            if (tcpbuf[i].data_type == FLOAT_T)
            {
                tcpbuf[i].value.data.s32 = tmp.f32 / (coeffi * unitCoeffi);
            }
            else
            {
                tcpbuf[i].value.data.s32 = tmp.s32 / (coeffi * unitCoeffi);
            }
        }
//         if(tcpbuf[i].data_id == 74 || tcpbuf[i].data_id == 24)
//         {
//             EMS_LOG(LL_ERROR, MODULE_C, FALSE, "i=%d, index=%d, dev_code=%d, data_id=%d, data_type=%d data--u32=%u, s32=%d float=%f.\n",
//                 i, tcpbuf[i].index, tcpbuf[i].dev_code, tcpbuf[i].data_id,tcpbuf[i].data_type,
//                 tcpbuf[i].value.data.u32, tcpbuf[i].value.data.s32, tcpbuf[i].value.data.f32);
//         }

        HCFREE(ptlData);
    }

    return ret;
}

//modbus 主站接收数据处理
void *CollectMasterInput(void *arg)
{
    MB_MASTER_T *mb_master = arg;

    prctl(PR_SET_NAME, "CLCT_CMDINPUT_THREAD");
    /* ModbusRtuMaster 等待数据输入 */
    while (!mb_master->inputThreadIsExit)
    {
        DEV_DATA_T *tcpbuf = NULL;

        int32_t ret = 0, count = 0;
        uint32_t i = 0, same_count = 0, diff_count = 0, diff_flag = 0, start_ptr = 0;
        int32_t ptl_type = -1, tmp_ptl_type = -1;

        Q_WAIT(cmdqOutQ);
        count = Q_NUMS(cmdqOutQ);//计算队列中元素个数，一次性读取全部
        if (count > 0)
        {
            tcpbuf = (DEV_DATA_T *)calloc(count, sizeof(DEV_DATA_T));

            Q_OUT_N(cmdqOutQ, tcpbuf, count);

            __sync_add_and_fetch(&g_PlatStic.recvCmdCntClctr, 1);

#ifdef SR_TEST
            static uint16_t m = 0;
            gettimeofday(&g_PlatSR[m].getCmdT, NULL);
            tcpbuf->u32Tag = g_PlatSR[m].u32Tag;
            printf("%s test_cout:%d\n", __func__, m);
            m++;
#endif
            if (SDB_GetUseCoeffFlag() == TRUE)
            {
                coeffiCoversion(tcpbuf, count);
            }

            if (count == 1)
            {
                ptl_type = SDB_GetDevPtlType(tcpbuf->dev_code, tcpbuf->index);

                ret = MasterSendCommand(mb_master, ptl_type, tcpbuf, 1);
                if (ret!= 0)
                {
                    EMS_LOG(LL_ERROR, MODULE_C, false, "SendCommand error!\n");
                }
            }
            else
            {
                for (i = 0; i < count; i++)
                {
                    if ((i+1)< count)
                    {
                        ptl_type = SDB_GetDevPtlType(tcpbuf[i].dev_code, tcpbuf[i].index);
                        tmp_ptl_type = SDB_GetDevPtlType(tcpbuf[i+1].dev_code, tcpbuf[i+1].index);
                        if (((ptl_type == tmp_ptl_type)&&(ptl_type == IEC104)) || (ptl_type != tmp_ptl_type))
                        {
                            ret = MasterSendCommand(mb_master, ptl_type, &tcpbuf[i], 1);
                            if (ret!= 0)
                            {
                                EMS_LOG(LL_ERROR, MODULE_C, false, "SendCommand error!\n");
                            }
                            start_ptr = i+1;
                            diff_flag ++;
                            continue;
                        }
                        else if ((ptl_type == tmp_ptl_type)&&(ptl_type == MODBUS))
                        {
                            if ((tcpbuf[i].dev_code == tcpbuf[i+1].dev_code)
                            && (tcpbuf[i].moduleID == tcpbuf[i+1].moduleID)
                            && (tcpbuf[i].index == tcpbuf[i+1].index)
                            && (tcpbuf[i].data_id +1 == tcpbuf[i+1].data_id))
                            {
                                same_count ++;
                            }
                            else
                            {
                                diff_count ++;
                            }
                        }
                    }
                    else if ((i+1) == count)
                    {
                        ptl_type = SDB_GetDevPtlType(tcpbuf[i].dev_code, tcpbuf[i].index);
                        tmp_ptl_type = SDB_GetDevPtlType(tcpbuf[i-1].dev_code, tcpbuf[i-1].index);
                        if (((ptl_type == tmp_ptl_type)&&(ptl_type == IEC104)) || (ptl_type != tmp_ptl_type))
                        {
                            ret = MasterSendCommand(mb_master, ptl_type, &tcpbuf[i], 1);
                            if (ret!= 0)
                            {
                                EMS_LOG(LL_ERROR, MODULE_C, false, "SendCommand error!\n");
                            }
                        }
                        else if ((ptl_type == tmp_ptl_type)&&(ptl_type == MODBUS))
                        {
                            if (((tcpbuf[i].dev_code != tcpbuf[i-1].dev_code)
                            || (tcpbuf[i].moduleID != tcpbuf[i-1].moduleID)
                            || (tcpbuf[i].index != tcpbuf[i-1].index)
                            || (tcpbuf[i].data_id != tcpbuf[i-1].data_id + 1)))  //最后一个
                            {
                                diff_count ++;
                            }
                        }
                    }

                    if ((diff_count > 0) || (diff_flag >0))
                    {
                        if ((diff_flag == 0)&&(same_count > 0))
                        {
                            ret = MasterSendCommand(mb_master, ptl_type, tcpbuf+start_ptr, same_count+1);
                            if (ret!= 0)
                            {
                                EMS_LOG(LL_ERROR, MODULE_C, false, "SendCommand error!\n");
                            }
                        }
                        else
                        {
                            ret = MasterSendCommand(mb_master, ptl_type, tcpbuf+start_ptr, 1);
                            if (ret!= 0)
                            {
                                EMS_LOG(LL_ERROR, MODULE_C, false, "SendCommand error!\n");
                            }
                        }
                        start_ptr = i + 1;
                        diff_count = 0;
                        same_count = 0;
                        diff_flag ++;

                    }
                    else if ((diff_count == 0)&&same_count == (count-1) && (diff_flag == 0))
                    {
                        ret = MasterSendCommand(mb_master, ptl_type, tcpbuf, count);
                        if (ret!= 0)
                        {
                            EMS_LOG(LL_ERROR, MODULE_C, false, "SendCommand error!\n");
                        }
                        same_count = 0;
                    }

                }

            }
        }

        HCFREE(tcpbuf);

    }

    printf("%s CLCT_CMDINPUT_THREAD exit.\n", __func__);
    return NULL;
}
