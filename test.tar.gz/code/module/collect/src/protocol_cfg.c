#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <stdbool.h>
#include "protocol.h"
#include "protocol_cfg.h"
#include "collect.h"
#include "common.h"
#include "logUtil.h"
#include "sdb.h"
#include "calc.h"


//各类型的modbus从站设备模型
MB_SLAVER_T g_mbSlaver[] =
{
    //lcd
    {
        "CEMS100",
        1,
        {0},
        0,
        0,
        0,
        {0},
        {0},
        0,
        {0},

        0,
        {0},
        0,
        0,
        1,
        0,
        0,
        NULL,
        {
            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL
        },
        0,
        CollectMasterScanSend,
        CollectMasterScanCmdSend,
        CollectMasterRevPro,

        {{{{0,0,0,0,0,0,0,{0},0,0,0,0,0,0,0,0}}, 0, 0, 0}},
        {{{0,0,0,0,0,0,0,{0},0,0,0,0,0,0,0,0}}, 0, 0, 0},
        {{{0,0,0,0,0,0,0,{0},0,0,0,0,0,0,0,0}}, 0, 0, 0},
        {0,0,0,0,0,0,0,{0},0,0,0,0,0,0,0,0},
        {0,500,500,300,0,0,0},
        MbmInit,
        MBM_ComRevCtl,
        MBM_ComSendCtl,
        MBM_CurCmdCtl,

        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        NULL,
        NULL,
    },

};

//动态分配设备的测点数据，用于传输管道
//TODO 可以删除，用实时数据库来代替其功能
void InitMbSlaverData(void)
{
    MB_SLAVER_T *mb_slaver = mb_slaver_tab.head;
    int32_t i, j, m = 0;

    for (i = 0; i < mb_slaver_tab.num; ++i)
    {
        mb_slaver->data_num = 0;
        mb_slaver->min_data_id = 1;

        for (j=0; j< mb_slaver->protocol_num; j++)
        {
            mb_slaver->data_num += mb_slaver->protocol[j]->ptl_data_num;

            if (mb_slaver->max_data_id < mb_slaver->protocol[j]->max_data_id)
            {
                mb_slaver->max_data_id = mb_slaver->protocol[j]->max_data_id;
            }
            if (mb_slaver->min_data_id > mb_slaver->protocol[j]->min_data_id)
            {
                mb_slaver->min_data_id = mb_slaver->protocol[j]->min_data_id;
            }
        }

        //传管道的测点数据，每个设备保存一份,设备id都是从1开始
        mb_slaver->data = (DATA_U *)malloc((mb_slaver->data_num + 1) * sizeof(DATA_U));
        if (mb_slaver->data != NULL)
        {
            // memset(mb_slaver->data, 0, (mb_slaver->data_num + 1));
            for (m = 0; m < mb_slaver->data_num + 1; m++)
            {
                mb_slaver->data[m].u32 = 0;
            }
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "malloc fail\n");
            exit(EXIT_FAILURE);
        }

        mb_slaver = mb_slaver->next;
    }
}

void InitCollectPara(void)
{
    uint16_t i = 0, dev_num = 0 ,j = 0;
    uint16_t mbmasterid = 0;
    COMPORT_T *comport = NULL;
    DEV_INFO_T *dev = NULL;

    int32_t dwCommNum = SDB_GetComDevNum();//获取设备类型数

    dev = (DEV_INFO_T *)calloc(1, sizeof(DEV_INFO_T));
    comport = (COMPORT_T *)calloc(1, sizeof(COMPORT_T));
    if ((dev == NULL) || (comport == NULL))
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "malloc comport/comdev failed !\n");
        exit(EXIT_FAILURE);
    }

    for (i = 0; i < dwCommNum; i++)
    {
        SDB_GetComportByNo(comport, &mbmasterid, i, &dev_num);
        InsertMbMaster(&mb_master_tab, comport, mbmasterid);

        for (j = 0; j < dev_num; j++)
        {
            SDB_GetDevOfComportByNo(dev, mbmasterid, j);
            InsertDevToMbSlaver(&mb_slaver_tab, dev);
            InsertDevToMbMaster(&mb_master_tab, &mb_slaver_tab, mbmasterid, dev->dev_name, dev->index, dev->dev_code);
        }
    }

    //初始化每个设备的数据
    InitMbSlaverData();

    GenerateDevCodeTab();

    //生成协议栈输入数据处理的相关数据结构
    CollectInputInterfaceInit();

    sem_init(&mb_master_tab.canBusLock, 0, 1);

    HCFREE(comport);
    HCFREE(dev);
}
