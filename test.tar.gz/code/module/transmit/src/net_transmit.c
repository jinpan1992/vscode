#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <netdb.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <sys/prctl.h>
#include "protocol_operate.h"
#include "net_transmit.h"
#include "transmit.h"
#include "xml_analysis.h"
#include "logUtil.h"
#include "transmit_conf.h"
#include "commonTest.h"
#include "sys.h"

//网络端口链接对象handle
typedef struct
{
    BOOL isRunning;
    pthread_t netThread;
} NET_SERVER_T;

int32_t g_NetServerN;  /* tcp socket  个数 */
COMM_NET_TYPE_T net_server_link[MAX_SERVER_LINK_NUM];
int32_t g_NetIpResetFlag;                   //网络重置标志
NET_SERVER_T g_NetServer = {0};
int32_t g_Efd = INVALID_VALUE;

// #define CONCURRENT_TEST 1

extern PLAT_STATISTICS_T g_PlatStic;

/**
 * @brief 设置客户端链接属性
 * @param
 *
 * @return
 */
void  SetKeepAliveSockopt(int32_t socketFd)
{
    int keepalive = 1; // 开启keepalive属性
    int keepidle = 10; // 如该连接在60秒内没有任何数据往来,则进行探测
    int keepinterval = 5; // 探测时发包的时间间隔为5 秒
    int keepcount = 3; // 探测尝试的次数。如果第1次探测包就收到响应了,则后2次的不再发。

    (void)setsockopt(socketFd, SOL_SOCKET, SO_KEEPALIVE, (void *) &keepalive, sizeof(keepalive));
    (void)setsockopt(socketFd, IPPROTO_TCP, TCP_KEEPIDLE, (void*) &keepidle, sizeof(keepidle));
    (void)setsockopt(socketFd, IPPROTO_TCP, TCP_KEEPINTVL, (void *) &keepinterval, sizeof(keepinterval));
    (void)setsockopt(socketFd, IPPROTO_TCP, TCP_KEEPCNT, (void *) &keepcount, sizeof(keepcount) );

    return;
}

/**
 * @brief  设置event方式加入到epoll句柄中
 * @param  int32_t epoll_fd  句柄集,int32_t  fd 网络设备句柄,uint32_t  EventType 读入边缘方式（预留）
 *
 * @return  NULL
 */
void epollAddEvent(int32_t epoll_fd, int32_t fd, uint32_t EventType)
{
    int32_t ret = 0;
    struct epoll_event event;
    memset(&event.data, 0, sizeof(epoll_data_t));
    event.data.fd = fd;
    event.events = EPOLLIN | EPOLLET; /*读入,边缘触发方式*/

    ret = epoll_ctl(epoll_fd, EPOLL_CTL_ADD, fd, &event);
    if (ret == -1)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "epoll_ctl EPOLL_CTL_ADD err, abort!\n");
        abort();
    }
}

/**
 * @brief
 * @param
 *
 * @return
 */
void EpollDelEvent ( int32_t epoll_fd, int32_t fd, uint32_t EventType )
{
    struct epoll_event event;
    event.data.fd = fd;
    event.events = EPOLLIN | EPOLLET;   //读入,边缘触发方式

    if (epoll_ctl(epoll_fd, EPOLL_CTL_DEL, fd, &event))
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "epoll_ctl err, abort!\n");
        return ;
    }
}

/**
 * @brief 关闭所有net客户端链接
 * @param
 *
 * @return 成功返回0  错误返回-1
 */
int32_t clear_net_client_comm_reg ( void )
{
    uint32_t eventType =  EPOLLIN | EPOLLET;
    CLIENT_LINK_SLAVER_T *p_head = NULL;
    CLIENT_LINK_SLAVER_T*p_client_tmp = NULL;
    int32_t reg_num = 0;
    int32_t que_id  = 0;

    p_head = g_CommReg.comm_L;//头结点是空节点
    reg_num = g_CommReg.num;

    if (reg_num == 0)
    {
        return 0;
    }

    if (p_head->next == NULL)
    {
        return 0;
    }

    for (que_id = 0; que_id < reg_num; que_id++)
    {
        p_client_tmp = p_head->next;

        if (p_client_tmp == NULL)
        {
            break;
        }

        if (p_client_tmp->comm_type == NETTYPE)
        {
            printf("%s close:%d (L%d)\n", __func__, p_client_tmp->link_fd, __LINE__);
            EpollDelEvent(g_Efd, p_client_tmp->link_fd, eventType);
            close(p_client_tmp->link_fd);
            DeleteComm(p_client_tmp->link_fd);
        }
        else
        {
            p_head = p_head->next ;
        }
    }

    int32_t i = 0;
    int32_t j = 0;
    //关闭所有存在的 等待链接的设备端口设备
    for (i = 0; i < g_NetServerN; i++)
    {
        for (j = 0; j < net_server_link[i].client_num; j++)
        {
            net_server_link[i].client_link[j] = 0;
        }
        net_server_link[i].client_num = 0;
    }

    return 0;
}

/**
 * @brief 关闭全局tcp socket   ，清空全局计数
 * @param
 *
 * @return 返回 0
 */
int32_t clear_net_server_conn ( void )
{
    int in = 0;
    uint32_t eventType = EPOLLIN | EPOLLET;
    //关闭所有存在的 等待链接的设备端口设备
    for (in = 0; in < g_NetServerN; in++)
    {
        EpollDelEvent(g_Efd,net_server_link[in].server_fd, eventType);

        close(net_server_link[in].server_fd);
    }
    //清空链接的设备端口设备计数
    memset(net_server_link, 0, sizeof (net_server_link));
    g_NetServerN = 0;
    return 0;
}

/**
 * @brief 重置所有网络链接，释放链接
 * @param
 *
 * @return 成功返回0
 */
int32_t ClearNetEpoll ( void )
{
    clear_net_client_comm_reg();
    clear_net_server_conn();

    return 0;
}

/**
 * @brief  创建和绑定一个TCP socket
 * @param  int32_t port 端口号 ,    char  netN  网络设备 0 为网口eth0 1 为 eth1
 *
 * @return  正确返回创建的socket  错误返回-1
 */
int32_t CreateAndBind(net_port_attr port_link, char netN)
{
    uint16_t port = port_link.netport;
    int sockfd;
    struct sockaddr_in addrLocal;
    struct ifreq ifr;

#if INTERFANCE
    char *ifname0="ens33";
    char *ifname1="lo";
#else
    char *ifname0="eth1";
    char *ifname1="eth2";
#endif
    int32_t bindErrorExitFlag = 0;

    if (netN == 0)
    {
        strncpy (ifr.ifr_name, ifname0, IFNAMSIZ - 1);
    }
    else if (netN == 1)
    {
        strncpy (ifr.ifr_name, ifname1, IFNAMSIZ - 1);
    }
    else
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "eth name error  only eth0 eth1 \n" );
    }

    /* Get the Socket file descriptor */
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "ERROR: Failed to obtain Socket Despcritor.\n" );
        return (0);
    }

    if (ioctl(sockfd, SIOCGIFADDR, &ifr) == -1)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "%s ioctl Error.\n", ifr.ifr_name);
        close(sockfd);
        return -1;
    }

    struct sockaddr_in *myaddr;
    myaddr = (struct sockaddr_in*) & (ifr.ifr_addr);

    /* Fill the local socket address struct */
    addrLocal.sin_family = AF_INET;
    addrLocal.sin_port = htons(port);
    addrLocal.sin_addr.s_addr = myaddr->sin_addr.s_addr;
//  addr_local.sin_addr.s_addr  =  htonl (INADDR_ANY);     //2018-04-19 更新绑定地址 为任意地址  AutoFill local address

    bzero(&( addrLocal.sin_zero ), 8);    // Flush the rest of struct
    int32_t reuse = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char*) &reuse, sizeof(reuse)) < 0)
    {
        return -1;
    }
    SetKeepAliveSockopt(sockfd);

    /*  Bind a special Port */
    while (1)
    {
        if (bind(sockfd, (struct sockaddr*)&addrLocal, sizeof(struct sockaddr)) == -1)
        {
            perror("bind err");
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "ERROR: Failed to bind IP:%s Port %d.\n", inet_ntoa(myaddr->sin_addr), port);

            usleep(100 * 1000);

            bindErrorExitFlag++;
            if (bindErrorExitFlag > 1500)  // 0.1s  * 1500 = 2.5min
            {
                EMS_LOG(LL_ERROR, MODULE_T, FALSE, "Bind error and exit.\n");
                exit(EXIT_FAILURE);
            }
        }
        else
        {
            EMS_LOG(LL_INFO, MODULE_T, FALSE,  "OK: Bind the Port %d sucessfully.sockfd %d   IP: %s \n",
                    port, sockfd, inet_ntoa(myaddr->sin_addr));
            return sockfd;
        }
    }
}

/**
 * @brief  设置网络客户端链接为非阻塞模式
 * @param  int sfd
 *
 * @return  返回 0
 */
int MakeSocketNonBlocking(int sfd)
{
    int flags, s;
    //得到文件状态标志
    flags = fcntl(sfd, F_GETFL, 0);
    if (flags == -1)
    {
        perror("get fcntl  error");
        abort();
        return -1;
    }
    //设置文件状态标志
    flags |= O_NONBLOCK;
    s = fcntl(sfd, F_SETFL, flags);
    if (s == -1)
    {
        perror("fcntl error MakeSocketNonBlocking");
        abort();
        return -1;
    }

    return 0;
}

/**
 * @brief  注册一个协议处理的链表实例，加入epoll访问方式
 * @param
 *
 * @return  NULL
 */
void InsetNetClient (int32_t epoll_fd, int32_t dwClientFd, COMM_NET_TYPE_T *pNetServer)
{
    uint32_t eventType = EPOLLIN | EPOLLET;
    int32_t cliendNum = pNetServer->client_num;
    int32_t cliendId = 0;
    int32_t commConnId = 0;

    if (cliendNum < MAX_CLINET_LINK_NUM)
    {
        printf ( "-----------InsetNetClient:%d ------------\n", pNetServer->client_num);
        commConnId = pNetServer->comm_conn_id;

        InsertComm(dwClientFd, commConnId, NETTYPE);                //注册一个协议处理的链表实例的
        epollAddEvent(epoll_fd, dwClientFd, eventType);

        pNetServer->com_type = NETTYPE;

        for(cliendId = 0; cliendId < MAX_CLINET_LINK_NUM; cliendId++)
        {
            if (pNetServer->client_link[cliendId] == 0 )
            {
                pNetServer->client_link[cliendId] = dwClientFd;
                pNetServer->client_num = pNetServer->client_num + 1;
                break;
            }
        }

        if (cliendId == MAX_CLINET_LINK_NUM)
        {
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "insert InsetNetClient error .\n");
        }
    }
    else
    {
        close(dwClientFd);
    }
}

/**
 * @brief 错误处理
 * @param
 *
 * @return
 */
void FaultStateCheck ( int ret_s, char * errorShow )
{
    if (ret_s == -1)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "errorShow err!\n");
        abort ();
    }
}

/**
 * @brief socket客户端连接
 * @param
 *
 * @return
 */
int32_t AccpetServerLink (int32_t sfd, COMM_NET_TYPE_T *net_server_data )
{
    char hbuf[NI_MAXHOST], sbuf[NI_MAXSERV];

    struct sockaddr in_addr;
    socklen_t in_len;
    int32_t  link_fd = 0;
    int32_t  accept_ret = 0;
    int32_t  ret_info = 0;

    in_len = sizeof(in_addr);
    link_fd = accept(sfd, &in_addr, &in_len);

    if (link_fd == -1)
    {
        if ((errno == EAGAIN) || (errno == EWOULDBLOCK))
        {
            /* We have processed all incoming connections. */
            //处理完 lisen队列里所有的连接
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "accept err!\n");
        }

        accept_ret = -1;
    }
    else
    {
        //将地址转化为主机名或者服务名
        //flag参数:以数字名返回
        //主机地址和服务地址
        ret_info = getnameinfo ( &in_addr, in_len, hbuf, sizeof hbuf, sbuf, sizeof sbuf, NI_NUMERICHOST | NI_NUMERICSERV );
        if ( ret_info == 0 )
        {
            printf("Accepted connection on descriptor %d (host=%s, port=%s)\n", link_fd, hbuf, sbuf);
        }

        if ( net_server_data->allow_all_flag  > 0 )
        {
            accept_ret =  link_fd;
        }
        else
        {
            if (strncmp(net_server_data->allow_ip, hbuf, strlen(net_server_data->allow_ip)))
            {
                close ( link_fd );
                accept_ret =  -1;
            }
            else
            {
                accept_ret =  link_fd;
            }

        }
        printf ("net_server_data.allow_ip  %s hbuf(host=%s)  accept_ret %d \n", net_server_data->allow_ip, hbuf, accept_ret);
    }
    return accept_ret;
}

/**
 * @brief 重置系统客户端网络链接，关闭无法使用的的链接，插入新链接
 * @param
 *
 * @return 成功返回0
 */
int32_t ResetNetEpollLink ( void )
{
    ClearNetEpoll();

    NetServer_Init();

    return 0;
}

/**
 * @brief 根据 net端口链接对象句柄 查询net端口实例类型
 * @param int fd 设备句柄
 *
 * @return 0查找不成功,> 0:查找成功返回端口实例类型
 */
int32_t  GetNetServerLinkCaseType (int32_t fd)
{
    int32_t comid = 0;

    for (comid = 0; comid < g_NetServerN; comid ++)
    {
        if (fd == net_server_link[comid].server_fd)
        {
            return comid;
        }
    }
    return  -1 ;
}

/**
 * @brief 重置系统客户端网络链接，关闭无法使用的的链接
 * @param int fd 设备句柄
 *
 * @return 成功返回0  失败返回-1
 */
int32_t detection_reset_net_client_link ( )
{
    int32_t net_link_id = 0;
    struct tcp_info info;
    int32_t link_id = 0;
    int optlen = sizeof (struct tcp_info);

    for (net_link_id = 0; net_link_id < g_NetServerN; net_link_id++)
    {
        for (link_id = 0; link_id < MAX_CLINET_LINK_NUM; link_id++)
        {
            if (net_server_link[net_link_id].client_link[link_id] > 0)
            {
                if (getsockopt(net_server_link[net_link_id].client_link[link_id], IPPROTO_TCP, TCP_INFO, &info, (socklen_t *) &optlen) < 0 )
                {
                    EMS_LOG(LL_ERROR, MODULE_T, FALSE, "getsockopt() TCP_INFO error. \n" );

                    return -1;
                }

                if (info.tcpi_state == TCP_ESTABLISHED)
                {

                }
                else
                {
                    DeleteComm ( net_server_link[net_link_id].client_link[link_id]);
                    printf ("TCP_ESTABLISHED net_client_link_info[ %d ].client_fd[%d] %d\n", net_link_id,link_id,net_server_link[net_link_id].client_link[link_id] );
                    close (net_server_link[net_link_id].client_link[link_id]);
                    net_server_link[net_link_id].client_link[link_id]= 0;
                    net_server_link[net_link_id].client_num = net_server_link[net_link_id].client_num -1;
                    printf ("client_num %d \n",net_server_link[net_link_id].client_num );
                }
            }
        }
    }
    return 0;
}

/**
 * @brief 关闭无法正常使用的客户端网络链接，重置网络计数
 * @param int fd 设备句柄
 *
 * @return 成功返回0  失败返回-1
 */
int32_t ShutdownNetClientConn(int32_t client_fd)
{
    int32_t link_id = 0;
    int32_t net_link_id = 0;

    for (net_link_id = 0; net_link_id < g_NetServerN; net_link_id ++)
    {
        for (link_id = 0; link_id < MAX_CLINET_LINK_NUM; link_id++)
        {
            if (net_server_link[ net_link_id ].client_link[link_id] == client_fd)
            {
                DeleteComm(client_fd);
                close(client_fd);

                net_server_link[net_link_id] .client_link[link_id] = 0;
                net_server_link[net_link_id].client_num =  net_server_link[net_link_id].client_num - 1;
                printf("client_num %d \n", net_server_link[net_link_id].client_num);
                break;
            }
        }
    }

    return 0;
}

/**
 * @brief  网络链接非阻塞 针对设备句柄操作及处理
 * @param
 *
 * @return 1:写失败, 0:非写失败
 */
int32_t NetFifoDataProcess(struct epoll_event *p_event_case, int16_t com_type)
{
    int32_t dataProcessRet = 0;
    ssize_t count = 0;
    uint8_t inbuf[2 * READ_FD_MAX_LEN] = { 0 };
    uint8_t sendbuf[2 * SEND_FD_MAX_LEN] = { 0 };
    int32_t sendptr = 0;
    int32_t readptr = 0;
    int32_t sendnum = 0;

    while (1)
    {
        count = read(p_event_case->data.fd, &inbuf[readptr], READ_FD_MAX_LEN);
        if (count <= 0)
        {
            break;
        }
        readptr += count;

        if (readptr > READ_FD_MAX_LEN)
        {
            printf("%s fd:%d readptr > READ_FD_MAX_LEN.(L%d)\n", __func__, p_event_case->data.fd, __LINE__);
            readptr = 0;
            break;
        }
    }

#ifdef CONCURRENT_TEST
//     PrintBuf(readptr, (char *)inbuf, p_event_case->data.fd, 0);
//     gettimeofday(&start_time, NULL);
//     printf("接受数据\n");
#endif
    //接收数据处理,结果填入sendbuf,立即回复或者异步回复
    sendnum = RevProcess(p_event_case->data.fd, inbuf, readptr, sendbuf);

    for (sendptr = 0; sendptr < sendnum; )
    {
        count = write(p_event_case->data.fd, &sendbuf[sendptr], sendnum);
        if (count == -1)
        {
            /* If errno == EAGAIN, that means send buffer is full. So send later. */
            if (errno != EAGAIN)
            {
                EMS_LOG(LL_ERROR, MODULE_T, FALSE,"write socket error %d\n", errno );
                dataProcessRet = 1;
                break;
            }
        }
        else
        {
            sendptr += count;
        }

        if (sendbuf[7] == 0x03 || sendbuf[7] == 0x04)
        {
            __sync_add_and_fetch(&g_PlatStic.respRTrsmt, 1);
        }
        else if (sendbuf[7] == 0x06 || sendbuf[7] == 0x10)
        {
            __sync_add_and_fetch(&g_PlatStic.respWTrsmt, 1);
        }
    }

#ifdef CONCURRENT_TEST
    //PrintBuf(sendptr, (char *)sendbuf, p_event_case->data.fd, 1);
#endif
    /* recvCmdCount++;
    if(recvCmdCount < 5000)
    {
        gettimeofday(&end_time, NULL);
        float ms = end_time.tv_sec * 1000000 + end_time.tv_usec - start_time.tv_sec * 1000000 - start_time.tv_usec;
        total_time2 = total_time2 +ms;
            printf("clientCount:%d,recvCmdCount:%f,end_time tv_sec:%ld tv_usec:%ld, start_time tv_sec:%ld tv_usec:%ld, cost time:%f us, total_time2 :%f.\n",
                clientCount, recvCmdCount, end_time.tv_sec, end_time.tv_usec, start_time.tv_sec, start_time.tv_usec, ms, total_time2);
    }*/


    return dataProcessRet;
}

void *NetThreadStart(void *arg)
{
    int32_t ret = 0;
    int32_t clientFd = 0;
    int32_t eventFd = 0;
    int32_t n = 0;
    int32_t i = 0;
    int32_t serverIdx = 0;
    struct epoll_event *pEvents = NULL;

    pEvents = (struct epoll_event *)calloc(MAX_EVENTS, sizeof(struct epoll_event));
    if (pEvents == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "calloc p_events error exit\n");
        exit(EXIT_FAILURE);
    }

    NET_SERVER_T *pHandle = (NET_SERVER_T*)arg;
    prctl(PR_SET_NAME, "NET_SERVER_THREAD");
    while (pHandle->isRunning)
    {
        if (g_NetIpResetFlag)
        {
            ResetNetEpollLink();  //net epoll restart init
            g_NetIpResetFlag = 0;
        }

        if (g_Efd <= 0)
        {
            NanoSleep(1000);
            // EMS_LOG(LL_WARNING, MODULE_T, FALSE, "NetServer donot start, maybe not bind.\n");
            continue;
        }

        n = epoll_wait(g_Efd, pEvents, MAX_EVENTS, 100);
        if (n > 0)
        {
#ifdef CONCURRENT_TEST
            static int32_t recvCmdCount = 0;
            static int32_t clientCount = 0;
            static struct timeval start_time;
            static struct timeval end_time;
            float32_t total_time2 = 0.0;

            if (recvCmdCount == 0 && clientCount == 0)
            {
                gettimeofday(&start_time, NULL);
            }
#endif
            for (i = 0; i < n; i++)
            {
                eventFd = pEvents[i].data.fd;

                serverIdx = GetNetServerLinkCaseType(eventFd);

                EMS_LOG(LL_DEBUG, MODULE_T, FALSE, "\n------event_fd :%d  server_idx:%d-------\n",eventFd, serverIdx);

                if ((pEvents[i].events & EPOLLERR)
                    || (pEvents[i].events & EPOLLHUP)
                    || (!(pEvents[i].events & EPOLLIN)))
                {
                    /* An error has occured on this fd, or the socket is not
                    ready for reading (why were we notified then?) */
                    EMS_LOG(LL_ERROR, MODULE_T, FALSE,  "error ---events[i].data.fd = %d\n", eventFd );

                    ShutdownNetClientConn(eventFd);
                }
                else if (serverIdx >= 0)     //listen 监听连接
                {
                    /* We have a notification on the listening socket, which
                    means one or more incoming connections. */
                    while (1)
                    {
                        detection_reset_net_client_link();

                        if (g_NetServerN > MAX_SERVER_LINK_NUM)
                        {
                            break;
                        }

                        clientFd = AccpetServerLink (eventFd, &net_server_link[serverIdx]);

                        if (-1 == clientFd)
                        {
                            break;
                        }
                        /* Make the incoming socket non-blocking and add it to the
                        list of fds to detection. */
                        SetKeepAliveSockopt(clientFd);
                        MakeSocketNonBlocking(clientFd);
                        InsetNetClient(g_Efd, clientFd, &net_server_link[serverIdx]);     //插入网络客户端

#ifdef CONCURRENT_TEST
                        //clientCount++;
#endif
                    }
                }
                else if (pEvents[i].events & EPOLLIN) //读事件触发
                {
                    int32_t net_type = NETTYPE;

                    ret = NetFifoDataProcess (&(pEvents[i]), net_type);
                    EMS_LOG(LL_DEBUG, MODULE_T, FALSE, "NetFifoDataProcess ret:%d.\n", ret);

                    if (ret > 0)
                    {
                        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "net write error  close connection fd  %d\n", eventFd);

                        /* Closing the descriptor will make epoll remove it
                        from the set of descriptors which are detectioned. */

                        ShutdownNetClientConn(eventFd);
                    }

                    __sync_add_and_fetch(&g_PlatStic.recvCmdCntTrsmt, 1);
#ifdef CONCURRENT_TEST
                    recvCmdCount++;
                    if(recvCmdCount < 1000)
                    {
                        gettimeofday(&end_time, NULL);
                        float ms = end_time.tv_sec * 1000 + end_time.tv_usec / 1000 - start_time.tv_sec * 1000 - start_time.tv_usec / 1000;
                        total_time2 = total_time2 +ms;
                        if (ms != 0.0)
                        {
                            printf("clientCount:%d,recvCmdCount:%d,end_time tv_sec:%ld tv_usec:%ld, start_time tv_sec:%ld tv_usec:%ld, cost time:%f ms, total_time2 :%f.\n",
                               clientCount, recvCmdCount, end_time.tv_sec, end_time.tv_usec, start_time.tv_sec, start_time.tv_usec, ms, total_time2);
                        }
                    }
#endif
                }
            }
        }
    }

    free(pEvents);
    ClearNetEpoll();

    return EXIT_SUCCESS;
}

int32_t NetServer_Bind(int32_t dwCommConnId)
{
    int32_t ret = 0, np_id = 0, tmp_server_fd = 0;
    uint32_t eventType =  EPOLLIN | EPOLLET;

    const comport_s *pComPort = CommConn_GetPortAttr(dwCommConnId);

    int32_t cur_net_port_num = pComPort->net_port_num;
    int32_t net_id = CommConn_GetPortId(dwCommConnId);

    if (g_Efd == INVALID_VALUE)
    {
        g_Efd = epoll_create1(0); /*除了参数size被忽略外,此函数和epoll_create完全相同*/
        FaultStateCheck (g_Efd, "epoll_create");
    }

    //网口注册 上位机
    for (np_id = 0; np_id < cur_net_port_num; np_id ++)
    {
        if (np_id < MAXNETPORTNUM)
        {
            tmp_server_fd = CreateAndBind(pComPort->port_attr[np_id], net_id);

            if (tmp_server_fd >= 0)
            {
                net_server_link[g_NetServerN].server_fd = tmp_server_fd;
                memset (net_server_link[g_NetServerN].client_link, 0, sizeof (net_server_link[g_NetServerN].client_link));
                net_server_link[g_NetServerN].com_type = NETTYPE;
                net_server_link[g_NetServerN].comm_conn_id = dwCommConnId;
                strcpy (net_server_link[ g_NetServerN ].allow_ip, pComPort->port_attr[np_id].allow_ip);
                net_server_link[g_NetServerN].allow_all_flag = pComPort->port_attr[np_id].allow_all_flag;
                net_server_link[g_NetServerN].link_flag = 0;
                g_NetServerN ++;

                MakeSocketNonBlocking(tmp_server_fd);

                ret = listen(tmp_server_fd, SOMAXCONN);
                if (ret == -1)
                {
                    EMS_LOG(LL_ERROR, MODULE_T, FALSE, "listen err!\n");
                    abort();
                }

                epollAddEvent(g_Efd, tmp_server_fd, eventType);
            }
        }
    }
    return 0;
}

/**
 * @brief
 * @param
 *
 * @return
 */
int32_t NetServer_Init()
{
    int32_t conn_id = 0;

    int32_t dwCommConnNum = CommConn_GetObjNum();
    for (conn_id = 0; conn_id < dwCommConnNum; conn_id++)
    {
        if (CommConn_GetType(conn_id) == NETTYPE)  //查询网络设备
        {
            NetServer_Bind(conn_id);
        }
    }

    return OK;
}

int32_t NetServer_Start()
{
    int32_t res = OK;

    g_NetServer.isRunning = TRUE;

    res = pthread_create(&g_NetServer.netThread, NULL, NetThreadStart, &g_NetServer);

    if (res != 0)
    {
        perror("Thread NetThreadStart creation failed");
        exit(EXIT_FAILURE);
    }

    return res;
}

int32_t NetServer_Stop()
{
    g_NetServer.isRunning = FALSE;

    void *rtest;
    if (g_NetServer.netThread)
    {
        pthread_join(g_NetServer.netThread, &rtest);
        printf("transmit netThread join done.\n");
    }

    return OK;
}

int32_t NetServer_Restart()
{
    g_NetIpResetFlag = TRUE;
    return OK;
}

BOOL NetServer_IsRuning()
{
    return g_NetServer.isRunning;
}
