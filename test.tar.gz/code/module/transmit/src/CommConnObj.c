#include "CommConnObj.h"
#include "logUtil.h"
#include "protocol_operate.h"

int32_t g_ProtocolNum = 0;                                  /* 全局协议个数 */
protocol_s g_protocol[PROTOCOLNUM];                   /* 全局通信协议 */
int32_t g_CommConnNum = 0;                                  /* 全局连接设备接口数量 */
CommConnObj  *g_pComConn = NULL;                            /* 全局连接设备接口 ：现有 有两个串口 两个网口 */
int32_t g_SlaveDevNum = 0;                                  /* 设备结构体数量 */
slave_device_config_content *g_pSlaveDeviceInfo = NULL;     /* 设备结构体 */

//全局函数数据初始化
CommObjFunc FuncType[] =
{
    NULL,
    ModbusRtuSlave,    //modbus Uart 读数据
    ModbusTcpSlave,    //modbus Tcp 读数据
    NULL,
    NULL
};

/////////////////////////////////////////////Global Protocal////////////////////////////////////////////////////////////////
int32_t GlobalProtocol_Add(PROTOCOL_T *pPtl)
{
    int32_t i = 0, dwPtlDataNum = 0;

    if (pPtl == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    if (g_ProtocolNum == 0)
    {
        memset(g_protocol, 0, sizeof(protocol_s) * PROTOCOLNUM);
    }

    dwPtlDataNum = pPtl->ptl_data_num;

    PROTOCOL_T *new_protocol = pPtl;
    protocol_data_s *protocol_data = (protocol_data_s *)calloc(dwPtlDataNum, sizeof(protocol_data_s));
    if (protocol_data == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "malloc protocol_data failed !\n");
        exit(EXIT_FAILURE);
    }

    EMS_LOG(LL_INFO, MODULE_T, FALSE, "%s devCode:%d ptlDataNum:%d, g_ProtocolNum:%d.\n",
            __func__, new_protocol->dev_code, dwPtlDataNum, g_ProtocolNum);
    for (i = 0; i < dwPtlDataNum; i++)
    {
        PROTOCOL_DATA_T *tmp_protocol_data = &new_protocol->protocol_data[i];
        strcpy(protocol_data[i].data_name, tmp_protocol_data->data_name);

        protocol_data[i].data_id = tmp_protocol_data->data_id;
        protocol_data[i].data_address = tmp_protocol_data->address;
        protocol_data[i].data_byte_num = tmp_protocol_data->data_len;
        strcpy(protocol_data[i].data_info, tmp_protocol_data->data_info);
        protocol_data[i].data_type = tmp_protocol_data->data_type;
        protocol_data[i].data_sign = tmp_protocol_data->data_sign;
        protocol_data[i].scale_coefficient = tmp_protocol_data->coefficient;
        if (protocol_data[i].data_sign == SIGN_U)
        {
            protocol_data[i].low_limit1_uint = tmp_protocol_data->low_limit;
            protocol_data[i].high_limit1_uint = tmp_protocol_data->high_limit;
            protocol_data[i].low_limit2_uint = tmp_protocol_data->low_limit1;
            protocol_data[i].high_limit2_uint = tmp_protocol_data->high_limit1;
        }
        else
        {
            protocol_data[i].low_limit1 = tmp_protocol_data->low_limit;
            protocol_data[i].high_limit1 = tmp_protocol_data->high_limit;
            protocol_data[i].low_limit2 = tmp_protocol_data->low_limit1;
            protocol_data[i].high_limit2 = tmp_protocol_data->high_limit1;
        }

    }
    g_protocol[g_ProtocolNum].protocol_data = protocol_data;
    g_protocol[g_ProtocolNum].address = new_protocol->address;
    g_protocol[g_ProtocolNum].len = new_protocol->len;

    g_protocol[g_ProtocolNum].ptl_max_addr = new_protocol->max_address;
    g_protocol[g_ProtocolNum].ptl_min_addr = new_protocol->min_address;
    g_protocol[g_ProtocolNum].max_ptl_data_id = new_protocol->max_data_id;
    g_protocol[g_ProtocolNum].ptl_data_num = new_protocol->ptl_data_num;
    g_protocol[g_ProtocolNum].cmd = new_protocol->cmd;
    g_protocol[g_ProtocolNum].ptl_dev_code = new_protocol->dev_code;
    g_protocol[g_ProtocolNum].protocol_byte = new_protocol->byte_seq;
    g_protocol[g_ProtocolNum].protocol_word = new_protocol->word_seq;
    g_ProtocolNum++;

    if (g_ProtocolNum > PROTOCOLNUM)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "protocol num:%d is exceed!!\n", g_ProtocolNum);
        return ERR;
    }

    return OK;
}

int32_t GlobalProtocol_Clear()
{
    int32_t i = 0;

    for (i = 0; i < g_ProtocolNum; i++)
    {
        HCFREE(g_protocol[i].protocol_data);
        HCFREE(g_protocol[i].map);
        memset(g_protocol + i, 0, sizeof(protocol_s));
    }

    g_ProtocolNum = 0;

    return OK;
}

/**
 * @brief  生成协议地址索引表
 * @param
 *
 * @return
 */
static int32_t protocolMapCreate (protocol_data_s *ptlDat, uint32_t *map, uint16_t protocolDataNum, int32_t curPtlMinAddr)
{
    uint32_t i;

    for (i = 0; i < protocolDataNum; i++)
    {
        map[ptlDat[i].data_address - curPtlMinAddr] = i;
    }

    return OK;
}

int32_t GlobalProtocol_CreateMap()
{
    uint32_t *Map = NULL, Map_num = 0;
    uint32_t ptlnum = 0;
    int32_t i = 0;

    ptlnum = g_ProtocolNum;

    for (i = 0; i < ptlnum; ++i)
    {
        Map_num = g_protocol[i].len + 1;
        Map = (uint32_t *)malloc(Map_num * sizeof(uint32_t));
        if (Map == NULL)
        {
            return ERROR_T(ERR_DEFAULT_NO_MEM);
        }

        memset(Map, 0xFFFF, Map_num * sizeof(uint32_t));

        if (g_protocol[i].len < g_protocol[i].ptl_data_num)
        {
            HCFREE(Map);
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "protocol-file:%d (len:%d, ptl_data_num:%d)analysis error.\n",
                    g_protocol[i].ptl_dev_code, g_protocol[i].len, g_protocol[i].ptl_data_num);
            return ERROR_T(ERR_DEFAULT_INTERNAL_ERROR);
        }

        protocolMapCreate(g_protocol[i].protocol_data, Map, g_protocol[i].ptl_data_num, g_protocol[i].ptl_min_addr);
        g_protocol[i].map = Map;
    }

    return OK;
}

int32_t GlobalProtocol_DestroyMap()
{
    int32_t i = 0;

    for (i = 0; i < g_ProtocolNum; ++i)
    {
        HCFREE(g_protocol[i].map);
    }

    return OK;
}

protocol_data_s* GlobalProtocol_GetPD(int32_t dwDevCode, int32_t dwDataId)
{
    int32_t i = 0, j = 0;
    int32_t ptlnum = g_ProtocolNum;

    for (i = 0; i < ptlnum; ++i)
    {
        protocol_s *pTmpPtl = g_protocol + i;
        if (dwDevCode == pTmpPtl->ptl_dev_code)
        {
            for (j = 0; j < pTmpPtl->ptl_data_num; ++j)
            {
                protocol_data_s *pTmpPtlData = pTmpPtl->protocol_data + j;

                if (dwDataId == pTmpPtlData->data_id)
                {
                    return pTmpPtlData;
                }
            }
        }
    }

    return NULL;
}

//////////////////////////////////////////////////////SlaveDevice///////////////////////////////////////////////////////////////////
int32_t SlaveDevice_Create(int32_t dwSlaverNum)
{
    g_SlaveDevNum = dwSlaverNum;

    if (g_SlaveDevNum > 0)
    {
        g_pSlaveDeviceInfo = (slave_device_config_content *)malloc(sizeof(slave_device_config_content) * g_SlaveDevNum);
        memset(g_pSlaveDeviceInfo, 0, sizeof (slave_device_config_content) * g_SlaveDevNum);
    }

    return OK;
}

int32_t SlaveDevice_Destroy()
{
    int32_t i = 0;

    for (i = 0; i < g_SlaveDevNum; i++)
    {
        printf("%s i:%d p_slaver_corr_index_arr:%p\n", __func__, i, g_pSlaveDeviceInfo[i].p_slaver_corr_index_arr);
        HCFREE(g_pSlaveDeviceInfo[i].p_slaver_corr_index_arr);
        memset(g_pSlaveDeviceInfo + i, 0, sizeof(slave_device_config_content));
    }

    HCFREE(g_pSlaveDeviceInfo);
    g_SlaveDevNum = 0;

    return OK;
}

slave_device_config_content* SlaveDevice_Get(int32_t dwIndex)
{
    if (dwIndex >= g_SlaveDevNum)
    {
        return NULL;
    }

    return g_pSlaveDeviceInfo + dwIndex;
}

int32_t SlaveDevice_GetNum()
{
    return g_SlaveDevNum;
}

int32_t SlaveDevice_GetDevCode(int32_t dwIndex)
{
    if (dwIndex >= g_SlaveDevNum)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    return g_pSlaveDeviceInfo[dwIndex].dev_code;
}

int32_t SlaveDevice_GetMaxDataId(int32_t dwIndex)
{
    if (dwIndex >= g_SlaveDevNum)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    return g_pSlaveDeviceInfo[dwIndex].max_data_id;
}

int32_t SlaveDevice_GetCorNum(int32_t dwIndex)
{
    if (dwIndex >= g_SlaveDevNum)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    return g_pSlaveDeviceInfo[dwIndex].slave_id_cor_num;
}

int32_t SlaveDevice_SetDevCode(int32_t dwIndex, int32_t dwDevCode)
{
    if (dwIndex >= g_SlaveDevNum)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    g_pSlaveDeviceInfo[dwIndex].dev_code = dwDevCode;
    return OK;
}

int32_t SlaveDevice_SetDevName(int32_t dwIndex, char *pcDevName)
{
    if (dwIndex >= g_SlaveDevNum || pcDevName == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    strcpy(g_pSlaveDeviceInfo[dwIndex].dev_name, pcDevName);

    return OK;
}

int32_t SlaveDevice_SetDevTypeName(int32_t dwIndex, char *pcDevTypeName)
{
    if (dwIndex >= g_SlaveDevNum || pcDevTypeName == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    strcpy(g_pSlaveDeviceInfo[dwIndex].dev_type_name, pcDevTypeName);

    return OK;
}

int32_t SlaveDevice_SetDev(int32_t dwDevCode, slaver_corr_index *pDev, int32_t dwDevNum)
{
    slave_device_config_content *pSlave = SlaveDevice_Find(dwDevCode);
    if (pSlave == NULL || pDev == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pSlave->slave_id_cor_num = dwDevNum;
    pSlave->p_slaver_corr_index_arr = pDev;

    return OK;
}

slave_device_config_content* SlaveDevice_Find(int32_t dwDevCode)
{
    slave_device_config_content *pSlave = NULL;

    int32_t i = 0;

    for (i = 0; i < g_SlaveDevNum; i++)
    {
        if(g_pSlaveDeviceInfo[i].dev_code == dwDevCode)
        {
            pSlave = g_pSlaveDeviceInfo + i;
            break;
        }
    }

    return pSlave;
}

int32_t SlaveDevice_SetMaxDataId(int32_t dwDevCode, int32_t dwMaxDataId)
{
    slave_device_config_content *pSlave = SlaveDevice_Find(dwDevCode);
    if (pSlave == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pSlave->max_data_id = dwMaxDataId;

    return OK;
}

int32_t SlaveDevice_SearchSlaveIdCorrespondingIndex (int32_t dwModbusSlaveId, int32_t dwDevCode)
{
    int32_t SlaveDid;
    int32_t mdrN;

    for (SlaveDid = 0; SlaveDid < g_SlaveDevNum; SlaveDid++)
    {
        for (mdrN = 0; mdrN < g_pSlaveDeviceInfo[SlaveDid].slave_id_cor_num; mdrN++)
        {
            if (dwDevCode == g_pSlaveDeviceInfo[SlaveDid].dev_code)
            {
                if (dwModbusSlaveId == g_pSlaveDeviceInfo[SlaveDid].p_slaver_corr_index_arr[mdrN].modbus_id) //modbus地址
                {
                    return  g_pSlaveDeviceInfo[SlaveDid].p_slaver_corr_index_arr[mdrN].slaveIndex;
                }
            }
        }
    }

    return INVALID_VALUE;
}

int32_t SlaveDevice_SearchSlaveId(int32_t dwModbusSlaveId, int32_t dwDevCode, int32_t address)
{
    int32_t SlaveDid;
    int32_t mdrN;

    for (SlaveDid = 0; SlaveDid < g_SlaveDevNum; SlaveDid++)
    {
        for (mdrN = 0; mdrN < g_pSlaveDeviceInfo[SlaveDid].slave_id_cor_num; mdrN++)
        {
            if (dwDevCode == g_pSlaveDeviceInfo[SlaveDid].dev_code)
            {
                if (
                    (dwModbusSlaveId == g_pSlaveDeviceInfo[SlaveDid].p_slaver_corr_index_arr[mdrN].modbus_id)  //modbus地址
                    &&
                    (address >= g_pSlaveDeviceInfo[SlaveDid].p_slaver_corr_index_arr[mdrN].dwMinAddr - 1
                      && address <= g_pSlaveDeviceInfo[SlaveDid].p_slaver_corr_index_arr[mdrN].dwMaxAddr - 1)
                   )
                {
                    return  g_pSlaveDeviceInfo[SlaveDid].p_slaver_corr_index_arr[mdrN].slaveIndex;
                }
            }
        }
    }

    return INVALID_VALUE;
}

////////////////////////////////////////////////////////CommConn////////////////////////////////////////////////////////////////////////
int32_t CommConn_Init(int32_t dwCommNum)
{
    g_CommConnNum = dwCommNum;

    if (g_CommConnNum > 0)
    {
        g_pComConn  = (CommConnObj *)malloc(sizeof(CommConnObj) * g_CommConnNum);
        if (g_pComConn == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "g_pComConn error\n" );
            return ERROR_T(ERR_DEFAULT_NO_MEM);
        }
        memset(g_pComConn, 0, sizeof (CommConnObj) * g_CommConnNum);
    }

    return OK;
}

int32_t CommConn_UnInit()
{
    HCFREE(g_pComConn);

    return OK;
}

CommConnObj* CommConn_GetObj(int32_t dwObjIndex)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return NULL;
    }
    return g_pComConn + dwObjIndex;
}

int32_t CommConn_SetType(int32_t dwObjIndex, COMM_TYPE_SHOW_E dwCOMMType)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    g_pComConn[dwObjIndex].cmm_type = dwCOMMType;
    return OK;
}

int32_t CommConn_SetCommId(int32_t dwObjIndex, int32_t dwCommId)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    g_pComConn[dwObjIndex].cmm_case_id = dwCommId;
    return OK;
}

int32_t CommConn_SetCommPortAttr(int32_t dwObjIndex, comport_s *pComPortAttr)
{
    if (dwObjIndex >= g_CommConnNum || pComPortAttr == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    memcpy(&(g_pComConn[dwObjIndex].comdev), pComPortAttr, sizeof(comport_s));

    return OK;
}

// int32_t CommConn_SetProcFunc(int32_t dwObjIndex, CommObjFunc cb)
int32_t CommConn_SetProcFunc(int32_t dwObjIndex, COMM_TYPE_SHOW_E eType)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    g_pComConn[dwObjIndex].func = FuncType[eType];

    return OK;
}

int32_t CommConn_SetSlaverConfig(int32_t dwObjIndex, int32_t dwConfigIndex, slave_device_config_content *pSlaverConfig)
{
    if (dwObjIndex >= g_CommConnNum || dwConfigIndex > MAX_COM_DEV_NUM || pSlaverConfig == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    g_pComConn[dwObjIndex].p_mbm_slaver_config[dwConfigIndex] = pSlaverConfig;

    return OK;
}

int32_t CommConn_GetObjNum()
{
    return g_CommConnNum;
}

int32_t CommConn_SetSlaverNum(int32_t dwObjIndex, int32_t dwSlaverNum)
{
    if (dwObjIndex >= g_CommConnNum || dwSlaverNum > MAX_COM_DEV_NUM)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    g_pComConn[dwObjIndex].mbm_slaver_num = dwSlaverNum;

    return OK;
}

int32_t CommConn_SetFd(int32_t dwObjIndex, uintptr_t dwFd)
{
    if (dwObjIndex >= g_CommConnNum || dwFd <= 0)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    g_pComConn[dwObjIndex].comm_obj_fd = dwFd;

    return OK;
}

int32_t CommConn_SetUnifyFlag(int32_t dwObjIndex, BOOL isUsed)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    g_pComConn[dwObjIndex].isUseUnifySlaveID = isUsed;

    return OK;
}

CommObj_s* CommConn_GetCommObj(int32_t dwObjIndex)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return NULL;
    }

    return &(g_pComConn[dwObjIndex].comm_protocol_gather);
}

protocol_s* CommConn_GetProtocol(int32_t dwObjIndex, int32_t dwPtlId)
{
    protocol_s *pTmpPtl = NULL;
    if (dwObjIndex >= g_CommConnNum || dwPtlId > g_pComConn[dwObjIndex].comm_protocol_gather.protocolNum)
    {
        return pTmpPtl;
    }

    return g_pComConn[dwObjIndex].comm_protocol_gather.p_comm_ptl[dwPtlId];
}

int32_t CommConn_GetDevdata(IN int32_t dwObjIndex, IN int32_t dwRegisterAddr, IN int32_t dwFuncCode,
                            OUT int32_t *pDevCode, OUT int32_t *pDevIndex, OUT int32_t *pDataId)
{
    int32_t ret = ERROR_T(ERR_DEFAULT_NOT_FOUND);

    if (g_pComConn[dwObjIndex].isUseUnifySlaveID == FALSE)
    {
        return ERROR_T(ERR_DEFAULT_OPERATOR_NOT_ALLOW);
    }

    if (pDevCode == NULL || pDevIndex == NULL || pDataId == NULL || dwObjIndex >= g_CommConnNum)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    int32_t dwptlNum = g_pComConn[dwObjIndex].comm_protocol_gather.protocolNum;
    int32_t dwSlaverNum = g_pComConn[dwObjIndex].mbm_slaver_num;
    int32_t i = 0, j = 0;

    *pDevCode = 0;
    for (i = 0; i < dwSlaverNum; ++i)
    {
        slave_device_config_content *pSlaverConfig = g_pComConn[dwObjIndex].p_mbm_slaver_config[i];
        if (
            (dwRegisterAddr >= pSlaverConfig->p_slaver_corr_index_arr[0].dwMinAddr - 1
                && dwRegisterAddr <= pSlaverConfig->p_slaver_corr_index_arr[0].dwMaxAddr - 1)
            )
        {
            *pDevCode = pSlaverConfig->dev_code;
            *pDevIndex = pSlaverConfig->p_slaver_corr_index_arr[0].slaveIndex;
            break;
        }
    }

    for (i = 0; i < dwptlNum; ++i)
    {
        protocol_s *p_tmp_ptl = g_pComConn[dwObjIndex].comm_protocol_gather.p_comm_ptl[i];
        if (*pDevCode != 0 && *pDevCode == p_tmp_ptl->ptl_dev_code && dwFuncCode == p_tmp_ptl->cmd)
        {
            for (j = 0; j < p_tmp_ptl->ptl_data_num; ++j)
            {
                if (p_tmp_ptl->protocol_data[j].data_address == dwRegisterAddr)
                {
                    *pDataId = p_tmp_ptl->protocol_data[j].data_id;
                    ret = OK;
                    break;
                }
            }
        }
    }

    return ret;
}

int32_t CommConn_GetProtocolNum(int32_t dwObjIndex)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return 0;
    }

    return g_pComConn[dwObjIndex].comm_protocol_gather.protocolNum;
}

int32_t CommConn_GetPortId(int32_t dwObjIndex)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return 0;
    }

    return g_pComConn[dwObjIndex].cmm_case_id;
}

const comport_s* CommConn_GetPortAttr(int32_t dwObjIndex)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return NULL;
    }

    return &(g_pComConn[dwObjIndex].comdev);
}

int32_t CommConn_GetType(int32_t dwObjIndex)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return 0;
    }

    if (g_pComConn[dwObjIndex].comm_case_lcd_flag > 0)
    {
        return -1;
    }

    return g_pComConn[dwObjIndex].cmm_type;
}

CommObjFunc CommConn_GetFunc(int32_t dwObjIndex)
{
    if (dwObjIndex >= g_CommConnNum)
    {
        return 0;
    }

    if (g_pComConn[dwObjIndex].comm_case_lcd_flag > 0)
    {
        return NULL;
    }

    return g_pComConn[dwObjIndex].func;
}

int32_t CommConn_AddProtocol(int32_t dwObjIndex, int32_t dwDevCode)
{
    uint32_t ptl_id = 0;
    CommObj_s *p_ptl_gather = &(g_pComConn[dwObjIndex].comm_protocol_gather);
    uint32_t ptl_num = p_ptl_gather->protocolNum;

    int32_t max_data_id = 0, tmp_data_id = 0;

    for (ptl_id = 0; ptl_id < g_ProtocolNum; ptl_id++)
    {
        if (dwDevCode == g_protocol[ptl_id].ptl_dev_code)
        {
            p_ptl_gather->p_comm_ptl[ptl_num] = &(g_protocol[ptl_id]);
            p_ptl_gather->protocolNum = ++ptl_num;

            tmp_data_id = g_protocol[ptl_id].max_ptl_data_id;

            if (max_data_id < tmp_data_id)
            {
                max_data_id = tmp_data_id;  //同设备编码中最大的数据id
            }
        }
    }

    return max_data_id;
}

int32_t CommConn_ClearSlaverConfig()
{
    int32_t i = 0;

    for (i = 0; i < g_CommConnNum; i++)
    {
        memset(g_pComConn[i].p_mbm_slaver_config, 0, sizeof(slave_device_config_content *) * MAX_COM_DEV_NUM);
        g_pComConn[i].mbm_slaver_num = 0;
    }

    return OK;
}

int32_t CommConn_ClearProtocol()
{
    int32_t i = 0;

    for (i = 0; i < g_CommConnNum; i++)
    {
        memset(g_pComConn[i].comm_protocol_gather.p_comm_ptl, 0, sizeof(protocol_s  *) * PROTOCOLNUM);
        g_pComConn[i].comm_protocol_gather.protocolNum = 0;
    }

    return OK;
}

int16_t CommConn_SearchDev(int32_t dwObjIndex, int32_t dwModbusSlaveId)
{
    int32_t type_id = 0, table_id = 0, dev_type_num = 0;
    uint16_t ret_code = MAX_DEV_CODE;
    int32_t tab_index_slaveid_num = 0;

    if (dwObjIndex >= g_CommConnNum)
    {
        return ret_code;
    }

    if(g_pComConn[dwObjIndex].isUseUnifySlaveID)
    {
        return ret_code;//如果端口下的设备使用的是统一的转发从机地址，那么我们无法根据上位机的Modbus 报文中slave id来找到对应的设备
    }

    dev_type_num = g_pComConn[dwObjIndex].mbm_slaver_num;
    for (type_id = 0; type_id < dev_type_num; type_id ++)
    {
        tab_index_slaveid_num = g_pComConn[dwObjIndex].p_mbm_slaver_config[type_id]->slave_id_cor_num;

        for (table_id = 0; table_id < tab_index_slaveid_num; table_id ++)
        {
            if (g_pComConn[dwObjIndex].p_mbm_slaver_config[type_id]->p_slaver_corr_index_arr[table_id].modbus_id == dwModbusSlaveId)
            {
                return g_pComConn[dwObjIndex].p_mbm_slaver_config[type_id]->dev_code;
            }
        }
    }

    return ret_code;
}
