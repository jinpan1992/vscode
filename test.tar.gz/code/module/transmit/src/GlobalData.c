#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "GlobalData.h"
#include "CommConnObj.h"
#include "logUtil.h"

//设备全局数据属性合集
typedef struct dev_gather_data_t
{
    uint16_t dev_code;                //设备编号
    int32_t dev_max_data_id;          //同种设备中最大的数据序号
    int32_t same_dev_num;             //同类型设备数量
    DATA_U **data_p;                  //全局数据集合
    int32_t *dev_communicate_state;   //设备通讯状态
    protocol_data_s **ppProtocolData; //设备协议集合
} DEV_GATHER_DATA_T;

//搜索设备全局数据属性
typedef struct search_dev_gather
{
    int32_t dev_type_num;               //设备数量
    int32_t *search_map;               //设备号映射
    DEV_GATHER_DATA_T *p_dev_gdata;     //设备全集数据
} SEARCH_DEV_GATHER;

static SEARCH_DEV_GATHER g_SearchDevGatherCase = {0, NULL, NULL};
static uint32_t g_MaxDevCode;
static uint32_t g_MinDevCode;

/*******************************************************************************
 * Function     : DistributeDevGdata
 * Author       : sungr
 * Date         :
 * Description  : 分配设备全局数据缓冲区
 * Calls        :
 * Input        : inbuf
 * Output       : sendbuf
 * Return       :
 ********************************************************************************/
int32_t DistributeDevGdata(void)
{
    int32_t maxDataId = 0, maxDevNum = 0;
    uint16_t id = 0;
    DEV_GATHER_DATA_T *pTmpDevGdata = NULL;

    int32_t dwSlaveDevNum = SlaveDevice_GetNum();
    pTmpDevGdata = (DEV_GATHER_DATA_T *)calloc(dwSlaveDevNum, sizeof(DEV_GATHER_DATA_T));
    if (pTmpDevGdata == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NO_MEM);
    }

    int32_t devCaseId = 0;
    int32_t *map = NULL;

    for (devCaseId = 0; devCaseId < dwSlaveDevNum; devCaseId++)
    {
        int32_t dwDevCode = SlaveDevice_GetDevCode(devCaseId);

        g_MinDevCode = (g_MinDevCode > dwDevCode) ? dwDevCode : g_MinDevCode;
        g_MaxDevCode = (g_MaxDevCode < dwDevCode) ? dwDevCode : g_MaxDevCode;

        pTmpDevGdata[devCaseId].dev_code = dwDevCode;
        maxDataId = SlaveDevice_GetMaxDataId(devCaseId);
        maxDevNum = SlaveDevice_GetCorNum(devCaseId);
        pTmpDevGdata[devCaseId].dev_max_data_id = maxDataId;
        pTmpDevGdata[devCaseId].same_dev_num = maxDevNum;

        int32_t *devCommState = (int32_t *)calloc(maxDevNum + 1, sizeof(int32_t));

        //申请  maxDevNum+1 个设备  第0 个设备 作为广播地址
        DATA_U **data_p = NULL;
        data_p = (DATA_U **)calloc(maxDevNum + 1, sizeof(DATA_U *));
        if (data_p == NULL)
        {
            exit( 1 );
        }

        //申请   max_data_id+1 边界扩大 1
        for (id = 0; id < maxDevNum + 1; id++)
        {
            data_p[id] = (DATA_U *)calloc(maxDataId + 1, sizeof(DATA_U));
            if (data_p[id] == NULL)
            {
                exit(1);
            }
        }

        protocol_data_s **ppPtlData = calloc(maxDataId + 1, sizeof(protocol_data_s*));
        for (id = 0; id < maxDataId + 1; ++id)
        {
            ppPtlData[id] = GlobalProtocol_GetPD(dwDevCode, id);
        }

        pTmpDevGdata[devCaseId].dev_communicate_state = devCommState ;
        pTmpDevGdata[devCaseId].data_p = data_p;
        pTmpDevGdata[devCaseId].ppProtocolData = ppPtlData;

//         printf("GData search id:%d, devCode:%d maxDataId:%d same_dev_num:%d \n", devCaseId, dwDevCode, maxDataId, maxDevNum);
    }

    map = (int32_t *)calloc(g_MaxDevCode + 1, sizeof(int32_t));

    for (devCaseId = 0; devCaseId < dwSlaveDevNum; devCaseId++)
    {
        int32_t dwDevCode = SlaveDevice_GetDevCode(devCaseId);
        map[dwDevCode] = devCaseId;
    }

    g_SearchDevGatherCase.p_dev_gdata = pTmpDevGdata;
    g_SearchDevGatherCase.search_map  = map;
    g_SearchDevGatherCase.dev_type_num = dwSlaveDevNum;

    return 0;
}

int32_t GdataFill(DEV_DATA_T *devData, uint32_t num)
{
    uint32_t i = 0;

    for (i = 0; i < num; ++i)
    {
        if ((devData[i].dev_code > g_MaxDevCode) || (devData[i].dev_code < g_MinDevCode) || g_SearchDevGatherCase.dev_type_num == 0)
        {
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "point dev_code:%d is not in [%d, %d].\n", devData[i].dev_code, g_MinDevCode, g_MaxDevCode);
            continue;
        }

        int32_t searchId = g_SearchDevGatherCase.search_map[devData[i].dev_code];

        if ((searchId == INVALID_VALUE)
            || (devData[i].data_id > g_SearchDevGatherCase.p_dev_gdata[searchId].dev_max_data_id)
            || (devData[i].index > g_SearchDevGatherCase.p_dev_gdata[searchId].same_dev_num))
        {
            EMS_LOG(LL_WARNING, MODULE_T, FALSE, "point devCode:%d data_id:%d or index:%d is wrong.\n", devData[i].dev_code, devData[i].data_id, devData[i].index);
        }
        else
        {
//             printf("%s rev[(%d %d %d)(datatype:%d)(%u,%d,%f)]\n", __func__, devData[i].dev_code, devData[i].index, devData[i].data_id,
//                    devData[i].data_type,devData[i].value.data.u32,
//                    devData[i].value.data.s32, devData[i].value.data.f32);

            float32_t coeffi = 1.0;

            if (SDB_GetUseCoeffFlag() == TRUE)
            {
                protocol_data_s *pProtocolData = g_SearchDevGatherCase.p_dev_gdata[searchId].ppProtocolData[devData[i].data_id];
                if (pProtocolData != NULL && pProtocolData->scale_coefficient != 0)
                {
                    coeffi = (1.0 / pProtocolData->scale_coefficient);
                }
            }


            if (devData[i].data_type == FLOAT_T)
            {
                g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[devData[i].index][devData[i].data_id].s32 = devData[i].value.data.f32 * coeffi;
            }
            else if (devData[i].data_type == S_INT_T)
            {
                g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[devData[i].index][devData[i].data_id].s32 = devData[i].value.data.s32 * coeffi;
            }
            else if (devData[i].data_type == U_INT_T)
            {
                g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[devData[i].index][devData[i].data_id].u32 = devData[i].value.data.u32 * coeffi;
            }

//             if (devData[i].dev_code != 2304)
//             printf("%s [(%d %d %d)(coffi:%f data:%f)(%u,%d,%f)]\n", __func__, devData[i].dev_code, devData[i].index, devData[i].data_id,
//                    coeffi,
//                    devData[i].value.data.f32 * coeffi,
//                    g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[devData[i].index][devData[i].data_id].u32,
//                    g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[devData[i].index][devData[i].data_id].s32,
//                    g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[devData[i].index][devData[i].data_id].f32
//                   );
        }

    }

    return 0;
}

int32_t GdataFetch(INOUT VALUE_INFO_T *pValueInfo, IN uint16_t deviceCode, IN uint16_t index, IN uint16_t dataId, IN int32_t dwDataType)
{
    if (deviceCode > g_MaxDevCode || deviceCode < g_MinDevCode || g_SearchDevGatherCase.dev_type_num == 0)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "point dev_code:%d is wrong.\n", deviceCode);
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    int32_t searchId = g_SearchDevGatherCase.search_map[deviceCode];

    if ((searchId == INVALID_VALUE)
        || (dataId > g_SearchDevGatherCase.p_dev_gdata[searchId].dev_max_data_id)
        || (index > g_SearchDevGatherCase.p_dev_gdata[searchId].same_dev_num))
    {
        EMS_LOG(LL_WARNING, MODULE_T, FALSE, "devcode:%d point data_id:%d or index:%d or searchId:0x%x is wrong.\n", deviceCode, dataId, index, searchId);
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }
    else
    {

        if (dwDataType == FLOAT_T || dwDataType == S_INT_T)
        {
            pValueInfo->data.s32 = g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[index][dataId].s32;
        }
        else if (dwDataType == U_INT_T)
        {
            pValueInfo->data.u32 = g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[index][dataId].u32;
        }
        else if (dwDataType == -1)
        {
            if (SDB_GetUseCoeffFlag() == TRUE)
            {
                protocol_data_s *pProtocolData = g_SearchDevGatherCase.p_dev_gdata[searchId].ppProtocolData[dataId];
                if (pProtocolData != NULL)
                {
                    if (pProtocolData->scale_coefficient != 1.0)
                    {
                        pValueInfo->ucDataType = FLOAT_T;
                        pValueInfo->data.f32 = g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[index][dataId].s32 * pProtocolData->scale_coefficient;
                    }
                    else if (pProtocolData->data_type == U_INT_T)
                    {
                        pValueInfo->data.u32 = g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[index][dataId].u32;
                        pValueInfo->ucDataType = U_INT_T;
                    }
                    else if(pProtocolData->data_type == S_INT_T)
                    {
                        pValueInfo->data.s32 = g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[index][dataId].s32;
                        pValueInfo->ucDataType = S_INT_T;
                    }

//                     printf("%s [dev(%d %d %d)(coffi:%f),value(type:%d:%u,%d,%f)]\n", __func__, deviceCode, index, dataId,
//                         pProtocolData->scale_coefficient,
//                         pValueInfo->ucDataType,
//                         pValueInfo->data.u32,
//                         pValueInfo->data.s32,
//                         pValueInfo->data.f32
//                         );
                }
                else
                {
                    printf("%s dev[%d,%d,%d] no protocol_data.\n", __func__, deviceCode, index, dataId);
                }

            }
        }
        else
        {
            //do nothing
        }
    }

    return OK;
}

int32_t ReadPointData(int32_t *dataOut,uint16_t deviceCode, uint16_t index, uint16_t dataId)
{
    uint32_t searchId;

    if((deviceCode > g_MaxDevCode) || (deviceCode < g_MinDevCode) || g_SearchDevGatherCase.search_map == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "point dev_code:%d is wrong.\n", deviceCode );

        return -1;
    }

    searchId = g_SearchDevGatherCase.search_map[deviceCode];

    if((searchId == INVALID_VALUE)
        || (dataId > g_SearchDevGatherCase.p_dev_gdata[searchId].dev_max_data_id)
        || (index > g_SearchDevGatherCase.p_dev_gdata[searchId].same_dev_num))
    {
        EMS_LOG(LL_WARNING, MODULE_T, FALSE, "point data_id:%d or index:%d is wrong.\n", dataId, index);

        return -1;
    }

    *dataOut = g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[index][dataId].s32;

    return 0;
}

int32_t WritePointData(int32_t value, uint16_t deviceCode, uint16_t index, uint16_t dataId)
{
    int32_t searchId;

    if((deviceCode > g_MaxDevCode) || (deviceCode < g_MinDevCode) || g_SearchDevGatherCase.search_map == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "point dev_code:%d is wrong.\n", deviceCode );
        return -1;
    }

    searchId = g_SearchDevGatherCase.search_map[deviceCode];

    if((searchId == INVALID_VALUE)
        || (dataId > g_SearchDevGatherCase.p_dev_gdata[searchId].dev_max_data_id)
        || (index > g_SearchDevGatherCase.p_dev_gdata[searchId].same_dev_num))
    {
        EMS_LOG(LL_WARNING, MODULE_T, FALSE, "point data_id:%d or index:%d is wrong.\n", dataId, index);
        return -1;
    }

    g_SearchDevGatherCase.p_dev_gdata[searchId].data_p[index][dataId].s32 = value;

    return 0;
}

/*******************************************************************************
 * Function       : PrintBuf
 * Author          : sungr
 * Date              : 2016.11.13
 * Description  : 打印接受数据  ，
 * Calls              :
 * Input          : in_fd  接受句柄   int32_t arr_len 数据长度 int32_t *in_buf 数据缓冲  int32_t int_out_direction 接受或者发送
 * Output       :
 * Return        :oid
 ********************************************************************************/
void PrintBuf(int32_t arr_len,char *in_buf,int32_t in_fd, int32_t int_out_direction)
{
    int32_t arr_id = 0;

    if (int_out_direction == 0)
    {
        printf("\n begin receive: readptr %d fd: %d \n ", arr_len ,in_fd);
    }
    else
    {
        printf("\n begin send : readptr %d fd: %d \n ", arr_len ,in_fd);
    }


    for(arr_id = 0; arr_id<arr_len; arr_id++)
    {
        printf("0x%0x ", in_buf[arr_id]);
    }
    printf("\n end\n ");


}

int32_t FreeDevGdata(void)
{
    int32_t i = 0, j = 0;
    for (i = 0; i < g_SearchDevGatherCase.dev_type_num; i++)
    {
        HCFREE(g_SearchDevGatherCase.p_dev_gdata[i].dev_communicate_state);

        for(j = 0; j < g_SearchDevGatherCase.p_dev_gdata[i].same_dev_num + 1; j++)
        {
            HCFREE(g_SearchDevGatherCase.p_dev_gdata[i].data_p[j]);
        }

        HCFREE(g_SearchDevGatherCase.p_dev_gdata[i].data_p);
        HCFREE(g_SearchDevGatherCase.p_dev_gdata[i].ppProtocolData);
    }

    HCFREE(g_SearchDevGatherCase.search_map);
    HCFREE(g_SearchDevGatherCase.p_dev_gdata);
    return OK;
}
