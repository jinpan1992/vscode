#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/epoll.h>
#include <signal.h>
#include <sys/prctl.h>
#include "transmit.h"
#include "net_transmit.h"
#include "protocol_operate.h"
#include "comReceive.h"
#include "xml_analysis.h"
#include "comReceive.h"
#include "SGQueue.h"
#include "common.h"
#include "logUtil.h"
#include "commonTest.h"
#include "uart.h"
#include "iec_slave_service.h"
#include "sdb.h"
#include "IMC.h"
#include "file_operate.h"
#include "mqtt.h"
#include "mqtt_service.h"


// #define CONCURRENT_TEST 0

typedef struct {
    pthread_t dataQueueThread;
    pthread_t iecSlaveThread;

    NORTH_PARAM_T stNorthParam;

    IEC104SlaveHandler *slaveHandler;

    BOOL isRunning;
} TRANSMIT_HANDLE_T;

TRANSMIT_HANDLE_T *g_pTransHandle = NULL;

Q_EXTERN(DEV_DATA_T, dataOutQ);
Q_EXTERN(DEV_DATA_T, cmdqInQ);

static BOOL checkTransmitPrecondition() {
    BOOL ret = FALSE;

    if (DirExist(CONFIGFILEPATH) && SDB_GetState() == MODULE_STATE_READY) {
        ret = TRUE;
    }

    return ret;
}

static int32_t InitCommPort(COMM_TYPE_SHOW_E dwCOMMType, int32_t dwPortNo) {
    int32_t ret = OK;

    comport_s stComport;
    stComport.commtype = dwCOMMType;
    stComport.commdef = COM_PC;
    stComport.net_port_num = 1;
    stComport.port_attr[0].netport = dwPortNo;
    stComport.port_attr[0].allow_all_flag = 1;

    int32_t i = 0;
    for (i = 0; i < CommConn_GetObjNum(); i++) {
        stComport.net_id = i;
        CommConn_SetCommPortAttr(i, &stComport);
        CommConn_SetType(i, dwCOMMType);
        CommConn_SetCommId(i, i);
        CommConn_SetProcFunc(i, dwCOMMType);
    }

    return ret;
}

static int32_t loadDB(NORTH_PARAM_T *pParam)
{
    int32_t ret = ERROR_T(ERR_DEFAULT_NOT_FOUND);
    NORTH_PARAM_T *northParam = NULL;
    int32_t recordNum = 0;

    sysCfg_Load(CFG_TYPE_NORTH_PARAM, (void **)(&northParam), &recordNum);    // 从数据库查找数据

    if (northParam != NULL)
    {
        memcpy(&(g_pTransHandle->stNorthParam), northParam, sizeof(NORTH_PARAM_T));
        ret = OK;
    }

    sysCfg_Free(northParam);

    return ret;
}

static int32_t handleDevUpdate() {
    int32_t i = 0;

    //1. 释放 slaverConfig
    GlobalProtocol_Clear();
    SlaveDevice_Destroy();
    FreeDevGdata();

    //2. 重建slaverConfig
    GetAllSlaverAndProtocol();

    int32_t num = CommConn_GetObjNum();
    for (i = 0; i < num; i++) {
        int32_t table_n = SDB_ND_GetKinds();

        int32_t j = 0, k = 0;
        for (j = 0; j < table_n; j++) {
            slave_device_config_content *pSlaverConfig = SlaveDevice_Get(j);
            int32_t dwDevCount = SDB_GetDevCountByCode(pSlaverConfig->dev_code);

            slaver_corr_index *p_slaver_corr_index_arr = calloc(dwDevCount, sizeof(slaver_corr_index));
//             printf("%s Comm id:%d p_slaver_corr_index_arr:%p dwDevCount:%d\n", __func__, i, p_slaver_corr_index_arr, dwDevCount);

            for (k = 0; k < dwDevCount; k++) {
//                 p_slaver_corr_index_arr[k].modbus_id = UNIFY_TRANSMIT_MODBUS_SLAVE_ID;
                p_slaver_corr_index_arr[k].slaveIndex = k + 1;

                DEV_INFO_EXT_T *pDevInfoExt = SDB_ND_Get(pSlaverConfig->dev_code, p_slaver_corr_index_arr[k].slaveIndex);
                p_slaver_corr_index_arr[k].modbus_id = (pDevInfoExt->dwTxSlaveId == 0) ? UNIFY_TRANSMIT_MODBUS_SLAVE_ID : pDevInfoExt->dwTxSlaveId;

                SDB_ND_GetAddrRange(pSlaverConfig->dev_code,
                                    p_slaver_corr_index_arr[k].slaveIndex,
                                    &(p_slaver_corr_index_arr[k].dwMaxAddr),
                                    &(p_slaver_corr_index_arr[k].dwMinAddr)
                );

                if (p_slaver_corr_index_arr[k].modbus_id == UNIFY_TRANSMIT_MODBUS_SLAVE_ID)
                    CommConn_SetUnifyFlag(i, TRUE);
            }

            SlaveDevice_SetDev(pSlaverConfig->dev_code, p_slaver_corr_index_arr, dwDevCount);

            int32_t dwMaxDataId = CommConn_AddProtocol(i, pSlaverConfig->dev_code);
            SlaveDevice_SetMaxDataId(pSlaverConfig->dev_code, dwMaxDataId);

            CommConn_SetSlaverConfig(i, j, pSlaverConfig);
        }

    }

    //3. 协议Map初始化
    GlobalProtocol_CreateMap();

    //4. 重建GData
    DistributeDevGdata();

    printf("%s done.\n", __func__);
    return OK;
}

static int32_t handleModbusPortChange(int32_t dwPortNo) {
    int32_t i = 0;
    int32_t num = CommConn_GetObjNum();

    for (i = 0; i < num; i++) {
        CommConnObj *pObj = CommConn_GetObj(i);
        if (pObj != NULL) {
            if (pObj->comdev.port_attr[0].netport != dwPortNo)
            {
                InitCommPort(NETTYPE, dwPortNo);
                if (NetServer_IsRuning() == TRUE)
                {
                    NetServer_Restart();
                }
                else
                {
                    NetServer_Init();
                    NetServer_Start();
                }

            }
        }
    }

    printf("%s CommConn:%d done.\n", __func__, num);
    return OK;
}

static int32_t handleIEC104PortChange(NORTH_PARAM_T *pParam) {

    if (pParam != NULL)
    {
        if (pParam->CfgSelect & 0x4)
        {
            if (g_pTransHandle->slaveHandler != NULL && g_pTransHandle->stNorthParam.Port104 == pParam->Port104)
            {
                printf("%s port is same.\n", __func__);
                return OK;
            }

            if (g_pTransHandle->slaveHandler != NULL)
            {
                IEC104SlaveService_Destroy(g_pTransHandle->slaveHandler);
                g_pTransHandle->slaveHandler = NULL;
            }

            IEC104SlaveConfig slaveCfg = {0x0001, 0x4000, 0x4001, 0x6000, 0x6001, 0x6200, 0x6201, 0x6400, 0x6401, 0x7000, 2404, "0.0.0.0"};
            slaveCfg.port = g_pTransHandle->stNorthParam.Port104 = pParam->Port104;

            g_pTransHandle->slaveHandler = IECSlaveService_Init(&slaveCfg);

        }
        else
        {
            IEC104SlaveService_Destroy(g_pTransHandle->slaveHandler);
            g_pTransHandle->slaveHandler = NULL;
        }
    }

    printf("%s done.\n", __func__);
    return OK;
}

static int32_t transmitMsgCB(uintptr_t user, void *pData) {
    int32_t ret = OK;
    SG_MSG_T stDestMsg = *(SG_MSG_T *) pData;
    int32_t eType = stDestMsg.udwMsgType;

    if (MODULE_ID(eType) != MODULE_T && MODULE_ID(eType) != MODULE_IPC && MODULE_ID(eType) != MODULE_SDB) {
        return ret;
    }

    printf("transmit recv msg:0x%x. \n", eType);

    switch (eType) {
        case MSG_TRANSIMIT_RESET_IP: {
            NetServer_Restart();
        }
            break;
        case MSG_IPC_DEV_UPDATE: {

            break;
        }
        case MSG_SDB_UPDATED: {
            if (g_pTransHandle->isRunning) {
                ret = handleDevUpdate();
            } else {
                ret = Transmitor_Start();
            }
            break;
        }
        case MSG_IPC_TRANSMIT_PROTOCOL_SETTING:   // TODO web的数据入口
        {
            NORTH_PARAM_T *pNorthParam = (NORTH_PARAM_T *) stDestMsg.pData;

            if (pNorthParam != NULL)
            {
                printf("%s CfgSelect:%d \n", __func__, pNorthParam->CfgSelect);

                {
                    WEB_CONFIG_MQTT mqttConfigTmp;
                    strcpy(mqttConfigTmp.mqtt_addr, pNorthParam->MqttAddr);
                    mqttConfigTmp.mqtt_port = pNorthParam->MqttPort;
                    mqttConfigTmp.is_use_mqtt = (pNorthParam->CfgSelect & 0x1) ? TRUE : FALSE;   // 是否使用mqtt协议
                    mqttConfigTmp.is_encrypt = pNorthParam->MqttEncry;         // 是否加密
                    mqttConfigTmp.encryAlgor = pNorthParam->MqttAlgor;         // 云加密算法
                    mqttConfigTmp.upload_method = pNorthParam->MqttMethod;     // 变化上传:1, 全量上传:0
                    mqttConfigTmp.all_upload_period = pNorthParam->MqttCycle;  // 全量上传周期
                    memcpy(mqttConfigTmp.pubTopic, pNorthParam->MqttPubTopic, 128 * sizeof(char));
                    memcpy(mqttConfigTmp.subTopic, pNorthParam->MqttSubTopic, 128 * sizeof(char));
                    memcpy(mqttConfigTmp.clientId, pNorthParam->MqttClientID, 128 * sizeof(char));
                    memcpy(mqttConfigTmp.username, pNorthParam->MqttUser, 128 * sizeof(char));
                    memcpy(mqttConfigTmp.pwd, pNorthParam->MqttPwd, 128 * sizeof(char));
                    memcpy(mqttConfigTmp.ip, g_pTransHandle->stNorthParam.IP1, 128 * sizeof(char));
                    mqttConfigTmp.port = g_pTransHandle->stNorthParam.EnDhcp1;
                    sleep(2);
                    updateMqttParameters(&mqttConfigTmp);
                }

                if (pNorthParam->CfgSelect & 0x2)
                {
                    ret = handleModbusPortChange(pNorthParam->ModbusPort);
                }
                else
                {
                    NetServer_Stop();
                    InitCommPort(NETTYPE, 0xFF);
                }

                handleIEC104PortChange(pNorthParam);
            }
            break;
        }
        case MSG_IPC_DEV_MAPPING:
        {
            if (g_pTransHandle->isRunning) {
                ret = handleDevUpdate();
            } else {
                ret = Transmitor_Start();
            }
            break;
        }
        default:
            break;
    }

    return ret;
}

/**
 * @brief 初始化全局变量参数 ，创建建立链接链表，将端口实例注册进入列表，端口句柄加入到epoll中。
 * @param
 *
 * @return
 */
int32_t ComportInfomationInit(void) {
    int32_t ret = OK;

    ret = CreateComm();    //建立链接链表

    ret = UartInit();

//     ret = NetServer_Init();

    return ret;
}

int32_t WritePointCommand(int32_t value, uint16_t deviceCode, uint16_t index, uint16_t dataId) {
    WritePointData(value, deviceCode, index, dataId);

    DEV_DATA_T devData;
    devData.value.data.s32 = value;
    devData.data_type = S_INT_T;
    devData.dev_code = deviceCode;
    devData.moduleID = MODULE_T;
    devData.data_id = dataId;
    devData.index = index;
    if (!Q_FULL(cmdqInQ)) {
        Q_INSERT_WAIT(cmdqInQ, devData);
    } else {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "CMDInQ is full!.\n");
    }

    return 0;
}

int32_t InitTransmitPara(void)
{
    int32_t ret = OK;

    /*1. 转发配置XML文件读取*/
    SysConfigContentInit(CONFIGFILEPATH);
    if (SlaveDevice_GetCorNum(0) <= 0) //xml中没有slave device 信息
    {
        CommConn_Init(MAX_NET_INTERFACES);

        ret = loadDB(&(g_pTransHandle->stNorthParam));
        if (ret == OK)
        {
            NORTH_PARAM_T *northParam = &(g_pTransHandle->stNorthParam);
            if (northParam->CfgSelect & 0x2) //Modbus
            {
                ret = InitCommPort(NETTYPE, g_pTransHandle->stNorthParam.ModbusPort);
                ret = NetServer_Init();
            }
        }

        handleDevUpdate();
    }
    else
    {
        if(DirExist(MQTTCONFIGFILEPATH) == TRUE)
        {
            ParseMqttConfig(MQTTCONFIGFILEPATH, &g_pTransHandle->stNorthParam);
        }

        /*默认开启modbus 和 iec104*/
        g_pTransHandle->stNorthParam.CfgSelect |= 0x2; //modbus & 104
//         g_pTransHandle->stNorthParam.Port104 = 2404;

        /*2. 协议Map初始化*/
        GlobalProtocol_CreateMap();

        /*3. 分配设备全局数据缓冲区*/
        DistributeDevGdata();

        ret = NetServer_Init();
    }

    /*4. 端口信息初始化 */
    ComportInfomationInit();

    return ret;
}

void *DataQHandleThread(void *arg) {
    TRANSMIT_HANDLE_T *pHandle = (TRANSMIT_HANDLE_T *) arg;
    DEV_DATA_T *devData;
    uint32_t num = 0;

    prctl(PR_SET_NAME, "TRANSMIT_DATA_THREAD");
    while (pHandle->isRunning) {
        Q_WAIT(dataOutQ);
        num = Q_NUMS(dataOutQ);
        // printf("发生变化的数据个数：%d\n",num);
        if (num > 0) {
            devData = (DEV_DATA_T *) malloc(sizeof(DEV_DATA_T) * num);
            if (devData != NULL) {
                memset((DEV_DATA_T *) devData, 0, sizeof(DEV_DATA_T) * num);
                Q_OUT_N(dataOutQ, devData, num);
                GdataFill(devData, num);

                // printf("dataQ中isRunning的状态:%d\n",g_mqtt_handle.isRunning);
                //mqttThreadInit初始化后，isRunning为true
                if (g_mqtt_handle.isRunning) {
                    runDataProduct(devData, num);
                }
                free(devData);
            }
        }
    }
    return NULL;
}

void CreatTMPthread(TRANSMIT_HANDLE_T *tansmitHandle) {
    int32_t res = 0;

    tansmitHandle->isRunning = TRUE;

    res = pthread_create(&tansmitHandle->dataQueueThread, NULL, DataQHandleThread, tansmitHandle);

    if (res != 0) {
        perror("Thread DataQHandleThread creation failed");
        exit(EXIT_FAILURE);
    }
}

int32_t Transmitor_Start() {
    int32_t ret = OK;

    InitTransmitPara();

    CreatTMPthread(g_pTransHandle);
    //test 打印
    printf("CfgSelect :%d\n", g_pTransHandle->stNorthParam.CfgSelect);


    if (g_pTransHandle->stNorthParam.CfgSelect & 0x2)
    {
        NetServer_Start();
    }

    if (g_pTransHandle->stNorthParam.CfgSelect & 0x4)
    {
        IEC104SlaveConfig slaveCfg = {0x0001, 0x4000, 0x4001, 0x6000, 0x6001, 0x6200, 0x6201, 0x6400, 0x6401, 0x7000, 2404, "0.0.0.0"};
        slaveCfg.port = g_pTransHandle->stNorthParam.Port104;

        g_pTransHandle->slaveHandler = IECSlaveService_Init(&slaveCfg);
    }

    if(g_pTransHandle->stNorthParam.CfgSelect & 0x1){
        WEB_CONFIG_MQTT mqttConfigTmp;
        strcpy(mqttConfigTmp.mqtt_addr, g_pTransHandle->stNorthParam.MqttAddr);
        mqttConfigTmp.mqtt_port = g_pTransHandle->stNorthParam.MqttPort;
        mqttConfigTmp.is_use_mqtt = (g_pTransHandle->stNorthParam.CfgSelect & 0x1) ? TRUE : FALSE;   // 是否使用mqtt协议
        mqttConfigTmp.is_encrypt = g_pTransHandle->stNorthParam.MqttEncry;         // 是否加密
        mqttConfigTmp.encryAlgor = g_pTransHandle->stNorthParam.MqttAlgor;         // 云加密算法
        mqttConfigTmp.upload_method = g_pTransHandle->stNorthParam.MqttMethod;     // 变化上传:1, 全量上传:0
        mqttConfigTmp.all_upload_period = g_pTransHandle->stNorthParam.MqttCycle;  // 全量上传周期
        memcpy(mqttConfigTmp.pubTopic, g_pTransHandle->stNorthParam.MqttPubTopic, 128 * sizeof(char));
        memcpy(mqttConfigTmp.subTopic, g_pTransHandle->stNorthParam.MqttSubTopic, 128 * sizeof(char));
        memcpy(mqttConfigTmp.clientId, g_pTransHandle->stNorthParam.MqttClientID, 128 * sizeof(char));
        memcpy(mqttConfigTmp.username, g_pTransHandle->stNorthParam.MqttUser, 128 * sizeof(char));
        memcpy(mqttConfigTmp.pwd, g_pTransHandle->stNorthParam.MqttPwd, 128 * sizeof(char));
        memcpy(mqttConfigTmp.ip, g_pTransHandle->stNorthParam.IP1, 128 * sizeof(char));
        mqttConfigTmp.port = g_pTransHandle->stNorthParam.EnDhcp1;

        sleep(5);//mqtt延迟5s初始化,确保已采集到设备数据，而不是发送初始化数据0
        updateMqttParameters(&mqttConfigTmp);
        ret = OK;
    }

    EMS_LOG(LL_INFO, MODULE_T, FALSE, "%s DONE.\n", __func__);
    return ret;
}

uintptr_t Transmitor_Create(void) {

    if (g_pTransHandle == NULL)
    {
        g_pTransHandle = (TRANSMIT_HANDLE_T *)calloc(1, sizeof(TRANSMIT_HANDLE_T));
    }
    else
    {
        return (uintptr_t) g_pTransHandle;
    }

    if (g_pTransHandle == NULL)
    {
        return INVALID_VALUE;
    }

    IMC_RegisterCB((uintptr_t) g_pTransHandle, transmitMsgCB);

    Transmitor_Start();

    return (uintptr_t) g_pTransHandle;
}

int32_t Transmitor_Destroy(uintptr_t handle) {
    TRANSMIT_HANDLE_T *tansmitHandle = (TRANSMIT_HANDLE_T *) handle;
    if (tansmitHandle == NULL || handle == INVALID_VALUE) {
        return -1;
    }

    tansmitHandle->isRunning = FALSE;

    void *rtest;
    if (tansmitHandle->iecSlaveThread) {
        pthread_join(tansmitHandle->iecSlaveThread, &rtest);
        printf("iecSlaveThread join done.\n");
    }

    if (tansmitHandle->dataQueueThread) {
        Q_POST(dataOutQ);
        pthread_join(tansmitHandle->dataQueueThread, &rtest);
        printf("dataQueueThread join done.\n");
    }

    IEC104SlaveService_Destroy(tansmitHandle->slaveHandler);
    tansmitHandle->slaveHandler = NULL;

    NetServer_Stop();

    HCFREE(tansmitHandle);

    FreeDevGdata();

    CLIENT_LINK_SLAVER_T *p1 = g_CommReg.comm_L->next;
    CLIENT_LINK_SLAVER_T *p2 = NULL;
    int32_t i = 0;
    for (i = 0; i < g_CommReg.num; i++) {
        p2 = p1;
        p1 = p1->next;
        HCFREE(p2);
    }
    HCFREE(g_CommReg.comm_L);

    GlobalProtocol_Clear();
    SlaveDevice_Destroy();
    CommConn_UnInit();

    printf("%s Done.\n", __func__);
    return 0;
}
