#include <errno.h>
#include <termios.h>
#include <sys/ioctl.h>

#include "protocol_operate.h"
#include "comReceive.h"
#include "xml_analysis.h"
#include "uart.h"
#include "logUtil.h"
#include "calc.h"
#include "modbus.h"
#include "sys.h"
#include "transmit_conf.h"

#define TIOCSRS485	0x542F

pthread_mutex_t MutexComRx;

int32_t comRxBufNum;
comRxBuffer comRxGloabl[COMRXBUFMAXN];

static int32_t g_SerialLinkNum = 0;
static COMMSERIALTYPE g_SerialLinkNode[MAX_SERIAL_PROT_FD_NUM];

static struct serial_rs485 rs485;

/********************************************************************************
 * Function     : set_485_init_state
 * Author       : sungr
 * Date         : 2021.09.22
 * Description  : 重置485串口属性
 * Calls        : None
 * Input        :int setFd 串口fd
 * Output       :
 * Return       : NULL
 *********************************************************************************/
int32_t set_485_init_state (int32_t setFd)
{
    int32_t ret_value = 0;

    rs485.flags = SER_RS485_ENABLED | SER_RS485_RTS_ON_SEND  | SER_RS485_RX_DURING_TX ;//|SER_RS485_RTS_AFTER_SEND
    rs485.delay_rts_before_send = 0;
    rs485.delay_rts_after_send = 1;

    ret_value = ioctl (setFd, TIOCSRS485, &rs485 );
    return ret_value;
}

/*******************************************************************************
 * Function     : PutRxBufData
 * Author       : sungr
 * Date         : 2021.09.22
 * Description  :上传数据至全局数据缓冲队列
 * Calls        :
 * Input        :uint8_t *buf,int32_t len,int32_t RxNum
 * Output       :
 * Return       :
 ********************************************************************************/
void PutRxBufData (uint8_t *buf, int32_t len, int32_t RxNum)
{
    int32_t i = 0;
    uint32_t tRxBufTail = comRxGloabl[RxNum].RxBufTail;

    for (i = 0; i < len; i++)
    {
        comRxGloabl[RxNum].RxBuf[tRxBufTail] = buf[i];
        tRxBufTail++;

        if (tRxBufTail > MAXCOMRXLEN)
        {
            InitClearRxBufData (RxNum);
            return;
        }
        comRxGloabl[RxNum].RxBufTail = tRxBufTail;
    }
}

/*******************************************************************************
 * Function     : GetRxBufData
 * Author       : sungr
 * Date         : 2021.09.22
 * Description  :从全局数据缓冲队列 获取数据
 * Calls        :
 * Input        :uint8_t *buf,int32_t RxNum 队列序号
 * Output       :
 * Return       :
 ********************************************************************************/
void GetRxBufData (uint8_t *buf, int32_t RxNum)
{
    int32_t i = 0;
    uint32_t tRxBufHead = comRxGloabl[RxNum].RxBufHead;
    uint32_t tRxBufTail = comRxGloabl[RxNum].RxBufTail;

    for (i = tRxBufHead; i < tRxBufTail; i++)
    {
        buf[i] = comRxGloabl[RxNum].RxBuf[i];
    }
}

/*******************************************************************************
 * Function     : GetRxBufDataLen
 * Author       : sungr
 * Date         : 2021.09.22
 * Description  :获取全局数据缓冲队列 长度
 * Calls        :
 * Input        :,int32_t RxNum 队列序号
 * Output       :
 * Return       :
 ********************************************************************************/
int32_t GetRxBufDataLen ( int32_t RxNum )
{
    int32_t len = 0;
    uint32_t tRxBufHead = comRxGloabl[RxNum].RxBufHead;
    uint32_t tRxBufTail = comRxGloabl[RxNum].RxBufTail;

    len = tRxBufTail - tRxBufHead;
    return len;
}

/*******************************************************************************
 * Function     : InitClearRxBufData
 * Author       : sungr
 * Date         : 2021.09.22
 * Description  :清空全局数据缓冲队列长度
 * Calls        :
 * Input        :,int32_t RxNum 队列序号
 * Output       :
 * Return       :
 ********************************************************************************/
void InitClearRxBufData ( int32_t RxNum )
{
    comRxGloabl[RxNum].RxBufHead = 0;
    comRxGloabl[RxNum].RxBufTail = 0;
}

/********************************************************************************
 * Function     : RefleshSerialComRegLink
 * Author       : sungr
 * Date         : 2021.09.22
 * Description  : 更新串口fd链表信息
 * Calls        : None
 * Input        : int32_t oldFd ,int32_t newFd
 * Output       :
 * Return       : NULL
 *********************************************************************************/
int32_t RefleshSerialComRegLink (int32_t oldFd, int32_t newFd)
{
    CLIENT_LINK_SLAVER_T *p_head, *pnext;
    int32_t i = 0;
    p_head = g_CommReg.comm_L;//头结点是空节点
    pnext = p_head->next;

    if (g_CommReg.num == 0)
    {
        return 0;
    }

    for (i = 0; i < g_CommReg.num; ++i)
    {
        if (pnext->link_fd == oldFd)
        {
            EMS_LOG(LL_INFO, MODULE_T, FALSE, "RefleshSerialComRegLink----%d oldfd newFd %d-------------- \n" , oldFd, newFd );
            pnext->link_fd = newFd;
            return 0;
        }
        p_head = pnext;
        pnext = pnext->next;
    }
    return -1;//替换失败,不存在要删除的节点
}

static int32_t startSerialThread(uintptr_t rtuHandle)
{
    int32_t ret = OK;
    pthread_attr_t attr;
    pthread_t threadId;

    pthread_attr_init(&attr);
    pthread_attr_setdetachstate (&attr, PTHREAD_CREATE_DETACHED);
    ret = pthread_create(&threadId, &attr, (void*)SerialDataRecvProcess, &rtuHandle);

    pthread_attr_destroy (&attr);

    return ret;
}

static int32_t insertSerialNode(int32_t comm_id, uintptr_t serialFd, int32_t dwBaudrate)
{
    int32_t ret = OK;

    g_SerialLinkNode[g_SerialLinkNum].comm_conn_id = comm_id;                                        //端口串口实例序号
    g_SerialLinkNode[g_SerialLinkNum].serial_fd = g_pComConn[comm_id].comm_obj_fd;                   //串口设备节点
    g_SerialLinkNode[g_SerialLinkNum].uartBaudrate = g_pComConn[comm_id].comdev.uartbaudrate;        //串口波特率
    g_SerialLinkNode[g_SerialLinkNum].com_type = CommConn_GetType(comm_id);

    g_SerialLinkNum++;


    return ret;
}

/**
 * @brief  串口初始化
 * @param
 *
 * @return
 */
int32_t UartInit()
{
    int32_t connId = 0;
    int32_t ret = OK;

    int32_t dwNum = CommConn_GetObjNum();

    //初始化全局锁
    pthread_mutex_init(&MutexComRx, NULL);

    for (connId = 0; connId < dwNum; connId++)
    {
        if (CommConn_GetType(connId) == COMTYPE)
        {
            const comport_s *pComDev = CommConn_GetPortAttr(connId);

            START_INFO_T start_info;
            start_info.uartId = pComDev->uartid;		                                        //串口号
            start_info.baud = pComDev->uartbaudrate;                                           //波特率
            start_info.data_bit = pComDev->uartdatabit;	                                    //串口数据位
            strncpy(start_info.stop_bit, pComDev->uartstopbit, sizeof(start_info.stop_bit)); 	//停止位
            start_info.parity  = pComDev->uartparity;	                                        //奇偶位
            start_info.type = MODBUS_BACKEND_TYPE_RTU;
            start_info.role = MODBUS_ROLE_SLAVE;
            uintptr_t rtuHandle = ModbusOpen(start_info);

            ret = CommConn_SetFd(connId, rtuHandle);
            ret = insertSerialNode(connId, rtuHandle, pComDev->uartbaudrate);
            ret = startSerialThread(rtuHandle);
            if (ret != OK)
            {
                EMS_LOG(LL_ERROR, MODULE_T, FALSE, "pthread_create error!\n");
                ModbusClose(rtuHandle);
            }
        }
    }

    return ret;
}

/**
 * @brief  串口非阻塞 数据接收应答延迟时间
 * @param
 *
 * @return
 */
void SerialDataDelayProcess(struct timeval *p_read_time, struct timeval *p_write_time, int32_t ComBaudRate)
{
    long int current_delay = 0;
    long int delay_millisecond = 0;
    /*默认设置 1起始位 1 停止位 0 奇偶位 8 数据位
    3.5T=3.5*(1起始位 +1 停止位 +0 奇偶位+ 8 数据位)/baudrate  换算为 35/baudrate
    baudrate >19200bps  帧间的超时时间为 1.750ms */

    long int frame_timeout= (long int)((35 * 1.0 / ComBaudRate) * 1000 * 1000);   //微妙

    if (ComBaudRate >= 19200)
    {
        frame_timeout = (long int)(1.75 * 1000); //微妙
    }

    if ((p_read_time != NULL) && (p_write_time != NULL))
    {
        delay_millisecond = (p_write_time->tv_sec - p_read_time->tv_sec) * 1000 * 1000 + (p_write_time->tv_usec - p_read_time->tv_usec);

        current_delay = frame_timeout - delay_millisecond ;

        if ((current_delay > 0) && (current_delay < 10000))
        {
            usleep (current_delay);
        }
    }
}

/**
 * @brief  串口非阻塞 数据接收处理
 * @param
 *
 * @return
 */
int32_t SerialNoblockDataProcess(int32_t fd, uint8_t inbuf[1024*4+1], int32_t readptr, int32_t uartBaudrate)
{
    uint8_t sendbuf[1024*4+1]= {0};
    int32_t sendnum = 0;

    struct timeval ReadCompleteTime;
    struct timeval WriteBeginTime;
    gettimeofday(&ReadCompleteTime, NULL);

    //接收数据处理,结果填入sendbuf,立即回复或者异步回复
    sendnum = RevProcess(fd, inbuf, readptr, sendbuf);

    gettimeofday(&WriteBeginTime, NULL);

    if (sendnum > 0)
    {
        SerialDataDelayProcess(&ReadCompleteTime, &WriteBeginTime, uartBaudrate);
        ModbusReply(fd, sendbuf, sendnum);
    }

    return 0;
}

/**
 * @brief  串口数据接收处理
 * @param
 *
 * @return NULL
 */
void SerialDataRecvProcess(const uintptr_t *p_conn_fd)
{
    uintptr_t comfd  = *p_conn_fd;

    uint8_t comRecPcArray[MAX_REV_LEN] = { 0 };
    uint8_t rxBufTemp[MAX_REV_LEN] = { 0 };
    uint8_t readbuf[MAX_REV_LEN] = { 0 };

    int32_t i = 0;
    int32_t link_id = 0;
    int32_t readlen = 0;
    int32_t RxNum  = 0;
    int32_t cur_uart_baudrate = 0;

    pthread_mutex_lock (&MutexComRx);
    comRxBufNum++;

    for (link_id = 0; link_id < g_SerialLinkNum; link_id++)
    {
        if (g_SerialLinkNode[link_id].serial_fd == comfd)
        {
            //int32_t serialType = g_SerialLinkNode[link_id].com_type;
            cur_uart_baudrate = g_SerialLinkNode[link_id].uartBaudrate;
        }
    }
    pthread_mutex_unlock (&MutexComRx);
    RxNum = comRxBufNum;

    int32_t crcCheckFlay = 0;

    while (1)
    {
        memset (readbuf, 0, sizeof (readbuf));

        readlen = ModbusRecv(comfd, readbuf);
        if (readlen < 0)
        {
            NanoSleep(10);
        }
        else
        {
            PutRxBufData (readbuf, readlen, RxNum);

            int32_t modbusModeFlay = 0;
            int RxBufDataLen = 0;
            uint8_t cmd;
            int32_t len;
            int32_t cmdlen = 8;
            uint8_t  recvDataAlaysis[MAX_REV_LEN] = {0};

            RxBufDataLen = GetRxBufDataLen (RxNum);
            memset (rxBufTemp, 0, sizeof (rxBufTemp));
            GetRxBufData (rxBufTemp, RxNum);

            crcCheckFlay = -1;

            for (i = 0; (i < (RxBufDataLen - 8 + 1)) && (modbusModeFlay == 0); i++)
            {
                memcpy (recvDataAlaysis,&rxBufTemp[i], RxBufDataLen - i);
                cmd = recvDataAlaysis[1];
                crcCheckFlay = -1;

                switch (cmd)
                {
                    case 0x01:
                    case 0x02:
                        len = (recvDataAlaysis[4] << 8) | recvDataAlaysis[5];

                        if (CrcCheck (recvDataAlaysis, 8, 0))
                        {
                            crcCheckFlay = 1;
                            modbusModeFlay = 1;
                            cmdlen = 8;
                            if ((len < 1 ) || (len > 2000)) //数量超长
                            {
                                crcCheckFlay = -1;
                                modbusModeFlay = 0;
                            }
                        }
                        else
                        {
                            crcCheckFlay = -1;
                            modbusModeFlay = 0;
                        }

                        break;
                        case 0x03:
                        case 0x04:
                            len = (recvDataAlaysis[4] << 8) | recvDataAlaysis[5];

                            if (CrcCheck (recvDataAlaysis, 8, 0))
                            {
                                crcCheckFlay = 1;
                                modbusModeFlay = 1;
                                cmdlen = 8;

                                if ((len < 1) || (len >125)) //数量超长
                                {
                                    crcCheckFlay = -1;
                                    modbusModeFlay = 0;
                                }
                            }
                            else
                            {
                                crcCheckFlay = -1;
                                modbusModeFlay = 0;
                            }

                            break;

                        case 0x06:
                            if (CrcCheck (recvDataAlaysis,8,0))
                            {
                                crcCheckFlay = 1;
                                modbusModeFlay = 1;
                                cmdlen = 8;
                            }
                            else
                            {
                                crcCheckFlay = -1;
                                modbusModeFlay = 0;

                            }

                            break;
                        case 0x10:
                            len = (recvDataAlaysis[4] << 8) | recvDataAlaysis[5];

                            if (CrcCheck(recvDataAlaysis, recvDataAlaysis[6]+9, 0))
                            {
                                crcCheckFlay = 1;
                                modbusModeFlay = 1;

                                cmdlen = recvDataAlaysis[6] + 9;

                                if ((( len < 1) || (len > 123 )) || (2* len != recvDataAlaysis[6]))
                                {
                                    crcCheckFlay = -1;
                                    modbusModeFlay = 0;
                                }
                            }
                            else
                            {
                                crcCheckFlay = -1;
                                modbusModeFlay = 0;
                            }

                            break;

                        default:
                            crcCheckFlay = -1;
                            break;
                }
            }

            if (crcCheckFlay  > 0)
            {
                InitClearRxBufData (RxNum);
            }

            if (crcCheckFlay > 0)
            {
                memset (comRecPcArray, 0, sizeof (comRecPcArray));
                memcpy (comRecPcArray, recvDataAlaysis, cmdlen);

                SerialNoblockDataProcess(comfd, comRecPcArray, cmdlen, cur_uart_baudrate);
            }
        }
    }
}
