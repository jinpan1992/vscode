#include <stdlib.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <stdbool.h>
#include <unistd.h>
#include <dirent.h>
#include "protocol_operate.h"
#include "xml_analysis.h"
#include "transmit.h"
#include "logUtil.h"
#include "protocol.h"
#include "config.h"
#include "sdb.h"
#include "file_operate.h"
#include "transmit_conf.h"
#include "CommConnObj.h"

int32_t g_CommLcdFlag;                                      /* 当前  包含大功率触摸屏标记 */

/**
 * @brief  根据xpath 路径解析xml文件中的节点数量
 * @param
 *
 * @return
 */
static int32_t GetNodeParameterNum (xmlXPathContextPtr context, const xmlChar *xpath)
{
    xmlXPathObjectPtr result = NULL;
    xmlNodeSetPtr nodeset = NULL;
    int32_t ret_parameter_num = 0;

    if (context == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "context is NULL\n");
        return 0;
    }
    result = xmlXPathEvalExpression (xpath, context);

    if (result == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "xmlXPathEvalExpression return NULL\n");
        return 0;
    }

    if (xmlXPathNodeSetIsEmpty(result->nodesetval))
    {
        xmlXPathFreeObject (result);
        return 0;
    }
    nodeset = result->nodesetval;
    //计算有多少个设备节点
    ret_parameter_num = nodeset->nodeNr;
    xmlXPathFreeObject(result);
    return ret_parameter_num;
}

int8_t GetXmlPointDataSignConfig(char *p_sign_element)
{
    int8_t ret  = 0;
    if (strchr (p_sign_element,'U'))
    {
        ret = SIGN_U;
    }
    else if (strchr (p_sign_element,'S'))
    {
        ret = SIGN_S;
    }
    else
    {
        ret  = -1;
    }
    return ret;
}

int8_t  GetXmlPointDataTypeConfig (char *p_data_element)
{
    int8_t ret  = 0;

    if (strchr(p_data_element,'I'))
    {
        ret = TYPE_INT;
    }
    else if (strchr(p_data_element,'F'))
    {
        ret = TYPE_F;
    }
    else
    {
        ret  = -1;
    }

    return ret;
}

int8_t GetXmlPointDataTypeContext(int8_t sign_flag, int8_t data_type_flag)
{
    int8_t ret  = 0;

    if ((SIGN_U == sign_flag ) && ( TYPE_INT == data_type_flag))
    {
        ret = U_INT_T;
    }
    else if ((SIGN_S == sign_flag) && (TYPE_INT == data_type_flag))
    {
        ret = S_INT_T;
    }
    else if (TYPE_F == data_type_flag)
    {
        ret = FLOAT_T;
    }
    else
    {
        ret = -1;
    }

    return ret;

}

int32_t GetTabFromXml(uint16_t dev_code, char *p_protocol_name, uint8_t protocol_byte_type, uint8_t protocol_word_type)
{
    protocol_data_s *p_ptl_data = NULL;
    int32_t file_max_data_id = 0;
    int8_t tmp_data_sign = 0;
    int8_t tmp_data_type = 0;

    xmlDocPtr doc;
    xmlNodePtr curNode;
    xmlNodePtr Node1;
    xmlNodePtr Node2;
    xmlXPathContextPtr context = NULL;

    char *szDocName = NULL;
    char ptl_ver[100 ] = { 0 };
    int32_t index_id = 0;
    int32_t proCmd = 0;

    szDocName = p_protocol_name;
    doc = xmlReadFile(szDocName, "UTF-8", XML_PARSE_RECOVER);
    if (NULL == doc)
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "string_xml empty !\n");
        xmlFreeDoc(doc);
        return -1;
    }

    context = xmlXPathNewContext(doc);
    if (context == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "context is NULL\n");
        xmlFreeDoc(doc);
        return 0;
    }

    //读取root节点
    curNode = xmlDocGetRootElement(doc);
    if (NULL == curNode)
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "string_xml no root !\n");
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return -1;
    }

    //解析root下子节点
    if (xmlStrcmp(curNode->name, BAD_CAST "root"))
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "document of the wrong type, root node != root");
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return -1;
    }
    curNode = curNode->xmlChildrenNode;
    xmlNodePtr propNodePtr = curNode;
    Node1 = curNode;

    while (Node1 != NULL)
    {
        if ((!xmlStrcmp(Node1->name, (const xmlChar * ) "protocol")))
        {
            //查找属性
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolCode"))
                {
                    xmlChar* szAttr = xmlGetProp ( propNodePtr,BAD_CAST "ProtocolCode" );
                    //uint32_t ptl_code = strtoul((const char * ) szAttr, NULL, 0);
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolVer"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolVer");
                    strcpy(ptl_ver, (const char * ) szAttr);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }
            //node2节点 是node1的子节点
            Node2 = Node1->xmlChildrenNode;
            while (Node2 != NULL)
            {
                propNodePtr = Node2;
                if ((!xmlStrcmp(Node2->name, (const xmlChar *) "table")))
                {
                    //查找每个协议的属性
                    xmlAttrPtr attrPtr = propNodePtr->properties;

                    int32_t tab_id = 0;

                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                            tab_id = strtoul((const char * ) szAttr, NULL, 0);
                            xmlFree (szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "cmd"))
                        {
                            xmlChar* szAttr = xmlGetProp (propNodePtr,BAD_CAST "cmd");
                            proCmd = strtoul((char *) szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        attrPtr = attrPtr->next;
                    }
                    char xpath_point[200] = { 0 };
                    char xpath_tab[100] = { 0 };
                    sprintf(xpath_tab, "/root/protocol/table[@id='%d' and @cmd='%d'  ]", tab_id, proCmd);
                    sprintf(xpath_point, "%s/register/point", xpath_tab);

                    xmlNodePtr tmp_node = NULL;
                    xmlXPathObjectPtr result = NULL;
                    xmlNodeSetPtr nodeset = NULL;
                    xmlChar *xpath_tmp = (xmlChar *) xpath_point;
                    result = xmlXPathEvalExpression (xpath_tmp, context);

                    if (result == NULL)
                    {
                        EMS_LOG(LL_ERROR, MODULE_T, false,  "xmlXPathEvalExpression   NULL\n");
                        xmlXPathFreeContext(context);
                        xmlFreeDoc(doc);
                        return 0;
                    }
                    if (xmlXPathNodeSetIsEmpty(result->nodesetval))
                    {
                        xmlXPathFreeObject(result);
                        xmlXPathFreeContext(context);
                        xmlFreeDoc(doc);
                        return 0;
                    }

                    uint32_t addr_min = 0, addr_max = 0;
                    int32_t tmp_data_id = 0, max_ptl_data_id = 0, node_id = 0;
                    nodeset = result->nodesetval;

                    int32_t line_num = nodeset->nodeNr;
                    p_ptl_data = (protocol_data_s *) malloc(line_num * sizeof(protocol_data_s));

                    memset(p_ptl_data, 0, line_num * sizeof(protocol_data_s));
                    for (node_id = 0; node_id < line_num; node_id++)
                    {
                        index_id = node_id;
                        tmp_node = nodeset->nodeTab[node_id];
                        propNodePtr = tmp_node ;
                        if ((!xmlStrcmp(tmp_node->name, (const xmlChar *) "point")))
                        {
                            xmlAttrPtr attrPtr = propNodePtr->properties;

                            //初始化比例系数为0
                            p_ptl_data[index_id].scale_coefficient = 1;

                            while (attrPtr != NULL)
                            {
                                if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataName"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataName");
                                    strcpy (p_ptl_data[index_id].data_name, (const char *) szAttr);
                                    xmlFree (szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataId"))
                                {
                                    xmlChar *szAttr = xmlGetProp (propNodePtr,BAD_CAST "DataId");
                                    p_ptl_data[index_id].data_id = strtoul((const char *) szAttr, NULL, 0);
                                    xmlFree ( szAttr );

                                    tmp_data_id = p_ptl_data[index_id].data_id ;
                                    if (max_ptl_data_id < tmp_data_id)
                                    {
                                        max_ptl_data_id = tmp_data_id;
                                    }
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataAddress"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataAddress");
                                    p_ptl_data[index_id].data_address = strtoul((char * ) szAttr, NULL, 0);

                                    uint32_t tmp_addr = p_ptl_data[index_id].data_address;

                                    if (addr_max < tmp_addr)
                                    {
                                        addr_max = tmp_addr;
                                    }
                                    if ((addr_min <= 0) || (addr_min > tmp_addr))
                                    {
                                        addr_min = tmp_addr;
                                    }
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataLen"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr, BAD_CAST "DataLen");
                                    p_ptl_data[index_id].data_byte_num = strtoul((const char *) szAttr, NULL, 0);
                                    xmlFree (szAttr);
                                }
                                else if (!xmlStrcmp( attrPtr->name, BAD_CAST "DataType"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr, BAD_CAST "DataType");
                                    tmp_data_type = GetXmlPointDataTypeConfig((char *) szAttr) ;
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp (attrPtr->name, BAD_CAST "DataSign"))
                                {
                                    xmlChar *szAttr = xmlGetProp ( propNodePtr,BAD_CAST "DataSign" );
                                    tmp_data_sign = GetXmlPointDataSignConfig((char *) szAttr);
                                    if (tmp_data_sign >= 0)
                                    {
                                        p_ptl_data[index_id].data_sign = tmp_data_sign;
                                    }

                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataInfo"))
                                {
                                    xmlChar* szAttr = xmlGetProp ( propNodePtr,BAD_CAST "DataInfo");
                                    strncpy (p_ptl_data[index_id ].data_info, (const char *) szAttr, 20);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataDecimal"))
                                {
                                    xmlChar* szAttr = xmlGetProp ( propNodePtr,BAD_CAST "DataDecimal");
                                    //p_ptl_data[index_id].dec_p = atof((const char *) szAttr);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataScaleCoefficient"))
                                {
                                    xmlChar* szAttr = xmlGetProp (propNodePtr, BAD_CAST "DataScaleCoefficient");
                                    p_ptl_data[index_id].scale_coefficient = atof ((const char *) szAttr);

                                    if ((p_ptl_data[index_id].scale_coefficient < 0.0000001 ) && (p_ptl_data[ index_id ].scale_coefficient > -0.0000001))
                                    {
                                        p_ptl_data[index_id].scale_coefficient =1;
                                    }
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMin"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr, BAD_CAST "DataMin");
                                    if (p_ptl_data[index_id].data_sign == SIGN_U)
                                    {
                                        p_ptl_data[index_id].low_limit1_uint = strtoul(( const char *) szAttr, NULL, 0);
                                    }
                                    else
                                    {
                                        p_ptl_data[index_id].low_limit1 = strtoul((const char *) szAttr, NULL, 0);
                                    }
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMax"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr, BAD_CAST "DataMax");

                                    if (p_ptl_data[index_id].data_sign == SIGN_U)
                                    {
                                        p_ptl_data[index_id].high_limit1_uint = strtoul((const char *) szAttr, NULL, 0);
                                    }
                                    else
                                    {
                                        p_ptl_data[index_id].high_limit1 = strtoul((const char *)szAttr, NULL, 0);
                                    }
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp (attrPtr->name, BAD_CAST "DataMin1"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr, BAD_CAST "DataMin1");

                                    if (p_ptl_data[index_id].data_sign == SIGN_U)
                                    {
                                        p_ptl_data[index_id].low_limit2_uint = strtoul((const char *) szAttr, NULL, 0);
                                    }
                                    else
                                    {
                                        p_ptl_data[index_id].low_limit2 = strtoul((const char *) szAttr, NULL, 0);
                                    }
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMax1"))
                                {
                                    xmlChar* szAttr = xmlGetProp( propNodePtr, BAD_CAST "DataMax1" );
                                    if (p_ptl_data[index_id].data_sign == SIGN_U)
                                    {
                                        p_ptl_data[index_id].high_limit2_uint = strtoul((const char *) szAttr, NULL, 0);
                                    }
                                    else
                                    {
                                        p_ptl_data[index_id].high_limit2 = strtoul((const char *) szAttr, NULL, 0);
                                    }
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "RevFunc"))
                                {
                                    xmlChar *szAttr = xmlGetProp ( propNodePtr, BAD_CAST "RevFunc");
                                    //strcpy(p_ptl_data[index_id ].func_Rev, ( const char * ) szAttr);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "SendFunc"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr, BAD_CAST "SendFunc");
                                    //strcpy ( p_ptl_data[index_id].func_Send, ( const char * ) szAttr);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "FifoFunc"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr, BAD_CAST "FifoFunc");
                                    //strcpy (p_ptl_data[index_id].func_Fifo, ( const char * ) szAttr);
                                    xmlFree (szAttr);
                                }
                                attrPtr = attrPtr->next;
                            }
                            p_ptl_data[index_id].data_type = GetXmlPointDataTypeContext (tmp_data_sign, tmp_data_type);
                        }
                    }

                    if (result)
                    {
                        xmlXPathFreeObject(result);
                    }

                    g_protocol[g_ProtocolNum].protocol_data = p_ptl_data;
                    g_protocol[g_ProtocolNum].address = addr_min;

                    if (proCmd == 0x01)
                    {
                        if (p_ptl_data[line_num-1].data_byte_num == 4)
                        {
                            g_protocol[g_ProtocolNum].len = addr_max - addr_min+4*8;
                        }
                        else
                        {
                            g_protocol[g_ProtocolNum].len = addr_max - addr_min+2*8;
                        }
                    }
                    else
                    {
                        if (p_ptl_data[line_num-1].data_byte_num == 4)
                        {
                            g_protocol[g_ProtocolNum].len = addr_max - addr_min+2;
                        }
                        else
                        {
                            g_protocol[g_ProtocolNum].len = addr_max - addr_min+1;
                        }
                    }

                    g_protocol[g_ProtocolNum].ptl_min_addr = addr_min;
                    g_protocol[g_ProtocolNum].ptl_max_addr = addr_max;
                    g_protocol[g_ProtocolNum].max_ptl_data_id = max_ptl_data_id;
                    g_protocol[g_ProtocolNum].ptl_data_num = line_num;
                    g_protocol[g_ProtocolNum].cmd = proCmd;
                    g_protocol[g_ProtocolNum].ptl_dev_code = dev_code;

                    g_protocol[g_ProtocolNum].protocol_byte  = protocol_byte_type;
                    g_protocol[g_ProtocolNum].protocol_word = protocol_word_type;

                    g_ProtocolNum ++;

                    if (g_ProtocolNum > PROTOCOLNUM)
                    {
                        EMS_LOG(LL_ERROR, MODULE_T, false, "protocol num is exceed!!\n");
                        exit(0);
                    }

                    if (file_max_data_id < max_ptl_data_id)
                    {
                        file_max_data_id  = max_ptl_data_id;
                    }

                }
                Node2 = Node2->next;
            }
        }
        Node1 = Node1->next;
    }

    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);

    return file_max_data_id;
}

/**
 * @brief  读取commport 节点的属性配置
 * @param
 *
 * @return
 */
void ReadCommportAttributeConfig(IN xmlNodePtr tempNode, IN int32_t attr_comm_type, IN int32_t comm_id, OUT comport_s *pCommPort)
{
    xmlChar *szKey = NULL;

    pCommPort->uartid = comm_id;
    if (attr_comm_type == COMTYPE)
    {
        if ((!xmlStrcmp (tempNode->name, ( const xmlChar * ) "uartbaud")))
        {
            szKey = xmlNodeGetContent(tempNode);
            pCommPort->uartbaudrate = strtoul((char *)szKey, NULL, 0);
            xmlFree (szKey);
        }
        else if ((!xmlStrcmp(tempNode->name, (const xmlChar *) "uartparity")))
        {
            szKey = xmlNodeGetContent (tempNode);
            pCommPort->uartparity = szKey[0];
            xmlFree (szKey);
        }
        else if ((!xmlStrcmp(tempNode->name, (const xmlChar *) "uartdatabit")))
        {
            szKey = xmlNodeGetContent (tempNode);
            pCommPort->uartdatabit = strtoul((char *)szKey, NULL, 0);
            xmlFree (szKey);
        }
        else if ((!xmlStrcmp(tempNode->name, (const xmlChar *) "uartstopbit")))
        {
            szKey = xmlNodeGetContent (tempNode);
            strncpy(pCommPort->uartstopbit, ( char * ) szKey, 4 );
            xmlFree (szKey);
        }
    }
    else if (attr_comm_type == NETTYPE)
    {
        pCommPort->net_id = comm_id;

        if ((!xmlStrcmp(tempNode->name, (const xmlChar *) "netport")))
        {
            xmlNodePtr propNodePtr = tempNode;
            int16_t np_id = 0;
            char allow_link_ip[30] = { 0 };

            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                {
                    xmlChar* szAttr = xmlGetProp (propNodePtr,BAD_CAST "id");
                    np_id = strtoul ((char *)szAttr, NULL, 0);
                    xmlFree (szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "allow_link_ip"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "allow_link_ip");
                    strcpy (allow_link_ip, (char *) szAttr);
                    xmlFree (szAttr);
                }
                attrPtr = attrPtr->next;
            }
            xmlChar* sz_cont = xmlNodeGetContent(tempNode);

            if (np_id <= MAXNETPORTNUM) //最多支持五个网络端口号
            {
                pCommPort->port_attr[np_id - 1].netport = strtoul((char *)sz_cont, NULL, 0);
                pCommPort->net_port_num = np_id;

                strcpy (pCommPort->port_attr[np_id - 1].allow_ip, allow_link_ip);

                if (0 == strncmp (allow_link_ip, "0.0.0.0", 7))
                {
                    pCommPort->port_attr[np_id - 1].allow_all_flag = 1;
                }
                else
                {
                    pCommPort->port_attr[np_id - 1].allow_all_flag = 0;
                }
            }
            else
            {
                EMS_LOG(LL_ERROR, MODULE_T, false, "net_port_id config error or too much net_port number\n");
            }
            xmlFree (sz_cont);
        }
    }
}

/**
 * @brief  解析xml 设备节点 的设备modbus地址 和  设备序号，填充设备类型结构体 ，将 端口对象 的下挂设备的结构体指针 指向当前的设备类型结构体
 * @param
 * @return
 */
slaver_corr_index* ReadSlaveCorrIndexTable(xmlNodePtr tempNode, int32_t table_num)
{
    xmlNodePtr propNodePtr = NULL;
    int32_t mbm_slave_num = 0, mbm_slave_id = 0, index_id = 0, slave_dev_id = 0;

    slaver_corr_index *pSlaverCorrIndexArr = (slaver_corr_index *)malloc(sizeof(slaver_corr_index) * table_num);
    if (pSlaverCorrIndexArr ==  NULL)
    {
        return NULL;
    }
    memset(pSlaverCorrIndexArr, 0, sizeof(slaver_corr_index) * table_num);

    //查找属性
    while (tempNode != NULL)
    {
        if ((!xmlStrcmp(tempNode->name, (const xmlChar *) "table")))
        {
            mbm_slave_id = mbm_slave_num;
            mbm_slave_num ++;
            propNodePtr = tempNode;
            xmlAttrPtr attrPtr = propNodePtr->properties;

            while (attrPtr != NULL)
            {
                if (!xmlStrcmp (attrPtr->name, BAD_CAST "DevId"))
                {
                    xmlChar* szAttr = xmlGetProp (propNodePtr,BAD_CAST "DevId");
                    index_id = strtoul((char *) szAttr, NULL, 0);
                    xmlFree ( szAttr );
                }
                else if (!xmlStrcmp (attrPtr->name, BAD_CAST "TSlaveID"))
                {
                    xmlChar* szAttr = xmlGetProp ( propNodePtr,BAD_CAST "TSlaveID" );
                    slave_dev_id = strtoul((char *) szAttr, NULL, 0);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }
            if (mbm_slave_num <=  table_num)
            {
                pSlaverCorrIndexArr[mbm_slave_id].modbus_id = slave_dev_id;
                pSlaverCorrIndexArr[mbm_slave_id].slaveIndex = index_id;
            }
            else
            {
                EMS_LOG(LL_DEBUG, MODULE_T, false, "ReadSlaveCorrIndexTable read config  slave_id_cor_num error\n");
                break;
            }
        }
        tempNode = tempNode->next;
    }
    return pSlaverCorrIndexArr;
}

/**
 * @brief  读取协议table  中protocol文件名称，解析csv文件内容，更新增加协议总数量
 * @param
 *
 * @return
 */
int32_t ReadProtocolTable (xmlNodePtr tempNode, int32_t dev_code)
{
    xmlNodePtr propNodePtr;
    char tmp_ptl_name[100] = { 0 };
    uint8_t byte_sequence = HL_BYTE;
    uint8_t word_sequence = LH_WORD;
    //查找属性
    propNodePtr = tempNode;

    xmlAttrPtr attrPtr = propNodePtr->properties;
    while (attrPtr != NULL)
    {
        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
        {
            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
            xmlFree(szAttr);
        }
        else if ( !xmlStrcmp ( attrPtr->name, BAD_CAST "ProtocolName" ) )
        {
            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolName");
            bzero(tmp_ptl_name, sizeof(tmp_ptl_name));
            strncpy(tmp_ptl_name, (char *) szAttr, 100);

            xmlFree ( szAttr );
        }
        else if (!xmlStrcmp ( attrPtr->name, BAD_CAST "ProtocolByte"))
        {
            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolByte");
            if (strcmp((const char *) szAttr, "低字节前高字节后") == 0)
            {
                byte_sequence = LH_BYTE;
            }
            else if (strcmp ((const char *) szAttr, "高字节前低字节后") == 0)
            {
                byte_sequence = HL_BYTE;
            }
            else
            {
                byte_sequence = HL_BYTE;
            }

            xmlFree (szAttr);
        }
        else if (!xmlStrcmp (attrPtr->name, BAD_CAST "ProtocolWord"))
        {
            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolWord");
            if (strcmp((const char *) szAttr, "低字前高字后") == 0)
            {
                word_sequence = LH_WORD;
            }
            else if (strcmp((const char *) szAttr, "高字前低字后") == 0)
            {
                word_sequence = HL_WORD;
            }
            else
            {
                word_sequence = LH_WORD;
            }
            xmlFree (szAttr);
        }
        attrPtr = attrPtr->next;
    }

    char csvFile[200] = { 0 };

    if (dev_code == CEMS_DEV_CODE)
    {
        sprintf (csvFile, PLATFOTM_DATA_XML"%s", tmp_ptl_name);
    }
    else
    {
        sprintf (csvFile, POINT_DATA_XML"%s", tmp_ptl_name);
    }

    /*测试文件存在与否,如果不存在,继续重新执行*/
    if (!DirExist(csvFile))
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "protocol_name %s file not exist---\n ", tmp_ptl_name);
    }
    else
    {
        GetTabFromXml(dev_code, csvFile, byte_sequence, word_sequence);
    }
    return  0;
}

void GetAllSlaverAndProtocol()
{
    int32_t id = 0;
    uint16_t total_num, total_dev_num;
    DEV_INFO_EXT_T *dev = NULL, *devList = NULL;
    int32_t table_num = 0, i = 0;
    int32_t k = 0, samecount = 0, count = 0;

    SDB_ND_Load();
    total_dev_num = SDB_ND_GetNum();
    total_num = SDB_ND_GetKinds();

    SlaveDevice_Create(total_num);

    devList = SDB_ND_GetList();
    for (id = 0; id < total_dev_num; id++)
    {
        samecount = 0;
        dev = devList + id;

        if (id == 0)
        {
            SlaveDevice_SetDevCode(count, dev->stDevUID.devCode);
            SlaveDevice_SetDevName(count, dev->stDevUID.devName);
            SlaveDevice_SetDevTypeName(count, dev->stDevUID.devName);
            count ++;
        }
        else
        {
            for (k = 0; k < id; k++)
            {
                if (SlaveDevice_GetDevCode(k) == dev->stDevUID.devCode)
                {
                    samecount ++;
                    break;
                }
                else
                {
                    if (k == id -1)
                    {
                        SlaveDevice_SetDevCode(count, dev->stDevUID.devCode);
                        SlaveDevice_SetDevName(count, dev->stDevUID.devName);
                        SlaveDevice_SetDevTypeName(count, dev->stDevUID.devName);
                        count++;
                    }
                }
            }
        }
        if (samecount > 0)
        {
            continue;
        }
        if (count > SlaveDevice_GetNum())
        {
            printf("count=%d > g_SlaveDevNum=%d\n", count, SlaveDevice_GetNum());
            EMS_LOG(LL_ERROR, MODULE_T, false, "count =%d > g_SlaveDevNum =%d\n", count, SlaveDevice_GetNum());
            exit(EXIT_FAILURE);
        }

        table_num = dev->dwPtlNum;

        for (i = 0; i < table_num; i++)
        {
            PROTOCOL_T *new_protocol = dev->pProtocol + i;
            GlobalProtocol_Add(new_protocol);
        }

        printf("%s id:%d dev(%d %d) dwTxSlaveId:%d\n", __func__, id, dev->stDevUID.devCode, dev->stDevUID.devIndex, dev->dwTxSlaveId);
    }

}

int SysConfigContentInit(char *configfilePATH)
{
    xmlDocPtr doc;
    xmlNodePtr curNode, Node1, Node2, Node3;
    xmlXPathContextPtr context;
    char *szDocName = configfilePATH;

    uint8_t comm_port_idx = 0;
    int32_t comm_case_n  = 0, ret = OK;

    doc = xmlReadFile(szDocName,"UTF-8",XML_PARSE_RECOVER);

    if (NULL == doc)
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "Document not parsed successfully\n" );
        return -1;
    }

    context = xmlXPathNewContext(doc);

    xmlChar *xpath1 = (xmlChar *) "/root/commport";
    comm_case_n = GetNodeParameterNum (context, xpath1);

    if(CommConn_Init(comm_case_n) != OK)
    {
        xmlXPathFreeContext (context);
        xmlFreeDoc (doc);
        return ret;
    }

    /*1. 从SDB中获取设备数量和设备协议 */
    GetAllSlaverAndProtocol();

    //确定文档根元素
    curNode = xmlDocGetRootElement(doc);
    /*检查确认当前文档中包含内容*/
    if (NULL == curNode)
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "empty document\n");

        xmlXPathFreeContext (context);
        xmlFreeDoc (doc);
        return -1;
    }
    if (xmlStrcmp (curNode->name, BAD_CAST "root"))
    {
        EMS_LOG(LL_ERROR, MODULE_T, false, "document of the wrong type, root node != root");
        xmlXPathFreeContext (context);
        xmlFreeDoc (doc);
        return -1;
    }
    curNode = curNode->xmlChildrenNode;
    xmlNodePtr propNodePtr = curNode;

    Node1 = curNode;

    while (Node1 != NULL)
    {
        int32_t record_mbm_id = 0;
         /*commport 结点内容解析*/
        if ((!xmlStrcmp (Node1->name, (const xmlChar *) "commport")))
        {
            char  g_CommTypeName[30] = { 0 };
            char touch_srceen_flag_name[100] = { 0 };
            int32_t comm_type = 0, lcd_flag = 0, comm_id = 0;

            propNodePtr = Node1;
            xmlAttrPtr node_attr_ptr = propNodePtr->properties;

            while (node_attr_ptr != NULL)
            {
                if (!xmlStrcmp(node_attr_ptr->name, BAD_CAST "commtype"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr, BAD_CAST "commtype");
                    strncpy (g_CommTypeName, ( char * ) szAttr, 30);
                    if (0 == strcmp (g_CommTypeName, "uart"))
                    {
                        comm_type =  COMTYPE;
                    }
                    else
                    {
                        comm_type =  NETTYPE;
                    }
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp (node_attr_ptr->name, BAD_CAST "commid"))
                {
                    xmlChar* szAttr = xmlGetProp (propNodePtr, BAD_CAST "commid");
                    comm_id = strtoul((char *) szAttr, NULL, 0);
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp (node_attr_ptr->name, BAD_CAST "commdef"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr, BAD_CAST "commdef");

                    bzero(touch_srceen_flag_name, sizeof(touch_srceen_flag_name));
                    strcpy(touch_srceen_flag_name, (char *) szAttr);
                    if ((strcmp ( touch_srceen_flag_name, "LCD" )  == 0) || (strcmp(touch_srceen_flag_name, "lcd")  == 0 ))
                    {
                        lcd_flag  = COM_LCD;
                        g_CommLcdFlag = lcd_flag;
                    }
                    else
                    {
                        lcd_flag  = COM_PC;
                    }
                    xmlFree(szAttr);
                }

                node_attr_ptr = node_attr_ptr->next;
            }

            CommConn_SetProcFunc(comm_port_idx, comm_type);
            CommConn_SetCommId(comm_port_idx, comm_id);
            CommConn_SetType(comm_port_idx, comm_type);

            char xml_comm_mbmslaver_path[100] = {0};

            sprintf(xml_comm_mbmslaver_path, "/root/commport[@commtype='%s' and @commid='%d'  ]/mbmslaver",
                      g_CommTypeName, comm_id);

            //端口链接对象下的mbmslaver 的设备总数
            int32_t mbm_slave_n = GetNodeParameterNum(context, BAD_CAST xml_comm_mbmslaver_path);
            if (mbm_slave_n > SlaveDevice_GetNum())
            {
                printf("mbmslaver num under transmit module commport > the total number of device\n");
                EMS_LOG(LL_ERROR, MODULE_T, false, "mbmslaver num under transmit module commport > the total number of device\n");
                exit(EXIT_FAILURE);
            }

            CommConn_SetSlaverNum(comm_port_idx, mbm_slave_n);
            Node2 = Node1->xmlChildrenNode;

            comport_s stComPort;
            memset(&stComPort, 0, sizeof(comport_s));

            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *) "mbmslaver")))
                {
                    Node3 = Node2->xmlChildrenNode;

                    uint16_t dev_code = 0;
                    int32_t mbm_slaver_id = 0;
                    propNodePtr = Node2;
                    xmlAttrPtr slaver_attr_ptr = propNodePtr->properties;

                    while (slaver_attr_ptr != NULL)
                    {
                        if (!xmlStrcmp(slaver_attr_ptr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp (propNodePtr, BAD_CAST "id");
                            mbm_slaver_id = strtoul((char *)szAttr, NULL, 0);
                            if (record_mbm_id < mbm_slaver_id)
                            {
                                record_mbm_id = mbm_slaver_id;
                            }
                            else
                            {
                                EMS_LOG(LL_ERROR, MODULE_T, false, "mbm_slaver_id id read config error _exit modbusSlave ");
                                exit(1);
                            }
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(slaver_attr_ptr->name, BAD_CAST "DevCode"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr, BAD_CAST "DevCode");
                            dev_code = strtoul((char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        slaver_attr_ptr = slaver_attr_ptr->next;
                    }

                    char mbmslaver_tab_path[200]= {0};
                    sprintf (mbmslaver_tab_path ,"%s[ @DevCode='%d' ]/table", xml_comm_mbmslaver_path, dev_code);

                    int32_t table_n = GetNodeParameterNum(context, BAD_CAST mbmslaver_tab_path);
                    slaver_corr_index* p_slaver_corr_index_arr = ReadSlaveCorrIndexTable(Node3, table_n);
                    int32_t i = 0;
                    for (i = 0; i < table_n && (p_slaver_corr_index_arr + i) != NULL; i++)
                    {
                        SDB_ND_GetAddrRange(dev_code,
                                            p_slaver_corr_index_arr[i].slaveIndex,
                                            &(p_slaver_corr_index_arr[i].dwMaxAddr),
                                            &(p_slaver_corr_index_arr[i].dwMinAddr)
                                          );
                    }
                    SlaveDevice_SetDev(dev_code, p_slaver_corr_index_arr, table_n);

                    int32_t dwMaxDataId = CommConn_AddProtocol(comm_port_idx, dev_code);
                    SlaveDevice_SetMaxDataId(dev_code, dwMaxDataId);

                    slave_device_config_content *pSlaverConfig = SlaveDevice_Find(dev_code);
                    CommConn_SetSlaverConfig(comm_port_idx, mbm_slaver_id-1, pSlaverConfig);

                }
                else
                {
                    ReadCommportAttributeConfig(Node2, comm_type, comm_id, &stComPort);
                }

                Node2 = Node2->next;
            }

            CommConn_SetCommPortAttr(comm_port_idx, &stComPort);
            comm_port_idx++;
        }
        Node1 = Node1->next;
    }

    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);
    xmlCleanupParser();

    return 0;
}

int32_t ParseMqttConfig(char* configfilePATH, void *northMqtt)
{
    xmlDocPtr doc;
    xmlNodePtr curNode, Node1;
    xmlXPathContextPtr context;
    char *szDocName = configfilePATH;
    int32_t ret = OK;

    NORTH_PARAM_T *mqttParam = (NORTH_PARAM_T *)northMqtt;
    doc = xmlReadFile(szDocName,"UTF-8", XML_PARSE_RECOVER);

    if (NULL == doc || mqttParam == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "Document not parsed successfully\n" );
        return -1;
    }

    context = xmlXPathNewContext(doc);
    if (context == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "context is NULL\n");
        xmlFreeDoc(doc);
        return -1;
    }

    //读取root节点
    curNode = xmlDocGetRootElement(doc);
    if (NULL == curNode)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "string_xml no root !\n");
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return -1;
    }

    //解析root下子节点
    if (xmlStrcmp(curNode->name, BAD_CAST "root"))
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "document of the wrong type, root node != root");
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return -1;
    }

    xmlNodePtr propNodePtr = curNode->xmlChildrenNode;
    Node1 = curNode->xmlChildrenNode;

    while (Node1 != NULL)
    {
        if ((!xmlStrcmp(Node1->name, (const xmlChar * ) "mqtt")))
        {
            //查找属性
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "enabled"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "enabled" );
                    if (strtoul((const char * )szAttr, NULL, 0) == 1)
                    {
                        mqttParam->CfgSelect |= 1;
                    }
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "host_ip"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "host_ip");
                    strcpy(mqttParam->MqttAddr, (const char * )szAttr);
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "host_port"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "host_port");
                    mqttParam->MqttPort = strtoul((const char * )szAttr, NULL, 0);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar * ) "client_id")))
        {
            xmlChar* szKey = xmlNodeGetContent(Node1);
            strcpy(mqttParam->MqttClientID, (const char * )szKey);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar * ) "username")))
        {
            xmlChar* szKey = xmlNodeGetContent(Node1);
            strcpy(mqttParam->MqttUser, (const char * )szKey);
            xmlFree(szKey);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar * ) "password")))
        {
            xmlChar* szKey = xmlNodeGetContent(Node1);
            strcpy(mqttParam->MqttPwd, (const char * )szKey);
            xmlFree(szKey);
        }
        else if((!xmlStrcmp(Node1->name, (const xmlChar * )"upload_method")))
        {
            xmlChar* szKey = xmlNodeGetContent(Node1);
            mqttParam->MqttMethod = strtoul((const char * )szKey, NULL, 0);
            xmlFree(szKey);
        }
        else if((!xmlStrcmp(Node1->name, (const xmlChar * )"encrypt")))
        {
            //查找属性
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "enabled"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "enabled" );
                    mqttParam->MqttEncry = strtoul((const char * )szAttr, NULL, 0);
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "en_method"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "en_method");
                    mqttParam->MqttAlgor = strtoul((const char * )szAttr, NULL, 0);
                    xmlFree(szAttr);
                }

                attrPtr = attrPtr->next;
            }
        }
        else if((!xmlStrcmp(Node1->name, (const xmlChar * )"upload_period")))
        {
            xmlChar* szKey = xmlNodeGetContent(Node1);
            mqttParam->MqttCycle = strtoul((const char * )szKey, NULL, 0);
            xmlFree(szKey);
        }
        else if((!xmlStrcmp(Node1->name, (const xmlChar * )"topic_pub_rundata_all")))
        {
            xmlChar* szKey = xmlNodeGetContent(Node1);
            strcpy(mqttParam->MqttPubTopic, (char *)szKey);
            xmlFree(szKey);
        }
        else if((!xmlStrcmp(Node1->name, (const xmlChar * )"topic_sub_command")))
        {
            xmlChar* szKey = xmlNodeGetContent(Node1);
            strcpy(mqttParam->MqttSubTopic, (char *)szKey);
            xmlFree(szKey);
        }
        Node1 = Node1->next;
    }

    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);

    return ret;
}
