#include <stdlib.h>
#include "protocol_operate.h"
#include "transmit.h"
#include "GlobalData.h"
#include "SGQueue.h"
#include "common.h"
#include "logUtil.h"
#include "commonTest.h"
#include "protocol.h"
#include "calc.h"
#include "sdb.h"
#include "CommConnObj.h"
#include "xml_analysis.h"

#define  HIBYTE(v1)  ((uint8_t)((v1)>>8))
#define  LOBYTE(v1)  ((uint8_t)((v1)&0xff))
#define  HIWORD(v1)  ((uint16_t)((v1)>>16))
#define  LOWORD(v1)  ((uint16_t)((v1)&0xffff))

#define  MODBUS_OPERATE_RIGHT    0x0           //正确操作返回
#define  MODBUS_CMD_NO_SUPPORT   0x01          //不支持的命令
#define  CMD_DATA_NUM_BEYOND     0x03          //寄存器数量越界   0x0001≤输出数量≤0x07D0   (2000)
#define  CMD_ADDRESS_BEYOND      0x02          //起始地址 != OK       起始地址+输出数量 !＝OK
#define  CMD_READ_WRITE_ERR      0x04          //读取离散输出!＝OK  设置失败
#define  MODBUS_DATA_NO_ANSWER   -1            //不应答数据
#define  CMD_DATA_LIMIT_BEYOND   0x05

PLAT_SR_T g_PlatSR[TEST_NUM];

COMM_REG_T g_CommReg;

/****************************************************************************************************************************************************
//modbus标准增加 解析

支持  0x01  0x03 0x04  0x06   0x10

#define  CMD_01_DATA_NUM_BEYOND               0x03          //寄存器数量越界   0x0001≤输出数量≤0x07D0   (2000)  0x0001 <= Quantity of Outputs <= 0x07D0
#define  CMD_03_04_DATA_NUM_BEYOND            0x03          //寄存器数量越界   0x0001≤输出数量≤0x007D   (125)    0x0001 <=Quantity of Registers <= 0x007D
#define  CMD_06_DATA_NUM_BEYOND               0x03          //寄存器数量越界   0x0001≤输出数量≤0x007D   (125)    0x0000 <= Register Value<= 0xFFFF
#define  CMD_16_DATA_NUM_BEYOND               0x03          //寄存器数量越界   0x0001≤输出数量≤0x007B   (123)     0x0001<= Quantity of Registers <=0x007B AND Byte Count == Quantity of Registers x 2

#define  CMD_01_ADDRESS_BEYOND                0x02          //起始地址 != OK       Starting Address == OK AND  Starting Address + Quantity of Outputs == OK
#define  CMD_03_04_16_ADDRESS_BEYOND          0x02          //起始地址 != OK       起始地址+输出数量 !＝OK ( Starting Address == OK   AND Starting Address + Quantity of Registers == OK)
#define  CMD_06_ADDRESS_BEYOND                0x02          //起始地址 != OK       (Register Address == OK)

#define  CMD_01_READ_ERR                      0x04          //读取离散输出!＝OK ReadDiscreteOutputs != OK
#define  CMD_03_READ_ERR                      0x04          //读取多个寄存器失败!＝OKReadMultipleRegisters != OK
#define  CMD_04_READ_ERR                      0x04          //读取多个寄存器失败! ReadInputRegisters != OK
#define  CMD_06_WRITE_ERR                     0x04          //写单个寄存器!＝OK WriteSingleRegister  != OK
#define  CMD_10_WRITE_ERR                     0x04          //写多个输出!=OK WriteMultipleRegisters  != OK

****************************************************************************************************************************************************/
//范围限制
int8_t DataLimitCheck ( int32_t pass_data,int32_t data_low_limit1,int32_t data_high_limit1,int32_t data_low_limit2,int32_t data_high_limit2 );

extern PLAT_STATISTICS_T g_PlatStic;

Q_EXTERN(DEV_DATA_T, cmdqInQ);

//建立链表头结点
int32_t CreateComm(void)
{
    CLIENT_LINK_SLAVER_T *commNew = (CLIENT_LINK_SLAVER_T *)calloc(1, sizeof(CLIENT_LINK_SLAVER_T));
    if (commNew == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "malloc commNew error.\n");
        exit ( 1 );
    }

    commNew->next = NULL;

    g_CommReg.num = 0;
    g_CommReg.comm_L = commNew;
    g_CommReg.end = commNew;

    return 0;
}

//动态注册通信连接
int32_t InsertComm(int32_t fd, int32_t commConnId, COMM_TYPE_SHOW_E commType)
{
    uint8_t ret = 1;
    CLIENT_LINK_SLAVER_T *commNew = NULL;

    if (g_CommReg.num >= MAX_EVENTS)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "MAX_EVENTS !\n");
        //超过最大连接数
        return 0;
    }

    commNew = (CLIENT_LINK_SLAVER_T *) malloc(sizeof(CLIENT_LINK_SLAVER_T));
    if (commNew == NULL)
    {
        EMS_LOG(LL_WARNING, MODULE_T, FALSE, "malloc fail.\n");
        exit(1);
    }
    memset(commNew, 0, sizeof(CLIENT_LINK_SLAVER_T));

    if (commConnId >= 0)
    {
        commNew->link_fd = fd;
        commNew->comm_conn_id = commConnId;
        commNew->comm_type = commType;

        g_CommReg.end->next = commNew;
        g_CommReg.end = commNew;
        g_CommReg.num += 1;

        ret = g_CommReg.num;

#ifndef CONCURRENT_TEST
        printf("%s link_fd:%d add comm %p,num:%d, head:%p\n",
               __func__, commNew->link_fd, commNew, g_CommReg.num, g_CommReg.comm_L);
#endif
    }
    else
    {
        free(commNew);
        ret = 0;
    }

    return ret;
}

//删除通信连接
int32_t DeleteComm(int32_t delFd)
{
    CLIENT_LINK_SLAVER_T *pHead = NULL;
    CLIENT_LINK_SLAVER_T  *pTmp = NULL;
    int32_t regId  = 0;
    int32_t regNum  = 0;

    regNum = g_CommReg.num;
    pHead = g_CommReg.comm_L;//头结点是空节点

    if (regNum == 0)
    {
        return  -1;
    }

    for (regId = 0; regId < regNum; ++regId)
    {
        if (pHead->next == NULL)
        {
           break;
        }
        pTmp = pHead->next;

        if (pTmp->link_fd == delFd)
        {
            pHead->next = pTmp->next;

            if (pTmp->next == NULL )
            {
                g_CommReg.end = pHead;
            }
            free(pTmp);
            g_CommReg.num--;
            return 0;
        }
        else
        {
            pHead = pHead->next;
        }
    }
    return -1;//删除失败,不存在要删除的节点
}

/*******************************************************************************
 * Function       : getCRC16
 * Author         :
 * Date           : 2011.09.13
 * Description    : CRC
 * Calls          : None
 * Input          : volatile uint8_t *ptr, uint16_t len
 * Output         : None
 * Return         : CRC
 ********************************************************************************/
uint16_t getCRC16 (volatile uint8_t *ptr, uint16_t len)
{
    uint8_t i;
    uint16_t crc = 0xFFFF;
    if (len == 0)
    {
        len = 1;
    }
    while (len--)
    {
        crc ^= *ptr;
        for (i = 0; i < 8; i++)
        {
            if (crc&1)
            {
                crc >>= 1;
                crc ^= 0xA001;
            }
            else
            {
                crc >>= 1;
            }
        }
        ptr++;
    }
    return (crc);
}

/*************************************************************************
 * Function       : AnalyModbusRtuSlaveData
 * Author         : sungr
 * Date           : 2021.09.22
 * Description    : 将crc校验正确的modbus从机数据按MODBUS_PROTOCOL_T格式存储至modbus_data，传输接口为串口，格式为RTU
 * Calls          : crccheck
 * Input          : uint8_t *rbuf modbus从机数据
 *                 buflen: 数据长度
 *
 * Output         : modbus_data: MODBUS_PROTOCOL_T结构指针
 * Return         : 0: 数据解析正确;-1:数据crc校验错误; 1:modbus数据为不支持的功能码; 3:数据长度不正确
**************************************************************************/
int32_t AnalyModbusRtuSlaveData(uint8_t *rbuf, uint8_t buflen, MODBUS_PROTOCOL_T *modbus_data )
{
    int32_t ret = 0;

    if (CrcCheck(rbuf, buflen, 0) == 0)
    {
        ret = MODBUS_DATA_NO_ANSWER;	//crc校验错误
    }
    else
    {
        modbus_data->id = rbuf[0];
        modbus_data->cmd = rbuf[1];
        modbus_data->address = (rbuf[2] << 8) | rbuf[3];

        switch (modbus_data->cmd)
        {
            case 0x01:
            case 0x02:
            {
                modbus_data->len = (rbuf[4] << 8) | rbuf[5];
                modbus_data->data = &rbuf[6];
                //01数量超长.数量不对
                if ((modbus_data->len < 1) || (modbus_data->len > 2000))
                {
                    ret = CMD_DATA_NUM_BEYOND;
                }
                break;
            }
            case 0x03:
            case 0x04:
            {
                modbus_data->len = (rbuf[4] << 8) | rbuf[5];
                modbus_data->data = &rbuf[6];
                //16数量超长.数量不对
                if ((modbus_data->len < 1) || (modbus_data->len > 125)) //数量超长
                {
                    ret = CMD_DATA_NUM_BEYOND;
                }
                break;
            }
            case 0x05:
            {
                modbus_data->len = 1;
                modbus_data->data = &rbuf[4];
                // 06 数量超长.数量不对
                uint32_t revCoilData = (rbuf[4] << 8) | rbuf[5];
                if (revCoilData != 0x0 && revCoilData != 0xFF00)
                {
                    ret = CMD_DATA_NUM_BEYOND;
                }
                break;
            }
            case 0x06:
            {
                modbus_data->len = 1;
                modbus_data->data = &rbuf[4];

                uint32_t rev_register_data = (rbuf[4] << 8) | rbuf[5];
                if (rev_register_data > 0xffffffff)
                {
                    ret = CMD_DATA_NUM_BEYOND;
                }
                break;
            }
            case 0x10:
            {
                modbus_data->len = (rbuf[4] << 8) | rbuf[5];
                modbus_data->data = &rbuf[7];

                //16数量超长.数量不对
                if (((modbus_data->len < 1) || (modbus_data->len > 123)) || (2 * modbus_data->len != rbuf[6]))
                {
                    ret = CMD_DATA_NUM_BEYOND;
                }
                break;
            }
            default:
                ret = MODBUS_CMD_NO_SUPPORT;//不支持其他功能码
                break;
        }
    }
    return ret;
}

/*************************************************************************
 * Function       : AnalyModbusTcpSlaveData
 * Author         : sungr
 * Date           : 2021.09.22
 * Description    : 将crc校验正确的modbus从机数据按MODBUS_PROTOCOL_T格式存储至modbus_data，传输接口为网口，格式为TCP
 * Calls          : crccheck
 * Input          : uint8_t *rbuf modbus从机数据
 *                 buflen: 数据长度
 *
 * Output         : modbus_data: MODBUS_PROTOCOL_T结构指针
 * Return         : 0: 数据解析正确;-1:数据crc校验错误; 1:modbus数据为不支持的功能码; 3:数据长度不正确
**************************************************************************/
int32_t AnalyModbusTcpSlaveData(uint8_t *rbuf, uint8_t buflen, MODBUS_PROTOCOL_T *modbus_data)
{
    int32_t ret = 0;

    modbus_data->protocolType = rbuf[2] << 8 | rbuf[3];  //协议号
    if (0x00 != modbus_data->protocolType)             //不是modbusTCP协议，丢弃报文
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "this is not modbus, discard it.\n");
        ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
        return ret;
    }

    modbus_data->id = rbuf[6];
    modbus_data->cmd = rbuf[7];
    modbus_data->address = (rbuf[8] << 8) | rbuf[9];

    switch (modbus_data->cmd)
    {
        case 01:
        case 02:
        {
            modbus_data->len = (rbuf[10] << 8) | rbuf[11];
            modbus_data->data = &rbuf[12];
            //01 02 数量超长.数量不对
            if ((modbus_data->len < 1) || (modbus_data->len > 2000)) //数量超长
            {
                ret = CMD_DATA_NUM_BEYOND;
            }
            break;
        }
        case 0x03:
        case 0x04:
        {
            modbus_data->len = (rbuf[10] << 8) | rbuf[11];
            modbus_data->data = &rbuf[12];
            //03 04 数量超长.数量不对
            if ((modbus_data->len < 1) || (modbus_data->len > 125)) //数量超长
            {
                ret = CMD_DATA_NUM_BEYOND;
            }
            break;
        }
        case 0x05:
        {
            modbus_data->len = 1;
            modbus_data->data = &rbuf[10];
            // 06 数量超长.数量不对
            uint32_t revCoilData = (rbuf[10] << 8) | rbuf[11];
            if (revCoilData != 0x0 && revCoilData != 0xFF00)
            {
                ret = CMD_DATA_NUM_BEYOND;
            }
            break;
        }
        case 0x06:
        {
            modbus_data->len = 1;
            modbus_data->data = &rbuf[10];
            // 06 数量超长.数量不对
            uint32_t revRegisterData = (rbuf[10] << 8) | rbuf[11];
            if (revRegisterData > 0xffffffff)
            {
                ret = CMD_DATA_NUM_BEYOND;
            }
            break;
        }
        case 0x10:
        {
            modbus_data->len = (rbuf[10] << 8) | rbuf[11];
            modbus_data->data = &rbuf[13];
            // 16 数量超长.数量不对
            if (((modbus_data->len < 1) || (modbus_data->len > 123)) || (2 * modbus_data->len != rbuf[12]))
            {
                ret = CMD_DATA_NUM_BEYOND;
            }
            break;
        }
        case 0x0F:
        {
            modbus_data->len = (rbuf[10] << 8) | rbuf[11];
            modbus_data->data = &rbuf[13];

            int32_t byteNum = modbus_data->len / 8;
            byteNum = (modbus_data->len % 8 == 0) ? byteNum : (byteNum + 1);
            // 16 数量超长.数量不对
            if (((modbus_data->len < 1) || (modbus_data->len > 0x7B0)) || (byteNum != rbuf[12]))
            {
                ret = CMD_DATA_NUM_BEYOND;
            }
            break;
        }
        default:
            ret = MODBUS_CMD_NO_SUPPORT;//不支持其他功能码
            break;
    }
    return ret;
}

//03 04命令处理
int32_t CreatePcPackage (int32_t modbus_slave_id, uint8_t *sbuf, uint32_t address, uint8_t inbuflen, protocol_s *proper_protocol)
{
    protocol_data_s  *protocol_data = proper_protocol->protocol_data;
    uint32_t *map = proper_protocol->map;
    uint16_t ptl_no = proper_protocol->ptl_dev_code;
    uint32_t first_addr = proper_protocol->address;

    uint8_t protocol_byte_type = proper_protocol->protocol_byte;
    uint8_t protocol_word_type = proper_protocol->protocol_word;

    int32_t tmp32 = 0;
    int16_t tmp16 = 0;
    uint32_t index = 0;
    uint16_t data_id = 0;
    uint32_t end_address = 0;
    uint8_t data_byte_len = 0;
    int32_t ret = 0;
    uint16_t cur_addr = 0;
    uint16_t post_offset = 0;
    uint16_t addr_id = 0;
    int32_t config_index_id = 0;
    int32_t slave_index_id = 0 ;

    end_address = address + inbuflen;

    //ProtocolByte="高字节前低字节后" ProtocolWord="低字前高字后"
    protocol_byte_type = (protocol_byte_type == 0xFF) ? HL_BYTE : protocol_byte_type;
    protocol_word_type = (protocol_word_type == 0xFF) ? LH_WORD : protocol_word_type;

    do
    {
//         config_index_id = SlaveDevice_SearchSlaveIdCorrespondingIndex(modbus_slave_id, ptl_no);
        config_index_id = SlaveDevice_SearchSlaveId(modbus_slave_id, ptl_no, address);

        if (config_index_id >= 0xffffffff)
        {
            ret = MODBUS_DATA_NO_ANSWER;  //设备对应转发modbus地址没有配置 不应答
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "index error, config_index_id  %d \n", config_index_id);
            break;
        }

        /*address 后台地址   first_addr  协议中的第一个寄存器地址，后台的访问地址比 协议寄存器地址小1*/
        for (cur_addr = address, post_offset = 0; cur_addr< end_address; cur_addr++)
        {
            addr_id = cur_addr - (first_addr - 1);
            index = map[addr_id];

            if (index == 0xffffffff) //寻不到地址
            {
                sbuf[post_offset++] = 0xff;
                sbuf[post_offset++] = 0xff;
            }
            else
            {
                slave_index_id = config_index_id;
                data_byte_len = protocol_data[index].data_byte_num;
                data_id = protocol_data[index].data_id;

                //设备通讯异常 应答无效数据
//                 int32_t dev_comm_flag  = 0;
//                 dev_comm_flag = g_SearchDevGatherCase.p_dev_gdata[search_id].dev_communicate_state[slave_index_id];
//                 if (DEV_COMM_FAULT == dev_comm_flag)
//                 {
//                     ret = CMD_READ_WRITE_ERR;   //设备通讯异常  读写错误
//                     EMS_LOG(LL_ERROR, MODULE_T, FALSE, "CMD_READ_WRITE_ERR error, CMD_READ_WRITE_ERR  %d \n", CMD_READ_WRITE_ERR);
//                     break;
//                 }

                VALUE_INFO_T stDataValue;
                GdataFetch(&stDataValue, ptl_no, slave_index_id, data_id, protocol_data[index].data_type);
                if (protocol_data[index].data_type == S_INT_T)
                {
                    tmp32 = stDataValue.data.s32;
                }
                else if (protocol_data[index].data_type == U_INT_T)
                {
                    tmp32 = stDataValue.data.u32;
                }
                else if (protocol_data[index].data_type == FLOAT_T)
                {
                    tmp32 = stDataValue.data.s32;
                }

                if (data_byte_len == 2)
                {
                    tmp16 = (uint16_t)tmp32;
                    SetU16(protocol_byte_type, &sbuf[post_offset], tmp16);
                    post_offset += 2;
                }
                else if (data_byte_len == 4)
                {
                    SetU32(protocol_word_type, protocol_byte_type, &sbuf[post_offset], tmp32);
                    post_offset += 4;
                    cur_addr++;
                }

            }
        }
    }while ( 0 );

    return ret;
}

//范围限制
int8_t DataLimitCheckuint(uint32_t pass_data, uint32_t data_low_limit1_uint, uint32_t data_high_limit1_uint,
                          uint32_t data_low_limit2_uint, uint32_t data_high_limit2_uint)
{
    int8_t  limit_ret = 0;
    if ((0 == data_low_limit2_uint ) && (0 == data_high_limit2_uint))
    {
        if ((pass_data >= data_low_limit1_uint) && (pass_data <= data_high_limit1_uint))
        {
            limit_ret = 1;
        }
    }
    else
    {
        if (((pass_data >= data_low_limit1_uint) && (pass_data <= data_high_limit1_uint))
            ||((pass_data >= data_low_limit2_uint) && (pass_data <= data_high_limit2_uint)))
        {
            limit_ret = 1;
        }
    }

    return limit_ret ;
}

//范围限制
int8_t DataLimitCheckSInt ( int32_t pass_data,int32_t data_low_limit1, int32_t data_high_limit1, int32_t data_low_limit2, int32_t data_high_limit2 )
{
    int8_t  limit_ret = 0;
    if ((0 == data_low_limit2) && (0 == data_high_limit2))
    {
        if ((pass_data >= data_low_limit1) && (pass_data <= data_high_limit1))
        {
            limit_ret = 1;
        }
    }
    else
    {
        if (((pass_data >= data_low_limit1) && (pass_data <= data_high_limit1))
            || (( pass_data >= data_low_limit2) && (pass_data <= data_high_limit2)))
        {
            limit_ret = 1;
        }
    }
    return limit_ret ;
}

//范围限制
int8_t DataLimitCheck ( int32_t pass_data, int32_t data_low_limit1,int32_t data_high_limit1, int32_t data_low_limit2, int32_t data_high_limit2 )
{
    int8_t  limit_ret = 0;
    if ((0 == data_low_limit2) && (0 == data_high_limit2))
    {
        if ((pass_data >= data_low_limit1) && (pass_data <= data_high_limit1))
        {
            limit_ret = 1;
        }
    }
    else
    {
        if (((pass_data >= data_low_limit1) && (pass_data <= data_high_limit1))
            || ((pass_data >= data_low_limit2) && (pass_data <= data_high_limit2)))
        {
            limit_ret = 1;
        }
    }
    return limit_ret ;
}

/********************************************************************************************************
 #define  MODBUS_OPERATE_RIGHT        0x0
 #define  MODBUS_CMD_NO_SUPPORT       0x01        //不支持的命令
 #define  CMD_DATA_NUM_BEYOND   	  0x03        //寄存器数量越界   0x0001≤输出数量≤0x07D0   (2000)
 #define  CMD_ADDRESS_BEYOND          0x02        //起始地址 != OK       起始地址+输出数量 !＝OK
 #define  CMD_READ_WRITE_ERR          0x04        //读取离散输出!＝OK
*********************************************************************************************************/

//06 10命令处理
int32_t revCmdPro(int32_t modbusId, uint8_t *data, uint32_t address, uint8_t inbuflen, protocol_s *proper_protocol)
{
    int32_t ret = 0;
    protocol_data_s *ptl_data = proper_protocol->protocol_data;
    uint32_t *map =  proper_protocol->map, tmpU32 = 0, tmpU16 = 0;
    uint16_t ptl_no = proper_protocol->ptl_dev_code;
    uint32_t first_addr = proper_protocol->address ;
    uint8_t protocol_byte_type =  proper_protocol->protocol_byte;
    uint8_t protocol_word_type =  proper_protocol->protocol_word;

    int32_t tmp32 = 0;
    int16_t tmp16 = 0;
    uint32_t end_address, index = 0;
    uint8_t data_byte_len = 0,fifo_ptr=0;

    DEV_DATA_T fifo_data[DATA_TOTEL];
    memset (&fifo_data, 0 ,sizeof (DEV_DATA_T) * DATA_TOTEL);

    int32_t dev_index = 0;
    int32_t xml_config_dev_index = 0;

    //ProtocolByte="高字节前低字节后" ProtocolWord="低字前高字后"
    protocol_byte_type = (protocol_byte_type == 0xFF) ? HL_BYTE : protocol_byte_type;
    protocol_word_type = (protocol_word_type == 0xFF) ? LH_WORD : protocol_word_type;

    do
    {
        if (modbusId == 0x0)
        {
            //local_int_broadcast_order_id  =  0x1;
            xml_config_dev_index = 0x0;
        }
        else
        {
//             xml_config_dev_index =  SlaveDevice_SearchSlaveIdCorrespondingIndex(modbusId, ptl_no);
            xml_config_dev_index =  SlaveDevice_SearchSlaveId(modbusId, ptl_no, address);
        }

        //不存在设备 不应答
        if (xml_config_dev_index >= 0xffffffff)
        {
            ret = MODBUS_DATA_NO_ANSWER;
            break;
        }

        end_address = address + inbuflen;

        uint32_t cur_addr = 0 ;
        uint16_t post_offset = 0;
        uint16_t addr_id = 0;

        for (cur_addr = address, post_offset = 0; cur_addr < end_address; cur_addr++)
        {
            addr_id = cur_addr - (first_addr - 1);
            index = map[addr_id];

            if (index == INVALID_VALUE)
            {
                post_offset += 2;
                continue;
            }
            dev_index = xml_config_dev_index;
            data_byte_len = ptl_data[index].data_byte_num;
            if (ptl_data[index].data_sign == SIGN_U)
            {
                if (data_byte_len == 2)
                {
                    tmpU16 = GetU16(protocol_byte_type, data + post_offset);

                    post_offset+=2;

                    tmpU32 = tmpU16;
                }
                else //=4
                {
                    tmpU32 = GetU32 (protocol_word_type, protocol_byte_type, data + post_offset);
                    post_offset+=4;
                    cur_addr += 1;

                }
            }
            else
            {
                if (data_byte_len == 2)
                {
                    tmp16 = GetS16(protocol_byte_type, data + post_offset);

                    post_offset+=2;

                    tmp32 = tmp16;
                }
                else //=4
                {
                    tmp32 = GetS32 (protocol_word_type, protocol_byte_type, data + post_offset);
                    post_offset+=4;
                    cur_addr += 1;

                }
            }

            //设备通讯异常 应答无效数据
//             int32_t dev_comm_flag  = 0;
//             dev_comm_flag = g_SearchDevGatherCase.p_dev_gdata[search_id].dev_communicate_state[dev_index];
//             if (DEV_COMM_FAULT == dev_comm_flag)
//             {
//                 ret = CMD_READ_WRITE_ERR;
//                 break;
//             }

            int8_t data_limit_check_flag  =  0;

            if (ptl_data[index].data_sign == SIGN_U)
            {
                data_limit_check_flag = DataLimitCheckuint(tmpU32, ptl_data[index].low_limit1_uint,ptl_data[index].high_limit1_uint,
                                                ptl_data[index].low_limit2_uint, ptl_data[index].high_limit2_uint);
            }
            else if (ptl_data[index].data_sign == SIGN_S)
            {
                data_limit_check_flag = DataLimitCheckSInt(tmp32, ptl_data[index].low_limit1,ptl_data[index].high_limit1,
                                                ptl_data[index].low_limit2, ptl_data[index].high_limit2);
            }
            else
            {
                data_limit_check_flag = 0;
            }

            if (data_limit_check_flag)
            {
                if (ptl_data[index].data_type == S_INT_T)
                {
                    fifo_data[fifo_ptr].value.data.s32 = (int32_t)tmp32;
                    fifo_data[fifo_ptr].data_type = S_INT_T;
                }
                else if (ptl_data[index].data_type == U_INT_T)
                {
                    fifo_data[fifo_ptr].value.data.u32 = (uint32_t)tmpU32;
                    fifo_data[fifo_ptr].data_type = U_INT_T;
                }
                else if (ptl_data[index].data_type == FLOAT_T)
                {
                    //fifo_data[fifo_ptr].data.f32 = g_SearchDevGatherCase.p_dev_gdata[search_id].data_p[dev_index][data_name].f32 ;
                    fifo_data[fifo_ptr].value.data.s32 = (int32_t)tmp32;
                    fifo_data[fifo_ptr].data_type = FLOAT_T;
                }

                if (SDB_GetUseCoeffFlag() == TRUE)
                {
                    float32_t coeffi = ptl_data[index].scale_coefficient;
                    if (coeffi > 0.0 && coeffi < 1.0)
                    {
                        fifo_data[fifo_ptr].data_type = FLOAT_T;
                        fifo_data[fifo_ptr].value.data.f32 = tmp32 * coeffi;
                    }
                }

                fifo_data[fifo_ptr].dev_code = ptl_no;
                fifo_data[fifo_ptr].moduleID = MODULE_T;
                fifo_data[fifo_ptr].data_id = ptl_data[index].data_id;
                fifo_data[fifo_ptr].index = dev_index;

#ifdef SR_TEST
                static int32_t test_cout = 0;
                if (test_cout < TEST_NUM)
                {
                    gettimeofday(&g_PlatSR[test_cout].startT, NULL);
                    g_PlatSR[test_cout].u32Tag = fifo_data[fifo_ptr].u32Tag = test_cout + 1000;
                    printf("%s test_cout:%d\n", __func__, test_cout);
                    test_cout++;
                }
#endif
                fifo_ptr++;
            }
            else
            {
                ret = CMD_READ_WRITE_ERR;
            }
        }

        GdataFill(fifo_data, fifo_ptr);

        if (!Q_FULL(cmdqInQ))
        {
            Q_INSERT_WAIT_N(cmdqInQ, fifo_data, fifo_ptr);
            __sync_add_and_fetch(&g_PlatStic.sendToClctrCnt, 1);
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "CMDInQ is full!.\n");
        }

    }while (0);

    return ret;
}

/**
 * @brief  0F 命令处理
 * @param inbuflen:输出数量
 *
 * @return
 */
int32_t WriteRunBitData(int32_t modbus_slave_id, uint8_t *data, uint32_t address, uint8_t inbuflen, protocol_s *proper_protocol, int32_t modbusCmd)
{
    protocol_data_s  *protocol_data = proper_protocol->protocol_data;
    uint32_t *map = proper_protocol->map;
    uint16_t ptl_no = proper_protocol->ptl_dev_code;
    uint32_t first_addr = proper_protocol->address;

    int32_t tmp32 = 0, index = 0, end_address = 0, ret = 0;
    uint16_t data_id = 0, cur_addr = 0, addr_id = 0;
    int32_t config_index_id = 0, slave_index_id = 0;
    uint32_t data_idx = 0, fifo_ptr = 0;

    DEV_DATA_T fifo_data[DATA_TOTEL];
    memset(&fifo_data, 0 ,sizeof (DEV_DATA_T) * DATA_TOTEL);

    end_address = address + inbuflen;
    do
    {
        config_index_id = SlaveDevice_SearchSlaveId(modbus_slave_id, ptl_no, address);

        if (config_index_id >= INVALID_VALUE)
        {
            ret = MODBUS_DATA_NO_ANSWER;  //设备对应转发modbus地址没有配置 不应答
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "index error, config_index_id:%d.\n", config_index_id);
            break;
        }

        if (modbusCmd == 0x05)
        {
            uint16_t tmpU16 = GetU16(HL_BYTE, data);

            fifo_data[fifo_ptr].dev_code = ptl_no;
            fifo_data[fifo_ptr].index = config_index_id;
            fifo_data[fifo_ptr].data_id = protocol_data[map[address - (first_addr - 1)]].data_id;
            fifo_data[fifo_ptr].data_type = fifo_data[fifo_ptr].value.ucDataType = S_INT_T;
            fifo_data[fifo_ptr].moduleID = MODULE_T;
            fifo_data[fifo_ptr].value.data.s32 = (tmpU16 == 0xFF00) ? 1 : 0;
            fifo_data[fifo_ptr].cmd = 0x05;
            fifo_ptr++;

            break;
        }
        int32_t shift = 0;
        /*address 后台地址   first_addr  协议中的第一个寄存器地址  ，后台的访问地址比 协议寄存器地址小1*/
        for (cur_addr = address; cur_addr < end_address; cur_addr++)
        {
            addr_id = cur_addr - (first_addr - 1);
            index = map[addr_id];

            if (index == INVALID_VALUE) //寻不到地址
            {
                continue;
            }
            else
            {
                slave_index_id = config_index_id;
                data_id = protocol_data[index].data_id;

                //TODO 设备通讯异常 应答无效数据

                data_idx = (cur_addr - address) / 8;

                tmp32 = (data[data_idx] & (1 << shift)) ? 1 : 0;

                fifo_data[fifo_ptr].dev_code = ptl_no;
                fifo_data[fifo_ptr].index = slave_index_id;
                fifo_data[fifo_ptr].data_id = data_id;
                fifo_data[fifo_ptr].data_type = fifo_data[fifo_ptr].value.ucDataType = S_INT_T;
                fifo_data[fifo_ptr].moduleID = MODULE_T;
                fifo_data[fifo_ptr].value.data.s32 = tmp32;
                fifo_data[fifo_ptr].cmd = 0x0F;
                fifo_ptr++;
            }

            shift++;
            shift %= 8;
        }
    }while(0);

    if (fifo_ptr > 0)
    {
        GdataFill(fifo_data, fifo_ptr);

        if (!Q_FULL(cmdqInQ))
        {
            Q_INSERT_WAIT_N(cmdqInQ, fifo_data, fifo_ptr);
            __sync_add_and_fetch(&g_PlatStic.sendToClctrCnt, 1);
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "CMDInQ is full!.\n");
        }
    }

    return ret;
}

int32_t SaveRunBitDataPack (int32_t modbus_slave_id, uint8_t *sbuf, uint32_t address, uint8_t inbuflen, protocol_s *proper_protocol)
{
    protocol_data_s  *protocol_data = proper_protocol->protocol_data;
    uint32_t *map = proper_protocol->map;
    uint16_t ptl_no = proper_protocol->ptl_dev_code;
    uint32_t first_addr = proper_protocol->address;

    int32_t tmp32 = 0, index = 0, end_address = 0, ret = 0;
    uint16_t data_id = 0, cur_addr = 0, post_offset = 0, addr_id = 0;
    int32_t config_index_id = 0, slave_index_id = 0;
    uint32_t data_idx = 0, data_offset = 0;

    end_address = address + inbuflen;
    do
    {
        config_index_id = SlaveDevice_SearchSlaveId(modbus_slave_id, ptl_no, address);

        if (config_index_id >= INVALID_VALUE)
        {
            ret = MODBUS_DATA_NO_ANSWER;  //设备对应转发modbus地址没有配置 不应答
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "index error, config_index_id:%d.\n", config_index_id);
            break;
        }

        /*address 后台地址   first_addr  协议中的第一个寄存器地址  ，后台的访问地址比 协议寄存器地址小1*/
        for (cur_addr = address, post_offset = 0; cur_addr < end_address; cur_addr++)
        {
            addr_id = cur_addr - (first_addr - 1);
            index = map[addr_id];

            if (index == INVALID_VALUE) //寻不到地址
            {
                sbuf[post_offset++] = 0xff;
                sbuf[post_offset++] = 0xff;
            }
            else
            {
                slave_index_id = config_index_id;
                data_id = protocol_data[index].data_id;

                //设备通讯异常 应答无效数据
//                 int32_t dev_comm_flag  = 0;
//                 dev_comm_flag = g_SearchDevGatherCase.p_dev_gdata[search_id].dev_communicate_state[slave_index_id];
//                 if (DEV_COMM_FAULT == dev_comm_flag)
//                 {
//                     ret = CMD_READ_WRITE_ERR;   //设备通讯异常  读写错误
//                     EMS_LOG(LL_ERROR, MODULE_T, FALSE, "CMD_READ_WRITE_ERR error, CMD_READ_WRITE_ERR  %d \n", CMD_READ_WRITE_ERR);
//                     break;
//                 }

                VALUE_INFO_T stDataValue;
                GdataFetch(&stDataValue, ptl_no, slave_index_id, data_id, protocol_data[index].data_type);

                if (protocol_data[index].data_type == S_INT_T)
                {
                    tmp32 = stDataValue.data.s32;
                }
                else if (protocol_data[index].data_type == U_INT_T)
                {
                    tmp32 = stDataValue.data.u32;
                }
                else if (protocol_data[index].data_type == FLOAT_T)
                {
                    tmp32 = (int32_t)(stDataValue.data.s32);
                }

                data_idx = (cur_addr - address) / 8;
                data_offset = (cur_addr - address) % 8;

                if (tmp32 == 1)
                {
                    sbuf[data_idx] = SetBitValue(sbuf[data_idx], data_offset);
//                     printf("%s cur_addr:%d data_idx:%d data_offset:%d sbuf[data_idx]:%d.\n", __func__,cur_addr, data_idx, data_offset, sbuf[data_idx]);
                }
            }
        }
    }while(0);

    return ret;
}

/**
 * @brief  根据端口链接号、接收的modbus协议寻找对应的从站协议
 * @param
 *
 * @return
 */
int32_t SearchProperProtocol(int32_t conn_id, MODBUS_PROTOCOL_T tmp_modbus, protocol_s **p_proper_protocol)
{
    int32_t ptl_search_ret = 0;
    int32_t search_result = 0;
    uint16_t ptl_id = 0 ;
    uint16_t modbus_transmit_dev = 0;   //搜索到的设备
    int32_t devSameType  = 0;
    BOOL isNeedCheckPtl = FALSE;

    protocol_s *p_tmp_ptl = NULL;
    int32_t ptl_num = 0;

    //查找协议和协议寻址表
    p_tmp_ptl = CommConn_GetProtocol(conn_id, 0);
    ptl_num = CommConn_GetProtocolNum(conn_id);
    modbus_transmit_dev = CommConn_SearchDev(conn_id, tmp_modbus.id);
    if (modbus_transmit_dev == MAX_DEV_CODE)
    {
        isNeedCheckPtl = TRUE; //如果没有找到devCode，再尝试根据ptl中寄存器地址范围寻找
    }

    for (ptl_id = 0; (ptl_id < ptl_num) && (p_tmp_ptl != NULL);)
    {
        if (modbus_transmit_dev != MAX_DEV_CODE && p_tmp_ptl->ptl_dev_code == modbus_transmit_dev)
        {
            devSameType = 1;
        }

        if ((devSameType == 1 || isNeedCheckPtl)
            &&
            (tmp_modbus.cmd == p_tmp_ptl->cmd || (((tmp_modbus.cmd == 0x06) || (tmp_modbus.cmd == 0x10)) && (p_tmp_ptl->cmd == 0x03))
                || (((tmp_modbus.cmd == 0x05) || (tmp_modbus.cmd == 0x0F)) && (p_tmp_ptl->cmd == 0x01))
            )
           )
        {
            //站号和地址类型符合
            if (((p_tmp_ptl->address + p_tmp_ptl->len) > (tmp_modbus.address + tmp_modbus.len))
                && (p_tmp_ptl->address - 1 <= (tmp_modbus.address)))
            {
                //地址符合范围
                *p_proper_protocol = p_tmp_ptl;
                search_result = 1;  //存在对应协议，协议地址符合

                break;
            }
            else
            {
                search_result = 2;   //存在对应协议，但协议地址不符合
            }
        }

        ptl_id++;
        p_tmp_ptl = CommConn_GetProtocol(conn_id, ptl_id);
    }

    if (0 == search_result)         //search_result == 0 没有查找合适的协议存在
    {
        //设备存在  没有查找合适的协议存在  作为寄存器地址越界
	   ptl_search_ret = CMD_ADDRESS_BEYOND;//寄存器地址非法
	   EMS_LOG(LL_ERROR, MODULE_T, FALSE, "cannot find ptl_search_ret   %d \n",ptl_search_ret);
    }
    else if (1 == search_result)    //search_result == 1 查找到合适的协议存在
    {
        //查找合适的协议存在
        ptl_search_ret = 0;
    }
    else if (2 == search_result)  //协议存在，地址不符合
    {
        ptl_search_ret = CMD_ADDRESS_BEYOND;      //寄存器地址非法
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "illegal addr, ptl_search_ret   %d \n",ptl_search_ret);
    }

    return ptl_search_ret;
}

/******************************************************************************
 * Function       : ModbusSlave
 * Author         :
 * Date           :
 * Description    : modbus从站数据解析,处理,回复
 * Calls          : None
 * Input          : buf: 接收报文, buflen:接收报文长度,fd:通信句柄
 * Output         : None
 * Return         : None
 *******************************************************************************/
int32_t ModbusRtuSlave (CLIENT_LINK_SLAVER_T *comm, uint8_t *inbuf, uint16_t inlen, uint8_t *sendbuf)
{
    int32_t rtu_ret = 0;
    int32_t cmd_ret = 0;
    int32_t data_check_result = 0;
    int32_t protocol_search_result = 0;
    uint32_t crcresult = 0;
    MODBUS_PROTOCOL_T modbus_data = { 0 };
    protocol_s *proper_protocol = NULL;
    int32_t conn_id = comm->comm_conn_id;

    data_check_result = AnalyModbusRtuSlaveData(inbuf, inlen, &modbus_data);  //写入modbus_data数据格式

    do
    {
        if (data_check_result < 0)
        {
            rtu_ret = data_check_result;
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "crc check error, data_check_result  %d \n", data_check_result);
            break;
        }
        else if (data_check_result > 0)  //length err
        {
            sendbuf[0] = modbus_data.id;
            sendbuf[1] = modbus_data.cmd | 0x80;
            sendbuf[2] = data_check_result;

            crcresult = getCRC16 (sendbuf, 3);

            sendbuf[3] = crcresult & 0xff;
            sendbuf[4] = (crcresult >> 8) & 0xff;

            comm->retnum = 5;
            rtu_ret = comm->retnum;

            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "length error, data_check_result  %d \n", data_check_result);
            break;
        }
        else if (data_check_result == 0)
        {
            protocol_search_result = SearchProperProtocol (conn_id, modbus_data, &proper_protocol);

            //设备不在
            if (protocol_search_result  < 0)
            {
                rtu_ret =  protocol_search_result;
                EMS_LOG(LL_ERROR, MODULE_T, FALSE, "protocol_search_result  %d \n", protocol_search_result);
                break;
            }
            else if (protocol_search_result > 0)   //寄存器地址不正确
            {
                sendbuf[0] = modbus_data.id;
                sendbuf[1] = modbus_data.cmd | 0x80;
                sendbuf[2] = protocol_search_result;
                crcresult = getCRC16 (sendbuf, 3);
                sendbuf[3] = crcresult & 0xff;
                sendbuf[4] = ( crcresult >> 8 ) &0xff;
                comm->retnum = 5;
                rtu_ret = comm->retnum;
                EMS_LOG(LL_ERROR, MODULE_T, FALSE, "protocol_search_result  %d \n", protocol_search_result);

                break;
            }
            else if (protocol_search_result == 0)  //寄存器地址正确
            {
                switch (modbus_data.cmd)
                {
                    case 0x03:
                    case 0x04:
                        cmd_ret = CreatePcPackage (modbus_data.id, &sendbuf[3], modbus_data.address, modbus_data.len, proper_protocol);

                        if (cmd_ret < 0)  // CreatePcPackage 错误  无需应答
                        {
                            rtu_ret = cmd_ret;
                            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "cmd_ret  %d \n", cmd_ret);
                        }

                        else if (cmd_ret == 0)
                        {
                            sendbuf[0] = modbus_data.id;
                            sendbuf[1] = modbus_data.cmd;
                            sendbuf[2] = modbus_data.len * 2;

                            crcresult = getCRC16(sendbuf, (modbus_data.len *2 + 3));

                            sendbuf[modbus_data.len *2 + 3] = crcresult & 0xff;
                            sendbuf[modbus_data.len *2 + 4] = (crcresult >> 8) & 0xff;

                            comm->retnum = modbus_data.len * 2 + 5;

                            rtu_ret = comm->retnum;
                        }
                        else
                        {
                            sendbuf[0] = modbus_data.id;
                            sendbuf[1] = modbus_data.cmd | 0x80;
                            sendbuf[2] = protocol_search_result;

                            crcresult = getCRC16(sendbuf, 3);

                            sendbuf[3] = crcresult & 0xff;
                            sendbuf[4] = (crcresult >> 8) & 0xff;

                            comm->retnum = 5;
                            rtu_ret =   comm->retnum;

                        }

                        break;

                    case 0x01:
                    case 0x02:
                    {
                        cmd_ret = SaveRunBitDataPack(modbus_data.id, &sendbuf[3], modbus_data.address, modbus_data.len, proper_protocol);
                        if (cmd_ret < 0) // SaveRunBitDataPack 错误 无需应答
                        {
                            rtu_ret = cmd_ret;
                            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "cmd_ret  %d \n", cmd_ret);
                        }

                        else if (cmd_ret == 0)
                        {
                            sendbuf[0] = modbus_data.id;
                            sendbuf[1] = modbus_data.cmd;

                            if ((modbus_data.len % 8) == 0)
                            {
                                sendbuf[2] = (modbus_data.len >> 3) & 0xFF;
                            }
                            else
                            {
                                sendbuf[2] = (modbus_data.len / 8) + 1;
                            }

                            crcresult = getCRC16(sendbuf, (sendbuf[2] + 3));
                            sendbuf[sendbuf[2] + 3] = crcresult & 0xff;
                            sendbuf[sendbuf[2] + 4] = (crcresult >> 8) & 0xff;
                            comm->retnum = sendbuf[2] + 5;

                            rtu_ret = comm->retnum;
                        }
                        else
                        {
                            sendbuf[0] = modbus_data.id;
                            sendbuf[1] = modbus_data.cmd | 0x80;
                            sendbuf[2] = cmd_ret;

                            crcresult = getCRC16(sendbuf, 3);

                            sendbuf[3] = crcresult & 0xff;
                            sendbuf[4] = (crcresult >> 8) & 0xff;

                            comm->retnum = 5;
                            rtu_ret = comm->retnum;
                        }
                        break;

                    }
                    case 0x05:
                    case 0x06:
                    case 0x10:
                    {
                        cmd_ret = revCmdPro(modbus_data.id, modbus_data.data,
                                                modbus_data.address, modbus_data.len, proper_protocol); //,retcomm);

                        if (cmd_ret < 0) // revCmdPro 错误 或者 广播指令 无需应答
                        {
                            rtu_ret = cmd_ret;
                            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "cmd_ret  %d \n", cmd_ret);
                        }
                        else if (cmd_ret == 0)
                        {
                            sendbuf[0] = modbus_data.id;
                            sendbuf[1] = modbus_data.cmd;
                            sendbuf[2] = (uint8_t)(modbus_data.address >> 8);
                            sendbuf[3] = (uint8_t)(modbus_data.address & 0xff);
                            sendbuf[4] = inbuf[4];
                            sendbuf[5] = inbuf[5];

                            crcresult = getCRC16(sendbuf, 6);

                            sendbuf[6] = crcresult & 0xff;
                            sendbuf[7] = (crcresult >> 8) & 0xff;

                            comm->retnum = 8;

                            rtu_ret = comm->retnum;
                        }
                        else if (cmd_ret > 0)
                        {
                            sendbuf[0] = modbus_data.id;
                            sendbuf[1] = modbus_data.cmd | 0x80;
                            sendbuf[2] = cmd_ret;

                            crcresult = getCRC16(sendbuf, 3);

                            sendbuf[3] = crcresult & 0xff;
                            sendbuf[4] = (crcresult >> 8) &0xff;

                            comm->retnum = 5;

                            rtu_ret = comm->retnum;
                        }
                        break;
                    }
                    default:
                        break;
                }
            }
        }
    }while ( 0 );

    return rtu_ret;
}

/******************************************************************************
 * Function       : ModbusSlave
 * Author         :
 * Date           :
 * Description    : modbus从站数据解析,处理,回复
 * Calls          : None
 * Input          : buf: 接收报文, buflen:接收报文长度,fd:通信句柄
 * Output         : None
 * Return         : None
 *******************************************************************************/
int32_t ModbusTcpSlave(CLIENT_LINK_SLAVER_T *comm, uint8_t *inbuf, uint16_t inlen, uint8_t *sendbuf )
{
    int32_t tcp_ret = 0;
    int32_t cmd_ret = 0;
    int32_t data_check_result = 0;
    int32_t protocol_search_result = 0;

    MODBUS_PROTOCOL_T modbus_data = { 0 };
    protocol_s *proper_protocol = NULL;

    int32_t conn_id = comm->comm_conn_id;
    data_check_result = AnalyModbusTcpSlaveData(inbuf, inlen, &modbus_data);

    memcpy(sendbuf, inbuf, 6);

    do
    {
        if (data_check_result < 0)
        {
            tcp_ret = data_check_result;
            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "data_check_result  %d \n", data_check_result);
            break;
        }
        else if (data_check_result > 0)
        {
            sendbuf[4] = 0;
            sendbuf[5] = 3;

            sendbuf[6] = inbuf[6];
            sendbuf[7] = inbuf[7] | 0x80;
            sendbuf[8] = tcp_ret;

            comm->retnum = 9;

            tcp_ret = comm->retnum;

            break;
        }
        else if (data_check_result == 0)
        {
            protocol_search_result = SearchProperProtocol(conn_id, modbus_data, &proper_protocol);

            if (protocol_search_result  < 0)
            {
                tcp_ret = protocol_search_result;
                EMS_LOG(LL_ERROR, MODULE_T, FALSE, "protocol_search_result  %d \n", protocol_search_result);
                break;

            }
            else if (protocol_search_result > 0)
            {
                sendbuf[4] = 0;
                sendbuf[5] = 3;

                sendbuf[6] = inbuf[6];
                sendbuf[7] = inbuf[7] | 0x80;
                sendbuf[8] = protocol_search_result;

                comm->retnum = 9;
                tcp_ret = comm->retnum;

                break;

            }
            else if (protocol_search_result == 0)
            {
                switch (modbus_data.cmd)
                {
                    case 0x03:
                    case 0x04:
                    {
                        cmd_ret = CreatePcPackage(modbus_data.id, &sendbuf[9], modbus_data.address, modbus_data.len, proper_protocol);

                        if (cmd_ret < 0)
                        {
                            tcp_ret = cmd_ret;
                            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "cmd_ret  %d \n", cmd_ret);
                        }
                        else  if (cmd_ret == 0)
                        {
                            sendbuf[4] = ((modbus_data.len *2+3) >> 8 ) & 0xFF;
                            sendbuf[5] = (modbus_data.len *2+3 ) & 0xFF;
                            sendbuf[6] = modbus_data.id;
                            sendbuf[7] = modbus_data.cmd;
                            sendbuf[8] = modbus_data.len * 2;
                            comm->retnum = 9 + modbus_data.len * 2;

                            tcp_ret = comm->retnum;

                        }
                        else if (cmd_ret > 0)
                        {
                            sendbuf[4] = 0;
                            sendbuf[5] = 3;
                            sendbuf[6] = inbuf[6];
                            sendbuf[7] = inbuf[7] | 0x80;
                            sendbuf[8] = cmd_ret;
                            comm->retnum = 9;

                            tcp_ret = comm->retnum;
                        }
                        break;
                    }
                    case 0x01:
                    case 0x02:
                    {
                        cmd_ret = SaveRunBitDataPack (modbus_data.id, &sendbuf[9], modbus_data.address, modbus_data.len, proper_protocol);
                        if (cmd_ret < 0) // SaveRunBitDataPack 错误 无需应答
                        {
                            tcp_ret = cmd_ret;
                            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "cmd_ret  %d \n", cmd_ret);
                        }
                        else if (cmd_ret == 0)
                        {
                            uint32_t dataLen = 0;

                            dataLen = (modbus_data.len % 8 == 0) ? ((modbus_data.len >> 3) & 0xFF) : (modbus_data.len / 8 + 1);

                            sendbuf[4] = (((3 + dataLen) >> 8) & 0xFF);
                            sendbuf[5] = ((3 + dataLen) & 0xFF);
                            sendbuf[6] = modbus_data.id;
                            sendbuf[7] = modbus_data.cmd;
                            sendbuf[8] = dataLen;

                            comm->retnum = 9 + dataLen;

                            tcp_ret = comm->retnum;
                        }
                        else
                        {
                            sendbuf[6] = modbus_data.id;
                            sendbuf[7] = modbus_data.cmd | 0x80;
                            sendbuf[8] = cmd_ret;

                            comm->retnum = 9;
                            tcp_ret = comm->retnum;
                        }
                        break;

                    }
                    case 0x06:
                    case 0x10:
                    {
                        cmd_ret = revCmdPro(modbus_data.id, modbus_data.data, modbus_data.address, modbus_data.len, proper_protocol);

                        if (cmd_ret < 0)
                        {
                            tcp_ret = cmd_ret;
                            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "cmd_ret  %d \n", cmd_ret);
                        }
                        else if (cmd_ret == 0)
                        {
                            sendbuf[4] = 0;
                            sendbuf[5] = 6;

                            sendbuf[6] = modbus_data.id;
                            sendbuf[7] = modbus_data.cmd;
                            sendbuf[8] = inbuf[8];
                            sendbuf[9] = inbuf[9];
                            sendbuf[10] = inbuf[10];
                            sendbuf[11] = inbuf[11];

                            comm->retnum = 12;

                            tcp_ret = comm->retnum;

                        }
                        else if (cmd_ret > 0)
                        {
                            sendbuf[4] = 0;
                            sendbuf[5] = 3;
                            sendbuf[6] = inbuf[6];
                            sendbuf[7] = inbuf[7] | 0x80;
                            sendbuf[8] = cmd_ret;
                            comm->retnum = 9;
                            tcp_ret = comm->retnum;
                        }
                        break;
                    }
                    case 0x05:
                    case 0x0F:
                    {
                        cmd_ret = WriteRunBitData(modbus_data.id, modbus_data.data, modbus_data.address, modbus_data.len, proper_protocol, modbus_data.cmd);

                        if (cmd_ret < 0)
                        {
                            tcp_ret = cmd_ret;
                            EMS_LOG(LL_ERROR, MODULE_T, FALSE, "cmd_ret  %d \n", cmd_ret);
                        }
                        else if (cmd_ret == 0)
                        {
                            sendbuf[4] = 0;
                            sendbuf[5] = 6;

                            sendbuf[6] = modbus_data.id;
                            sendbuf[7] = modbus_data.cmd;
                            sendbuf[8] = inbuf[8];
                            sendbuf[9] = inbuf[9];
                            sendbuf[10] = inbuf[10];
                            sendbuf[11] = inbuf[11];

                            comm->retnum = 12;

                            tcp_ret = comm->retnum;

                        }
                        else if (cmd_ret > 0)
                        {
                            sendbuf[4] = 0;
                            sendbuf[5] = 3;
                            sendbuf[6] = inbuf[6];
                            sendbuf[7] = inbuf[7] | 0x80;
                            sendbuf[8] = cmd_ret;
                            comm->retnum = 9;
                            tcp_ret = comm->retnum;
                        }
                        break;
                    }
                    default:
                        break;
                }
            }
        }
    }while ( 0 );

    return tcp_ret;
}

/**
 * @brief  查找对应fd,函数调用.
 * @param
 *
 * @return
 */
int32_t RevProcess(int32_t fd, uint8_t *inbuf, int32_t inlen, uint8_t *sendbuf)
{
    CLIENT_LINK_SLAVER_T *pTmpObj = g_CommReg.comm_L->next;
    int32_t ret = 0;
    int32_t revRet = 0;
    int32_t i = 0;

    for (i = 0; i < g_CommReg.num; ++i)
    {
        if (fd == pTmpObj->link_fd)
        {
            CommObjFunc func = CommConn_GetFunc(pTmpObj->comm_conn_id);
            if (func != NULL)
            {
                memset(pTmpObj->retbuf, 0, sizeof(uint8_t) * BUFLEN);
                ret = func(pTmpObj, inbuf, inlen, pTmpObj->retbuf);

                if (ret < 0)
                {
                    revRet = ret;
                }
                else
                {
                    memcpy(sendbuf, pTmpObj->retbuf, pTmpObj->retnum);
                    revRet = pTmpObj->retnum;
                }
            }

            break;
        }
        pTmpObj = pTmpObj->next;
    }

    return  revRet ;
}
