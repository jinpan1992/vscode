#ifndef COMRECEIVE_H
#define COMRECEIVE_H

#include <linux/ioctl.h>
#include "common.h"
#include "transmit_conf.h"
#include "CommConnObj.h"

void InitClearRxBufData (int RxNum);
void PutRxBufData (uint8_t *buf, int32_t len, int32_t RxNum);
void GetRxBufData (uint8_t *buf, int32_t RxNum);
int32_t GetRxBufDataLen (int32_t RxNum);

typedef struct COMRXBUFFER
{
    uint32_t RxBufHead;
    uint32_t RxBufTail;
    uint8_t RxBuf[COMRXBUFMAXLEN];
} comRxBuffer;

//串口端口链接对象结构体
typedef struct   COMMSERIALTYPE
{
    int32_t com_type;
    uintptr_t serial_fd;      //文件句柄标
    int32_t comm_conn_id;     //端口 绑定 id
    int32_t uartBaudrate;
} COMMSERIALTYPE;

extern comRxBuffer comRxBuf[ ];
extern int32_t comRxBufNum;

struct serial_rs485
{
    uint32_t flags;                                      /* RS485 feature flags */
#define SER_RS485_ENABLED               (1 << 0)         /* If enabled */
#define SER_RS485_RTS_ON_SEND           (1 << 1)         /* Logical level for RTS pin when sending */

#define SER_RS485_RTS_AFTER_SEND        (1 << 2)         /* Logical level for RTS pin after sent*/
#define SER_RS485_RX_DURING_TX          (1 << 4)
    uint32_t delay_rts_before_send;                      /* Delay before send (milliseconds) */
    uint32_t delay_rts_after_send;                       /* Delay after send (milliseconds) */
    uint32_t padding[5];                                 /* Memory is cheap, new structs are a royal PITA .. */
};

int32_t UartInit(void);

int32_t InsertSerialNode(CommConnObj *pCommConn, int32_t comm_id);

void SerialDataRecvProcess(const uintptr_t *p_conn_fd);

int32_t SerialNoblockDataProcess(int32_t fd, uint8_t inbuf[1024 * 4 + 1], int32_t readptr, int32_t uartBaudrate);

#endif
