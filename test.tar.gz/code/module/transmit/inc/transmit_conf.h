#ifndef TRANSMIT_CONF_H_INCLUDED
#define TRANSMIT_CONF_H_INCLUDED

//单个网口最多支持端口号数量
#define MAXNETPORTNUM (int32_t)5
//网口数量
#define MAX_NET_INTERFACES 2
#define MAX_SERVER_LINK_NUM (MAXNETPORTNUM * MAX_NET_INTERFACES)
#define MAX_EVENTS 1020

//端口下挂设备数量
#define MAX_COM_DEV_NUM (int32_t)202

//最大客户端链接数量
#define MAX_CLINET_LINK_NUM (int32_t)1020

#define BUFLEN  (int32_t)1024*10+1

#define MAX_SERIAL_PROT_FD_NUM (int32_t)10
#define COMRXBUFMAXN (int32_t)10                //串口接收缓冲区个数
#define COMRXBUFMAXLEN (int32_t)1024+1024       //串口接收队列缓冲区大小
#define MAX_REV_LEN   (int32_t)1024+1024
#define MAXCOMRXLEN (int32_t)1024

//对转发的设备使用统一的从机地址
#define UNIFY_TRANSMIT_MODBUS_SLAVE_ID (int32_t)1

//MQTT 配置参数
#define MQTTCONFIGFILEPATH "/home/SGComm/conf/transmit/MQTTConfig.xml"
#endif // TRANSMIT_CONF_H_INCLUDED
