#ifndef COMMCONNOBJ_H_INCLUDED
#define COMMCONNOBJ_H_INCLUDED

#include "common.h"
#include "xml_analysis.h"
#include "protocol_operate.h"
#include "sdb.h"
#include "err.h"

typedef int32_t (*CommObjFunc) (struct client_link_slaver_st *, uint8_t *, uint16_t , uint8_t *);

typedef struct SLAVE_CORRESPOND_INDEX  //modbus 地址 对应包含的l类型设备序号
{
    int32_t modbus_id;               //modbus地址
    int32_t slaveIndex;              //对应设备索引
    int32_t dwMaxAddr;               //最大寄存器地址
    int32_t dwMinAddr;               //最小寄存器地址
} slaver_corr_index;

typedef struct SLAVER_CONFIG_CONTENT
{
    char dev_type_name[32];                         //中功率 或者 大功率设备总类型名称  中功率设备SG_STRING_INV
    char dev_name[MAX_DEV_NAME_LEN];                //具体设备名称
    uint8_t slave_flag ;                            //设备对应关系初始化 完成标志
    int32_t max_data_id ;                           //同类设备中的最大设备id节点
    uint16_t dev_code;                              //设备类型
    int32_t slave_id_cor_num;                       //同类型设备数量
    slaver_corr_index *p_slaver_corr_index_arr;     //modbus 地址 对应包含的l类型设备序号
} slave_device_config_content;                      //设备配置对应内容

//客户端对象
typedef struct CommObj_st
{
    int32_t protocolNum;                    //协议个数
    protocol_s *p_comm_ptl[PROTOCOLNUM];    //通信协议指针
} CommObj_s;

//端口链接对象结构体
typedef struct CommConn_Obj
{
    CommObj_s comm_protocol_gather;                                         //设备类型对象协议合集
    int32_t mbm_slaver_num;                                                  //端口链接对象下的slaver 的设备总数
    slave_device_config_content *p_mbm_slaver_config[MAX_COM_DEV_NUM];       //最多下挂十个设备
    uintptr_t comm_obj_fd;                                                   //端口链接文件句柄标识    此处用于串口标识 网口存在多客户端情况
    int32_t cmm_case_id;                                                     //串口 网口  id
    int32_t comm_case_lcd_flag;                                              //端口类型 是否为 lcd 触摸屏接口
    int32_t cmm_type;                                                        //端口类型
    comport_s  comdev;                                                       //端口属性 串口和 网口
    CommObjFunc func;                                                        //函数回调
    struct CommConnObj *next;                                                //单链表指针
    BOOL isUseUnifySlaveID;                                                  //端口链接对象下的设备是否使用统一的从机地址
} CommConnObj;

/////////////////////////////////////////////Global Protocal////////////////////////////////////////////////////////////////
/**
 * @brief  将设备协议添加到全局协议区
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t GlobalProtocol_Add(PROTOCOL_T *pPtl);

/**
 * @brief  清除全局协议区
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t GlobalProtocol_Clear();

/**
 * @brief  通信协议MAP初始化
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t GlobalProtocol_CreateMap();

/**
 * @brief  获取dataId 对应的测点信息
 * @param
 *
 * @return 失败返回NULL
 */
protocol_data_s* GlobalProtocol_GetPD(int32_t dwDevCode, int32_t dwDataId);

/////////////////////////////////////////////SlaveDevice////////////////////////////////////////////////////////////////////
/**
 * @brief  设备类型对象创建
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t SlaveDevice_Create(int32_t dwSlaverNum);

/**
 * @brief  设备类型对象销毁
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t SlaveDevice_Destroy();

/**
 * @brief  获取设备类型对象
 * @param
 *
 * @return
 */
slave_device_config_content* SlaveDevice_Get(int32_t dwIndex);

/**
 * @brief  获取设备类型对象数量
 * @param
 *
 * @return
 */
int32_t SlaveDevice_GetNum();

int32_t SlaveDevice_GetDevCode(int32_t dwIndex);

int32_t SlaveDevice_GetMaxDataId(int32_t dwIndex);

int32_t SlaveDevice_GetCorNum(int32_t dwIndex);

int32_t SlaveDevice_SetDevCode(int32_t dwIndex, int32_t dwDevCode);

int32_t SlaveDevice_SetDevName(int32_t dwIndex, char *pcDevName);

int32_t SlaveDevice_SetDevTypeName(int32_t dwIndex, char *pcDevTypeName);

/**
 * @brief  为设备类型添加设备
 * @param
 *
 * @return
 */
int32_t SlaveDevice_SetDev(int32_t dwDevCode, slaver_corr_index *pDev, int32_t dwDevNum);

/**
 * @brief  对某种类型设备设置max data id
 * @param
 *
 * @return
 */
int32_t SlaveDevice_SetMaxDataId(int32_t dwDevCode, int32_t dwMaxDataId);

slave_device_config_content* SlaveDevice_Find(int32_t dwDevCode);

/**
 * @brief  根据modbus slave id 找到设备index
 * @param
 *
 * @return
 */
int32_t SlaveDevice_SearchSlaveIdCorrespondingIndex(int32_t dwModbusSlaveId, int32_t dwDevCode);

/**
 * @brief  根据modbus slave id、address 找到设备index
 * @param
 *
 * @return
 */
int32_t SlaveDevice_SearchSlaveId(int32_t dwModbusSlaveId, int32_t dwDevCode, int32_t address);

/////////////////////////////////////////////////CommConn/////////////////////////////////////////////////////////////
int32_t CommConn_Init(int32_t dwCommNum);

int32_t CommConn_UnInit();

CommConnObj* CommConn_GetObj(int32_t dwObjIndex);

/**
 * @brief  设置端口链接对象类型（网口、串口）
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t CommConn_SetType(int32_t dwObjIndex, COMM_TYPE_SHOW_E dwCOMMType);

/**
 * @brief  设置端口链接对象id（网口、串口 id）
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t CommConn_SetCommId(int32_t dwObjIndex, int32_t dwCommId);

/**
 * @brief  设置端口链接对象端口属性
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t CommConn_SetCommPortAttr(int32_t dwObjIndex, comport_s *pComPortAttr);

/**
 * @brief  设置端口链接对象函数回调
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t CommConn_SetProcFunc(int32_t dwObjIndex, COMM_TYPE_SHOW_E eType);

/**
 * @brief  设置端口链接对对象下挂的设备以及配置
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t CommConn_SetSlaverConfig(int32_t dwObjIndex, int32_t dwConfigIndex, slave_device_config_content *pSlaverConfig);

/**
 * @brief  端口链接对对象下挂的设备数量
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t CommConn_SetSlaverNum(int32_t dwObjIndex, int32_t dwSlaverNum);

/**
 * @brief
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t CommConn_SetFd(int32_t dwObjIndex, uintptr_t dwFd);

/**
 * @brief
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t CommConn_SetUnifyFlag(int32_t dwObjIndex, BOOL isUsed);

/**
 * @brief  获取端口链接对象数目
 * @param
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t CommConn_GetObjNum();

/**
 * @brief  获取端口对象
 * @param
 *
 * @return
 */
CommObj_s* CommConn_GetCommObj(int32_t dwObjIndex);

/**
 * @brief  获取端口链接对象协议
 * @param
 *
 * @return
 */
protocol_s* CommConn_GetProtocol(int32_t dwObjIndex, int32_t dwPtlId);

/**
 * @brief  获取端口链接对象协议数目
 * @param
 *
 * @return
 */
int32_t CommConn_GetProtocolNum(int32_t dwObjIndex);

/**
 * @brief  获取端口链接对象串口/网口号
 * @param
 *
 * @return
 */
int32_t CommConn_GetPortId(int32_t dwObjIndex);

/**
 * @brief  获取端口链接对象端口属性
 * @param
 *
 * @return
 */
const comport_s* CommConn_GetPortAttr(int32_t dwObjIndex);

/**
 * @brief  获取端口链接对象端口类型
 * @param
 *
 * @return
 */
int32_t CommConn_GetType(int32_t dwObjIndex);

/**
 * @brief  获取端口链接对象处理函数
 * @param
 *
 * @return
 */
CommObjFunc CommConn_GetFunc(int32_t dwObjIndex);

/**
 * @brief  添加端口链接对象协议
 * @param
 *
 * @return max_data_id  同设备编码中最大的数据id
 */
int32_t CommConn_AddProtocol(int32_t dwObjIndex, int32_t dwDevCode);

/**
 * @brief  清除链接对象下挂的设备以及配置
 * @param
 *
 * @return
 */
int32_t CommConn_ClearSlaverConfig();

/**
 * @brief  清除链接对象协议集合
 * @param
 *
 * @return
 */
int32_t CommConn_ClearProtocol();

/**
 * @brief  获取设备类型支持的从机modbus_slave_id,
 * @param
 *
 * @return 0  或 设备类型
 */
int16_t CommConn_SearchDev(int32_t dwObjIndex, int32_t dwModbusSlaveId);

int32_t g_CommConnNum;                              //串口网口 对象 数量
extern CommConnObj *g_pComConn;                     //端口链接对象结构体指针
extern int32_t g_CommLcdFlag;                       //大功率触摸屏标记
extern int32_t g_ProtocolNum;                       //协议个数
extern protocol_s g_protocol[];                     //通信协议
#endif // COMMCONNOBJ_H_INCLUDED
