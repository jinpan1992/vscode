#ifndef TRANSMIT_H_INCLUDED
#define TRANSMIT_H_INCLUDED
#include <stdint.h>
#include "common.h"
#include "err.h"
#include "GlobalData.h"

uintptr_t Transmitor_Create(void);
int32_t Transmitor_Start();
int32_t Transmitor_Destroy(uintptr_t handle);

int32_t WritePointCommand(int32_t value, uint16_t deviceCode, uint16_t index, uint16_t dataId);
#endif
