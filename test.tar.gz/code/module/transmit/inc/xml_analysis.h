#ifndef XML_CSV_H
#define   XML_CSV_H

#include "common.h"

#define COM_LCD 1   //接入lcd串口
#define COM_PC  0   //接入pc串口

//通信连接类型
typedef enum
{
    COMTYPE = 1,    //串口设备
    NETTYPE,        //网络设备
} COMM_TYPE_SHOW_E;

//网口接口属性
typedef struct
{
    char allow_ip[30];            //允许链接ip地址
    uint16_t netport;             //端口号
    uint16_t allow_all_flag;      //允许链接所有ip地址请求标记
    uint16_t max_allow_link_num;  //允许最大的链接数量
} net_port_attr;

//端口属性
typedef struct
{
    int32_t commtype;             //端口类型
    int32_t commdef;              //LCD 设置标记  兼容大功率标记
    int32_t uartid;               //串口号
    int32_t uartbaudrate;         //波特率
    int32_t uartdatabit;          //串口数据位
    char uartstopbit[4];          //停止位
    char uartparity;              //校验位

    uint16_t net_id;               //网口号
    uint8_t net_port_num;          //端口号个数
    net_port_attr port_attr[5];    //端口号
} comport_s;

//通信协议点表
typedef struct protocol_data_st
{
    char data_name[100];       //数据名称
    uint16_t data_id;          //数据id
    uint32_t data_address;     //寄存器地址
    uint8_t data_byte_num;     //数据类型
    char data_info[20];
    uint8_t data_type;         //数据类型     i     F
    uint8_t data_sign;         //数据正负  U   S
    float scale_coefficient;   //比例系数

    int32_t low_limit1;         //下限
    int32_t high_limit1;        //上限
    int32_t low_limit2;         //下限
    int32_t high_limit2;        //上限

    uint32_t low_limit1_uint;  // 无符号下限
    uint32_t high_limit1_uint; //无符号上限
    uint32_t low_limit2_uint;  //无符号下限
    uint32_t high_limit2_uint; //无符号上限

    char func_Rev[30];         //数据处理函数
    char func_Send[30];        //数据处理函数
    char func_Fifo[30];        //数据处理函数

} protocol_data_s;

//点表属性
typedef struct
{
    uint16_t ptl_dev_code;          //协议唯一编号 ,类型的设备编号
    uint32_t max_ptl_data_id;       //点表最大数据id
    uint8_t cmd;                    //寄存器类型
    uint32_t address;               //起始地址
    uint32_t len;                   //长度
    protocol_data_s *protocol_data; //点表起始地址
    uint16_t ptl_data_num;
    uint32_t *map;                  //点表映射表	协议寄存器地址-点表序号
    uint8_t protocol_byte;          //字节序
    uint8_t protocol_word;          // 字序

    int32_t ptl_min_addr;
    int32_t ptl_max_addr;
} protocol_s;

/**
 * @brief  XML文件读取
 * @param  configfilePATH xml文件路径
 *
 * @return
 */
int32_t SysConfigContentInit (char* configfilePATH);

/**
 * @brief  获取所有下挂设备协议，填充全局协议变量
 * @param
 *
 * @return
 */
void GetAllSlaverAndProtocol();

/**
 * @brief  MQTT配置读取
 * @param
 *
 * @return
 */
int32_t ParseMqttConfig(char* configfilePATH, void *northMqtt);

#endif
