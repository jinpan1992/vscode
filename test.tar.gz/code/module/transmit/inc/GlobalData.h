#ifndef DATA_PROCESS_H
#define DATA_PROCESS_H

#include "common.h"
#include "err.h"

int32_t DistributeDevGdata(void);
int32_t GdataFill(DEV_DATA_T *devData, uint32_t num);

/**
 * @brief  获取测点数据类型和值
 * @param  dwDataType == -1，表示依据协议类型和精度来取值
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t GdataFetch(INOUT VALUE_INFO_T *pValueInfo, IN uint16_t deviceCode, IN uint16_t index, IN uint16_t dataId, IN int32_t dwDataType);
int32_t ReadPointData(int32_t *dataOut, uint16_t deviceCode, uint16_t index, uint16_t dataId);
int32_t WritePointData(int32_t value, uint16_t deviceCode, uint16_t index, uint16_t dataId);
int32_t FreeDevGdata(void);

void PrintBuf(int32_t arr_len, char *in_buf, int32_t in_fd, int32_t int_out_direction);

#endif
