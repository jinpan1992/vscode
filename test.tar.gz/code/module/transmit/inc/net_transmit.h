#ifndef _NET_TRANSMIT_H
#define _NET_TRANSMIT_H

#include "protocol_operate.h"
#include "CommConnObj.h"

#define READ_FD_MAX_LEN (int32_t)4104
#define SEND_FD_MAX_LEN (int32_t)4104

//网络端口链接对象结构体
typedef struct comm_net_type_t
{
    uint16_t link_flag;
    int32_t com_type;
    int32_t server_fd;
    int32_t comm_conn_id;                       //网口id
    char allow_ip[30];
    uint16_t allow_all_flag;
    int32_t client_num;
    int32_t client_link[MAX_CLINET_LINK_NUM];   //客户端句柄
} COMM_NET_TYPE_T;

int32_t NetServer_Init();
int32_t NetServer_Start();
int32_t NetServer_Stop();
int32_t NetServer_Restart();
BOOL NetServer_IsRuning();

#endif
