#ifndef PROTOCOL_H_
#define PROTOCOL_H_
#include <stdint.h>
#include "common.h"
#include "transmit_conf.h"
#include "xml_analysis.h"

#define DATA_TOTEL  1024

//端口链接对象结构体
typedef struct   client_link_slaver_st
{
    int32_t comm_type;                      //设备链接端口类型
    int32_t link_fd;	                    //文件句柄标
    int32_t comm_conn_id;                   //端口绑定 id
    uint32_t retnum;	                    //处理结果数据个数
    uint8_t retbuf[BUFLEN];                 //处理结果数据
    struct client_link_slaver_st *next;     //单链表指针
} CLIENT_LINK_SLAVER_T;

//数据处理客户端结构体
typedef struct
{
    CLIENT_LINK_SLAVER_T *comm_L;       //客户端数据处理链表头
    CLIENT_LINK_SLAVER_T *end;          //客户端数据处理链表尾
    int32_t num;                        //客户端数量
} COMM_REG_T;

int32_t ModbusRtuSlave(CLIENT_LINK_SLAVER_T* comm, uint8_t* inbuf, uint16_t inlen, uint8_t* sendbuf);
int32_t ModbusTcpSlave (CLIENT_LINK_SLAVER_T *comm, uint8_t *inbuf, uint16_t inlen,uint8_t *sendbuf);
int32_t RevProcess(int32_t fd, uint8_t *inbuf, int32_t inlen, uint8_t *sendbuf);

int32_t CreateComm(void);
int32_t InsertComm(int32_t fd, int32_t comm_conn_id, COMM_TYPE_SHOW_E commType);
int32_t DeleteComm(int32_t del_fd);

extern COMM_REG_T g_CommReg;

#endif
