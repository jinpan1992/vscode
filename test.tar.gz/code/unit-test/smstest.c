#include <stdio.h>
#include "sms4.h"

int main(void) {
    //加密参数初始化
    sms4_key_t sms4_key_enc;
    unsigned char plain_text[1024];
    unsigned char enc_text[1024];
    unsigned char key[] = "1234567890123456";
    unsigned char iv[] = "asdfghjklzxcvbnm";

    //uint32_t buffer[8] = {0x01234567, 0x89ABCDEF, 0xFEDCBA98, 0x76543210, 0x10101010, 0x10101010, 0x10101010, 0x10101010};
    uint32_t buffer[4] = {0x01234567, 0x89ABCDEF, 0xFEDCBA98, 0x76543210};
    //uint32_t buffer[3] = {0x01234567, 0x89ABCDEF, 0xFEDCBA98};

    //SM4加密
    memset(sms4_key_enc.rk, 0, sizeof(sms4_key_enc.rk));
    sms4_set_encrypt_key(&sms4_key_enc, key);
    size_t outLen = sms4_cbc_encrypt((const unsigned char*)buffer, enc_text, 16, &sms4_key_enc, iv, 1);
	printf("enc_text:%zu\n", outLen);
    int i = 0;
	for (i = 0; i < outLen; i++)
	{
		printf("%d ", enc_text[i]);
	}
	printf("\n");

    //SM4解密
    unsigned char iv_dec[] = "asdfghjklzxcvbnm";
    sms4_key_t sms4_key_decrypt;
    memset(sms4_key_decrypt.rk, 0, sizeof(sms4_key_decrypt.rk));
    sms4_set_decrypt_key(&sms4_key_decrypt, key);
    outLen = sms4_cbc_encrypt(enc_text, plain_text, 32, &sms4_key_decrypt, iv_dec, 0);
	printf("plain_text:%zu\n", outLen);
	for (i = 0; i < outLen; i++)
	{
		printf("0x%x ", plain_text[i]);
	}
	printf("\n");


    return 0;
}
