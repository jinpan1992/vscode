#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include "modbus.h"
#include "modbus_tcp.h"
#include "protocol.h"

/*00 01 00 00 00 06 01 03 0A 0C 00 02

* 00 01 00 00 00 07 01 03 04 00 06 00 08
*/
#if 1
static int g_sock;
static uint16_t g_metaid = 0;
char *configPath = "./SG_OTHER_HYPLC_Modbus_Test.xml";
char *configPath1 = "./SG_OTHER_HYACDC_Modbus_Test.xml";
char *configPath2 = "./SG_OTHER_CHARGE_Modbus.xml";
SLIST_T *cmdList;

static int32_t TcpSetIpv4Option(int32_t s)
{
    int32_t rc;
    int32_t option;

    /* Set the TCP no delay flag */
    /* SOL_TCP = IPPROTO_TCP */
    option = 1;
    rc = setsockopt(s, IPPROTO_TCP, TCP_NODELAY,
                    (const void *)&option, sizeof(int));
    if (rc == -1) {
        return -1;
    }

    /**
     * Cygwin defines IPTOS_LOWDELAY but can't handle that flag so it's
     * necessary to workaround that problem.
     **/
    /* Set the IP low delay option */
    option = IPTOS_LOWDELAY;
    rc = setsockopt(s, IPPROTO_IP, IP_TOS,
                    (const void *)&option, sizeof(int));
    if (rc == -1) {
        return -1;
    }

    return 0;
}

int32_t TcpConnect(char *ip, int port)
{
    int32_t rc;
    struct sockaddr_in addr;

    g_sock = socket(PF_INET, SOCK_STREAM, 0);
    if (g_sock == -1) {
        return -1;
    }

    rc = TcpSetIpv4Option(g_sock);
    if (rc == -1) {
        close(g_sock);
        return -1;
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);

    printf("%s port:%d s_addr:%d\n", __FUNCTION__, addr.sin_port, addr.sin_addr.s_addr);
    rc = connect(g_sock, (struct sockaddr *)&addr, sizeof(struct sockaddr));

    printf("%s sock:%d connect ret:%d\n", __FUNCTION__, g_sock, rc);

    if (rc == -1) {
        close(g_sock);
        return -1;
    }

    return 0;
}

uint32_t GetTableCountFromXml(char *configfilePATH)
{
    xmlDocPtr doc;
    xmlNodePtr curNode;
    xmlNodeSetPtr nodeset;
    xmlXPathObjectPtr result;
    xmlXPathContextPtr context;
    char *szDocName;
    uint32_t protocol_num = 0;
    szDocName = configfilePATH;


    doc = xmlReadFile(szDocName,"UTF-8",XML_PARSE_RECOVER);
    if (NULL == doc)
    {
        printf("%sDocument not parsed successfully.\n",szDocName);
        xmlFreeDoc(doc);
        return -1;
    }

    curNode = xmlDocGetRootElement(doc);
    if (NULL == curNode)
    {
        printf("modbusmaster_xml no root!\n");
        xmlFreeDoc(doc);
        return -1;
    }
    context = xmlXPathNewContext(doc);
    xmlChar *xpath = (xmlChar *)"/root/protocol/table";

    result = xmlXPathEvalExpression(xpath, context);
    if (result)
    {
        nodeset = result->nodesetval;
        if (nodeset->nodeNr)
        {
            protocol_num = nodeset->nodeNr;
        }
    }
    xmlXPathFreeObject(result);

    xmlXPathFreeContext(context);


    xmlFreeDoc(doc);
    return protocol_num;
}


uint32_t ParseProtocalFromXml(char *configfilePATH, PROTOCOL_T *pProtocol)
{
    xmlDocPtr doc;
    xmlNodePtr curNode, Node1, Node2, Node3;
    xmlNodeSetPtr nodeset;
    xmlXPathObjectPtr result;
    xmlXPathContextPtr context;
    char *szDocName;
    uint32_t point_num = 0;
    uint32_t total_point_num = 0;
    uint32_t i = 0;
    uint8_t tableid = 0;
    uint8_t tablecmd = 0;
    int32_t index_id = 0;
    szDocName = configfilePATH;
    PROTOCOL_DATA_T *protocol_data = NULL;
    uint16_t dev_code;
    uint8_t ptl_type;                   //协议类型
    uint8_t byte_seq;                   //字节序号
    uint8_t word_seq;                   //字序号

    doc = xmlReadFile(szDocName,"UTF-8", XML_PARSE_RECOVER);
    if (NULL == doc)
    {
        printf("%s Document not parsed successfully.\n", szDocName);
        xmlFreeDoc(doc);
        return -1;
    }

    curNode = xmlDocGetRootElement(doc);
    if (NULL == curNode)
    {
        printf("no root!\n");
        xmlFreeDoc(doc);
        return -1;
    }

    context = xmlXPathNewContext(doc);
    if (context == NULL)
    {
        printf("context is NULL\n");
        return -1;
    }

    if (xmlStrcmp(curNode->name, BAD_CAST "root"))
    {
        printf("document of the wrong type, root node != root.\n");
        xmlFreeDoc(doc);
        return -1;
    }

    curNode = curNode->xmlChildrenNode;
    xmlNodePtr propNodePtr = curNode;
    Node1 = curNode;
    while (Node1 != NULL)
    {
        if ((!xmlStrcmp(Node1->name, (const xmlChar *)"protocol")))
        {
            xmlAttrPtr attrPtr = Node1->properties;
            while (attrPtr != NULL)
            {
                propNodePtr = Node1;
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevCode"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr, BAD_CAST "DevCode");
                    dev_code = strtoul((const char *)szAttr, NULL, 10);
                    xmlFree(szAttr);
                    //printf("%s dev_code:%d (L%d)\n", __func__, dev_code, __LINE__);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolType"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolType");
                    if (strcmp((const char *)szAttr, "ModbusTcp") == 0)
                    {
                        ptl_type = MODBUS;
                    }
                    else if (strcmp((const char *)szAttr, "DLT645") == 0)
                    {
                        ptl_type = DLT645;
                    }
                    else
                    {
                        ptl_type = MODBUS;
                    }
                    //printf("%s ptl_type:%d (L%d)\n", __func__, ptl_type, __LINE__);
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolByte"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolByte");
                    if (strcmp((const char *)szAttr, "低字节前高字节后") == 0)
                    {
                        byte_seq = LH_BYTE;
                    }
                    else if (strcmp((const char *)szAttr, "高字节前低字节后") == 0)
                    {
                        byte_seq = HL_BYTE;
                    }
                    else
                    {
                        //printf("xml 字节输入有误，默认高字节前低字节后 \n");
                        byte_seq= HL_BYTE;
                    }
                    //printf("byte_seq = %d \n", byte_seq);
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolWord"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolWord");
                    if (strcmp((const char *)szAttr, "低字前高字后") == 0)
                    {
                        word_seq = LH_WORD;
                    }
                    else if (strcmp((const char *)szAttr, "高字前低字后") == 0)
                    {
                        word_seq = HL_WORD;
                    }
                    else
                    {
                        //printf("xml 字输入有误，默认低字前高字后 \n");
                        word_seq = LH_WORD;
                    }

                    //printf("word_seq = %d \n", word_seq);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }

            Node2 = Node1->xmlChildrenNode;
            uint32_t protocol_num = 0;
            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"table")))
                {
                    propNodePtr = Node2;
                    attrPtr = propNodePtr->properties;
                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                            tableid = strtoul((const char *)szAttr, NULL, 10);
                            pProtocol[protocol_num].ptl_id = tableid;
                            //printf("protocol_num:%d tableid = %d (L%d)\n", protocol_num, tableid, __LINE__);
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "cmd"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "cmd");
                            tablecmd = strtoul((const char *)szAttr, NULL, 10);
                            pProtocol[protocol_num].cmd = tablecmd;
                            //printf("protocol_num:%d cmd = %d\n", protocol_num, pProtocol[protocol_num].cmd );
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "address"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "address");
                            pProtocol[protocol_num].address = strtoul((const char *)szAttr, NULL, 0);
                            //printf("protocol_num:%d address = %d\n", protocol_num, pProtocol[protocol_num].address);
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "cyc_enable"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "cyc_enable");
                            pProtocol[protocol_num].cyc_enable = strtoul((const char *)szAttr, NULL, 0);
                            //EMS_LOG(LL_DEBUG, MODULE_C, false, "read_set = %d\n", protocol_data_p[protocol_num].cyc_enable);
                            xmlFree(szAttr);
                        }
                        attrPtr = attrPtr->next;
                    }
                    Node3 = Node2->xmlChildrenNode;
                    while (Node3 != NULL)
                    {
                        int32_t tmp_data_id = 0;
                        int32_t min_data_id = 0;
                        int32_t max_ptl_data_id = 0;
                        int32_t tmp_addr = 0;
                        int32_t addr_min = 0;
                        int32_t addr_max = 0;
                        if ((!xmlStrcmp(Node3->name, (const xmlChar *)"register")))
                        {
                            uint32_t j = 0;
                            char xpath_point[100] = {0};
                            char xpath_tab[100] = {0};
                            xmlNodePtr tmp_node= NULL;
                            sprintf (xpath_tab, "/root/protocol/table[@id='%d' and @cmd='%d'  ]", tableid, tablecmd);
                            sprintf (xpath_point , "%s/register/point", xpath_tab);
                            xmlChar *xpath_tmp = (xmlChar *) xpath_point;
                            result = xmlXPathEvalExpression (xpath_tmp, context);
                            if (result)
                            {
                                nodeset = result->nodesetval;
                                if (nodeset->nodeNr)
                                {
                                    point_num = nodeset->nodeNr;
                                    total_point_num += point_num;
                                    protocol_data = (PROTOCOL_DATA_T *) malloc (point_num * sizeof(PROTOCOL_DATA_T));
                                    if (protocol_data == NULL)
                                    {
                                        printf("malloc protocol_data error.\n");
                                        exit(EXIT_FAILURE);
                                    }
                                    else
                                    {
                                        memset(protocol_data, 0, point_num*(sizeof(PROTOCOL_DATA_T)));
                                    }
                                    for (i = 0; i < point_num; i++)
                                    {
                                        protocol_data[i].low_limit = 0x80000000;
                                        protocol_data[i].high_limit = 0x7fffffff;
                                    }
                                }
                            }
                            for (j = 0; j < point_num; j++)
                            {
                                index_id = j;
                                tmp_node = nodeset->nodeTab[j];
                                propNodePtr = tmp_node;
                                if ((!xmlStrcmp(tmp_node->name, (const xmlChar *)"point")))
                                {
                                    xmlAttrPtr attrPtr = propNodePtr->properties;
                                    while (attrPtr != NULL)
                                    {
                                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataName"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataName");
                                            strcpy(protocol_data[j].data_name, (char *)szAttr);
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].data_name=%10s\n", j, protocol_data[j].data_name);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataId"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataId");
                                            protocol_data[j].data_id = strtoul((char *)szAttr, NULL, 0);
                                            tmp_data_id = protocol_data[j].data_id;
                                            if (max_ptl_data_id < tmp_data_id )
                                            {
                                                max_ptl_data_id = tmp_data_id;
                                            }
                                            if ((min_data_id <= 0) || (addr_min > tmp_data_id))
                                            {
                                                min_data_id = tmp_data_id;
                                            }
                                            //printf("protocol_data[%d].data_id=%4d\n", j, protocol_data[j].data_id);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ShowId"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ShowId");
                                            protocol_data[j].show_id = strtoul((char *)szAttr, NULL, 0);
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].show_id=%4d\n", j, protocol_data[j].show_id);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataUnit"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataUnit");
                                            strcpy(protocol_data[j].data_unit, (char *)szAttr);
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].data_unit=%5s\n", j, protocol_data[j].data_unit);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataAddress"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataAddress");
                                            protocol_data[j].address = strtoul((char *)szAttr, NULL, 0);
                                            tmp_addr = protocol_data[j].address;
                                            if (addr_max < tmp_addr)
                                            {
                                                addr_max = tmp_addr;
                                            }
                                            if ((addr_min <= 0) || (addr_min > tmp_addr))
                                            {
                                                addr_min = tmp_addr;
                                            }
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].address=%5d\n", j, protocol_data[j].address);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataLen"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataLen");
                                            protocol_data[j].data_len = strtoul((char *)szAttr, NULL, 0);
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].data_len=%5d\n", j, protocol_data[j].data_len);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataType"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataType");
                                            if(strcmp((char *)szAttr, "I") == 0)
                                            {
                                                protocol_data[j].data_type = 2;
                                            }
                                            else if(strcmp((char *)szAttr, "F") == 0)
                                            {
                                                protocol_data[j].data_type = 4;
                                            }
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].data_type=%5d\n", j, protocol_data[j].data_type);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataInfo"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataInfo");
                                            strcpy(protocol_data[j].data_info, (char *)szAttr);
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].data_info=%s\n", j, protocol_data[j].data_info);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataSign"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataSign");
                                            if(strcmp((char *)szAttr, "U") == 0)
                                            {
                                                protocol_data[j].data_sign = SIGN_U;
                                            }
                                            else if(strcmp((char *)szAttr, "S") == 0)
                                            {
                                                protocol_data[j].data_sign = SIGN_S;
                                            }
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].data_sign=%5d\n", j, protocol_data[j].data_sign);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataDecimal"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataDecimal");
                                            //protocol_data[j].dec_p = atof((char *)szAttr);
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].dec_p=%1.3f\n", j, protocol_data[j].dec_p);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMin"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataMin");
                                            uint16_t len ;
                                            len = strlen((char *)szAttr);
                                            if (len > 0 && len< 32)
                                            {
                                                //strcpy(protocol_data[j].min_data, (char *)szAttr);
                                                protocol_data[j].low_limit = strtoul((char *)szAttr, NULL, 0);
                                            }
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].low_limit=%d\n", j, protocol_data[j].low_limit);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMax"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataMax");
                                            uint16_t len ;
                                            len = strlen((char *)szAttr);
                                            if (len > 0 && len< 32)
                                            {
                                               //strcpy(protocol_data[j].max_data, (char *)szAttr);
                                                protocol_data[j].high_limit = strtoul((char *)szAttr, NULL, 0);
                                            }
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].high_limit=%d\n", j, protocol_data[j].high_limit);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMin1"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataMin1");
                                            uint16_t len ;
                                            len = strlen((char *)szAttr);
                                            if (len > 0 && len< 32)
                                            {
//                                                 strcpy(protocol_data[j].min_data1, (char *)szAttr);
                                                protocol_data[j].low_limit1 = strtoul((char *)szAttr, NULL, 0);
                                            }
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].low_limit1=%d\n", j, protocol_data[j].low_limit1);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMax1"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataMax1");
                                            uint16_t len ;
                                            len = strlen((char *)szAttr);
                                            if (len > 0 && len< 32)
                                            {
//                                                 strcpy(protocol_data[j].max_data1, (char *)szAttr);
                                                protocol_data[j].high_limit1 = strtoul((char *)szAttr, NULL, 0);
                                            }
                                            xmlFree(szAttr);
                                            //printf("protocol_data[%d].low_high_limit1=%d\n", j, protocol_data[j].high_limit1);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Appendix"))
                                        {
                                            /*xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Appendix");
                                            uint16_t appendix_len ;
                                            appendix_len = strlen((char *)szAttr);
                                            if (appendix_len > 0)
                                            {
                                                protocol_data[j].appendix_enable = 1;
                                                protocol_data[j].appendix = (char *)malloc(sizeof(char) * (appendix_len + 10));
                                                if (protocol_data[j].appendix == NULL)
                                                {
                                                    EMS_LOG(LL_ERROR, MODULE_C, false, "mallco appendix error\n");
                                                    exit(EXIT_FAILURE);
                                                }
                                                strcpy(protocol_data[j].appendix, (char *)szAttr);
                                            }
                                            else
                                            {
                                                protocol_data[j].appendix_enable = 0;
                                                protocol_data[j].appendix = NULL;
                                            }
                                            xmlFree(szAttr);*/
                                        }

                                        attrPtr = attrPtr->next;
                                    }
                                }

                            }
                            pProtocol[protocol_num].protocol_data = protocol_data;
                            if (pProtocol[protocol_num].cmd == 0x01 || pProtocol[protocol_num].cmd == 0x02)
                            {
                                if (protocol_data[point_num-1].data_len == 4 )
                                {
                                    pProtocol[protocol_num].len = addr_max - addr_min + 4*8;
                                }
                                else
                                {
                                    pProtocol[protocol_num].len  = addr_max - addr_min + 2*8;
                                }
                            }
                            else
                            {
                                if (protocol_data[point_num-1].data_len == 4 )
                                {
                                    pProtocol[protocol_num].len = addr_max - addr_min + 2;
                                }
                                else
                                {
                                    pProtocol[protocol_num].len  = addr_max - addr_min + 1;
                                }
                            }
                            //printf("len = %d   ", pProtocol[protocol_num].len);
                            pProtocol[protocol_num].min_address = addr_min;
                            pProtocol[protocol_num].max_address = addr_max;

                            pProtocol[protocol_num].min_data_id = min_data_id;
                            pProtocol[protocol_num].max_data_id = max_ptl_data_id;
                            if (pProtocol[protocol_num].address != addr_min)
                            {
                                pProtocol[protocol_num].address = addr_min;
                                //printf("protocol_data_p[protocol_num].address is not min address\n");
                            }

                            pProtocol[protocol_num].dev_code = dev_code;
                            pProtocol[protocol_num].ptl_type = ptl_type;
                            pProtocol[protocol_num].byte_seq = byte_seq;
                            pProtocol[protocol_num].word_seq = word_seq;
                            pProtocol[protocol_num].ptl_data_num = point_num;
                        }
                        Node3 = Node3->next;
                    }
                    protocol_num ++;
                }
                Node2 = Node2->next;
            }
        }
        Node1 = Node1->next;
    }
    xmlFreeDoc(doc);

    return total_point_num;
}

static int32_t CreateReq(uint16_t slave_id, PROTOCOL_T *protocol, uint8_t *req)
{
    uint16_t k = 0;

    /* Transaction ID */
    req[0] = g_metaid >> 8;
    req[1] = g_metaid & 0x00ff;

    /* Protocol Modbus */
    req[2] = 0;
    req[3] = 0;

    /* Length will be defined later by set_req_length_tcp at offsets 4
       and 5 */

    req[6] = slave_id;//unit_id;
    req[7] = protocol->cmd;   //function;
    req[8] = (protocol->address -1) >> 8;   //addr >> 8;
    req[9] = (protocol->address - 1) & 0xff; //addr & 0x00ff;
    req[10] = protocol->len >> 8;//nb >> 8;
    req[11] = protocol->len & 0x00ff; //nb & 0x00ff;

    k = MODBUS_TCP_PRESET_REQ_LENGTH;
    if (protocol->cmd == WriteMultipleRegister)
    {
        /*
        int byte_count = protocol->len * 2;
        req[k++] = byte_count;

        for (i = 0; i < protocol->len; i++)
        {
            req[k++] = pSendCmd->data[i] >> 8;
            req[k++] = pSendCmd->data[i] & 0x00FF;
        }
        */
    }

    int32_t mbap_length = k - 6;

    req[4] = mbap_length >> 8;
    req[5] = mbap_length & 0x00FF;

    g_metaid++;

    return 0;
}

static int32_t CreateWReq(uint16_t slave_id, uint16_t address, uint16_t nb, uint8_t *req)
{
    uint16_t k = 0;
    uint16_t i;

    /* Transaction ID */
    req[0] = g_metaid >> 8;
    req[1] = g_metaid & 0x00ff;

    /* Protocol Modbus */
    req[2] = 0;
    req[3] = 0;

    /* Length will be defined later by set_req_length_tcp at offsets 4
       and 5 */

    req[6] = slave_id;//unit_id;
    req[7] = WriteMultipleRegister;   //function;
    req[8] = (address -1) >> 8;   //addr >> 8;
    req[9] = (address - 1) & 0xff; //addr & 0x00ff;
    req[10] = nb >> 8;
    req[11] = nb & 0x00ff;

    k = MODBUS_TCP_PRESET_REQ_LENGTH;
    if (req[7] == WriteMultipleRegister)
    {
        int byte_count = nb * 2;
        req[k++] = byte_count;

        for (i = 0; i < nb; i++)
        {
            req[k++] = (100 + i) >> 8;
            req[k++] = (100 + i) & 0x00FF;
        }
    }

    int32_t mbap_length = k - 6;

    req[4] = mbap_length >> 8;
    req[5] = mbap_length & 0x00FF;

    g_metaid++;

    return 0;
}

int CreateCmdByEquipProtocal(void)
{
    int tab_nums = GetTableCountFromXml(configPath);

    PROTOCOL_T *pProtocol = malloc(tab_nums * sizeof(PROTOCOL_T));
    memset(pProtocol, 0, sizeof(tab_nums * sizeof(PROTOCOL_T)));

    int points = ParseProtocalFromXml(configPath, pProtocol);
    printf("%s points = %d pProtocol:%p (L%d)\n", __func__, points, pProtocol, __LINE__);

    for (int i = 0; i < tab_nums; i++)
    {
        //uint8_t *req = malloc(256 * sizeof(uint8_t));
        uint8_t *reqW = malloc(256 * sizeof(uint8_t));

        printf("%s i:%d (L%d)\n", __func__, i, __LINE__);
        memset(reqW, 0, 256 * sizeof(uint8_t));
        CreateWReq(1, pProtocol[i].address, 1, reqW);
        ListInsertTail(cmdList, reqW);

/*
        memset(req, 0, 256 * sizeof(uint8_t));
        CreateReq(1, pProtocol + i, req);
        ListInsertTail(cmdList, req);
*/
    }

    return 0;
}
int CreateCmdByACDCEquipProtocal(void)
{
    int tab_nums = GetTableCountFromXml(configPath1);

    PROTOCOL_T *pProtocol = malloc(tab_nums * sizeof(PROTOCOL_T));
    memset(pProtocol, 0, sizeof(tab_nums * sizeof(PROTOCOL_T)));

    int points = ParseProtocalFromXml(configPath1, pProtocol);
    printf("%s points = %d pProtocol:%p (L%d)\n", __func__, points, pProtocol, __LINE__);

    for (int i = 0; i < tab_nums; i++)
    {
        //uint8_t *req = malloc(256 * sizeof(uint8_t));
        uint8_t *reqW = malloc(256 * sizeof(uint8_t));

        printf("%s i:%d (L%d)\n", __func__, i, __LINE__);
        memset(reqW, 0, 256 * sizeof(uint8_t));
        CreateWReq(2, pProtocol[i].address, 1, reqW);
        ListInsertTail(cmdList, reqW);

/*
        memset(req, 0, 256 * sizeof(uint8_t));
        CreateReq(1, pProtocol + i, req);
        ListInsertTail(cmdList, req);
*/
    }

    return 0;
}

int CreateCmdByChargeEquipProtocal(void)
{
    int tab_nums = GetTableCountFromXml(configPath2);

    PROTOCOL_T *pProtocol = malloc(tab_nums * sizeof(PROTOCOL_T));
    memset(pProtocol, 0, sizeof(tab_nums * sizeof(PROTOCOL_T)));

    int points = ParseProtocalFromXml(configPath2, pProtocol);
    printf("%s points = %d pProtocol:%p (L%d)\n", __func__, points, pProtocol, __LINE__);

    for (int i = 0; i < tab_nums; i++)
    {
        //uint8_t *req = malloc(256 * sizeof(uint8_t));
        uint8_t *reqW = malloc(256 * sizeof(uint8_t));

        printf("%s i:%d (L%d)\n", __func__, i, __LINE__);
        memset(reqW, 0, 256 * sizeof(uint8_t));
        CreateWReq(3, pProtocol[i].address, 1, reqW);
        ListInsertTail(cmdList, reqW);

/*
        memset(req, 0, 256 * sizeof(uint8_t));
        CreateReq(1, pProtocol + i, req);
        ListInsertTail(cmdList, req);
*/
    }

    return 0;
}

int CreateCmdByDefault(void)
{
    uint16_t addr[2] = {1, 4};
    //ACDC
    for (int i = 0; i < 2; i++)
    {
        //uint8_t *req = malloc(256 * sizeof(uint8_t));
        uint8_t *reqW = malloc(256 * sizeof(uint8_t));

        printf("%s i:%d (L%d)\n", __func__, i, __LINE__);
        memset(reqW, 0, 256 * sizeof(uint8_t));
        CreateWReq(2, addr[i], 1, reqW);
        ListInsertTail(cmdList, reqW);
/*
        memset(req, 0, 256 * sizeof(uint8_t));
        CreateReq(1, pProtocol + i, req);
        ListInsertTail(cmdList, req);
*/
    }

    return 0;
}

int main(int argc, char** argv)
{
    char ip[] = "255.255.255.255";
    printf("Please enter IP:\n");
    scanf("%s", ip);

    printf("argc:%d argv:%s ip:%s\n", argc, *argv, ip);
    int port = 502;

    cmdList = malloc(sizeof(SLIST_T));
    ListInit(cmdList);

//     CreateCmdByEquipProtocal();
//     CreateCmdByACDCEquipProtocal();

    CreateCmdByChargeEquipProtocal();

    TcpConnect(ip, port);

    int count = 0;
    int interval[2] = {10000, 10000};
    while(ListSize(cmdList))
    {
        if (count >= 1000)
        {
            sleep(5);
            continue;
        }

        void *cmd;
        cmd = ListHeadData(cmdList);

        printf("main send count:%d\n", count);
        for (int j = 0; j < 16; j++)
        {
            printf(" 0x%2x ", ((uint8_t*)cmd)[j]);
        }
        printf(".\n");

        send(g_sock, (const char*)cmd, 256, MSG_NOSIGNAL);

        uint8_t *tmp = malloc(256 * sizeof(uint8_t));
        memcpy(tmp, cmd, 256 * sizeof(uint8_t));
        ListRemoveHead(cmdList);
        ListInsertTail(cmdList, tmp);


        usleep(interval[count % 2]);
        count++;
    }
    printf("main done.\n");

    return 0;
}
#endif

#if 0
pid_t gettid()
{
    return syscall(SYS_gettid);

}

void threadMain(void *arg)
{
    uintptr_t fd = *(uintptr_t*)arg;

    printf("%s fd:%lu (L%d,pid:%d)\n", __func__, fd, __LINE__, gettid());

    MODBUS_CMD_T cmd;
    cmd.transaction = 1;
    cmd.protocolType = 0;
    cmd.id = 1;
    cmd.cmd = 0x03;
    cmd.address = 99;
    cmd.registerCount = 1;
    printf("%s fd:%lu (L%d,pid:%d)\n", __func__, fd, __LINE__, gettid());
    ModbusSend(fd, &cmd);
    printf("%s fd:%lu (L%d,pid:%d)\n", __func__, fd, __LINE__, gettid());
    /*uint8_t req[] = {0x00, 0x01, 0x00, 0x00, 0x00, 0x06, 0x01, 0x03, 0x0a, 0x0c, 0x00, 0x02};
    for (int i = 0; i < 4; i++)
    {
        ModbusTcpSend((modbus_priv_t*)fd, req, sizeof(req));
        sleep(1);
    }*/

    usleep(5000000);

    uint8_t req[MODBUS_TCP_MAX_ADU_LENGTH];
    ModbusRecv(fd, req);
    /*printf("main recv:\n");
    for (int j = 0; j < 13; j++)
    {
        printf(" 0x%2x ", req[j]);
    }
    printf(".\n");
    */
    printf("%s fd:%lu (L%d,pid:%d)\n", __func__, fd, __LINE__, gettid());

    ModbusClose(fd);
    printf("%s fd:%lu (L%d,pid:%d) end.\n", __func__, fd, __LINE__, getgid());
}

int main()
{
    int i = 0;
    int res;
    pthread_t pid[10];
    pthread_attr_t thread_attr;
    size_t stacksize;

    res = pthread_attr_init(&thread_attr);
    if (res != 0) {
        printf("Attribute creation failed");
    }

    stacksize = 512*1024;/* 512KB 栈空间 */
    res = pthread_attr_setstacksize(&thread_attr, stacksize);

    res = pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
    if (res != 0) {
        printf("Setting detached attribute failed");
    }

    for (i = 0; i < 10; i++)
    {
        START_INFO_T start_info;
        char c[] = "127.0.0.1";
        //char c[] = "192.168.27.17";
        //char c[] = "192.168.28.88";

        strncpy(start_info.sIp, c, sizeof(c));
        start_info.iPort = 502;
        start_info.type = MODBUS_BACKEND_TYPE_TCP;
        start_info.role = MODBUS_ROLE_MASTER;

        printf("start_info.sIp:%s \n", start_info.sIp);
        uintptr_t fd = ModbusOpen(start_info);

        res = pthread_create(&(pid[i]), &thread_attr, (void*)threadMain, (void*)(&fd));
        if (res != 0) {
            printf("Thread creation failed");
        }

    }

    while(1)
    {
        sleep(1);
    }
    return 0;
}
#endif


