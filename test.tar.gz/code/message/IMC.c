/*
 * Internal Message Communicatio module.
 */

#include <stdlib.h>
#include "IMC.h"

typedef struct client_info_st{
    int32_t dwClientType;
    imc_cb  clientCB;
}CLIENT_INFO_T;

struct imc_handle_st{
    int32_t dwClientNum;
    CLIENT_INFO_T* pClientList;
    pthread_mutex_t imcMtx;
    BOOL isDestroy;
    BOOL debug;
};

IMC_HANDLE_T g_stIMC_Handle;

static CLIENT_INFO_T* findClient(int32_t handle)
{
    CLIENT_INFO_T *pClient = NULL;
    int32_t i = 0;

    for (i = 0; i < g_stIMC_Handle.dwClientNum; i ++)
    {
        if (g_stIMC_Handle.pClientList[i].dwClientType == handle)
        {
            pClient = g_stIMC_Handle.pClientList + i;
            break;
        }
    }

    return pClient;
}

int32_t IMC_Create()
{
    int32_t ret = OK;

    pthread_mutex_init(&g_stIMC_Handle.imcMtx, NULL);
    g_stIMC_Handle.isDestroy = FALSE;
    g_stIMC_Handle.debug = FALSE;
    g_stIMC_Handle.dwClientNum = 0;

    g_stIMC_Handle.pClientList = malloc(sizeof(CLIENT_INFO_T) * MSG_CLIENT_MAX_NUM);
    memset(g_stIMC_Handle.pClientList, 0 , sizeof(CLIENT_INFO_T) * MSG_CLIENT_MAX_NUM);

    return ret;
}

int32_t IMC_RegisterCB(uintptr_t handle, imc_cb cb)
{
    int32_t ret = OK;

    pthread_mutex_lock(&g_stIMC_Handle.imcMtx);
    do
    {
        if (cb == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        /*已经注册过cb，覆盖原来的cb*/
        CLIENT_INFO_T *pTmpClient = findClient(handle);
        if (pTmpClient != NULL)
        {
            pTmpClient->clientCB = cb;
            break;
        }


        g_stIMC_Handle.dwClientNum++;
        if (g_stIMC_Handle.dwClientNum > MSG_CLIENT_MAX_NUM)
        {
            pTmpClient = realloc(pTmpClient, sizeof(CLIENT_INFO_T) * g_stIMC_Handle.dwClientNum);
        }
        else
        {
            pTmpClient = g_stIMC_Handle.pClientList;
        }

        CLIENT_INFO_T *pNewClient = pTmpClient + g_stIMC_Handle.dwClientNum - 1;
        pNewClient->clientCB = cb;
        pNewClient->dwClientType = handle;

    }while(0);

    pthread_mutex_unlock(&g_stIMC_Handle.imcMtx);

    return ret;
}

int32_t IMC_Send(void *pvMsg)
{
    int32_t ret = OK, res = OK;
    int32_t i = 0;

    pthread_mutex_lock(&g_stIMC_Handle.imcMtx);

    do
    {
        if (pvMsg == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        if (g_stIMC_Handle.isDestroy == TRUE)
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_INIT);
            break;
        }

        for (i = 0; i < g_stIMC_Handle.dwClientNum; i++)
        {
            if (g_stIMC_Handle.pClientList[i].clientCB != NULL)
            {
                res = g_stIMC_Handle.pClientList[i].clientCB(g_stIMC_Handle.pClientList[i].dwClientType, pvMsg);

                if (g_stIMC_Handle.debug)
                {
                    printf("notify res:%d \n", res);
                }

            }
        }

    }while(0);

    pthread_mutex_unlock(&g_stIMC_Handle.imcMtx);

    return ret;
}

int32_t IMC_Destroy()
{
    int32_t ret = OK;

    pthread_mutex_lock(&g_stIMC_Handle.imcMtx);
    g_stIMC_Handle.isDestroy = TRUE;
    pthread_mutex_unlock(&g_stIMC_Handle.imcMtx);

    HCFREE(g_stIMC_Handle.pClientList);
    g_stIMC_Handle.dwClientNum = 0;

    pthread_mutex_destroy(&g_stIMC_Handle.imcMtx);
    return ret;
}
