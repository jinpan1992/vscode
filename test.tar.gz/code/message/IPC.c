#include <sys/socket.h>
#include <stddef.h>
#include <sys/un.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/epoll.h>
#include "IPC.h"

char *socket_path = "/tmp/server.socket";
char *cli_path = "/tmp/cli.socket";

struct ipc_handle
{
    int32_t dwListenfd;
    ipc_cb eventcb;
    int32_t epoll_fd;
    pthread_t stThread;
    BOOL isStop;
    BOOL debug;
    int32_t arrClient[IPC_CLIENT_MAX];   //客户端文件句柄
    pthread_mutex_t mutex;
};

static int32_t serverInit(int32_t *pdwListenfd)
{
    int32_t ret = OK;
    int32_t listenfd = 0;

    do
    {
        if (pdwListenfd == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        struct sockaddr_un serun;
        int32_t size;

        if ((listenfd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
            printf("ipc socket error. \n");
            ret = errno;
            break;
        }

        memset(&serun, 0, sizeof(serun));
        serun.sun_family = AF_UNIX;
        strncpy(serun.sun_path, socket_path, strlen(socket_path) + 1);
        size = offsetof(struct sockaddr_un, sun_path) + strlen(serun.sun_path);
        unlink(socket_path);

        if (bind(listenfd, (struct sockaddr *)&serun, size) < 0) {
            printf("ipc bind error. \n");
            ret = errno;
            break;
        }

        printf("UNIX domain socket bind.\n");

        if (listen(listenfd, IPC_CLIENT_MAX) < 0) {
            printf("ipc listen error. \n");
            ret = errno;
            break;
        }

        *pdwListenfd = listenfd;

        printf("IPC listenfd:%d.\n", listenfd);

        return ret;
    }while(0);

    if (listenfd != 0)
    {
        close(listenfd);
    }

    return ret;
}

static int32_t closeClient(IPC_HANDLE_T *pHandle, int32_t clientFd)
{
    int32_t ret = OK;
    int32_t i = 0;

    for (i = 0; i < IPC_CLIENT_MAX; i++)
    {
        if (pHandle->arrClient[i] == clientFd)
        {
            pHandle->arrClient[i] = 0;
        }
    }

    pthread_mutex_lock(&pHandle->mutex);
    epoll_ctl(pHandle->epoll_fd, EPOLL_CTL_DEL, clientFd, NULL);//将event_array[i].data.fd从epollfd中删除；
    close(clientFd);
    pthread_mutex_unlock(&pHandle->mutex);

    return ret;
}

static int32_t findClientType(IPC_HANDLE_T *pHandle, int32_t clientFd)
{
    int32_t ret = OK;
    int32_t i = 0;

    for (i = 0; i < IPC_CLIENT_MAX; i++)
    {
        if (pHandle->arrClient[i] == clientFd)
        {
            ret = i;
            break;
        }
    }

    return ret;
}

static void reply(IPC_HANDLE_T *pHandle, int32_t fd, void* pMsg, uint32_t uiMsgLen)
{
    if (fd > 0 && pHandle->isStop == FALSE)
    {
        pthread_mutex_lock(&pHandle->mutex);
        int32_t ret = write(fd, pMsg, uiMsgLen);
        pthread_mutex_unlock(&pHandle->mutex);
        if(ret < 0 )
        {
            printf("socket[%d] write failure: %s\n", fd, strerror(errno));
        }
    }

    return;
}

static void *event_loop(void *arg)
{
    IPC_HANDLE_T *pHandle   = (IPC_HANDLE_T *) arg;
    int32_t       epoll_fd  = pHandle->epoll_fd;
    int32_t       connfd, rv;
    uint8_t       ucInbuf[MAX_READ_BUFFER_LEN] = {'0'};

    while (1) {
        struct epoll_event event = { 0 };

        int32_t ret = epoll_wait(epoll_fd, &event, 10, 1000);

        if (ret < 0) {
            continue;
        }
        if (pHandle->isStop) {
            printf("event loop exit, stop: %d\n", pHandle->isStop);
            break;
        }

        if ((event.events & EPOLLHUP) || (event.events & EPOLLRDHUP)) {
            printf("IPC get error event on fd[%d]: %s\n", event.data.fd, strerror(errno));

            closeClient(pHandle, event.data.fd);
        }
        /* 处理连接事件 */
        else if(event.data.fd == pHandle->dwListenfd)//如果是我要找的listenfd；
        {
            if((connfd = accept(pHandle->dwListenfd, (struct sockaddr *)NULL, NULL)) < 0)
            {
                printf("accept new client failure: %s\n", strerror(errno));
                continue;
            }

            event.data.fd = connfd;
            event.events = EPOLLIN;
            if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, connfd, &event) < 0 )//如果connfd加入epollfd错误；
            {
                printf("IPC add client socket failure: %s\n", strerror(errno));
                close(event.data.fd);
                continue;
            }

            struct sockaddr_un clientun;
            socklen_t addrlen = sizeof(struct sockaddr_un);

            getpeername(connfd, (struct sockaddr*)&clientun, &addrlen);
            printf("IPC add new client socket[%d], name:%s.\n", connfd, clientun.sun_path);

            if (strstr(clientun.sun_path, cli_path) != NULL)
            {
                pHandle->arrClient[IPC_CLIENT_CLI] = connfd;
            }
            else
            {
                pHandle->arrClient[IPC_CLIENT_WEB] = connfd;
            }
        }
        /*处理已连接的客户端事件*/
        else if(event.events & EPOLLIN)
        {
            if( (rv = read(event.data.fd, ucInbuf, sizeof(ucInbuf))) <= 0)
            {
                printf("socket[%d] read failure or get disconncet and will be removed.\n", event.data.fd);

                closeClient(pHandle, event.data.fd);

                continue;
            }
            else
            {
                if (pHandle->debug)
                {
                    printf("socket[%d] read get %d bytes data\n", event.data.fd, rv);
                    int32_t i = 0;
                    for (i = 0; i < rv; i++)
                    {
                        printf("%d ", ucInbuf[i]);
                    }
                    printf("\n");
                }

                if (pHandle->eventcb)
                {
                    int32_t dwClientType = findClientType(pHandle, event.data.fd);

                    ret = pHandle->eventcb(dwClientType, ucInbuf, rv);

                    SG_MSG_T *pstWebMsg = (SG_MSG_T *)ucInbuf;
                    char tmp[10] = "recv ok";
                    pstWebMsg->udwlen = sizeof(char) * 10;
                    pstWebMsg->pData = (u_int8_t*)pstWebMsg + offsetof(SG_MSG_T, pData);
                    memcpy(pstWebMsg->pData, tmp, pstWebMsg->udwlen);
                    reply(pHandle, event.data.fd, pstWebMsg, offsetof(SG_MSG_T, pData) + pstWebMsg->udwlen);

                    if (pHandle->debug)
                        printf("0x%x reply  done.\n", pstWebMsg->udwMsgType);
                }

            }
        }

    }

    return NULL;
}

uintptr_t IPC_Init(ipc_cb cb)
{
    uintptr_t retPtr;

    IPC_HANDLE_T *pHandle = (IPC_HANDLE_T*)malloc(sizeof(IPC_HANDLE_T));
    if (pHandle == NULL)
    {
        return INVALID_VALUE;
    }

    memset(pHandle, 0, sizeof(IPC_HANDLE_T));
//     pHandle->debug = TRUE;

    retPtr = (uintptr_t)pHandle;

    pHandle->eventcb = cb;
    int32_t ret = serverInit(&pHandle->dwListenfd);
    if (ret != OK)
    {
        HCFREE(pHandle);

        retPtr = INVALID_VALUE;
    }

    pthread_mutex_init(&pHandle->mutex, NULL);

    return retPtr;
}

int32_t IPC_UnInit(uintptr_t handle)
{
    int32_t ret = OK;
    int32_t i = 0;
    IPC_HANDLE_T *pHandle = (IPC_HANDLE_T*)handle;
    if (pHandle == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pHandle->isStop = TRUE;

    if (pHandle->stThread)
    {
        pthread_join(pHandle->stThread, NULL);
    }

    pthread_mutex_lock(&pHandle->mutex);
    for (i = 0; i < IPC_CLIENT_MAX; i++)
    {
        close(pHandle->arrClient[i]);
    }

    close(pHandle->epoll_fd);

    pthread_mutex_unlock(&pHandle->mutex);

    pthread_mutex_destroy(&pHandle->mutex);

    HCFREE(pHandle);

    return ret;
}

int32_t IPC_Start(uintptr_t handle)
{
    int32_t ret = OK;
    IPC_HANDLE_T *pHandle = (IPC_HANDLE_T*)handle;
    if (pHandle == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pHandle->epoll_fd = epoll_create(1);

    /*写入event.events = EPOLLIN|EPOLLET;*/
    struct   epoll_event     event;
    event.events = EPOLLIN | EPOLLET;
    event.data.fd = pHandle->dwListenfd;
    if(epoll_ctl(pHandle->epoll_fd, EPOLL_CTL_ADD, pHandle->dwListenfd, &event) < 0)//将listenfd添加到epollfd中的兴趣列表里面去；
    {
        printf("epoll add listen socket failure: %s\n", strerror(errno));
        return errno;
    }

    pthread_create(&pHandle->stThread, NULL, event_loop, pHandle);

    return ret;
}

int32_t IPC_SendMsg(uintptr_t handle, enum ipc_client_type eType, void *pMsg, uint32_t uiMsgLen)
{
    int32_t ret = OK;

    IPC_HANDLE_T *pHandle = (IPC_HANDLE_T*)handle;
    if (pHandle == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    if (pHandle->arrClient[eType] > 0 && pHandle->isStop == FALSE)
    {
        pthread_mutex_lock(&pHandle->mutex);
        ret = write(pHandle->arrClient[eType], pMsg, uiMsgLen);
        pthread_mutex_unlock(&pHandle->mutex);
        if(ret < 0 )
        {
            printf("socket[%d] write failure: %s\n", pHandle->arrClient[eType], strerror(errno));
        }
    }


    return ret;
}
