#ifndef IPC_H_INCLUDED
#define IPC_H_INCLUDED

#include <stdint.h>
#include "common.h"
#include "err.h"

#define MAX_READ_BUFFER_LEN 1500

enum ipc_client_type {
    IPC_CLIENT_CLI   = 0x0,
    IPC_CLIENT_WEB   = 0x1,
    IPC_CLIENT_MAX
};

typedef struct ipc_handle IPC_HANDLE_T;

typedef int32_t (*ipc_cb)(enum ipc_client_type eType, void *pData, uint32_t len);

uintptr_t IPC_Init(ipc_cb cb);
int32_t IPC_UnInit(uintptr_t handle);
int32_t IPC_Start(uintptr_t handle);
int32_t IPC_SendMsg(uintptr_t handle, enum ipc_client_type eType, void *pMsg, uint32_t uiMsgLen);

#endif // IPC_H_INCLUDED
