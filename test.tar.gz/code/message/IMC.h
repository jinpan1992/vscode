#ifndef IMC_H_INCLUDED
#define IMC_H_INCLUDED

#include <stdint.h>
#include "common.h"
#include "msg.h"
#include "err.h"

typedef struct imc_handle_st IMC_HANDLE_T;

typedef int32_t (*imc_cb)(uintptr_t user, void *pvData);

#define MSG_CLIENT_MAX_NUM 20

/**
 * @brief  创建内部消息通信模块
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t IMC_Create();

/**
 * @brief  注册消息回调函数
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t IMC_RegisterCB(uintptr_t handle, imc_cb cb);

/**
 * @brief  发送消息
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t IMC_Send(void *pvMsg);

/**
 * @brief  销毁内部消息通信模块
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t IMC_Destroy();
#endif // IMC_H_INCLUDED
