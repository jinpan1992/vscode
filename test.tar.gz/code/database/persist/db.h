#ifndef DB_H_INCLUDED
#define DB_H_INCLUDED

#include <sqlite3.h>
#include "common.h"

typedef int (*DB_Callback)(void *data, int argc, char **argv, char **azColName);
typedef int (*DB_Query_Callback)(char **dbresult, int nrow, int ncolumn, void *arg);

int32_t db_open(const char *path,sqlite3 **db);
int db_begin_trans(sqlite3 *db);
int  db_done(char *sql, sqlite3 *db, DB_Callback Fcallback, char *data);
int db_commit(sqlite3 *db);
int32_t db_close(sqlite3 *db);
int32_t db_query(const char *path, char *sql, DB_Query_Callback func, void *arg);

#endif // DB_H_INCLUDED
