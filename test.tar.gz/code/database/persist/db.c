#include <stdio.h>
#include <unistd.h>
#include "db.h"

int32_t db_open(const char *path,sqlite3 **db)
{
    int32_t rc;

    rc = sqlite3_open(path, db);
    if(rc)
    {
        printf("Can't open database: %s,%s\n", sqlite3_errmsg(*db), path);
    }

    sqlite3_exec(*db, "PRAGMA synchronous = OFF;", 0, 0, 0);

    return rc;
}

int db_begin_trans(sqlite3 *db)
{
    char *zErrMsg = NULL;
    //   sqlite3_exec(db, "PRAGMA journal_mode = WAL;", 0, 0, 0);
    int ret = sqlite3_exec(db, "BEGIN TRANSACTION", 0, 0, &zErrMsg);

    if (ret != SQLITE_OK)
    {
        printf("SQL excutive error: %s, begin transaction\n", zErrMsg);
        sqlite3_free(zErrMsg);
    }

    return ret;
}

int busy_callback(void* lpVoid, int c)
{
    char *sql = (char *)lpVoid;

    usleep(500);

    if(c >= 10000)
    {
        printf("sql_busy_handler 超时5s, 退出 ！！ @ %s\n", sql);
        return 0;
    }
    else
    {
        //  printf("sql_busy_handler cnt = %d @ %s\n", c, sql);
        return 1;
    }
}

//执行数据库操作语句,带回调函数
int  db_done(char *sql, sqlite3 *db, DB_Callback Fcallback, char *data)
{
    char *zErrMsg = NULL;
    int rc;

    sqlite3_busy_handler(db, busy_callback,(void *)sql);  //等待锁

    if ((Fcallback != NULL)&&(data != NULL))
    {
        rc = sqlite3_exec(db, sql, Fcallback, data, &zErrMsg);
    }
    else
    {
//         printf("%s\n", sql);
        rc = sqlite3_exec(db, sql, 0, 0, &zErrMsg);
//         printf("****rc = %d\n", rc);
    }

    if( rc != SQLITE_OK )
    {
        printf("SQL done error: %s, %s\n", zErrMsg, sql);
        sqlite3_free(zErrMsg);
    }

    return rc;
}

int db_commit(sqlite3 *db)
{
    char *zErrMsg = NULL;
    int ret = sqlite3_exec(db, "COMMIT TRANSACTION", 0, 0, &zErrMsg);

    if (ret != SQLITE_OK)
    {
        printf("SQL excutive error: %s, commit transaction\n", zErrMsg);
        sqlite3_free(zErrMsg);
    }
    return ret;
}

int32_t db_close(sqlite3 *db)
{
    int32_t rc = 0;
    if(db != NULL)
    {
        rc = sqlite3_close(db);
    }

    return rc;
}

int32_t db_query(const char *path, char *sql, DB_Query_Callback func, void *arg)
{
    int32_t rc = OK;
    sqlite3 *db = NULL;

    rc = db_open(path, &db);

    if(db == NULL || rc != OK)
    {
        db_close(db);
        return SQLITE_ERROR;
    }

    int nrow = 0, ncolumn = 0;
    char **dbresult = 0;
    char *errmsg = 0;

    //查询
    //SELECT column-list  FROM table_name 	[WHERE condition] [ORDER BY column1, column2, .. columnN] [ASC | DESC];
    //SELECT column1, column2, columnN 	FROM table_name   LIMIT [no of rows] OFFSET [row num]
    int ret = sqlite3_get_table(db, sql, &dbresult, &nrow, &ncolumn, &errmsg);
    printf("126 ret:%d\n", ret);
    if(ret == SQLITE_OK && func != NULL)
    {
        func(dbresult, nrow, ncolumn, arg);
    }

    sqlite3_free_table(dbresult);
    sqlite3_free(errmsg);
    sqlite3_close(db);

    return ret ;
}
