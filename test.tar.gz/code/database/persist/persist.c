#include <stdlib.h>
#include <sys/time.h>
#include <sys/vfs.h>
#include <math.h>
#include "persist.h"
#include "db.h"
#include "sdb.h"
#include "sys.h"
#include "mapping.h"
#include "logUtil.h"
#include "file_operate.h"

typedef struct
{
    sqlite3  *pDBHis;
    char     acTableName[RTDB_MAX_DEV_NAME_LEN];
    time_t   triggerTime;     //触发过期删除动作的时间
    time_t   firstTime;       //第一条记录的时间
    SLIST_T stBufferList;  //缓冲链表
}HISTABLE_T;

typedef struct
{
    uint16_t ubTableNum;
    HISTABLE_T *pHisTable;

    uint32_t uiWriteIntervalSec; //second
    uint32_t uiExpireTimeMin; //min

    pthread_t writeThread;   //写入线程
    pthread_t cacheThread;  //缓冲线程
    BOOL bWriteThreadExit;
    BOOL bCacheThreadExit;

    BOOL isStop;
    sem_t rwlock;

    HISRULE_E eRule;
}HISINFO_T;

typedef struct
{
    char *path;
    uint8_t pathLen;

    HISINFO_T *pHisData;     //历史设备数据
    HISINFO_T *pHisRecord;   //历史故障,历史告警,历史运行记录

    BOOL debug;
}PERSISTER_T;

PERSISTER_T *g_pstPersister = NULL;
static pthread_mutex_t g_persistMutex = PTHREAD_MUTEX_INITIALIZER;

char arrcTableName[HIS_RECORD_MAX][32] =
{
    "Fault",
    "Warn",
    "RunState"
};

static double getSpace(char *path)
{
    if(path == NULL || DirExist(path) == 0)
        return -1;

    struct statfs diskInfo;
    statfs(path, &diskInfo);
    unsigned long long blocksize = diskInfo.f_bsize; //每个block里包含的字节数

    unsigned long long freeDisk = diskInfo.f_bfree * blocksize;  //剩余空间的大小
    unsigned long long availableDisk = diskInfo.f_bavail * blocksize; //可用空间大小

//     printf("%s Disk_free=%llu(MB)=%llu(GB), Disk_available=%llu(KB)=%llu(MB)=%llu(GB) (L%d)\n",
//             path, freeDisk>>20, freeDisk>>30, availableDisk, availableDisk>>20, availableDisk>>30, __LINE__);

    return availableDisk>>20;
}

static BOOL checkOverflow()
{
    BOOL isOverFlow = FALSE;
    double ret = getSpace(g_pstPersister->path);
    if (ret != -1 && ret <= MAX_RESERVER_SZ)
    {
        isOverFlow = TRUE;

        if (g_pstPersister->debug)
        {
            printf("%s available:%f is too small.\n", g_pstPersister->path, ret);
        }
    }

    return isOverFlow;
}

static int32_t queryDescCb(char **dbresult, int32_t nrow, int32_t ncolumn, void *arg)
{
    int32_t ret = OK;

    do
    {
        if (arg == NULL || dbresult == NULL || *dbresult == NULL || nrow <= 0)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        QUERY_DATA_T *pstQueryData = (QUERY_DATA_T*)arg;

        float32_t *pList = (float32_t*)calloc(nrow * ncolumn, sizeof(float32_t));

        //从第0索引到第 nColumn - 1索引都是字段名称
        //从第 nColumn 索引开始，后面都是字段值
        int32_t i;
        for(i = 0; i < nrow; i++ )
        {
            uint32_t row = i + 1, j = 0;

            for(j = 0; j < ncolumn; j++)
            {
                char *element = dbresult[row * ncolumn + j];
                if (element != NULL)
                {
                    pList[i * ncolumn + j] = atof(dbresult[row * ncolumn + j]);
//                     printf("%s (%d,%d,:%s),%f,%d\n", __func__, row, j, dbresult[row * ncolumn + j],
//                            atof(dbresult[row * ncolumn + j]), atoi(dbresult[row * ncolumn + j]));
                }

            }

        }

        pstQueryData->pvdata = pList;
        pstQueryData->pvdataLen = nrow;

    }while(0);

    return ret;
}

static HISINFO_T* findHandleByType(HISTYPE_E eHisType)
{
    HISINFO_T *pHisInfo = NULL;

    if (g_pstPersister == NULL)
    {
        return NULL;
    }

    switch (eHisType)
    {
        case HIS_DATA:
            pHisInfo = g_pstPersister->pHisData;
            break;
        case HIS_RECORD:
            pHisInfo = g_pstPersister->pHisRecord;
            break;
        default:
            break;
    }

    return pHisInfo;
}

static int32_t hasTableCB(void *data, int32_t argc, char **argv, char **azColName)
{
    if (argc == 1)
    {
        int32_t iTableExist = atoi(*argv); //此处返回值为查询到同名表的个数，没有则为0，否则大于0
        if (data != NULL)
        {
            int32_t *Res = (int32_t*)data;
            *Res = iTableExist;
        }

    }

    return OK;
}

static int32_t hasTable(const char *dbPathAndName, const char *tableName)
{
    int32_t ret = OK;

    if (dbPathAndName == NULL || tableName == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    sqlite3  *pDBHis = NULL;
    char pcSql[128] = {0};
    int32_t nTableNums = 0;

    db_open(dbPathAndName, &pDBHis);

    //select count(*) from sqlite_master where type='table' and name='his_e-FMC';
    sprintf(pcSql, "select count(*) from sqlite_master where type='table' and name='%s'", tableName);

    ret = db_done(pcSql, pDBHis, hasTableCB, (char*)&nTableNums);

    db_close(pDBHis);

    printf("%s table:%s nTableNums:%d ret:%d\n", __func__, tableName, nTableNums, ret);

    return nTableNums;
}

static int32_t createTable(const char *dbPathAndName, const char *tableName, DEVINFO_T *pstDevInfo)
{
    int32_t ret = OK;
    int32_t si = 0, j = 0, k = 0;
    sqlite3  *pDBHis = NULL;

    if (dbPathAndName == NULL || tableName == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    //1. 拼接sql（加入table name）
    uint16_t dataNameMax = 128;
    uint16_t sqlLen = sizeof(char) * pstDevInfo->ucPointLen * dataNameMax + 300;
    char *pcSql = calloc(sqlLen, sizeof(char));
    si = sprintf(pcSql, "CREATE TABLE IF NOT EXISTS '%s' (id INTEGER PRIMARY KEY ASC AUTOINCREMENT UNIQUE NOT NULL", tableName);

    //2. 获取测点名称，拼接到sql 语句
    POINT_T stPoint[RTDB_MAX_POINT_NUM];
    uint8_t ucPointCount = pstDevInfo->ucPointLen;
    ret = ShareRTDB_Query(pstDevInfo->uwDevCode, pstDevInfo->ucDevId, stPoint, &ucPointCount);
    for (j = 0; j < ucPointCount; j++)
    {
        //3. 查找映射后的北向测点
        int32_t dwValueNum = 0;
        RECORD_KEY_T stKey, **ppstValue = NULL;

        stKey.devCode = pstDevInfo->uwDevCode;
        stKey.devIndex = pstDevInfo->ucDevId;
        stKey.dataId = stPoint[j].iPointId;

        if (pstDevInfo->uwDevCode == CEMS_DEV_CODE)
        {
            const PROTOCOL_DATA_T *p = SDB_ND_GetProtocolData(stKey.devCode, stKey.devIndex, stKey.dataId);

            si += sprintf(pcSql + si, ",`%s` DOUBLE (20, 4)", p->data_name); //DOUBLE (20, 4): 表示一个长度为20的双精度浮点数，小数点后保留4位, 指定字段的数据类型和精度
            if (si >= sqlLen)
            {
                //TODO
            }
        }
        else
        {
            ppstValue = S2NPoint_GetValue(&stKey, &dwValueNum);
//                     printf("%s acTableName:%s j:%d uwDevCode:%d devIndex:%d dataId:%d S2N count:%d\n",
//                         __func__, pstTable->acTableName, j, stKey.devCode, stKey.devIndex, stKey.dataId, dwValueNum);

            for (k = 0; k < dwValueNum; k++)
            {
                const PROTOCOL_DATA_T *p = SDB_ND_GetProtocolData(ppstValue[k]->devCode, ppstValue[k]->devIndex, ppstValue[k]->dataId);
                si += sprintf(pcSql + si, ",`%s` DOUBLE (20, 4)", p->data_name);
                if (si >= sqlLen)
                {
                    //TODO
                }
            }

        }

//                 si += sprintf(pcSql + si, ",`%s` DOUBLE (20, 4)", pointAttr[j].data_name);
    }

    si += sprintf(pcSql + si, ",update_time TimeStamp NOT NULL DEFAULT (datetime('now','localtime')));");

    db_open(dbPathAndName, &pDBHis);

    ret = db_done(pcSql, pDBHis, NULL, NULL);

    memset(pcSql, 0, sizeof(char) * sqlLen);
    sprintf(pcSql, "create index '%s_index_1' on '%s'(update_time)", tableName, tableName);
    ret = db_done(pcSql, pDBHis, NULL, NULL);

    db_close(pDBHis);

    HCFREE(pcSql);

    return ret;
}

static int32_t calcTriggerTime(HISINFO_T *pHisInfo, uint32_t uiTableId)
{
    int32_t ret = OK;
    char acAql[4096] = {'0'};

    HISTABLE_T *pstTable = pHisInfo->pHisTable + uiTableId;

    pstTable->firstTime = time(NULL);

    sprintf(acAql, "select update_time from '%s' LIMIT 1", pstTable->acTableName);

    sqlite3_stmt *pstmt = NULL;

    if((sqlite3_prepare(pstTable->pDBHis, acAql, strlen(acAql), &pstmt, NULL)) == SQLITE_OK)
    {
        sqlite3_step(pstmt);    //真正开始执行前面的sql语句

        /* 读取第一个数据 */
        const unsigned char *text = sqlite3_column_text(pstmt, 0);

        if (text != NULL)
        {
            struct tm tm_ptr;
            strptime((const char*)text, "%Y-%m-%d %H:%M:%S", &tm_ptr);    //2017-12-21 18:53:58

            pstTable->firstTime = mktime(&tm_ptr);

            if (g_pstPersister->debug)
                EMS_LOG(LL_WARNING, MODULE_D, FALSE, "sqlite3_prepare text:%s --> %ld.\n", text, pstTable->firstTime);
        }

        /*释放前面为stmt分配的内存，必须要有，否则会有内存泄露*/
        sqlite3_finalize(pstmt);
    }
    else
    {
        EMS_LOG(LL_INFO, MODULE_D, FALSE, "sqlite3_prepare error.\n");
    }

    pstTable->triggerTime = pstTable->firstTime + pHisInfo->uiWriteIntervalSec + pHisInfo->uiExpireTimeMin * 60;

    if (g_pstPersister->debug)
    {
        char t[30];
        strftime(t, sizeof(t), "%Y-%m-%d %H:%M:%S", localtime(&(pstTable->triggerTime)));

        EMS_LOG(LL_WARNING, MODULE_D, FALSE, "table:%s firstTime:%ld, triggerTime:%ld --> str:%s.\n",
                pstTable->acTableName, pstTable->firstTime, pstTable->triggerTime, t);
    }

    return ret;
}

static int32_t initHisData(char *path)
{
    int32_t ret = ERROR_T(ERR_DEFAULT_NO_MEM);
    DEVINFO_T *pstDevInfo = NULL;
    char *pcPath = NULL;

    do
    {
        HISINFO_T *pHisInfo = g_pstPersister->pHisData;
        if (pHisInfo == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INTERNAL_ERROR);
            break;
        }

        uint8_t ucTableCount;
        pstDevInfo = ShareRTDB_GetDevInfo(&ucTableCount, &ret);
        if (pstDevInfo == NULL)
        {
            break;
        }

        pHisInfo->ubTableNum = ucTableCount;
        pHisInfo->pHisTable = calloc(ucTableCount, sizeof(HISTABLE_T));
        if (pHisInfo->pHisTable == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_NO_MEM);
            break;
        }

        uint32_t uilen = g_pstPersister->pathLen + strlen(HIS_DATA_NAME) + 1;
        pcPath = calloc(uilen, sizeof(char));
        sprintf(pcPath, "%s/%s", path, HIS_DATA_NAME);

        int8_t i = 0;
        for (i = 0; i < ucTableCount; i++)
        {
            char name[100] = {'0'};

            DEVINFO_T stDev;
            memcpy(&stDev, pstDevInfo + i, sizeof(DEVINFO_T));
            HISTABLE_T *pstTable = &(pHisInfo->pHisTable[i]);

            //1. 生成table name
            sprintf(name, "his_%s", stDev.cDevName);
            strcpy(pstTable->acTableName, name);

            EMS_LOG(LL_INFO, MODULE_D, FALSE, "%s table count :%d name:%s (L%d)\n", __func__, i, pstTable->acTableName, __LINE__);

            //2. 检查表是否存在
            if (hasTable(pcPath, pstTable->acTableName) > 0)
            {

            }
            else
            {
                createTable(pcPath, pstTable->acTableName, &stDev);
            }

            db_open(pcPath, &pstTable->pDBHis);
            calcTriggerTime(pHisInfo, i);
            db_close(pstTable->pDBHis);

            ListInit(&(pstTable->stBufferList));

        }

    }while(0);

    HCFREE(pcPath);
    HCFREE(pstDevInfo);

    return ret;
}

static int32_t initHisRecord()
{
    int32_t ret = OK;
    char *pcPath = NULL;

    do {

        HISINFO_T *pHisInfo = g_pstPersister->pHisRecord;;
        if (pHisInfo == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INTERNAL_ERROR);
            break;
        }

        pHisInfo->ubTableNum = HIS_RECORD_MAX;
        pHisInfo->pHisTable = calloc(pHisInfo->ubTableNum, sizeof(HISTABLE_T));
        if (pHisInfo->pHisTable == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_NO_MEM);
            break;
        }

        uint32_t uilen = g_pstPersister->pathLen + strlen(HIS_RECORD_NAME) + 1;
        pcPath = malloc(sizeof(char) * uilen);
        sprintf(pcPath, "%s/%s", g_pstPersister->path, HIS_RECORD_NAME);
        uint32_t dwHisType = 0;

        for (dwHisType = HIS_RECORD_FAULT; dwHisType < HIS_RECORD_MAX; dwHisType++)
        {
            char arrcSql[4096];
            uint32_t si = 0;
            si = sprintf(arrcSql, "CREATE TABLE IF NOT EXISTS '%s' (id INTEGER PRIMARY KEY, devId INTEGER not NULL,devName TEXT not NULL", arrcTableName[dwHisType]);

            if (dwHisType == HIS_RECORD_FAULT)
            {
                si += sprintf(arrcSql + si, ",faultType TEXT not NULL");
            }
            else if (dwHisType == HIS_RECORD_WARNING)
            {
                si += sprintf(arrcSql + si, ",warnType TEXT not NULL, warnLevel INTEGER not NULL");
            }
            si += sprintf(arrcSql + si, ",description TEXT NOT NULL,update_time TimeStamp NOT NULL DEFAULT (datetime('now','localtime')));");

            HISTABLE_T *pstTable = pHisInfo->pHisTable + dwHisType;
            strcpy(pstTable->acTableName, arrcTableName[dwHisType]);

            db_open(pcPath, &pstTable->pDBHis);

            EMS_LOG(LL_INFO, MODULE_D, FALSE, "%s dwHisType:%d name:%s \n", __func__, dwHisType, arrcTableName[dwHisType]);
            if (db_done(arrcSql, pstTable->pDBHis, NULL, NULL) == SQLITE_OK)
            {
                calcTriggerTime(pHisInfo, dwHisType);
            }

            db_close(pstTable->pDBHis);

            ListInit(&(pstTable->stBufferList));
        }

    }while(0);

    HCFREE(pcPath);

    return ret;
}

static int32_t closeAndFreeTable(HISTYPE_E eType)
{
    int32_t ret = OK;
    int8_t i = 0;
    do
    {
        HISINFO_T *pstHisInfo = findHandleByType(eType);
        if(pstHisInfo == NULL)
        {
            break;
        }

        int32_t uiTableNum = pstHisInfo->ubTableNum;
        for (i = 0; i < uiTableNum; i++)
        {
            HISTABLE_T *pstHisTable = pstHisInfo->pHisTable + i;
            db_close(pstHisTable->pDBHis);
            ListDestroy(&pstHisTable->stBufferList);
            pstHisInfo->ubTableNum--;
        }

        HCFREE(pstHisInfo->pHisTable);

    }while(0);

    return ret;
}

static int32_t unInitHisData()
{
    pthread_mutex_lock(&g_persistMutex);

    closeAndFreeTable(HIS_DATA);

    sem_destroy(&g_pstPersister->pHisData->rwlock);

    pthread_mutex_unlock(&g_persistMutex);

    return 0;
}

static int32_t unInitHisRecord()
{
    uint32_t ret = OK;
    pthread_mutex_lock(&g_persistMutex);

    do {
        HISINFO_T *pHisInfo = g_pstPersister->pHisRecord;
        if (pHisInfo == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INTERNAL_ERROR);
            break;
        }

        uint32_t i = 0;
        for (i = 0; i < pHisInfo->ubTableNum; i ++)
        {
            HISTABLE_T *pstHisTable = pHisInfo->pHisTable + i;
            db_close(pstHisTable->pDBHis);
        }

        HCFREE(pHisInfo->pHisTable);
        sem_destroy(&pHisInfo->rwlock);
    }while(0);

    pthread_mutex_unlock(&g_persistMutex);

    return ret;
}

static int32_t deleteExpiredData(HISINFO_T *pHisInfo, uint32_t uiTableId, char **ppSql)
{
    int32_t ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);

    HISTABLE_T *pstHisTable = pHisInfo->pHisTable + uiTableId;
    if (ppSql == NULL || *ppSql == NULL || pstHisTable == NULL || uiTableId >=pHisInfo->ubTableNum )
    {
        return ret;
    }

    if (pHisInfo->eRule == RULE_BY_TIME)
    {
        time_t  nowtime = 0, deleteFromTime = 0;
        char nowt[30] = {'0'};
        char deleteTimeStr[30] = {0};

        time(&nowtime); /* 获取当前时间(秒级) */
        strftime(nowt, sizeof(nowt), "%Y-%m-%d %H:%M:%S", localtime(&nowtime));

        if (nowtime >= pstHisTable->triggerTime)
        {
            int32_t delta = 0;
            if (pHisInfo->uiExpireTimeMin > 24 * 60)
            {
                //delta = 4 * 60; /* 每次删除24小时的数据 */
                delta = 24 * 60; /* 每次删除24小时的数据 */
            }
            else
            {
                delta = 1 * 60;
            }

            deleteFromTime = pstHisTable->firstTime + delta * 60;
            strftime(deleteTimeStr, sizeof(deleteTimeStr), "%Y-%m-%d %H:%M:%S", localtime(&deleteFromTime));
            sprintf(*ppSql, "delete from `%s` WHERE update_time < '%s'", pstHisTable->acTableName, deleteTimeStr);

            pstHisTable->triggerTime += delta * 60;  /* 24小时后再次触发删除动作 */
            pstHisTable->firstTime += delta * 60;    /* 删除数据之后更新第一条记录的时间 */

            if (g_pstPersister->debug)
            {
                printf("%s now:%ld s --> %s, deleteTimeStr:%s, firstTime:%ld s, next triggerTime:%ld s.\n",
                        pstHisTable->acTableName, nowtime, nowt, deleteTimeStr, pstHisTable->firstTime, pstHisTable->triggerTime);
            }

            ret = OK;
        }
    }

    return ret;
}

static int32_t writeHisData()
{
    char sql[4096] = {'0'};
    int32_t i = 0, ret = 0;
    int32_t uiHisDataTableCount = 0;
    uiHisDataTableCount = g_pstPersister->pHisData->ubTableNum;

    for (i = 0; i< uiHisDataTableCount; i++)
    {
        HISTABLE_T *pstHisTable = g_pstPersister->pHisData->pHisTable + i;

        uint32_t j = 0;
        uint32_t uiNum = ListSize(&(pstHisTable->stBufferList));

        if (uiNum == 0)
        {
            continue;
        }

        if (checkOverflow() == TRUE)
        {
            ListRemoveHead(&(pstHisTable->stBufferList));
            continue;
        }
        sprintf(sql, "%s/%s", g_pstPersister->path, HIS_DATA_NAME);
        db_open(sql, &pstHisTable->pDBHis);

        memset(sql, 0, sizeof(char) * 4096);
        char *tmp = sql;
        ret = deleteExpiredData(g_pstPersister->pHisData, i, &tmp);
        if (ret == OK)
        {
            db_begin_trans(pstHisTable->pDBHis);
            db_done(tmp, pstHisTable->pDBHis, NULL, NULL);
            db_commit(pstHisTable->pDBHis);
        }

        db_begin_trans(pstHisTable->pDBHis);

        if (uiNum > 0)
        {
            for (j = 0; j < uiNum; j++)
            {
                char *pcSql = ListHeadData(&(pstHisTable->stBufferList));
                db_done(pcSql, pstHisTable->pDBHis, NULL, NULL);
//                 db_done(pcSql, pstHisTable->pDBHis, NULL, NULL);
//                 db_done(pcSql, pstHisTable->pDBHis, NULL, NULL);
//                 db_done(pcSql, pstHisTable->pDBHis, NULL, NULL);
//                 db_done(pcSql, pstHisTable->pDBHis, NULL, NULL);
//                 db_done(pcSql, pstHisTable->pDBHis, NULL, NULL);

//                 printf("write sql:%s \n", pcSql);

                ListRemoveHead(&(pstHisTable->stBufferList));

                if (uiHisDataTableCount >= 50 && (j % 10 == 0))
                {
                    NanoSleep(20);
                }
            }
        }

        if (!g_pstPersister->pHisData->bWriteThreadExit)
            db_commit(pstHisTable->pDBHis);
        else
        {
            system("sync");
            printf("sync... \n");
            EMS_LOG(LL_WARNING, MODULE_D, FALSE, "sync.....\n");
        }

        db_close(pstHisTable->pDBHis);
    }

    return ret;
}

static int32_t writeHisRecord()
{
    char sql[4096] = {'0'};
    int32_t i = 0, ret = 0;

    HISINFO_T *pstHisInfo = g_pstPersister->pHisRecord;
    if (pstHisInfo == NULL)
    {
        EMS_LOG(LL_INFO, MODULE_D, FALSE, "Can not find Record HisInfo or is during deleting.\n");
        return ERROR_T(ERR_DEFAULT_INTERNAL_ERROR);
    }

    for (i = 0; i < pstHisInfo->ubTableNum; i++)
    {
        HISTABLE_T *pstHisTable = pstHisInfo->pHisTable + i;
        uint32_t j = 0;
        uint32_t uiNum = ListSize(&(pstHisTable->stBufferList));

        if (uiNum == 0)
        {
            continue;
        }

        if (checkOverflow() == TRUE)
        {
            ListRemoveHead(&(pstHisTable->stBufferList));
            continue;
        }

        sprintf(sql, "%s/%s", g_pstPersister->path, HIS_RECORD_NAME);
        db_open(sql, &pstHisTable->pDBHis);

        db_begin_trans(pstHisTable->pDBHis);

        memset(sql, 0, sizeof(char) * 4096);

        char *tmp = sql;
        ret = deleteExpiredData(g_pstPersister->pHisRecord, i, &tmp);
        if (ret == OK)
            db_done(tmp, pstHisTable->pDBHis, NULL, NULL);

        if (uiNum > 0)
        {
            for (j = 0; j < uiNum; j++)
            {
                char *pcSql = ListHeadData(&(pstHisTable->stBufferList));
                db_done(pcSql, pstHisTable->pDBHis, NULL, NULL);

                ListRemoveHead(&(pstHisTable->stBufferList));
            }
        }

        db_commit(pstHisTable->pDBHis);
        db_close(pstHisTable->pDBHis);
    }

    return 0;
}

void *cacheProc(void *arg)
{
    HISINFO_T *pstHisInfo = (HISINFO_T*)arg;
    uint32_t dur = 10;    /* 10s缓存一次 */
    struct timeval tempval;
    struct timeval t1, t2;
    uint32_t costSec = 0, tmp = dur;
    int32_t ret = OK;
    char arrcNowTime[30] = {'0'};

    if (pstHisInfo->ubTableNum >= 50 && pstHisInfo->ubTableNum <= RTDB_MAX_DEV_NUM)
    {
        tmp = dur * 6; /* 1min缓存一次 */
    }
    while(!g_pstPersister->pHisData->bCacheThreadExit)
    {
        tempval.tv_sec = tmp;
        tempval.tv_usec = 0;
        select(0, NULL, NULL, NULL, &tempval);

        if (checkOverflow() == TRUE)
        {
            continue;
        }

        gettimeofday(&t1, NULL);

        strftime(arrcNowTime, sizeof(arrcNowTime), "%Y-%m-%d %H:%M:%S", localtime(&t1.tv_sec));

        uint8_t i = 0, ucTableCount = 0;//数据库中表的个数
        DEVINFO_T *pstDevInfo = NULL;
        uint32_t si = 0;
        POINT_T stPoint[RTDB_MAX_POINT_NUM];

        pstDevInfo = ShareRTDB_GetDevInfo(&ucTableCount, &ret);
        if (pstDevInfo != NULL)
        {
            for (i = 0; i < ucTableCount; i++)
            {
                uint8_t ucPointCount = pstDevInfo[i].ucPointLen;
                uint32_t j = 0, k = 0;
                float32_t dataVal = 0.0;
                char *pcSql = malloc(64 * ucPointCount + 200);

                ret = ShareRTDB_Query(pstDevInfo[i].uwDevCode, pstDevInfo[i].ucDevId, stPoint, &ucPointCount);
                if (ret == OK)
                {
                    int32_t dwNotFoundCount = 0, dwFoundCount = 0;
                    //拼接SQL语句
                    si = sprintf(pcSql, "INSERT INTO `%s` VALUES (NULL", pstHisInfo->pHisTable[i].acTableName);
                    for (j = 0; j < ucPointCount; j++)
                    {
                        //1. 查找映射后的北向测点
                        int32_t dwValueNum = 0;
                        RECORD_KEY_T stKey;

                        stKey.devCode = pstDevInfo[i].uwDevCode;
                        stKey.devIndex = pstDevInfo[i].ucDevId;
                        stKey.dataId = stPoint[j].iPointId;

                        if (stKey.devCode == CEMS_DEV_CODE)
                        {
                            dwValueNum = 1;
                        }
                        else
                        {
                            S2NPoint_GetValue(&stKey, &dwValueNum);
                            if (dwValueNum == 0)
                            {
                                dwNotFoundCount++;
                            }
                        }

                        for (k = 0; k < dwValueNum; k++)
                        {
                            dwFoundCount++;
                            DATA_U data = stPoint[j].unDataValue;
                            BOOL isSpecial = FALSE;

                            switch (stPoint[j].ucDataType){
                                case FLOAT_T:
                                    dataVal = data.f32;
                                    if (isfinite(dataVal) == 0)
                                    {
                                        //printf("[debug] isfinite devCode:%d dataid:%d dataVal:%f\n", stKey.devCode, stKey.dataId, dataVal);
                                        isSpecial = TRUE;
                                    }
                                    break;
                                case U_INT_T:
                                    dataVal = data.u32;
                                    break;
                                case S_INT_T:
                                    dataVal = data.s32;
                                    break;
                                default:
                                    dataVal = data.s32;
                                    break;
                            }
                            if (isSpecial)
                            {
                                si += sprintf(pcSql + si, ",NULL");
                            }
                            else
                            {
                                si += sprintf(pcSql + si, ",%.4f", dataVal);
                            }
                        }
                    }

                    if (dwNotFoundCount >= ucPointCount)//找不到映射后的北向测点认为该南向设备没有映射
                    {
                        printf("%s dev:%s maybe not mapping when write HIS_DATA.\n",
                                __func__, pstDevInfo[i].cDevName);
                        HCFREE(pcSql);
                        continue;
                    }
//                     si += sprintf(pcSql + si, ",datetime('now','localtime'));");
                    si += sprintf(pcSql + si, ",'%s');", arrcNowTime);

//                     printf("871 pcSql:%s si:%d ucPointCount:%d, dwFoundCount:%d, dwNotFoundCount:%d.\n",
//                             pcSql, si, ucPointCount, dwFoundCount, dwNotFoundCount);
                    //插入缓冲队列
                    ListInsertTail(&(pstHisInfo->pHisTable[i].stBufferList), pcSql);
                }
                else
                {
                    HCFREE(pcSql);
                }

            }
        }

        HCFREE(pstDevInfo);

        gettimeofday(&t2, NULL);

        if (g_pstPersister->debug)
        {
            printf("%s cost time:%ld ms,\n", __func__, t2.tv_sec*1000 + t2.tv_usec/1000 - t1.tv_sec*1000 - t1.tv_usec/1000);
        }

        costSec = t2.tv_sec - t1.tv_sec;
        tmp = (costSec >= dur) ? dur : (dur - costSec);
    }

    EMS_LOG(LL_INFO, MODULE_D, FALSE, "%s thread exit. \n", __func__);

    return NULL;
}

void *persistentDataProc(void *arg)
{
    HISINFO_T *pstHisInfo = (HISINFO_T*)arg;
    uint32_t dur = pstHisInfo->uiWriteIntervalSec;

    struct timeval tempval;
    struct timeval t1, t2;
    uint32_t costSec = 0, tmp = dur;

    int32_t cancel_type = pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);
    if (cancel_type != 0)
    {
        printf("%s set cancel type fail.\n", __func__);
    }

    //如果设备数量超过50台（没有依据），写入周期改为5min
    if (pstHisInfo->ubTableNum >= 50 && pstHisInfo->ubTableNum <= RTDB_MAX_DEV_NUM)
    {
        if (dur < 300)
        {
            tmp = 300;
        }
    }

    while(!g_pstPersister->pHisData->bWriteThreadExit)
    {
        tempval.tv_sec = tmp;
        tempval.tv_usec = 0;

        select(0, NULL, NULL, NULL, &tempval);

//         pthread_mutex_lock(&g_persistMutex);

        gettimeofday(&t1, NULL);

        if (g_pstPersister->debug)
        {
            printf("write data start.\n");
        }

        pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);

        if (!g_pstPersister->pHisData->bWriteThreadExit)
        {
            writeHisData();
        }

        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

        gettimeofday(&t2, NULL);

        if (g_pstPersister->debug)
        {
            printf("write data, cost time:%ld ms,\n", t2.tv_sec*1000 + t2.tv_usec/1000 - t1.tv_sec*1000 - t1.tv_usec/1000);
        }

        costSec = t2.tv_sec - t1.tv_sec;

        tmp = (costSec >= dur) ? dur : (dur - costSec);

//         pthread_mutex_unlock(&g_persistMutex);
    }

    EMS_LOG(LL_WARNING, MODULE_D, FALSE, "%s thread exit. \n", __func__);

    return NULL;
}

void *persistentRecordProc(void *arg)
{
    HISINFO_T *pstHisInfo = (HISINFO_T*)arg;
    struct timeval t1, t2;

    while(!pstHisInfo->bWriteThreadExit)
    {
        sem_wait(&pstHisInfo->rwlock);

//         pthread_mutex_lock(&g_persistMutex);

        gettimeofday(&t1, NULL);

        writeHisRecord();

        if (g_pstPersister->debug)
        {
            gettimeofday(&t2, NULL);
            printf("record proc time:%ld ms,\n", t2.tv_sec*1000 + t2.tv_usec/1000 - t1.tv_sec*1000 - t1.tv_usec/1000);
        }

//         pthread_mutex_unlock(&g_persistMutex);
    }

    EMS_LOG(LL_INFO, MODULE_D, FALSE, "%s thread exit.\n", __func__);

    return NULL;
}

int32_t Persister_Init(const char *cDir, const uint8_t ucDirLen)
{
    int32_t ret = OK;

    do{
        if (cDir == NULL || ucDirLen == 0)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        if (g_pstPersister != NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_ALREADY_INIT);
            break;
        }

        g_pstPersister = (PERSISTER_T*)calloc(1, sizeof(PERSISTER_T));
        if (g_pstPersister == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_NO_MEM);
            break;
        }

        g_pstPersister->debug = FALSE;

        g_pstPersister->path = malloc(sizeof(char) * ucDirLen);
        memcpy(g_pstPersister->path, cDir, sizeof(char) * ucDirLen);
        g_pstPersister->pathLen = ucDirLen;

        g_pstPersister->pHisData = calloc(1, sizeof(HISINFO_T));
        g_pstPersister->pHisRecord = calloc(1, sizeof(HISINFO_T));
        if (g_pstPersister->pHisData == NULL || g_pstPersister->pHisRecord == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_NO_MEM);
            break;
        }

        ret = sem_init(&(g_pstPersister->pHisRecord->rwlock),0,0); /* 第二个参数 0 标识线程同步 大于0则标识进程同步 */
        if (ret != 0)
        {
            EMS_LOG(LL_INFO, MODULE_D, FALSE, "%s init sem fail!!!\n", __func__);
            break;
        }

        ret = sem_init(&(g_pstPersister->pHisData->rwlock),0,1); /* 第二个参数 0 标识线程同步 大于0则标识进程同步 */
        if (ret != 0)
        {
            EMS_LOG(LL_INFO, MODULE_D, FALSE, "%s init sem fail!!!\n", __func__);
            break;
        }

    }while(0);

    if (ret != OK)
    {
        HCFREE(g_pstPersister->path);
        HCFREE(g_pstPersister->pHisData);
        HCFREE(g_pstPersister->pHisRecord);
    }

    EMS_LOG(LL_WARNING, MODULE_D, FALSE, "%s in %s.\n", __func__, cDir);

    return ret;
}

void Persister_UnInit()
{
    if (g_pstPersister == NULL)
    {
        return;
    }

    if (g_pstPersister->pHisData)
    {
        g_pstPersister->pHisData->bCacheThreadExit = TRUE;
        g_pstPersister->pHisData->bWriteThreadExit = TRUE;

        if (g_pstPersister->pHisData->cacheThread)
        {
            pthread_join(g_pstPersister->pHisData->cacheThread, NULL);

            EMS_LOG(LL_WARNING, MODULE_D, FALSE, "pHisData->cacheThread join.\n");
        }

        if (g_pstPersister->pHisData->writeThread)
        {
            pthread_cancel(g_pstPersister->pHisData->writeThread);
            pthread_join(g_pstPersister->pHisData->writeThread, NULL);

            system("sync");
            EMS_LOG(LL_WARNING, MODULE_D, FALSE, "pHisData->writeThread join.\n");
        }

        unInitHisData();
    }

    if (g_pstPersister->pHisRecord)
    {
        if (g_pstPersister->pHisRecord->writeThread)
        {
            g_pstPersister->pHisRecord->bWriteThreadExit = TRUE;
            sem_post(&(g_pstPersister->pHisRecord->rwlock));
            pthread_join(g_pstPersister->pHisRecord->writeThread, NULL);

            EMS_LOG(LL_WARNING, MODULE_D, FALSE, "pHisRecord->writeThread join.\n");
        }

        unInitHisRecord();
    }

    HCFREE(g_pstPersister->path);
    HCFREE(g_pstPersister->pHisData);
    HCFREE(g_pstPersister->pHisRecord);
    HCFREE(g_pstPersister);

    return ;
}

int32_t Persister_Set(PERSIST_CONFIG_T *pstConfig)
{
    int32_t ret = OK;

    do
    {
        if (pstConfig == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        HISINFO_T *pHisInfo = findHandleByType(pstConfig->eHisType);

        if (pHisInfo != NULL)
        {
            pHisInfo->uiWriteIntervalSec = pstConfig->uiWriteIntervalSec;
            pHisInfo->uiExpireTimeMin = pstConfig->uiExpireTimeMin;
            pHisInfo->eRule = pstConfig->eRule;
        }
        else{
            ret = ERROR_T(ERR_DEFAULT_INTERNAL_ERROR);
            break;
        }

    }while(0);

    return ret;
}

#if 0
static void* fault(void *arg)
{
    while(1)
    {
        time_t now;
        time(&now);

        PERSIST_NODE_INFO_T node;
        node.FAULT_INFO_T.pcFaultType = "电压";
        strcpy(node.arrcDevName, "Fault");
        node.uiDevID = 0;
        strftime(node.date, sizeof(node.date), "%Y-%m-%d %H:%M:%S", localtime(&now));
        node.pcDescription = "故障测试";

        Persister_StoreNode(HIS_RECORD_FAULT, &node);

        NanoSleep(1000);
    }

    return NULL;
}

static void* warning(void *arg)
{
    while(1)
    {
        time_t now;
        time(&now);

        PERSIST_NODE_INFO_T node;
        node.WARNING_INFO_T.pcWarnType = "告警";
        node.WARNING_INFO_T.uiWarnLevel = 2;
        strcpy(node.arrcDevName, "Warn");
        node.uiDevID = 1;
        node.pcDescription = "告警测试";

        strftime(node.date, sizeof(node.date), "%Y-%m-%d %H:%M:%S", localtime(&now));

        Persister_StoreNode(HIS_RECORD_WARNING, &node);
        NanoSleep(1000);
    }
    return NULL;
}

static void* runstate(void *arg)
{
    while(1)
    {
        time_t now;
        time(&now);

        PERSIST_NODE_INFO_T node;
        strcpy(node.arrcDevName, "Warn");
        node.uiDevID = 1;
        strftime(node.date, sizeof(node.date), "%Y-%m-%d %H:%M:%S", localtime(&now));
        node.pcDescription = "运行记录测试";

        Persister_StoreNode(HIS_RECORD_RUN_STATE, &node);
        NanoSleep(1000);
    }
    return NULL;
}
#endif

int32_t Persister_Run(HISTYPE_E eHisType)
{
    int32_t ret = OK;

    pthread_attr_t thread_attr;
    size_t stacksize;

    ret = pthread_attr_init(&thread_attr);
    if (ret != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, FALSE, "Attribute creation failed\n");
        exit(EXIT_FAILURE);
    }

    stacksize = 512*1024;       //512KB 栈空间
    ret = pthread_attr_setstacksize(&thread_attr, stacksize);

    ret = pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
    if (ret != 0)
    {
        EMS_LOG(LL_FATAL, MODULE_D, FALSE, "Setting detached attribute failed\n");
        exit(EXIT_FAILURE);
    }

    if (eHisType == HIS_DATA)
    {
        ret = initHisData(g_pstPersister->path);
        g_pstPersister->pHisData->bCacheThreadExit = FALSE;
        g_pstPersister->pHisData->bWriteThreadExit = FALSE;

        ret = pthread_create(&(g_pstPersister->pHisData->writeThread), &thread_attr, persistentDataProc, g_pstPersister->pHisData);
        if (ret != 0)
        {
            EMS_LOG(LL_ERROR, MODULE_D, FALSE, "Thread persistentProc creation failed.\n");
            exit(EXIT_FAILURE);
        }

        ret = pthread_create(&(g_pstPersister->pHisData->cacheThread), &thread_attr, cacheProc, g_pstPersister->pHisData);
        if (ret != 0)
        {
            EMS_LOG(LL_ERROR, MODULE_D, FALSE, "Thread cacheProc creation failed.\n");
            exit(EXIT_FAILURE);
        }
    }
    else if (eHisType == HIS_RECORD)
    {
        ret = initHisRecord();
        g_pstPersister->pHisRecord->bWriteThreadExit = FALSE;

        ret = pthread_create(&(g_pstPersister->pHisRecord->writeThread), &thread_attr, persistentRecordProc, g_pstPersister->pHisRecord);
        if (ret != 0)
        {
            EMS_LOG(LL_ERROR, MODULE_D, FALSE, "Thread persistentRecordProc creation failed.\n");
            exit(EXIT_FAILURE);
        }
    }

#if 0
    pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_DETACHED);
    pthread_t tid1, tid2, tid3;

    pthread_create(&tid1, NULL, fault, (void*)arrcTableName[HIS_RECORD_FAULT]);

    pthread_create(&tid2, NULL, warning, (void*)arrcTableName[HIS_RECORD_WARNING]);

    pthread_create(&tid3, NULL, runstate, (void*)arrcTableName[HIS_RECORD_RUN_STATE]);
#endif

    EMS_LOG(LL_WARNING, MODULE_D, FALSE, "%s done.\n", __func__);

    return ret;
}

int32_t Persister_Stop(HISTYPE_E eHisType)
{
    int32_t ret = OK;
    HISINFO_T *pHisInfo;

    do{

        pHisInfo = findHandleByType(eHisType);
        if (pHisInfo == NULL)
        {
            break;
        }

        pHisInfo->isStop = TRUE;

        if (pHisInfo->cacheThread)
        {
            pHisInfo->bCacheThreadExit = TRUE;
            pthread_cancel(pHisInfo->cacheThread);
            pthread_join(pHisInfo->cacheThread, NULL);
        }

        if (pHisInfo->writeThread)
        {
            pHisInfo->bWriteThreadExit = TRUE;

            if (eHisType == HIS_DATA)
            {
                pthread_cancel(pHisInfo->writeThread);
            }
            else if(eHisType == HIS_RECORD)
            {
                sem_post(&pHisInfo->rwlock);
            }
            pthread_join(pHisInfo->writeThread, NULL);
        }

        EMS_LOG(LL_WARNING, MODULE_D, FALSE, "%s done.\n", __func__);
    }while(0);


    return ret;
}

int32_t Persister_StoreNode(HIS_RECORD_TYPE_E eHisType, PERSIST_NODE_INFO_T *pstNodeInfo)
{
    int32_t ret = OK;

    do{
        if (pstNodeInfo == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        if (g_pstPersister == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_OPERATOR_NOT_ALLOW);
            break;
        }

        HISINFO_T *pHisInfo = g_pstPersister->pHisRecord;
        if (pHisInfo == NULL ||
            (pHisInfo != NULL && pHisInfo->isStop)
        )
        {
            ret = ERROR_T(ERR_DEFAULT_OPERATOR_NOT_ALLOW);
            break;
        }

        char *pcSql = malloc(sizeof(char) * 200);
        switch (eHisType)
        {
            case HIS_RECORD_FAULT:
            {
                sprintf(pcSql,"INSERT INTO '%s' (devId, devName, faultType, description, update_time) VALUES (%d,'%s','%s','%s','%s')",
                    pHisInfo->pHisTable[HIS_RECORD_FAULT].acTableName,pstNodeInfo->uiDevID, pstNodeInfo->arrcDevName,
                    pstNodeInfo->FAULT_INFO_T.pcFaultType, pstNodeInfo->pcDescription, pstNodeInfo->date
                );
                ListInsertTail(&(pHisInfo->pHisTable[HIS_RECORD_FAULT].stBufferList), pcSql);
                sem_post(&pHisInfo->rwlock);
            }
                break;
            case HIS_RECORD_WARNING:
            {
                sprintf(pcSql,"INSERT INTO '%s' (devId, devName, warnType, warnLevel, description, update_time) VALUES (%d,'%s','%s',%d,'%s','%s')",
                    pHisInfo->pHisTable[HIS_RECORD_WARNING].acTableName, pstNodeInfo->uiDevID,
                    pstNodeInfo->arrcDevName, pstNodeInfo->WARNING_INFO_T.pcWarnType,
                    pstNodeInfo->WARNING_INFO_T.uiWarnLevel, pstNodeInfo->pcDescription, pstNodeInfo->date
                );
                ListInsertTail(&(pHisInfo->pHisTable[HIS_RECORD_WARNING].stBufferList), pcSql);
                sem_post(&pHisInfo->rwlock);
            }
                break;
            case HIS_RECORD_RUN_STATE:
            {
                sprintf(pcSql,"INSERT INTO '%s' (devId, devName, description, update_time) VALUES (%d,'%s','%s','%s')",
                    pHisInfo->pHisTable[HIS_RECORD_RUN_STATE].acTableName, pstNodeInfo->uiDevID,
                    pstNodeInfo->arrcDevName, pstNodeInfo->pcDescription, pstNodeInfo->date
                );
                ListInsertTail(&(pHisInfo->pHisTable[HIS_RECORD_RUN_STATE].stBufferList), pcSql);
                sem_post(&pHisInfo->rwlock);
            }
                break;
            default:
                HCFREE(pcSql);
                break;
        }
    }while(0);

    return ret;
}

int32_t Persister_DeleteFile(HISTYPE_E eHisType)
{
    int32_t ret = OK;
    HISINFO_T *pHisInfo;

    do{

        pHisInfo = findHandleByType(eHisType);
        if (pHisInfo == NULL)
        {
            break;
        }

        char pcPath[256] = {'0'};
        if (eHisType == HIS_DATA)
        {
            sprintf(pcPath, "%s/%s", g_pstPersister->path, HIS_DATA_NAME);
        }
        else if(eHisType == HIS_RECORD)
        {
            sprintf(pcPath, "%s/%s", g_pstPersister->path, HIS_RECORD_NAME);
        }

        closeAndFreeTable(eHisType);
        remove(pcPath);

        EMS_LOG(LL_WARNING, MODULE_D, FALSE, "%s:%s done.\n", __func__, pcPath);

    }while(0);

    return ret;
}

int32_t Persister_QueryElement(IN HISDATA_ELEMENT_T *pElement, IN int32_t dwEleCount, IN int32_t num,
                               OUT float32_t **ppstValue, OUT int32_t *valueCount)
{
    int32_t i = 0, si = 0, ret = 0;

    //1. check
    if (g_pstPersister == NULL)
    {
        return ERROR_T(ERR_DEFAULT_OPERATOR_NOT_ALLOW);
    }

    if (pElement == NULL || dwEleCount == 0 || num == 0 || num > 50)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    //2. 拼接sql
    uint16_t dataNameMax = 128;
    uint16_t sqlLen = sizeof(char) * dwEleCount * dataNameMax + 300;
    char *pcSql = calloc(sqlLen, sizeof(char));
    si = sprintf(pcSql, "select ");//'%s' form 'his_%s'

    do
    {
        for (i = 0; i < dwEleCount; i++)
        {
            HISDATA_ELEMENT_T *pTmp = pElement + i;

            const PROTOCOL_DATA_T  *ptl = SDB_ND_GetProtocolData(pTmp->devCode, pTmp->devIndex, pTmp->dataId);

            if (i != dwEleCount - 1)
            {
                 si += sprintf(pcSql + si, "`%s`,", ptl->data_name);
            }
            else
            {
                si += sprintf(pcSql + si, "`%s` ", ptl->data_name);
            }
        }

        DEV_UID_T pN = {pElement->devCode, pElement->devIndex};
        DEV_UID_T pS;
        ret = N2SDev_GetValue(&pN, &pS);
        si += sprintf(pcSql + si, "from `his_%s` order by id desc LIMIT %d ", pS.devName, num);
        printf("%s sql:%s\n", __func__, pcSql);

        //3. 查询
        QUERY_DATA_T stUserQuery;
        stUserQuery.eType = 0;
        stUserQuery.pvdata = NULL;
        stUserQuery.pvdataLen = 0;

        char path[100] = {0};
        sprintf(path, "%s/%s", g_pstPersister->path, HIS_DATA_NAME);
        ret = db_query(path, pcSql, queryDescCb, &stUserQuery);
        printf("%s ret:%d\n", __func__, ret);
        if (ret == OK)
        {
            *valueCount = stUserQuery.pvdataLen;
            *ppstValue= stUserQuery.pvdata;
        }
    }while(0);

    HCFREE(pcSql);

    return ret;
}
