#ifndef PERSIST_H_INCLUDED
#define PERSIST_H_INCLUDED

#include <sqlite3.h>
#include <semaphore.h>
#include "common.h"
#include "ShareRTDB.h"
#include "slist.h"
#include "err.h"

#define HIS_DATA_NAME "HISDATA.db"
#define HIS_RECORD_NAME "HISRECORD.db"

#define MAX_RESERVER_SZ  1024 //单位M  1024

typedef enum
{
    RULE_BY_TIME,
    RULE_BY_NUM,
    RULE_BY_MAX
}HISRULE_E;

typedef enum
{
    HIS_RECORD,
    HIS_DATA,
    HIS_TYPE_MAX
}HISTYPE_E;

typedef enum
{
    HIS_RECORD_FAULT,
    HIS_RECORD_WARNING,
    HIS_RECORD_RUN_STATE,
    HIS_RECORD_MAX
}HIS_RECORD_TYPE_E;

typedef struct{
    int32_t devCode;
    int32_t devIndex;
    int32_t dataId;
}HISDATA_ELEMENT_T;

typedef struct {
    uint32_t uiDevID;
    char arrcDevName[RTDB_MAX_DEV_NAME_LEN];

    union
    {
        struct {
            char *pcFaultType;      //故障大类
        }FAULT_INFO_T;

        struct{
            char *pcWarnType;       //告警大类
            uint32_t uiWarnLevel;   //告警级别
        }WARNING_INFO_T;
    };

    char *pcDescription;    //故障子类具体内容,告警子类具体内容,运行状态
    char date[30];
} PERSIST_NODE_INFO_T;     //故障

typedef struct
{
    HISTYPE_E eHisType;
    uint32_t  uiWriteIntervalSec; //second
    uint32_t  uiExpireTimeMin; //min
    HISRULE_E eRule; //存储规则
}PERSIST_CONFIG_T;

/**
 * @brief  Init persister.
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t Persister_Init(const char *cDir, const uint8_t ucDirLen);

/**
 * @brief  Destroy perister.
 * @param
 * @return OK：成功；ERRNO：错误码
 */
void Persister_UnInit();

/**
 * @brief  Set config.
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t Persister_Set(PERSIST_CONFIG_T *pstConfig);

/**
 * @brief  start.
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t Persister_Run(HISTYPE_E eHisType);

/**
 * @brief  stop.
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t Persister_Stop(HISTYPE_E eHisType);

/**
 * Persist nodes.
 * @param
 * @param
 * @return 0 on success, non-zero on failure
 */
int32_t Persister_StoreNode(HIS_RECORD_TYPE_E eHisType, PERSIST_NODE_INFO_T *pstNodeInfo);

/**
 * Delete db files.
 * @param
 * @param
 * @return 0 on success, non-zero on failure
 */
int32_t Persister_DeleteFile(HISTYPE_E eHisType);

/**
 * Query elements.
 * @param pstValue:输入为NULL，获取成功后需释放；
 * @param
 * @return 0 on success, non-zero on failure
 */
int32_t Persister_QueryElement(IN HISDATA_ELEMENT_T *pElement, IN int32_t dwEleCount, IN int32_t num,
                               OUT float32_t **ppstValue, OUT int32_t *valueCount);

#endif // PERSIST_H_INCLUDED
