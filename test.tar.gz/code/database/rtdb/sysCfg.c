#include "sysCfg.h"
#include "db.h"
#include "file_operate.h"
#include "logUtil.h"

#define FILL_INT(st, member, dbresult, nrow, ncolumn) \
{\
    int32_t j = findColumnNum(dbresult, ncolumn, #member); \
    if (j != INVALID_VALUE && j < ncolumn) \
    {\
        char *element = dbresult[nrow * ncolumn + j]; \
        if (element != NULL) \
            st->member = atoi(dbresult[nrow * ncolumn + j]); \
    }\
}

#define FILL_FLOAT(st, member, dbresult, nrow, ncolumn) \
{\
    int32_t j = findColumnNum(dbresult, ncolumn, #member); \
    if (j != INVALID_VALUE && j < ncolumn) \
    {\
        char *element = dbresult[nrow * ncolumn + j]; \
        if (element != NULL) \
            st->member = atof(dbresult[nrow * ncolumn + j]); \
    }\
}

#define FILL_STRING(st, member, dbresult, nrow, ncolumn) \
{\
    int32_t j = findColumnNum(dbresult, ncolumn, #member); \
    if (j != INVALID_VALUE && j < ncolumn) \
    {\
        char *element = dbresult[nrow * ncolumn + j]; \
        if (element != NULL) \
            strcpy(st->member, element); \
    }\
}

typedef struct dbTableInfo_t{
	const char *dbFile;
	const char *table_name;
	pthread_mutex_t lock;
}TABLE_INFO_T;

TABLE_INFO_T g_tableList[] =
{
    //CFG_TYPE_ALGOR
    {.dbFile = "/home/SGWeb/webserver/cfg/system/websyscfg.db", .table_name = "serialcfg", .lock = PTHREAD_MUTEX_INITIALIZER},

    //CFG_TYPE_RUN_CTRL
    {.dbFile = "/home/SGWeb/webserver/cfg/system/websyscfg.db", .table_name = "runcfg", .lock = PTHREAD_MUTEX_INITIALIZER},

    //CFG_TYPE_PROTECT_STORAGE
    {.dbFile = "/home/SGWeb/webserver/cfg/system/websyscfg.db", .table_name = "protectstorage", .lock = PTHREAD_MUTEX_INITIALIZER},

    //CFG_TYPE_PROTECT_NET
    {.dbFile = "/home/SGWeb/webserver/cfg/system/websyscfg.db", .table_name = "protectnet", .lock = PTHREAD_MUTEX_INITIALIZER},

    //CFG_TYPE_NORTH_PARAM
    {.dbFile = "/home/SGWeb/webserver/cfg/system/websyscfg.db", .table_name = "netcfg", .lock = PTHREAD_MUTEX_INITIALIZER},

    //CFG_TYPE_IO
    {.dbFile = "/home/SGWeb/webserver/cfg/system/websyscfg.db", .table_name = "iocfg", .lock = PTHREAD_MUTEX_INITIALIZER},

    //CFG_TYPE_NORTH_DEV_LIST
    {.dbFile = "/home/SGWeb/webserver/cfg/ptmap/mapdev.db", .table_name = "mapdev", .lock = PTHREAD_MUTEX_INITIALIZER},

    //CFG_TYPE_TIME_CFG
    {.dbFile = "/home/SGWeb/webserver/cfg/system/websyscfg.db", .table_name = "timecfg", .lock = PTHREAD_MUTEX_INITIALIZER},
};

static int32_t findColumnNum(char **dbresult, int32_t totalColumn, char *name)
{
    int32_t num = INVALID_VALUE;
    int32_t j = 0;

    for(j = 0; j < totalColumn; j++)
    {
        if (strcmp(dbresult[j], name) == 0)
        {
            num = j;
            break;
        }
    }

    return num;
}

static int32_t fillAlogr(char **dbresult, int32_t nrow, int32_t ncolumn, QUERY_DATA_T *arg)
{
    int32_t ret = OK;

    if (nrow <= 0)
    {
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }

    ALOGR_T *pstAlogr = (ALOGR_T*)calloc(nrow, sizeof(ALOGR_T));
    memset(pstAlogr, 0, sizeof(ALOGR_T) * nrow);

    //从第0索引到第 nColumn - 1索引都是字段名称
    //从第 nColumn 索引开始，后面都是字段值
    int32_t i;
    for(i = 0 ; i < nrow; i++ )
    {
        ALOGR_T *pstTmp = pstAlogr + i;

        uint32_t row = i + 1;
        FILL_INT(pstTmp, UartNo, dbresult, row, ncolumn);
        FILL_INT(pstTmp, Enable, dbresult, row, ncolumn);
        FILL_INT(pstTmp, HistoryNum, dbresult, row, ncolumn);
        FILL_INT(pstTmp, SampleNum, dbresult, row, ncolumn);
        FILL_INT(pstTmp, FilterAlgor, dbresult, row, ncolumn);

        if (pstTmp->FilterAlgor == FILTER_ALGOR_WEIGHT_RECURSIVE_AVE)
        {
            AVE_FILTER_T *pstAve = &(pstTmp->ALOGR_PARAM_U.stAve);
            FILL_INT(pstAve, AveNum, dbresult, row, ncolumn);
            FILL_STRING(pstAve, AveWeight, dbresult, row, ncolumn);
        }

        if (pstTmp->FilterAlgor == FILTER_ALGOR_LPF)
        {
            LPF_PARAM_T *pstLPF = &(pstTmp->ALOGR_PARAM_U.stLPF);
            FILL_FLOAT(pstLPF, FirstInitValue, dbresult, row, ncolumn);
            FILL_FLOAT(pstLPF, FirstTimeValue, dbresult, row, ncolumn);
        }

        if (pstTmp->FilterAlgor == FILTER_ALGOR_LIMIT_SHAKE)
        {
            LIMIT_SHAKE_T *pstLimit = &(pstTmp->ALOGR_PARAM_U.stLimit);
            FILL_FLOAT(pstLimit, ALimitMaxVarValue, dbresult, row, ncolumn);
            FILL_INT(pstLimit, ALimitMaxVarCnt, dbresult, row, ncolumn);
            FILL_FLOAT(pstLimit, ALimitValidValue, dbresult, row, ncolumn);
        }

        FILL_INT(pstTmp, MissAlgor, dbresult, row, ncolumn);
        FILL_INT(pstTmp, ValueNum, dbresult, row, ncolumn);
        FILL_INT(pstTmp, AbnormalAlgor, dbresult, row, ncolumn);

//         int j = 0;
//         for(j = 0; j < ncolumn; j++)
//         {
//             printf( "%s:%s,", dbresult[j], dbresult[(i+1)*ncolumn+j]);
//         }
//         printf("\n");
//
//         printf("%d %d %d SampleNum:%d FilterAlogr:%d AbnormalAlogr:%d\n",
//                pstTmp->UartNo, pstTmp->Enable,
//                pstTmp->HistoryNum, pstTmp->SampleNum, pstTmp->FilterAlgor,
//                pstTmp->AbnormalAlgor
//               );
    }

    arg->pvdata = pstAlogr;
    arg->pvdataLen = nrow;

    return ret;
}

static int32_t fillRunCfg(char **dbresult, int32_t nrow, int32_t ncolumn, QUERY_DATA_T *arg)
{
    int32_t ret = OK;

    if (nrow <= 0)
    {
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }

    RUN_PARAM_T *pstRun = (RUN_PARAM_T*)calloc(nrow, sizeof(RUN_PARAM_T));

    //从第0索引到第 nColumn - 1索引都是字段名称
    //从第 nColumn 索引开始，后面都是字段值
    int32_t i;
    for(i = 0 ; i < nrow; i++ )
    {
        RUN_PARAM_T *pstTmp = pstRun + i;
        uint32_t row = i + 1;

        FILL_INT(pstTmp, DevNo, dbresult, row, ncolumn);
        FILL_INT(pstTmp, JoinOffSelect, dbresult, row, ncolumn);
        FILL_INT(pstTmp, ModeSelect, dbresult, row, ncolumn);
        FILL_FLOAT(pstTmp, ModeParSet, dbresult, row, ncolumn);
        FILL_INT(pstTmp, CtrlMode, dbresult, row, ncolumn);
        FILL_INT(pstTmp, LoopMode, dbresult, row, ncolumn);

        LOOP_PARAM_T *pstLoopParam = &(pstTmp->stLoopParam);
        FILL_FLOAT(pstLoopParam, LoopP, dbresult, row, ncolumn);
        FILL_FLOAT(pstLoopParam, LoopI, dbresult, row, ncolumn);
        FILL_FLOAT(pstLoopParam, LoopD, dbresult, row, ncolumn);
        FILL_FLOAT(pstLoopParam, LoopError, dbresult, row, ncolumn);
        FILL_FLOAT(pstLoopParam, LoopCycle, dbresult, row, ncolumn);

        FILL_INT(pstTmp, PowerMode, dbresult, row, ncolumn);
        FILL_INT(pstTmp, ActorPower, dbresult, row, ncolumn);
        FILL_FLOAT(pstTmp, ActorPowerPar, dbresult, row, ncolumn);
        FILL_INT(pstTmp, ReactPower, dbresult, row, ncolumn);
        FILL_FLOAT(pstTmp, ReactPowerPar, dbresult, row, ncolumn);
    }

    arg->pvdata = pstRun;
    arg->pvdataLen = nrow;

    return ret;
}

static int32_t fillProtectStorage(char **dbresult, int32_t nrow, int32_t ncolumn, QUERY_DATA_T *arg)
{
    int32_t ret = OK;

    if (nrow <= 0)
    {
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }


    PROTECTSTORAGE_T *pstPS = (PROTECTSTORAGE_T*)calloc(nrow, sizeof(PROTECTSTORAGE_T));

    //从第0索引到第 nColumn - 1索引都是字段名称
    //从第 nColumn 索引开始，后面都是字段值
    int32_t i;
    for(i = 0; i < nrow; i++ )
    {
        PROTECTSTORAGE_T *pstTmp = pstPS + i;
        uint32_t row = i + 1;

        FILL_INT(pstTmp, DevNo, dbresult, row, ncolumn);

        PROTECT_CELL_T *pstCell = &(pstTmp->stProtectCell);
        FILL_FLOAT(pstCell, OVL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, OVL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, OVL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, UVL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, UVL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, UVL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, OTL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, OTL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, OTL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, LTL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, LTL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstCell, LTL3, dbresult, row, ncolumn);

        PROTECT_PACK_T *pstPack = &(pstTmp->stProtectPack);
        FILL_FLOAT(pstPack, PackOV1, dbresult, row, ncolumn);
        FILL_FLOAT(pstPack, PackOV2, dbresult, row, ncolumn);
        FILL_FLOAT(pstPack, PackOV3, dbresult, row, ncolumn);
        FILL_FLOAT(pstPack, PackUV1, dbresult, row, ncolumn);
        FILL_FLOAT(pstPack, PackUV2, dbresult, row, ncolumn);
        FILL_FLOAT(pstPack, PackUV3, dbresult, row, ncolumn);

        PROTECT_RACK_SOC_T *pstRackSOC = &(pstTmp->stProtectRack.stRackSOC);
        FILL_FLOAT(pstRackSOC, SocUpL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackSOC, SocUpL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackSOC, SocUpL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackSOC, SocDownL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackSOC, SocDownL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackSOC, SocDownL3, dbresult, row, ncolumn);

        PROTECT_RACK_SOH_T *pstRackSOH = &(pstTmp->stProtectRack.stRackSOH);
        FILL_FLOAT(pstRackSOH, SohDownL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackSOH, SohDownL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackSOH, SohDownL3, dbresult, row, ncolumn);

        PROTECT_RACK_V_T *pstRackV = &(pstTmp->stProtectRack.stRackV);
        FILL_FLOAT(pstRackV, RackVUpL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackV, RackVUpL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackV, RackVUpL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackV, RackVDownL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackV, RackVDownL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackV, RackVDownL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackV, RackParUpL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackV, RackParUpL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackV, RackParUpL3, dbresult, row, ncolumn);

        PROTECT_RACK_A_T *pstRackA = &(pstTmp->stProtectRack.stRackA);
        FILL_FLOAT(pstRackA, RackOCL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackA, RackOCL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackA, RackOCL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackA, RackCurL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackA, RackCurL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstRackA, RackCurL3, dbresult, row, ncolumn);
    }

    arg->pvdata = pstPS;
    arg->pvdataLen = nrow;

    return ret;
}

static int32_t fillProtectNet(char **dbresult, int32_t nrow, int32_t ncolumn, QUERY_DATA_T *arg)
{
    int32_t ret = OK;

    if (nrow <= 0)
    {
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }

    PROTECTNET_T *pstPN = (PROTECTNET_T*)calloc(nrow, sizeof(PROTECTNET_T));

    //从第0索引到第 nColumn - 1索引都是字段名称
    //从第 nColumn 索引开始，后面都是字段值
    int32_t i;
    for(i = 0; i < nrow; i++ )
    {
        PROTECTNET_T *pstTmp = pstPN + i;
        uint32_t row = i + 1;

        FILL_INT(pstTmp, DevNo, dbresult, row, ncolumn);

        PROTECT_DEMAND_T *pstDemand = &(pstTmp->stDemand);
        FILL_FLOAT(pstDemand, Demand, dbresult, row, ncolumn);
        FILL_FLOAT(pstDemand, DemandL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstDemand, DemandL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstDemand, DemandL3, dbresult, row, ncolumn);

        PROTECT_VOLT_T *pstVolt = &(pstTmp->stVolt);
        FILL_FLOAT(pstVolt, Volt, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, VoltUpL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, VoltUpL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, VoltUpL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, VoltDownL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, VoltDownL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, VoltDownL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, Fre, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, FreUpL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, FreUpL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, FreUpL3, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, FreDownL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, FreDownL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstVolt, FreDownL3, dbresult, row, ncolumn);

        PROTECT_FEEDER_T *pstFeeder = &(pstTmp->stFeeder);
        FILL_FLOAT(pstFeeder, Feeder, dbresult, row, ncolumn);
        FILL_FLOAT(pstFeeder, FeederUpL1, dbresult, row, ncolumn);
        FILL_FLOAT(pstFeeder, FeederUpL2, dbresult, row, ncolumn);
        FILL_FLOAT(pstFeeder, FeederUpL3, dbresult, row, ncolumn);
    }

    arg->pvdata = pstPN;
    arg->pvdataLen = nrow;

    return ret;
}

static int32_t fillNorthParam(char **dbresult, int32_t nrow, int32_t ncolumn, QUERY_DATA_T *arg)
{
    int32_t ret = OK;

    if (nrow <= 0)
    {
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }

    NORTH_PARAM_T *pstNP = (NORTH_PARAM_T*)calloc(nrow, sizeof(NORTH_PARAM_T));

    //从第0索引到第 nColumn - 1索引都是字段名称
    //从第 nColumn 索引开始，后面都是字段值
    int32_t i;
    for(i = 0; i < nrow; i++ )
    {
        NORTH_PARAM_T *pstTmp = pstNP + i;
        uint32_t row = i + 1;

        FILL_INT(pstTmp, EnDhcp1, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, IP1, dbresult, row, ncolumn);

        FILL_INT(pstTmp, CfgSelect, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, MqttAddr, dbresult, row, ncolumn);
        FILL_INT(pstTmp, MqttPort, dbresult, row, ncolumn);
        FILL_INT(pstTmp, MqttEncry, dbresult, row, ncolumn);
        FILL_INT(pstTmp, MqttAlgor, dbresult, row, ncolumn);
        FILL_INT(pstTmp, MqttMethod, dbresult, row, ncolumn);
        FILL_INT(pstTmp, MqttCycle, dbresult, row, ncolumn);
        FILL_INT(pstTmp, ModbusPort, dbresult, row, ncolumn);
        FILL_INT(pstTmp, Port104, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, MqttPubTopic, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, MqttSubTopic, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, MqttClientID, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, MqttUser, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, MqttPwd, dbresult, row, ncolumn);

        printf("ip: %s port: %d\n", pstTmp->IP1, pstTmp->EnDhcp1);
        printf("%s i:%d CfgSelect:%d \n", __func__, i, pstTmp->CfgSelect);
        printf("MqttAddr:%s, MqttPort:%d, MqttEncry:%d, MqttAlgor:%d, MqttMethod:%d, MqttCycle:%d, \n",
               pstTmp->MqttAddr, pstTmp->MqttPort, pstTmp->MqttEncry, pstTmp->MqttAlgor, pstTmp->MqttMethod, pstTmp->MqttCycle
              );
        printf("MqttClientID:%s, MqttUser:%s, MqttPwd:%s, MqttPubTopic:%s, MqttSubTopic:%s\n",
               pstTmp->MqttClientID, pstTmp->MqttUser, pstTmp->MqttPwd, pstTmp->MqttPubTopic, pstTmp->MqttSubTopic
              );
        printf("ModbusPort:%d, Port104:%d \n", pstTmp->ModbusPort, pstTmp->Port104);
    }

    arg->pvdata = pstNP;
    arg->pvdataLen = nrow;

    return ret;
}

static int32_t fillIOParam(char **dbresult, int32_t nrow, int32_t ncolumn, QUERY_DATA_T *arg)
{
    int32_t ret = OK;
    if (nrow <= 0)
    {
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }

    IO_PARAM_T *pstIO = (IO_PARAM_T*)calloc(nrow, sizeof(IO_PARAM_T));

    //从第0索引到第 nColumn - 1索引都是字段名称
    //从第 nColumn 索引开始，后面都是字段值
    int32_t i;
    for(i = 0; i < nrow; i++ )
    {
        IO_PARAM_T *pstTmp = pstIO + i;
        uint32_t row = i + 1;

        FILL_INT(pstTmp, ID, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, Name, dbresult, row, ncolumn);
        FILL_INT(pstTmp, Type, dbresult, row, ncolumn);

        FILL_INT(pstTmp, DIEnable, dbresult, row, ncolumn);
        FILL_INT(pstTmp, DIFunction, dbresult, row, ncolumn);
        FILL_INT(pstTmp, DIMode, dbresult, row, ncolumn);
        FILL_INT(pstTmp, DOFunction, dbresult, row, ncolumn);

//         printf("ID:%d Name:%s Type:%d DIEnable:%d DIFunction:%d DIMode:%d DOFunction:%d.\n",
//                pstTmp->ID, pstTmp->Name, pstTmp->Type, pstTmp->DIEnable, pstTmp->DIFunction, pstTmp->DIMode, pstTmp->DOFunction);
    }

    arg->pvdata = pstIO;
    arg->pvdataLen = nrow;

    return ret;
}

static int32_t fillNorthDevList(char **dbresult, int32_t nrow, int32_t ncolumn, QUERY_DATA_T *arg)
{
    int32_t ret = OK;
    if (nrow <= 0)
    {
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }

    NORTH_DEV_RECORD_T *pstDevList = (NORTH_DEV_RECORD_T*)calloc(nrow, sizeof(NORTH_DEV_RECORD_T));
    memset(pstDevList, 0, sizeof(NORTH_DEV_RECORD_T) * nrow);

    //从第0索引到第 nColumn - 1索引都是字段名称
    //从第 nColumn 索引开始，后面都是字段值
    int32_t i;
    for(i = 0; i < nrow; i++ )
    {
        NORTH_DEV_RECORD_T *pstTmp = pstDevList + i;
        uint32_t row = i + 1;

        FILL_INT(pstTmp, ID, dbresult, row, ncolumn);
        FILL_INT(pstTmp, MapGrp, dbresult, row, ncolumn);
        FILL_INT(pstTmp, MapType, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, MapName, dbresult, row, ncolumn);
        FILL_INT(pstTmp, DevNo, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, MapFile, dbresult, row, ncolumn);
        FILL_INT(pstTmp, TxSlaveAddr, dbresult, row, ncolumn);
        FILL_INT(pstTmp, MapDevCode, dbresult, row, ncolumn);
        FILL_INT(pstTmp, MapDevIndex, dbresult, row, ncolumn);

        printf("MapGrp:%d MapType:%d MapName:%s MapFile:%s.\n", pstTmp->MapGrp, pstTmp->MapType, pstTmp->MapName, pstTmp->MapFile);
        EMS_LOG(LL_WARNING, MODULE_D, FALSE, "MapGrp:%d MapType:%d MapName:%s MapFile:%s TxSlaveAddr:%d MapDevCode:%d MapDevIndex:%d.\n",
                pstTmp->MapGrp, pstTmp->MapType, pstTmp->MapName, pstTmp->MapFile,
                pstTmp->TxSlaveAddr, pstTmp->MapDevCode, pstTmp->MapDevIndex);
    }

    arg->pvdata = pstDevList;
    arg->pvdataLen = nrow;

    return ret;
}

static int32_t fillTimeCfg(char **dbresult, int32_t nrow, int32_t ncolumn, QUERY_DATA_T *arg)
{
    int32_t ret = OK;
    if (nrow <= 0)
    {
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }

    TIME_CFG_T *pstDevList = (TIME_CFG_T*)calloc(nrow, sizeof(TIME_CFG_T));
    memset(pstDevList, 0, sizeof(TIME_CFG_T) * nrow);

    //从第0索引到第 nColumn - 1索引都是字段名称
    //从第 nColumn 索引开始，后面都是字段值
    int32_t i;
    for(i = 0; i < nrow; i++ )
    {
        TIME_CFG_T *pstTmp = pstDevList + i;
        uint32_t row = i + 1;

        FILL_INT(pstTmp, ID, dbresult, row, ncolumn);
        FILL_INT(pstTmp, SynTimeMode, dbresult, row, ncolumn);
        FILL_STRING(pstTmp, NTPAddr, dbresult, row, ncolumn);
        FILL_INT(pstTmp, NTPPort, dbresult, row, ncolumn);

        printf("%s SynTimeMode:%d NTPAddr:%s NTPPort:%d.\n", __func__, pstTmp->SynTimeMode, pstTmp->NTPAddr, pstTmp->NTPPort);
    }

    arg->pvdata = pstDevList;
    arg->pvdataLen = nrow;

    return ret;
}

static int32_t sysCfg_queryCallback(char **dbresult, int32_t nrow, int32_t ncolumn, void *arg)
{
    int32_t ret = OK;

    do
    {
        if (arg == NULL || dbresult == NULL || *dbresult == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        QUERY_DATA_T *pstQueryData = (QUERY_DATA_T*)arg;

        switch (pstQueryData->eType)
        {
            case CFG_TYPE_ALGOR:
                ret = fillAlogr(dbresult, nrow, ncolumn, pstQueryData);
                break;
            case CFG_TYPE_RUN_CTRL:
                ret = fillRunCfg(dbresult, nrow, ncolumn, pstQueryData);
                break;
            case CFG_TYPE_PROTECT_STORAGE:
                ret = fillProtectStorage(dbresult, nrow, ncolumn, pstQueryData);
                break;
            case CFG_TYPE_PROTECT_NET:
                ret = fillProtectNet(dbresult, nrow, ncolumn, pstQueryData);
                break;
            case CFG_TYPE_NORTH_PARAM:
                ret = fillNorthParam(dbresult, nrow, ncolumn, pstQueryData);
                break;
            case CFG_TYPE_IO:
                ret = fillIOParam(dbresult, nrow, ncolumn, pstQueryData);
                break;
            case CFG_TYPE_NORTH_DEV_LIST:
                ret = fillNorthDevList(dbresult, nrow, ncolumn, pstQueryData);
                break;
            case CFG_TYPE_TIME_CFG:
                ret = fillTimeCfg(dbresult, nrow, ncolumn, pstQueryData);
                break;
            default:
                ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
                break;
        }

    }while(0);

    return ret;
}

// static void printData(QUERY_DATA_T *pstQueryData)
// {
//     if (pstQueryData->eType == CFG_TYPE_ALGOR)
//     {
//         int32_t num = pstQueryData->pvdataLen / sizeof(ALOGR_T);
//         int32_t i = 0;
//
//         for (i = 0; i < num; i++)
//         {
//             ALOGR_T *pTmp = (ALOGR_T *)pstQueryData->pvdata + i;
//
//             printf("UartNo:%d Enable:%d HistoryNum:%d SampleNum:%d FilterAlgor:%d\n",
//                 pTmp->UartNo, pTmp->Enable, pTmp->HistoryNum, pTmp->SampleNum, pTmp->FilterAlgor);
//
//             if (pTmp->FilterAlgor == FILTER_ALGOR_WEIGHT_RECURSIVE_AVE)
//             {
//                 printf("AveNum:%d AveWeight:%s\n", pTmp->ALOGR_PARAM_U.stAve.AveNum, pTmp->ALOGR_PARAM_U.stAve.AveWeight);
//             }
//
//             if (pTmp->FilterAlgor == FILTER_ALGOR_LPF)
//             {
//                 printf("FirstInitValue:%f FirstTimeValue:%f\n", pTmp->ALOGR_PARAM_U.stLPF.FirstInitValue, pTmp->ALOGR_PARAM_U.stLPF.FirstTimeValue);
//             }
//
//             if (pTmp->FilterAlgor == FILTER_ALGOR_LIMIT_SHAKE)
//             {
//                 printf("ALimitMaxVarCnt:%d ALimitMaxVarValue:%f ALimitValidValue:%f\n",
//                     pTmp->ALOGR_PARAM_U.stLimit.ALimitMaxVarCnt, pTmp->ALOGR_PARAM_U.stLimit.ALimitMaxVarValue, pTmp->ALOGR_PARAM_U.stLimit.ALimitValidValue);
//             }
//         }
//
//     }
//     return;
// }

int32_t sysCfg_Load(IN CFG_TYPE_E type, INOUT void **ppvdata, INOUT int32_t *pDataLen)
{
    int32_t ret = OK;

    TABLE_INFO_T pstTableInfo = g_tableList[type];
    pthread_mutex_lock(&pstTableInfo.lock);

    do
    {
        if (pstTableInfo.dbFile == NULL || !DirExist((char *)pstTableInfo.dbFile))
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_FOUND);
            break;
        }

        char sql[1024] = "0";
        sprintf(sql, "select * from %s", pstTableInfo.table_name);

        QUERY_DATA_T stUserQuery;
        stUserQuery.eType = type;
        stUserQuery.pvdata = NULL;
        stUserQuery.pvdataLen = 0;
        ret = db_query(pstTableInfo.dbFile, sql, sysCfg_queryCallback, &stUserQuery);
//         printf("615 ret: %d\n", ret);
        if (ret == OK)
        {
            *pDataLen = stUserQuery.pvdataLen;
            *ppvdata= stUserQuery.pvdata;
//             printData(&stUserQuery);
        }

    }while(0);

    pthread_mutex_unlock(&pstTableInfo.lock);

    return ret;
}

void sysCfg_Free(IN void *pvdata)
{
    HCFREE(pvdata);

    return;
}
