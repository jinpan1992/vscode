#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include "sdb.h"
#include "logUtil.h"
#include "config.h"
#include "sys.h"
#include "db.h"
#include "calc.h"
#include "ShareRTDB.h"
#include "mapping.h"
#include "file_operate.h"
#include "IMC.h"

SOFTDATABASE_T softdata;
COMMDEV_TABLE_T commdev_table;
DEV_TABLE_T com_dev_info_table;

char *comm_type_name[] =
{
    "uart",
    "can",
    "net",
    "SG_METER",
    "CJT_188",
};

static uint16_t GetIdFromNames(char *element, char **names, uint32_t num)
{
    uint32_t i = 0;
    for (i = 1; i < num; ++i)
    {
        if (0 == strcmp(element, names[i]))
        {
            return i;
        }
    }
    return 0;
}

static int32_t getNodeCount(xmlXPathContextPtr context, char *pNodePath)
{
    int32_t dwNodeCount = INVALID_VALUE;

    xmlChar *xpath = (xmlChar *)pNodePath;
    xmlXPathObjectPtr result = xmlXPathEvalExpression(xpath, context);
    if (result)
    {
        xmlNodeSetPtr nodeset = result->nodesetval;
        if (nodeset->nodeNr)
        {
            dwNodeCount = nodeset->nodeNr;
        }
    }
    xmlXPathFreeObject(result);

    return dwNodeCount;
}

static int32_t loadPointXml(IN char *filePathAndName, INOUT PROTOCOL_T **ppProtocol, INOUT int32_t *dwPtlNum)
{
    int32_t file_max_data_id = 0;
    int8_t tmp_data_type = 0;
    int32_t maxSouthDataId = 0;

    xmlDocPtr doc;
    xmlNodePtr curNode;
    xmlNodePtr Node1;
    xmlNodePtr Node2;
    xmlXPathContextPtr context = NULL;

    int32_t index_id = 0, proCmd = 0;
    uint8_t protocol_byte_type = 0xFF, protocol_word_type = 0xFF;

    doc = xmlReadFile(filePathAndName, "UTF-8", XML_PARSE_RECOVER);
    if (NULL == doc)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "string_xml empty !\n");
        return -1;
    }

    context = xmlXPathNewContext(doc);
    if (context == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "context is NULL\n");
        xmlFreeDoc(doc);
        return 0;
    }

    //读取root节点
    curNode = xmlDocGetRootElement(doc);
    if (NULL == curNode)
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "string_xml no root !\n");
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return -1;
    }

    //解析root下子节点
    if (xmlStrcmp(curNode->name, BAD_CAST "root"))
    {
        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "document of the wrong type, root node != root");
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return -1;
    }
    curNode = curNode->xmlChildrenNode;
    xmlNodePtr propNodePtr = curNode;
    Node1 = curNode;

    int32_t protocolNum = 0;
    int32_t protocolCount = getNodeCount(context, "/root/protocol/table");
    PROTOCOL_T *pPtl = calloc(protocolCount, sizeof(PROTOCOL_T));
    if (pPtl == NULL)
    {
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return ERROR_T(ERR_DEFAULT_NO_MEM);
    }

    PROTOCOL_DATA_T *pPtlData = NULL;
    int32_t count = 0;

    while (Node1 != NULL)
    {
        if ((!xmlStrcmp(Node1->name, (const xmlChar * ) "protocol")))
        {
            //查找属性
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolByte"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolByte");
                    if (strcmp((const char *)szAttr, "低字节前高字节后") == 0)
                    {
                        protocol_byte_type = LH_BYTE;
                    }
                    else if (strcmp((const char *)szAttr, "高字节前低字节后") == 0)
                    {
                        protocol_byte_type = HL_BYTE;
                    }
                    else
                    {
                        protocol_byte_type= HL_BYTE;
                    }
                    xmlFree(szAttr);
                }
                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolWord"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolWord");
                    if (strcmp((const char *)szAttr, "低字前高字后") == 0)
                    {
                        protocol_word_type = LH_WORD;
                    }
                    else if (strcmp((const char *)szAttr, "高字前低字后") == 0)
                    {
                        protocol_word_type = HL_WORD;
                    }
                    else
                    {
                        protocol_word_type = LH_WORD;
                    }
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }
            //node2节点 是node1的子节点
            Node2 = Node1->xmlChildrenNode;
            while (Node2 != NULL)
            {
                propNodePtr = Node2;
                if ((!xmlStrcmp(Node2->name, (const xmlChar *) "table")))
                {
                    //查找每个协议的属性
                    int32_t tab_id = 0;
                    xmlAttrPtr attrPtr = propNodePtr->properties;
                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                            tab_id = strtoul((const char * ) szAttr, NULL, 0);
                            xmlFree (szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "cmd"))
                        {
                            xmlChar* szAttr = xmlGetProp (propNodePtr,BAD_CAST "cmd");
                            proCmd = strtoul((char *) szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ctrl_cmd"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ctrl_cmd");
                            pPtl[protocolNum].ctrlcmd = strtoul((const char *)szAttr, NULL, 10);
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "address"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "address");
                            pPtl[protocolNum].address = strtoul((const char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "cyc_enable"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "cyc_enable");
                            pPtl[protocolNum].cyc_enable = strtoul((const char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "MeterSendCmd"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "MeterSendCmd");
                            pPtl[protocolNum].dlt645_07cmd = strtoul((const char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "MeterRevCmd"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "MeterRevCmd");
                            pPtl[protocolNum].dlt645_Re_cmd = strtoul((const char *)szAttr, NULL, 0);
                            xmlFree(szAttr);
                        }
                        attrPtr = attrPtr->next;
                    }
                    char xpath_point[200] = { 0 };
                    char xpath_tab[100] = { 0 };
                    sprintf(xpath_tab, "/root/protocol/table[@id='%d' and @cmd='%d'  ]", tab_id, proCmd);
                    sprintf(xpath_point, "%s/register/point", xpath_tab);

                    xmlNodePtr tmp_node = NULL;
                    xmlXPathObjectPtr result = NULL;
                    xmlNodeSetPtr nodeset = NULL;
                    xmlChar *xpath_tmp = (xmlChar *) xpath_point;
                    result = xmlXPathEvalExpression (xpath_tmp, context);

                    if (result == NULL)
                    {
                        EMS_LOG(LL_ERROR, MODULE_T, FALSE,  "xmlXPathEvalExpression   NULL\n");
                        xmlXPathFreeContext(context);
                        xmlFreeDoc(doc);
                        return 0;
                    }
                    if (xmlXPathNodeSetIsEmpty(result->nodesetval))
                    {
                        xmlXPathFreeObject(result);
                        xmlXPathFreeContext(context);
                        xmlFreeDoc(doc);
                        return 0;
                    }

                    uint32_t addr_min = 0, addr_max = 0;
                    int32_t tmp_data_id = 0, max_ptl_data_id = 0, min_data_id = 0, node_id = 0;
                    nodeset = result->nodesetval;

                    int32_t line_num = nodeset->nodeNr;
                    pPtlData = (PROTOCOL_DATA_T *) malloc(line_num * sizeof(PROTOCOL_DATA_T));
                    memset(pPtlData, 0, line_num * sizeof(PROTOCOL_DATA_T));

                    for (node_id = 0; node_id < line_num; node_id++)
                    {
                        index_id = node_id;
                        tmp_node = nodeset->nodeTab[node_id];
                        propNodePtr = tmp_node ;
                        if ((!xmlStrcmp(tmp_node->name, (const xmlChar *) "point")))
                        {
                            xmlAttrPtr attrPtr = propNodePtr->properties;

                            while (attrPtr != NULL)
                            {
                                if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataName"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataName");
                                    strcpy(pPtlData[index_id].data_name, (const char *) szAttr);
                                    xmlFree (szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataId"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataId");

                                    if (softdata.dataId_modify == 1)
                                    {
                                        count++;
                                        char dataidvalue[10] = {0};
                                        sprintf(dataidvalue, "%d", count);
                                        xmlSetProp(propNodePtr, (const xmlChar *)"DataId", (const xmlChar *)dataidvalue);
                                        pPtlData[index_id].data_id = count;
                                    }
                                    else
                                    {
                                        pPtlData[index_id].data_id = strtoul((char *)szAttr, NULL, 0);
                                    }

                                    tmp_data_id = pPtlData[index_id].data_id;
                                    if (max_ptl_data_id < tmp_data_id )
                                    {
                                        max_ptl_data_id = tmp_data_id;
                                    }
                                    if ((min_data_id <= 0) || (min_data_id > tmp_data_id))
                                    {
                                        min_data_id = tmp_data_id;
                                    }

                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataUnit"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataUnit");
                                    strcpy(pPtlData[index_id].data_unit, (char *)szAttr);

                                    //szAttr: 0.001*A
                                    char *p = strchr((const char *)szAttr, '*');
                                    if (p == NULL)
                                    {
                                        pPtlData[index_id].unitCoefficient = 1;
                                    }
                                    else
                                    {
                                        char c[8] = {0};
                                        strncpy(c, (const char *)szAttr, p - (const char *)szAttr);

                                        float32_t tmp = atof((const char *)c);
                                        pPtlData[index_id].unitCoefficient = (tmp == 0.0) ? 1 : tmp;
                                    }

                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataCode"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataCode");
                                    pPtlData[index_id].datacode = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataAddress")
                                    || !xmlStrcmp(attrPtr->name, BAD_CAST "NorthAddress")
                                )
                                {
                                    xmlChar *szAttr;
                                    if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataAddress"))
                                    {
                                        szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataAddress");
                                    }
                                    else {
                                        szAttr = xmlGetProp(propNodePtr,BAD_CAST "NorthAddress");
                                    }
                                    pPtlData[index_id].address = strtoul((char * ) szAttr, NULL, 0);

                                    uint32_t tmp_addr = pPtlData[index_id].address;

                                    if (addr_max < tmp_addr)
                                    {
                                        addr_max = tmp_addr;
                                    }
                                    if ((addr_min <= 0) || (addr_min > tmp_addr))
                                    {
                                        addr_min = tmp_addr;
                                    }
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataLen"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr, BAD_CAST "DataLen");
                                    pPtlData[index_id].data_len = strtoul((const char *) szAttr, NULL, 0);
                                    xmlFree (szAttr);
                                }
                                else if (!xmlStrcmp( attrPtr->name, BAD_CAST "DataType"))
                                {
                                    xmlChar *szAttr = xmlGetProp(propNodePtr, BAD_CAST "DataType");
                                    if(strcmp((char *)szAttr, "I") == 0)
                                    {
                                        tmp_data_type = TYPE_INT;
                                    }
                                    else if(strcmp((char *)szAttr, "F") == 0)
                                    {
                                        tmp_data_type = TYPE_F;
                                    }

                                    pPtlData[index_id].data_type = tmp_data_type;
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp (attrPtr->name, BAD_CAST "DataSign"))
                                {
                                    xmlChar *szAttr = xmlGetProp ( propNodePtr,BAD_CAST "DataSign" );
                                    if(strcmp((char *)szAttr, "U") == 0)
                                    {
                                        pPtlData[index_id].data_sign = SIGN_U;
                                    }
                                    else if(strcmp((char *)szAttr, "S") == 0)
                                    {
                                        pPtlData[index_id].data_sign = SIGN_S;
                                    }
                                    else
                                    {
                                        pPtlData[index_id].data_sign = SIGN_F;
                                    }

                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataDecimal"))
                                {
                                    xmlChar* szAttr = xmlGetProp ( propNodePtr,BAD_CAST "DataDecimal");
                                    float32_t tmp = atof((const char *) szAttr);
                                    pPtlData[index_id].coefficient = (tmp == 0.0) ? 1 : tmp;
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMin"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataMin");
                                    pPtlData[index_id].low_limit = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMax"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataMax");
                                    pPtlData[index_id].high_limit = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMin1"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataMin1");
                                    pPtlData[index_id].low_limit1 = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "DataMax1"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DataMax1");
                                    pPtlData[index_id].high_limit1 = strtoul((char *)szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "IECCode"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "IECCode");
                                    pPtlData[index_id].iecCode = strtoul((const char * ) szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "IECAddress"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "IECAddress");
                                    pPtlData[index_id].iec_address = strtoul((const char * ) szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Appendix"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Appendix");
                                    uint16_t appendix_len;
                                    appendix_len = strlen((char *)szAttr);

                                    if (appendix_len > 0)
                                    {
                                        pPtlData[index_id].appendix_enable = 1;
                                        pPtlData[index_id].appendix = (char *)malloc(sizeof(char) * (appendix_len + 10));
                                        if (pPtlData[index_id].appendix == NULL)
                                        {
                                            EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "mallco appendix error\n");
                                            break;
                                        }
                                        strcpy(pPtlData[index_id].appendix, (char *)szAttr);
                                    }
                                    else
                                    {
                                        pPtlData[index_id].appendix_enable = 0;
                                        pPtlData[index_id].appendix = NULL;
                                    }
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "SouthDataId"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr, BAD_CAST "SouthDataId");
                                    pPtlData[index_id].dwSouthDataId = strtoul((const char *) szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                    tmp_data_id = pPtlData[index_id].data_id ;
                                    if (maxSouthDataId < tmp_data_id)
                                    {
                                        maxSouthDataId = tmp_data_id;
                                    }
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST "SouthAddr"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr, BAD_CAST "SouthAddr");
                                    pPtlData[index_id].dwSouthAddr = strtoul((const char *) szAttr, NULL, 0);
                                    xmlFree(szAttr);
                                }

                                if ((SIGN_U == pPtlData[index_id].data_sign) && (TYPE_INT == tmp_data_type))
                                {
                                    pPtlData[index_id].data_type = U_INT_T;
                                }
                                else if ((SIGN_S == pPtlData[index_id].data_sign) && (TYPE_INT == tmp_data_type))
                                {
                                    pPtlData[index_id].data_type = S_INT_T;
                                }
                                else if (TYPE_F == tmp_data_type)
                                {
                                    pPtlData[index_id].data_type = FLOAT_T;
                                }
                                attrPtr = attrPtr->next;
                            }
                        }
                    }

                    if (result)
                    {
                        xmlXPathFreeObject(result);
                    }

                    pPtl[protocolNum].protocol_data = pPtlData;
                    if (proCmd == 0x01 || proCmd == 0x02)
                    {
                        if (pPtlData[line_num-1].data_len == 4)
                        {
                            pPtl[protocolNum].len = addr_max - addr_min + 2;
                        }
                        else
                        {
                            pPtl[protocolNum].len  = addr_max - addr_min + 1;
                        }
                    }
                    else
                    {
                        if (pPtlData[line_num-1].data_len == 4)
                        {
                            pPtl[protocolNum].len = addr_max - addr_min + 2;
                        }
                        else if (pPtlData[line_num-1].data_len == 2)
                        {
                            pPtl[protocolNum].len  = addr_max - addr_min + 1;
                        }
                        else
                        {
                            pPtl[protocolNum].len  = addr_max - addr_min + (pPtlData[line_num-1].data_len)/2;
                        }
                    }

                    pPtl[protocolNum].min_address = addr_min;
                    pPtl[protocolNum].max_address = addr_max;
                    pPtl[protocolNum].min_data_id = min_data_id;
                    pPtl[protocolNum].max_data_id = max_ptl_data_id;
                    if (pPtl[protocolNum].address != addr_min)
                    {
                        pPtl[protocolNum].address = addr_min;
                    }
                    pPtl[protocolNum].cmd = proCmd;
                    pPtl[protocolNum].byte_seq = protocol_byte_type;
                    pPtl[protocolNum].word_seq = protocol_word_type;
                    pPtl[protocolNum].ptl_data_num = line_num;

                    protocolNum ++;

                    if (protocolNum > PROTOCOLNUM)
                    {
                        EMS_LOG(LL_ERROR, MODULE_T, FALSE, "protocol num is exceed!!\n");
                        xmlSaveFile(filePathAndName, doc);
                        xmlXPathFreeContext(context);
                        xmlFreeDoc(doc);
                        exit(0);
                    }

                    if (file_max_data_id < max_ptl_data_id)
                    {
                        file_max_data_id  = max_ptl_data_id;
                    }

                }
                Node2 = Node2->next;
            }
        }
        Node1 = Node1->next;
    }

    *ppProtocol = pPtl;
    *dwPtlNum = protocolCount;

    xmlSaveFile(filePathAndName, doc);
    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);
    xmlCleanupParser();

    return OK;
}

//插入一个com
int32_t ComInsertToMaster(COMMDEV_TABLE_T *table_commdev, COMPORT_T *comport, int32_t mbmasterid)
{
    COMMDEV_T *new_comdev = NULL;
    new_comdev = (COMMDEV_T *)malloc (sizeof(COMMDEV_T));

    if (new_comdev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "malloc new_comdev error\n");
        exit(EXIT_FAILURE);
        return -1;
    }

    memset(new_comdev, 0, sizeof(COMMDEV_T));

    new_comdev->id = mbmasterid;
    memcpy(&(new_comdev->comport), comport, sizeof(COMPORT_T));
    new_comdev->dev_num = 0;
    new_comdev->head = NULL;
    new_comdev->end = NULL;

    if (table_commdev->head_commDev == NULL)
    {
        table_commdev->head_commDev = new_comdev;
    }

    if (table_commdev->end_commDev != NULL)
    {
        table_commdev->end_commDev->next = new_comdev;
    }

    table_commdev->end_commDev= new_comdev;

    table_commdev->total_num += 1;

    return 0;
}

//动态注册主站下挂的从设备
int32_t InsertDevInfo(DEV_TABLE_T *tab, uint8_t com, int32_t com_type, DEV_INFO_T *pDevInfo)
{
    int32_t j = 0;
    DEV_INFO_T *newdev = NULL;

    if (tab->total_dev_num >= MAX_DEV_NUM)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "insert dev failed ! max slavers  = %d\n", tab->total_dev_num);
        return 0;
    }
    newdev = (DEV_INFO_T *)calloc(1, sizeof(DEV_INFO_T));
    if (newdev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "malloc newdev failed !\n");
        return -1;
    }

    newdev->id = pDevInfo->id;
    newdev->index = pDevInfo->id;
    strcpy(newdev->dev_sn, pDevInfo->dev_sn);
    strcpy(newdev->position, pDevInfo->position);
    newdev->dev_code = pDevInfo->dev_code;
    memcpy(newdev->dev_name, pDevInfo->dev_name, 32);
    strcpy(newdev->name,  pDevInfo->name);
    //2022.0608 add by huangjie
    newdev->ucSubType = pDevInfo->ucSubType;
    for (j = 0; j < 32; j++)
    {
        newdev->dev_address[j] = pDevInfo->dev_address[j];
    }

    newdev->dev_breaker = pDevInfo->dev_breaker;
    newdev->slaverid_modify = pDevInfo->slaverid_modify;
    newdev->com = com;
    newdev->com_type = com_type;
    newdev->cslave_id = pDevInfo->cslave_id;
    newdev->scan_clock.start_delay = 0;
    newdev->scan_clock.scan_stop = 0;
    newdev->scan_clock.tim_flag = 0;
    newdev->scan_clock.timing = pDevInfo->scan_clock.timing;//ScanPeriod;
    newdev->scan_clock.timeout = pDevInfo->scan_clock.timeout;//Timeout;
    newdev->scan_clock.tim_cur = newdev->scan_clock.timing;
    for (j = 0; j < 6; j++)
    {
        newdev->meter_addr[j] = pDevInfo->meter_addr[j];
    }
    newdev->PT_Pare = pDevInfo->PT_Pare;
    newdev->CT_Pare = pDevInfo->CT_Pare;
    newdev->Meter_dire = pDevInfo->Meter_dire;

    newdev->canid_send = pDevInfo->canid_send;
    newdev->canid_rev = pDevInfo->canid_rev;
    newdev->heart_type = pDevInfo->heart_type;
    newdev->heart_time = pDevInfo->heart_time;
    newdev->dwPtlNum = 0;
    newdev->point_num = 0;
    newdev->max_data_id = 0;
    newdev->min_data_id = 0;
    newdev->dbUID = pDevInfo->dbUID;

    for (j = 0; j < MAX_PROTOCOL_NUM; j++)
    {
        newdev->protocol[j] = NULL;
    }
    newdev->pValue = NULL;
    newdev->map_id = NULL;
    newdev->next = NULL;

    if (tab->head_dev == NULL)
    {
        tab->head_dev = newdev;
    }
    if (tab->end_dev != NULL)
    {
        tab->end_dev->next = newdev;
    }
    tab->end_dev = newdev;

    tab->total_dev_num += 1;

    return tab->total_dev_num;
}

int32_t InsertDevInfoToCommDev(COMMDEV_TABLE_T *port_tab, DEV_TABLE_T *dev_tab,int32_t mbmasterid,
                               char * name, uint16_t mbslaverid, uint16_t dev_code)
{
    int32_t i = 0, j = 0;
    UN_COMM_DEV_T *new_dev = NULL;
    COMMDEV_T *mbm;
    DEV_INFO_T *dev;

    new_dev = (UN_COMM_DEV_T *)calloc(1, sizeof(UN_COMM_DEV_T));
    if (new_dev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "malloc new_dev error\n");

        return -1;
    }

    mbm = port_tab->head_commDev;
    dev = dev_tab->head_dev;

    for (i = 0; i < port_tab->total_num; ++i)
    {
        if (mbm->id == mbmasterid)
        {
            for (j = 0; j < dev_tab->total_dev_num; ++j)
            {
                if ((0 == strcmp(dev->dev_name, name)) && (dev->id == mbslaverid) && (dev->dev_code == dev_code))
                {
                    new_dev->dev = dev;

                    if (mbm->head == NULL)
                    {
                        mbm->head = new_dev;
                    }
                    new_dev->next = mbm->head;

                    if (mbm->end != NULL)
                    {
                        mbm->end->next = new_dev;
                    }
                    mbm->end = new_dev;

                    mbm->dev_num ++;

                    return 0;
                }
                dev = dev->next;
            }
        }
        mbm = mbm->next;
    }

    if (new_dev != NULL)
    {
        HCFREE(new_dev);
    }
    return -1;
}

void InitDevInfoData(DEV_TABLE_T *dev_tab)
{
    DEV_INFO_T *new_dev = dev_tab->head_dev;
    int i = 0, j = 0, m = 0, k = 0;

    for (i = 0; i < dev_tab->total_dev_num; ++i)
    {
        new_dev->point_num = 0;
        new_dev->min_data_id = 1;

        for (j = 0; j < new_dev->dwPtlNum; j++)
        {
            new_dev->point_num += new_dev->protocol[j]->ptl_data_num;

            if (new_dev->max_data_id < new_dev->protocol[j]->max_data_id)
            {
                new_dev->max_data_id = new_dev->protocol[j]->max_data_id;
            }
            if (new_dev->min_data_id > new_dev->protocol[j]->min_data_id)
            {
                new_dev->min_data_id = new_dev->protocol[j]->min_data_id;
            }
        }

        //传管道的测点数据，每个设备保存一份,设备id都是从1开始
        new_dev->pValue = (VALUE_INFO_T *)malloc((new_dev->point_num + 1) * sizeof(VALUE_INFO_T));
        if (new_dev->pValue != NULL)
        {
            for (m = 0; m < new_dev->point_num + 1; m++)
            {
                new_dev->pValue[m].data.u32 = 0;
            }
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "malloc fail\n");
            exit(EXIT_FAILURE);
        }

        new_dev->map_id = (uint32_t *)malloc((new_dev->max_data_id + 1) * sizeof(uint32_t));
        if (new_dev->map_id == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "malloc new_dev->map_id error !\n");
            exit(EXIT_FAILURE);
        }
        else
        {
            uint32_t map_index = 0;
            for (k = 0; k < new_dev->dwPtlNum; k++)
            {
                PROTOCOL_T *protocol = new_dev->protocol[k];
                for (m = 0; m < protocol->ptl_data_num; m++)
                {
                    new_dev->map_id[protocol->protocol_data[m].data_id] = map_index;
                    map_index++;
                }
            }
        }

        DEVMAP_T stDevMap;
        memset(&stDevMap, 0, sizeof(DEVMAP_T));
        strcpy(stDevMap.stDevInfo.cDevName, new_dev->dev_name);
        stDevMap.stDevInfo.ucDevId = new_dev->index;
        stDevMap.stDevInfo.ucPointLen = new_dev->max_data_id + 1;
        stDevMap.stDevInfo.uwDevCode = new_dev->dev_code;
        stDevMap.stDevInfo.dbUID = new_dev->dbUID;
        ShareRTDB_Add(&stDevMap);

        new_dev = new_dev->next;
    }
}

/*******************************************************************************
 * Function     : GetElementFromStr
 * Author       : sungr
 * Date         : 2021.09.22
 * Description  : 使用逗号分隔符解析字符串,
 * Calls        :
 * Input        : char *buf,字符串,char separator 分隔符
 * Output       :char *element 返回字段
 * Return       :字符串位置
 ********************************************************************************/

uint16_t GetElemFromStr(char *buf, char *element)
{
    char ele1[20] = {0} ;
    char ele2[20] = {0} ;
    char ele3[20] = {0};
    char ele4[20] = {0};
    int32_t len = 0;
    len += GetElementFromStr(&buf[len], ele1, '.');
    printf("buf: %s: ele1 %s element=%s\n", buf, ele1,element);

    *element = strtoul(ele1, NULL, 0);
    len += GetElementFromStr(&buf[len], ele2, '.');
    printf("buf: %s: ele2 %s element=%s\n", buf, ele2,element);

    *(element+1)= strtoul(ele2, NULL, 0);
    len += GetElementFromStr(&buf[len], ele3, '.');
    printf("buf: %s: ele3 %s element=%s \n", buf, ele3,element);

    *(element+2)= strtoul(ele3, NULL, 0);
    len += GetElementFromStr(&buf[len], ele4, '.');
   *(element+3) = strtoul(ele4, NULL, 0);
    printf("buf: %s: ele4 %s element=%s\n", buf, ele4,element);

    return 0;
}

int32_t GetCommTableFromXml(char *configfilePATH)
{
    xmlDocPtr doc;
    xmlNodePtr curNode;
    xmlNodeSetPtr nodeset;
    xmlXPathObjectPtr result;
    xmlXPathContextPtr context;
    char *szDocName;
    int32_t protocol_num = 0;
    szDocName = configfilePATH;

    doc = xmlReadFile(szDocName, "UTF-8", XML_PARSE_RECOVER);
    if (NULL == doc)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "%sDocument not parsed successfully.\n",szDocName);
        xmlFreeDoc(doc);
        return -1;
    }

    curNode = xmlDocGetRootElement(doc);
    if (NULL == curNode)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "modbusmaster_xml no root!\n");
        xmlFreeDoc(doc);
        return -1;
    }

    context = xmlXPathNewContext(doc);
    xmlChar *xpath = (xmlChar *)"/root/protocol/table";

    result = xmlXPathEvalExpression(xpath, context);
    if (result)
    {
        nodeset = result->nodesetval;
        if (nodeset->nodeNr)
        {
            protocol_num = nodeset->nodeNr;
        }
    }

    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);

    return protocol_num;
}

uint16_t CalcDevIndex(COMMDEV_TABLE_T *port_tab, DEV_TABLE_T *tab, int32_t mbmasterid, uint16_t dev_code, char *name)
{
    int32_t i = 0, typenum = 0, j = 0;
    uint16_t num = 0;
    DEV_INFO_T *tmp_dev = tab->head_dev;
    COMMDEV_T *mbm = port_tab->head_commDev;
    num = tab->total_dev_num;

    if (num == 1)
    {
        //uint16_t index = 1;
    }
    else
    {
        for (i = 1; i < num; i++)
        {
            if (tmp_dev->dev_code == dev_code)
            {
                typenum ++;
            }
            tmp_dev = tmp_dev->next;
        }
        if (typenum == 0)
        {
            tmp_dev->index = 1;
        }
        else
        {
            tmp_dev->index = 1 + typenum;
        }
    }

    //错误处理
    for (j = 0; j < port_tab->total_num; ++j)
    {
        if (mbm->id != mbmasterid)
        {
            uint16_t dev_num = mbm->dev_num;
            UN_COMM_DEV_T *tmp_comm_dev = mbm->head;
            for (i = 0; i < dev_num; ++i)
            {
                DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
                if (tmp_newdev->dev_code == dev_code)
                {
                    if (0 == strcmp(tmp_newdev->dev_name, name))
                    {
                        printf("Equipment of the same type has the same name\n");
                        EMS_LOG(LL_FATAL, MODULE_DEFAULT, FALSE, "Equipment of the same type has the same name\n");
                        exit(EXIT_FAILURE);
                    }
                }
                tmp_comm_dev= tmp_comm_dev->next;
            }
        }
        mbm = mbm->next;
    }

    return 0;
}


PROTOCOL_T* GetCommPointFromXml(uint16_t dev_code, uint8_t ptl_type, uint8_t protocol_byte_type, uint8_t protocol_word_type, char *configfilePATH)
{
    int32_t dwPtlNum = 0, i = 0;

    PROTOCOL_T *pPlt = NULL;
    loadPointXml(configfilePATH, &pPlt, &dwPtlNum);

    for (i = 0; i < dwPtlNum; i++)
    {
        pPlt[i].ptl_type = ptl_type;
        pPlt[i].dev_code = dev_code;
        pPlt[i].byte_seq = protocol_byte_type;
        pPlt[i].word_seq = protocol_word_type;
    }

    return pPlt;
}

int32_t InitSoftDataBase(SOFTDATABASE_T *softdata)
{
    memset(&(softdata->deviceVer), 0, sizeof(PLATFORMVER_T));

    softdata->total_commDev_num = 0;
    softdata->total_Dev_num = 0;
    softdata->dataId_modify = 0;
    softdata->dev_conncomm_value = 0;

    softdata->commDev = NULL;
    pthread_mutex_init(&softdata->sdbLock, NULL);

    return 0;
}

int32_t InsertDataBase(SOFTDATABASE_T *softdata, COMMDEV_TABLE_T *port_tab, DEV_TABLE_T *dev_tab)
{
    COMMDEV_T *new_comdev = port_tab->head_commDev;

    softdata->total_commDev_num = port_tab->total_num;
    softdata->total_Dev_num = dev_tab->total_dev_num;

    if (softdata->commDev == NULL)
    {
        softdata->commDev = new_comdev;
    }

    return 0;
}
//生成协议地址索引表
static int ProtocolMapCreat(PROTOCOL_DATA_T *ptl_dat, uint32_t *map, uint16_t protocol_num)
{
    uint16_t i = 0;

    for (i = 0; i < protocol_num; i++)
    {
        if (ptl_dat[i].address >= 1)
        {
            map[ptl_dat[i].address-1] = i;      //4999 = 5000-1 ,注意减一索引
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "error : ptl_dat[%d].address = %d\n", i, ptl_dat[i].address);
        }
    }
    return 0;
}

//通信协议注册到该协议对应的所有从站设备
int32_t InsertProtocolToDevInfo(DEV_TABLE_T *tab, int32_t mum, uint16_t dev_code, char *name, uint8_t com, PROTOCOL_T *protocol)
{
    DEV_INFO_T *new_dev;
    int32_t i = 0, j = 0;

    new_dev = tab->head_dev;

    for (i = 0; i < tab->total_dev_num; ++i)
    {
        if ((new_dev->dev_code == dev_code) && (com == new_dev->com))
        {
            if (new_dev->dwPtlNum < MAX_PROTOCOL_NUM)
            {
                //同一个端口下的、相同devCode使用相同的protocol
                for (j = 0; j < mum; ++j)
                {
                    new_dev->protocol[j] = &protocol[j];
                    protocol[j].dwRefCount++;

//                     printf("%s devCode:%d protocol:%p dwRefCount:%d\n", __func__, dev_code, &protocol[j], protocol[j].dwRefCount);
                    EMS_LOG(LL_INFO, MODULE_DEFAULT, FALSE, "%s devCode:%d protocol:%p dwRefCount:%d\n",
                            __func__, dev_code, &protocol[j], protocol[j].dwRefCount);
                }
            }
            else
            {
                EMS_LOG(LL_WARNING, MODULE_DEFAULT, FALSE, "%s protocol:%d > MAX_PROTOCOL_NUM\n", name, new_dev->dwPtlNum);
            }
            new_dev->dwPtlNum = mum;
        }
        new_dev = new_dev->next;
    }

    return 0;
}

//通信协议初始化
void ProtocolInit(uint32_t protocol_table_num, PROTOCOL_T *protocol)
{
    uint32_t *Map, Map_num = 0, i = 0;

    for (i = 0; i < protocol_table_num; i++)
    {
        Map_num = protocol[i].address + protocol[i].len;

        Map = (uint32_t *)malloc(Map_num * sizeof(uint32_t));
        if (Map == NULL)
        {
            EMS_LOG(LL_DEBUG, MODULE_DEFAULT, FALSE, "malloc map error !\n");
            exit(EXIT_FAILURE);
        }
        else
        {
            memset(Map, 0xff, Map_num * sizeof(uint32_t));
        }

        ProtocolMapCreat(protocol[i].protocol_data, Map, protocol[i].ptl_data_num);
        protocol[i].map = Map;
    }
}

int32_t InitVerConfig(char *configfilePATH, SOFTDATABASE_T *softdata)
{
    xmlDocPtr doc = NULL;
    xmlNodePtr curNode, Node1;

    char *szDocName = configfilePATH;
    doc = xmlReadFile(szDocName, "UTF-8", XML_PARSE_RECOVER);
    if (NULL == doc)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "Document not parsed successfully\n");
        return -1;
    }

    //读取root节点
    curNode = xmlDocGetRootElement(doc);
    if(curNode == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "parsed xml file failed!.\n");
        xmlFreeDoc(doc);
        return -1;
    }
    //解析root下子节点
    if (xmlStrcmp(curNode->name, BAD_CAST "root"))
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "document of the wrong type, root node != root");
        xmlFreeDoc(doc);
        return -1;
    }
    curNode = curNode->xmlChildrenNode;
    Node1 = curNode;
    while (Node1 != NULL)
    {
        PLATFORMVER_T *devver = &softdata->deviceVer;
        if ((!xmlStrcmp(Node1->name, (const xmlChar *)"ProtocalNo")))
        {
            xmlChar* szAttr = xmlNodeGetContent(Node1);
            devver->protocalNo = strtoul((char *)szAttr, NULL, 0);
            xmlFree(szAttr);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"ProtocalVersion")))
        {
            xmlChar* szAttr = xmlNodeGetContent(Node1);
            GetEthInfo(szAttr, devver->protocalVer);
            xmlFree(szAttr);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"SoftwareVersion")))
        {
            xmlChar* szAttr = xmlNodeGetContent(Node1);
            strcpy(devver->softWareVer, (char *)szAttr);
            //GetEthInfo(szAttr, devver->softWareVer);
            xmlFree(szAttr);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"MachineModel")))
        {
            xmlChar* szAttr = xmlNodeGetContent(Node1);
            strcpy(devver->machineModel, (char *)szAttr);
            xmlFree(szAttr);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"MachineVersion")))
        {
            xmlChar* szAttr = xmlNodeGetContent(Node1);
            strcpy(devver->machineVer, (char *)szAttr);
            //GetEthInfo(szAttr, devver->machineVer);
            xmlFree(szAttr);
        }
        else if ((!xmlStrcmp(Node1->name, (const xmlChar *)"SN")))
        {
            xmlChar* szAttr = xmlNodeGetContent(Node1);
            strcpy(devver->PlatformSN, (char *)szAttr);
            xmlFree(szAttr);
        }
        Node1 = Node1->next;
    }

    xmlFreeDoc(doc);

    return 0;
}

int32_t InitDevConfig(char *configfilePATH, SOFTDATABASE_T *softdata)
{
    xmlDocPtr doc;
    xmlNodePtr curNode, Node1, Node2, Node3, Node4;
    xmlChar *szKey;
    char *szDocName;
    PROTOCOL_T *protocolname = NULL;

    szDocName = configfilePATH;

    doc = xmlReadFile(szDocName, "UTF-8", XML_PARSE_RECOVER);
    if (NULL == doc)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "Document not parsed successfully\n");
        return -1;
    }

    //读取root节点
    curNode = xmlDocGetRootElement(doc);
    if (curNode == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "parsed xml file failed!.\n");
        xmlFreeDoc(doc);
        return -1;
    }

    //解析root下子节点
    if (xmlStrcmp(curNode->name, BAD_CAST "root"))
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "document of the wrong type, root node != root");
        xmlFreeDoc(doc);
        return -1;
    }

    curNode = curNode->xmlChildrenNode;
    xmlNodePtr propNodePtr = curNode;
    Node1 = curNode;

    while (Node1 != NULL)
    {
        if ((!xmlStrcmp(Node1->name, (const xmlChar *)"mbmmaster")))/* mbmmaster 结点内容解析  */
        {
            COMPORT_T comport = {0};
            int32_t mbmasterid = 0;
            uint32_t comtype = 0;
            int32_t mbmtimout = 0;
            char IPAddress[4][128]={{0},{0}};

            Node2 = Node1->xmlChildrenNode;
            propNodePtr = Node1;
            xmlAttrPtr attrPtr = propNodePtr->properties;
            while (attrPtr != NULL)
            {
                if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                {
                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                    mbmasterid = strtoul((const char *)szAttr, NULL, 10);
                    xmlFree(szAttr);
                }
                attrPtr = attrPtr->next;
            }
            while (Node2 != NULL)
            {
                if ((!xmlStrcmp(Node2->name, (const xmlChar *)"commport")))
                {
                    propNodePtr = Node2;
                    xmlAttrPtr attrPtr = propNodePtr->properties;
                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "commtype"))
                        {
                            szKey = xmlGetProp(propNodePtr,BAD_CAST "commtype");
                            comtype = GetIdFromNames((char *)szKey, comm_type_name, COMM_TYPE_MAX);
                            comport.commtype = comtype;
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(attrPtr->name, (const xmlChar *)"commid")))
                        {
                            szKey = xmlGetProp(propNodePtr,BAD_CAST "commid");
                            comport.uartid = strtoul((const char *)szKey, NULL, 10);
                            xmlFree(szKey);
                        }
                        attrPtr = attrPtr->next;
                    }
                    Node3 = Node2->xmlChildrenNode;
                    while (Node3 != NULL)
                    {
                        if ((!xmlStrcmp(Node3->name, (const xmlChar *)"uartbaud")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            comport.uartbaudrate = strtoul((const char *)szKey, NULL, 10);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"uartparity")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            memcpy(&(comport.uartparity), szKey, 1);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"uartdatabit")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            comport.uartdatabit = strtoul((const char *)szKey, NULL, 10);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"uartstopbit")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            strncpy(comport.uartstopbit, (char *) szKey, sizeof(char) * 4);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"ip")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            sscanf((char *)szKey,"%[^.].%[^.].%[^.].%[^.]",
                                        IPAddress[0],
                                        IPAddress[1],
                                        IPAddress[2],
                                        IPAddress[3]);
                            comport.ip[0] = strtoul(IPAddress[0], NULL, 0);
                            comport.ip[1] = strtoul(IPAddress[1], NULL, 0);
                            comport.ip[2] = strtoul(IPAddress[2], NULL, 0);
                            comport.ip[3] = strtoul(IPAddress[3], NULL, 0);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"netport")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            comport.netport = strtoul((const char *)szKey, NULL, 10);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"canbaud")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            comport.canbaudrate = strtoul((const char *)szKey, NULL, 10);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"canframe")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            strcpy(comport.canframe, (const char *)szKey);
                            xmlFree(szKey);
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"canid_mask")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            comport.canid_mask = strtoul((const char *)szKey, NULL, 10);
                            xmlFree(szKey);
                        }
                        Node3 = Node3->next;
                    }
                    ComInsertToMaster(&commdev_table, &comport, mbmasterid);
                }
                else if ((!xmlStrcmp(Node2->name, (const xmlChar *)"slaver")))      //slaver 结点内容解析
                {
                    Node3 = Node2->xmlChildrenNode;
                    int32_t Timeout = 0, len = 0, devCount = 0, slaverid = 0;

                    char  temp_meter_addr[32] = {0}, temp_dev_address[32]= {0};
                    int32_t protocol_table_num = 0;
                    DEV_INFO_T *pstDevInfo = NULL;
                    DEV_INFO_T stDevInfo;
                    memset(&stDevInfo, 0, sizeof(DEV_INFO_T));

                    propNodePtr = Node2;
                    xmlAttrPtr attrPtr = propNodePtr->properties;
                    while (attrPtr != NULL)
                    {
                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "id"))
                        {
                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "id");
                            slaverid = strtoul((const char *)szAttr, NULL, 10);
                            xmlFree(szAttr);
                        }
                        attrPtr = attrPtr->next;
                    }

                    while(Node3 != NULL)
                    {
                        if ((!xmlStrcmp(Node3->name, (const xmlChar *)"name")))
                        {
                            szKey = xmlNodeGetContent(Node3);
                            strcpy(stDevInfo.name, (const char *)szKey);
                            xmlFree(szKey);

                            propNodePtr = Node3;
                            xmlAttrPtr attrPtr = propNodePtr->properties;
                            while (attrPtr != NULL)
                            {
                                if (!xmlStrcmp(attrPtr->name, BAD_CAST"DevCode"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevCode");
                                    stDevInfo.dev_code = strtoul((const char *)szAttr, NULL, 10);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST"SubType"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "SubType");
                                    stDevInfo.ucSubType = strtoul((const char *)szAttr, NULL, 10);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST"DevAddress"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevAddress");
                                    strcpy(temp_dev_address, (const char *)szAttr);
                                    CharToHex((uint8_t*)(&stDevInfo.dev_address), temp_dev_address, 14);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST"Devbreaker"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Devbreaker");
                                    stDevInfo.dev_breaker = strtoul((const char *)szAttr, NULL, 10);
                                    xmlFree(szAttr);
                                }
                                else if (!xmlStrcmp(attrPtr->name, BAD_CAST"CSlaveID_modify"))
                                {
                                    xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "CSlaveID_modify");
                                    stDevInfo.slaverid_modify = strtoul((const char *)szAttr, NULL, 10);
                                    xmlFree(szAttr);
                                }
                                attrPtr = attrPtr->next;
                            }
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"devices")))
                        {
                            Node4 = Node3->xmlChildrenNode;

                            int32_t i = 0;
                            xmlXPathContextPtr context = xmlXPathNewContext(doc);
                            if (context == NULL)
                            {
                                EMS_LOG(LL_ERROR, MODULE_T, FALSE, "context is NULL\n");
                                xmlFreeDoc(doc);
                                return -1;
                            }

                            char xml_comm_mbmslaver_path[100] = {0};
                            sprintf(xml_comm_mbmslaver_path, "/root/mbmmaster[@id='%d']/slaver[@id='%d']/devices/table",
                                    mbmasterid, slaverid);
                            devCount = getNodeCount(context, xml_comm_mbmslaver_path);
                            if (devCount > 0)
                            {
                                pstDevInfo = calloc(devCount, sizeof(DEV_INFO_T));
                                if (pstDevInfo == NULL)
                                {
                                    EMS_LOG(LL_ERROR, MODULE_T, FALSE, "context is NULL\n");
                                    xmlXPathFreeContext(context);
                                    xmlFreeDoc(doc);
                                    return -1;
                                }
                            }
                            else
                            {
                                continue;
                            }

                            while (Node4 != NULL)
                            {
                                if ((!xmlStrcmp(Node4->name, (const xmlChar *)"table")))
                                {
                                    propNodePtr = Node4;
                                    xmlAttrPtr attrPtr = propNodePtr->properties;

                                    while (attrPtr != NULL)
                                    {
                                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "DevId"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevId");
                                            pstDevInfo[i].id = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST"DevName"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevName");
                                            len = MAX_DEV_NAME_LEN > strlen((char*)szAttr) ? strlen((char*)szAttr) : MAX_DEV_NAME_LEN;
                                            strncpy(pstDevInfo[i].dev_name, (char*)szAttr, len);
                                            /* 同类型设备的DevName 不可以相同*/
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST"DevDBNo"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevDBNo");
                                            pstDevInfo[i].dbUID = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST"SubType"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "SubType");
                                            pstDevInfo[i].ucSubType = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "sn"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "sn");
                                            strcpy(pstDevInfo[i].dev_sn, (const char *)szAttr);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "MeterAddr"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "MeterAddr");
                                            strcpy(temp_meter_addr, (const char *)szAttr);
                                            CharToHex(pstDevInfo[i].meter_addr,temp_meter_addr, 12);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "PT_Pare"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "PT_Pare");
                                            pstDevInfo[i].PT_Pare = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "CT_Pare"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "CT_Pare");
                                            pstDevInfo[i].CT_Pare = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Meter_dire"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Meter_dire");
                                            pstDevInfo[i].Meter_dire = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "position"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "position");
                                            strcpy(pstDevInfo[i].position, (const char *)szAttr);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "CSlaveID"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "CSlaveID");
                                            pstDevInfo[i].cslave_id = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ScanPeriod"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ScanPeriod");
                                            pstDevInfo[i].scan_clock.timing = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST"DevAddress"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "DevAddress");
                                            int32_t size = strlen((char*)szAttr) > sizeof(stDevInfo.dev_address) ? sizeof(stDevInfo.dev_address) : strlen((char*)szAttr);
                                            strncpy(pstDevInfo[i].dev_address, (const char *)szAttr, size);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Timeout"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Timeout");
                                            pstDevInfo[i].scan_clock.timeout = strtoul((const char *)szAttr, NULL, 10);
                                            if (Timeout>mbmtimout)
                                            {
                                                mbmtimout = Timeout;
                                            }
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "canid_send"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "canid_send");
                                            pstDevInfo[i].canid_send = strtoul((const char *)szAttr, NULL, 0);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "canid_rev"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "canid_rev");
                                            pstDevInfo[i].canid_rev = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Heart_type"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Heart_type");
                                            pstDevInfo[i].heart_type = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "Heart_time"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "Heart_time");
                                            pstDevInfo[i].heart_time = strtoul((const char *)szAttr, NULL, 10);
                                            xmlFree(szAttr);
                                        }
                                        attrPtr = attrPtr->next;
                                    }

//                                     InsertDevInfo(&com_dev_info_table, comport.uartid, comport.commtype, &stDevInfo);
//
//                                     InsertDevInfoToCommDev(&commdev_table, &com_dev_info_table, mbmasterid,
//                                                            stDevInfo.dev_name, stDevInfo.id, stDevInfo.dev_code);
//
//                                     CalcDevIndex(&commdev_table, &com_dev_info_table, mbmasterid, stDevInfo.dev_code, stDevInfo.dev_name);

                                    i++;
                                }

                                Node4 = Node4->next;
                            }
                        }
                        else if ((!xmlStrcmp(Node3->name, (const xmlChar *)"protocol")))
                        {
                            uint8_t ptl_type = 0, protocol_byte_type = 0, protocol_word_type = 0;
                            Node4 = Node3->xmlChildrenNode;

                            while (Node4 != NULL)
                            {
                                if ((!xmlStrcmp(Node4->name, (const xmlChar *)"table")))
                                {
                                    propNodePtr = Node4;
                                    xmlAttrPtr attrPtr = propNodePtr->properties;
                                    while (attrPtr != NULL)
                                    {
                                        if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolType"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolType");
                                            if ((strcmp((const char *)szAttr, "ModbusTcp") == 0) || (strcmp((const char *)szAttr, "ModbusRtu") == 0) )
                                            {
                                                ptl_type = MODBUS;
                                            }
                                            else if (strcmp((const char *)szAttr, "DLT645") == 0)
                                            {
                                                ptl_type = DLT645;
                                            }
                                            else if (strcmp((const char *)szAttr, "IEC104") == 0)
                                            {
                                                ptl_type = IEC104;
                                            }
                                            else if (strcmp((const char *)szAttr, "CJT188") == 0)
                                            {
                                                ptl_type = CJT188;
                                            }
                                            else
                                            {
                                                ptl_type = MODBUS;
                                            }
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolByte"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolByte");
                                            if (strcmp((const char *)szAttr, "低字节前高字节后") == 0)
                                            {
                                                protocol_byte_type = LH_BYTE;
                                            }
                                            else if (strcmp((const char *)szAttr, "高字节前低字节后") == 0)
                                            {
                                                protocol_byte_type = HL_BYTE;
                                            }
                                            else
                                            {
                                                protocol_byte_type= HL_BYTE;
                                            }
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolWord"))
                                        {
                                            xmlChar* szAttr = xmlGetProp(propNodePtr,BAD_CAST "ProtocolWord");
                                            if (strcmp((const char *)szAttr, "低字前高字后") == 0)
                                            {
                                                protocol_word_type = LH_WORD;
                                            }
                                            else if (strcmp((const char *)szAttr, "高字前低字后") == 0)
                                            {
                                                protocol_word_type = HL_WORD;
                                            }
                                            else
                                            {
                                                protocol_word_type = LH_WORD;
                                            }
                                            xmlFree(szAttr);
                                        }
                                        else if (!xmlStrcmp(attrPtr->name, BAD_CAST "ProtocolName"))
                                        {
                                            xmlChar *szAttr = xmlGetProp(propNodePtr, BAD_CAST "ProtocolName");

                                            char szAttrname[100] = {0};

                                            if (stDevInfo.dev_code == CEMS_DEV_CODE)
                                            {
                                                sprintf(szAttrname, PLATFOTM_DATA_XML"%s", szAttr);
                                            }
                                            else
                                            {
                                                sprintf(szAttrname, POINT_DATA_XML"%s", szAttr);
                                            }

                                            xmlFree(szAttr);

                                            protocol_table_num = GetCommTableFromXml((char *)szAttrname);
                                            if (protocol_table_num > 0)
                                            {
                                                protocolname = GetCommPointFromXml(stDevInfo.dev_code, ptl_type, protocol_byte_type,
                                                                                   protocol_word_type, (char *)szAttrname);
                                            }
                                            else
                                            {
                                                EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "%s has no protocal table!!!\n", szAttrname);
                                            }

                                        }
                                        attrPtr = attrPtr->next;
                                    }

                                    if (protocolname != NULL)
                                    {
                                        int32_t m = 0;
                                        for (m = 0; m < devCount; ++m)
                                        {
                                            pstDevInfo[m].dev_code = stDevInfo.dev_code;
                                            InsertDevInfo(&com_dev_info_table, comport.uartid, comport.commtype, pstDevInfo + m);

                                            InsertDevInfoToCommDev(&commdev_table, &com_dev_info_table, mbmasterid,
                                                                pstDevInfo[m].dev_name, pstDevInfo[m].id, stDevInfo.dev_code);

                                            CalcDevIndex(&commdev_table, &com_dev_info_table, mbmasterid, stDevInfo.dev_code, pstDevInfo[m].dev_name);
                                        }

                                        if (ptl_type == MODBUS)
                                        {
                                            if (protocolname[0].address > 0)
                                            {
                                                ProtocolInit(protocol_table_num, protocolname);
                                            }
                                        }

                                        if (protocolname[0].address > 0)
                                        {
                                            InsertProtocolToDevInfo(&com_dev_info_table, protocol_table_num, stDevInfo.dev_code,
                                                                    stDevInfo.dev_name, comport.uartid, protocolname);
                                        }
                                    }

                                }
                                Node4 = Node4->next;
                            }
                        }
                        Node3 = Node3->next;
                    }
                }
                Node2 = Node2->next;
            }
        }
        Node1 = Node1->next;
    }

    InitDevInfoData(&com_dev_info_table);

    InsertDataBase(softdata, &commdev_table, &com_dev_info_table);

    xmlFreeDoc(doc);

    return 0;
}

int32_t SDB_Init()
{
    int32_t ret = OK;

    ret = InitSoftDataBase(&softdata);

    softdata.eSDBState = MODULE_STATE_INIT;

    SDB_LD_Load();

    if (softdata.deviceVer.protocalNo == 0 && DirExist(APPVERDATA_XML_NAME))
    {
        ret = InitVerConfig(APPVERDATA_XML_NAME, &softdata);
        if (-1 == ret)
        {
            EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "APPVERDATA_XML_NAME error.\n");
        }
    }

    softdata.eSDBState = MODULE_STATE_READY;

    if (softdata.total_Dev_num == 0 && DirExist(MASTER_XML_NAME))
    {
        ret = SDB_LoadXML(MASTER_XML_NAME);
        if (-1 == ret)
        {
            EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "MASTER_XML_NAME error.\n");
        }
    }

    EMS_LOG(LL_WARNING, MODULE_SDB, FALSE, "%s done,ret:%d.\n", __func__, ret);
    return ret;
}

int32_t SDB_LoadXML(IN char *pcfileNameAndPath)
{
    int32_t ret = OK;

    if (strcmp(pcfileNameAndPath, MASTER_XML_NAME) == 0)
    {
        if (softdata.total_Dev_num > 0)
        {
            return ERROR_T(ERR_DEFAULT_ALREADY_EXIST);
        }

        ret = InitDevConfig(MASTER_XML_NAME, &softdata);
        if (softdata.total_Dev_num > 0)
        {
            softdata.eSDBState = MODULE_STATE_RUNNING;
            SG_MSG_T stMsg = {MSG_SDB_UPDATED, 0, 0, NULL};
            IMC_Send(&stMsg);
        }
    }

    return ret;
}

int32_t SDB_Destory()
{
    pthread_mutex_lock(&softdata.sdbLock);
    softdata.eSDBState = MODULE_STATE_NONE;

    COMMDEV_T *mb_master = commdev_table.head_commDev;
    COMMDEV_T *mb_master_cur = mb_master;
    COMMDEV_T *mb_master_tmp = NULL;

    DEV_INFO_T *mb_slaver = com_dev_info_table.head_dev;
    DEV_INFO_T *mb_slaver_cur = NULL;
    DEV_INFO_T *mb_slaver_tmp = NULL;

    int32_t i = 0, j = 0;

    for (i = 0; i < commdev_table.total_num; i++)
    {
        if (mb_master_cur != NULL)
        {
            mb_master_tmp = mb_master_cur;
            mb_master_cur = mb_master_cur->next;

            HCFREE(mb_master_tmp);
        }
    }

    mb_slaver_cur = mb_slaver;
    mb_slaver_tmp = NULL;
    for (i = 0; i < com_dev_info_table.total_dev_num; i++)
    {
        if (mb_slaver_cur != NULL)
        {
            mb_slaver_tmp = mb_slaver_cur;
            mb_slaver_cur = mb_slaver_cur->next;

            HCFREE(mb_slaver_tmp->pValue);

            for (j = 0; j < mb_slaver_tmp->dwPtlNum; j++)
            {
                mb_slaver_tmp->protocol[j]->dwRefCount--;
                printf("%s devCode:%d index:%d protocol:%p dwRefCount:%d\n",
                       __func__, mb_slaver_tmp->dev_code, mb_slaver_tmp->index,mb_slaver_tmp->protocol[j], mb_slaver_tmp->protocol[j]->dwRefCount);

                //同一个端口下的、同一个devcode，protocol只需要释放一次
                if (mb_slaver_tmp->protocol[j] != NULL && mb_slaver_tmp->protocol[j]->dwRefCount == 0)
                {
                    if (mb_slaver_tmp->protocol[j]->protocol_data != NULL)
                    {
                        HCFREE(mb_slaver_tmp->protocol[j]->protocol_data->appendix);

                        HCFREE(mb_slaver_tmp->protocol[j]->protocol_data);
                    }

                    HCFREE(mb_slaver_tmp->protocol[j]->map);
                }
            }

            if (mb_slaver_tmp->protocol[0]->dwRefCount == 0)
            {
                HCFREE(mb_slaver_tmp->protocol[0]);//protocol 是整块分配的
            }

            ShareRTDB_Delete(mb_slaver_tmp->dev_name, MAX_DEV_NAME_LEN);
            HCFREE(mb_slaver_tmp);
        }

    }

    SDB_ND_UnLoad();

    pthread_mutex_unlock(&softdata.sdbLock);

    memset(&softdata, 0, sizeof(SOFTDATABASE_T));
    memset(&com_dev_info_table, 0, sizeof(DEV_TABLE_T));
    memset(&commdev_table, 0, sizeof(COMMDEV_TABLE_T));

    return 0;
}

int32_t SDB_GetRegisterValue(INOUT DEV_DATA_T *data, IN uint16_t num)
{
    int32_t res = -1, i = 0, j = 0, m = 0;
    COMMDEV_T *new_commDev = NULL;

    int32_t dwCommNum = softdata.total_commDev_num;
    new_commDev = softdata.commDev;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }

    for (i = 0; i< dwCommNum; i++)
    {
        uint16_t dev_num = new_commDev->dev_num;

        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        for (j = 0; j < dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (tmp_newdev == NULL)
            {
                EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "tmp_newdev == NULL\n");
                return -1;
            }
            for (m = 0; m< num; m++)
            {
                if (data[m].index > softdata.total_Dev_num)
                {
                    EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "index > num\n");
                    return -1;
                }
                if ((data[m].dev_code == tmp_newdev->dev_code) && (data[m].index == tmp_newdev->index))
                {
                    if ((data[m].data_id > tmp_newdev->max_data_id) || (data[m].data_id < tmp_newdev->min_data_id))
                    {
                        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "data_id > max_data_id\n");
                        return -1;
                    }
                    int32_t id_index = tmp_newdev->map_id[data[m].data_id];
                    pthread_mutex_lock(&(softdata.sdbLock));
                    //data[m].data = tmp_newdev->data[id_index];
                    data[m].value.data = tmp_newdev->pValue[id_index].data;
                    data[m].value.dataTimeMS = tmp_newdev->pValue[id_index].dataTimeMS;
                    res ++;
                    pthread_mutex_unlock(&softdata.sdbLock);
                }
            }
            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }

    return res;
}

int32_t SDB_SetRegisterValue(INOUT DEV_DATA_T *data, IN uint16_t num)
{
    int32_t res = 0, i = 0, j = 0, m = 0;;

    int32_t dwCommNum = softdata.total_commDev_num;
    COMMDEV_T *new_commDev = softdata.commDev;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }
    if (data->index > softdata.total_Dev_num)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "index > num\n");
        return -1;
    }

    for (i = 0; i < dwCommNum; i++)
    {
        uint16_t dev_num = new_commDev->dev_num;

        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        for (j = 0; j < dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (tmp_newdev == NULL)
            {
                EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "tmp_newdev == NULL\n");
                return -1;
            }
            for (m = 0; m < num; m++)
            {
                if (data[m].index > softdata.total_Dev_num)
                {
                    EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "index > num\n");
                    return -1;
                }

                if ((data[m].dev_code == tmp_newdev->dev_code) && (data[m].index == tmp_newdev->index))
                {
                    if ((data[m].data_id > tmp_newdev->max_data_id)|| (data[m].data_id < tmp_newdev->min_data_id))
                    {
                        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "data_id > max_data_id\n");
                        return -1;
                    }
                    pthread_mutex_lock(&(softdata.sdbLock));
                    uint32_t id_index = tmp_newdev->map_id[data[m].data_id];
                    //tmp_newdev->data[id_index] = data[m].data;
                    tmp_newdev->pValue[id_index].data = data[m].value.data;
                    tmp_newdev->pValue[id_index].dataTimeMS = GetTickCount();
                    pthread_mutex_unlock(&softdata.sdbLock);

                    POINT_T stPoint = {0};
                    if (data[m].data_type == FLOAT_T)
                    {
                        stPoint.dPointValue = data[m].value.data.f32;
                    }
                    else
                    {
                        stPoint.dPointValue = data[m].value.data.s32;
                    }

                    stPoint.iPointId = data[m].data_id;
                    stPoint.ucDataType = data[m].data_type;
                    stPoint.unDataValue = data[m].value.data;

                    ShareRTDB_Update(data[m].dev_code, data[m].index, &stPoint, 1);
                }
            }
            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }
    return res;
}

int32_t SDB_GetSN(IN uint16_t devcode, INOUT char *value)
{
    if (devcode == CEMS_DEV_CODE)
    {
        strcpy(value, softdata.deviceVer.PlatformSN);
    }
    return  0;
}

int32_t SDB_SetSN(INOUT char *value)
{
    pthread_mutex_lock(&(softdata.sdbLock));
    strcpy(softdata.deviceVer.PlatformSN, value);
    pthread_mutex_unlock(&softdata.sdbLock);
    return  0;
}

int32_t SDB_GetVer(IN uint16_t devcode, INOUT PLATFORMVER_T *value)
{
    PLATFORMVER_T ver = softdata.deviceVer;
    uint32_t i = 0;

    if (devcode == CEMS_DEV_CODE)
    {
        for (i = 0; i< 4; i++)
        {
            value->protocalVer[i] = ver.protocalVer[i];
        }
        value->protocalNo = ver.protocalNo;
        strcpy(value->softWareVer, ver.softWareVer);
        strcpy(value->machineVer, ver.machineVer);
        strcpy(value->machineModel, ver.machineModel);
    }

    return  0;
}


int32_t SDB_GetDevPointAttr(IN uint16_t devcode, OUT PROTOCOL_DATA_T** pointAttrList)
{
    int32_t i = 0, j = 0, k = 0, m = 0 ,s = 0;
    PROTOCOL_T *new_protocol = NULL;
    PROTOCOL_DATA_T* new_protocol_data = NULL;
    uint16_t point_num = 0;
    int32_t count = 0;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }

    for (i = 0; i < dwCommNum; i++)
    {
        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        uint16_t dev_num = new_commDev->dev_num;
        for (j = 0; j< dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (devcode == tmp_newdev->dev_code)
            {
                point_num = tmp_newdev->point_num;
                new_protocol_data = (PROTOCOL_DATA_T *)calloc(point_num, sizeof(PROTOCOL_DATA_T));

                for (s = 0; s < tmp_newdev->dwPtlNum; s++)
                {
                    new_protocol = tmp_newdev->protocol[s];
                    for (k = 0; k < new_protocol->ptl_data_num; k++)
                    {
                        new_protocol_data[m] = new_protocol->protocol_data[k];
                        m++;
                    }
                }
                count ++;
                break;
            }
            tmp_comm_dev = tmp_comm_dev->next;
        }
        if (count > 0)
        {
            break;
        }
        new_commDev = new_commDev->next;
    }
    *pointAttrList = new_protocol_data;

    return point_num;
}

int16_t SDB_GetPointInfoByName(IN uint16_t devcode, INOUT DEV_DATA_T *data, IN char *name, IN uint16_t num)
{
    int32_t i = 0, j = 0, k = 0, m = 0, count = 0;
    PROTOCOL_T *new_protocol = NULL;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }
    for (i = 0; i< dwCommNum; i++)
    {
        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        uint16_t dev_num = new_commDev->dev_num;
        for (j = 0; j< dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (devcode == tmp_newdev->dev_code)
            {
                for (m = 0; m < tmp_newdev->dwPtlNum; m++)
                {
                    new_protocol = tmp_newdev->protocol[m];
                    for (k = 0; k< new_protocol->ptl_data_num; k++)
                    {
                        if (0 == strcmp(name, new_protocol->protocol_data[k].data_name))
                        {
                            count++;
                            if (count == num)
                            {
                                data->dev_code = devcode;
                                data->data_id = new_protocol->protocol_data[k].data_id;
                                data->index = tmp_newdev->index;
                                data->moduleID = MODULE_T;
                                break;
                            }

                        }
                    }
                }
            }

            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }

    return 0;
}

int16_t SDB_GetDataIdByName(IN uint16_t devcode, IN char *name)
{
    int32_t i = 0, j = 0, k = 0, m = 0;
    PROTOCOL_T *new_protocol = NULL;
    uint16_t dataid = 0;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }
    for (i = 0; i< dwCommNum; i++)
    {
        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        uint16_t dev_num = new_commDev->dev_num;
        for (j = 0; j< dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (devcode == tmp_newdev->dev_code)
            {
                for (m = 0; m < tmp_newdev->dwPtlNum; m++)
                {
                    new_protocol = tmp_newdev->protocol[m];
                    for (k = 0; k< new_protocol->ptl_data_num; k++)
                    {
                        if (0 == strcmp(name, new_protocol->protocol_data[k].data_name))
                        {
                            dataid = new_protocol->protocol_data[k].data_id;

                            return dataid;
                        }
                    }
                }

            }
            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }

    return dataid;
}

int32_t SDB_GetDevOfComportByNo(INOUT DEV_INFO_T *dev, IN uint16_t id, IN uint16_t num)
{
    int32_t i = 0, j = 0;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }
    for (i = 0; i < dwCommNum; i++)
    {
        if (new_commDev->id == id)
        {
            UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
            uint16_t dev_num = new_commDev->dev_num;
            for (j = 0; j < dev_num; j++)
            {
                DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
                if (j == num)
                {
                    pthread_mutex_lock(&(softdata.sdbLock));
                    memcpy(dev, tmp_newdev, sizeof(DEV_INFO_T));
                    pthread_mutex_unlock(&softdata.sdbLock);
                    break;
                }

                tmp_comm_dev = tmp_comm_dev->next;
            }
        }
        new_commDev = new_commDev->next;
    }

    return  0;
}

int32_t SDB_GetComportByNo(INOUT COMPORT_T *comport, INOUT uint16_t *id, IN uint16_t num, INOUT uint16_t *dev_num)
{
    int32_t i = 0, count = 0;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }

    for (i = 0; i < dwCommNum; i++)
    {
        if (count == num)
        {
            memcpy(id, &(new_commDev->id), sizeof(uint16_t));
            memcpy(dev_num, &(new_commDev->dev_num), sizeof(uint16_t));
            memcpy(comport, &(new_commDev->comport), sizeof(COMPORT_T));
            break;
        }
        new_commDev = new_commDev->next;
        ++count;
    }
    return  0;
}

int32_t SDB_GetDevInfo(INOUT DEV_INFO_T *dev, IN uint16_t num)
{
    int32_t i = 0, j = 0, count = 0;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }

    for (i = 0; i < dwCommNum; i++)
    {
        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        uint16_t dev_num = new_commDev->dev_num;
        for (j = 0; j < dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;

            if (count == num)
            {
//                 pthread_mutex_lock(&(softdata.sdbLock));
                memcpy(dev, tmp_newdev, sizeof(DEV_INFO_T));
//                 pthread_mutex_unlock(&softdata.sdbLock);
                return OK;
            }
            count ++;
            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }

    return  0;
}

int32_t SDB_GetDevInfoByCode(INOUT DEV_INFO_T *dev, IN uint32_t dwDevCode, IN uint32_t dwDevIndex)
{
    int32_t i = 0, j = 0;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    for (i = 0; i < dwCommNum; i++)
    {
        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        uint16_t dev_num = new_commDev->dev_num;
        for (j = 0; j< dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (tmp_newdev->dev_code == dwDevCode && tmp_newdev->index == dwDevIndex)
            {
                pthread_mutex_lock(&(softdata.sdbLock));
                memcpy(dev, tmp_newdev, sizeof(DEV_INFO_T));
                pthread_mutex_unlock(&softdata.sdbLock);
                break;
            }

            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }

    return  OK;
}

int32_t SDB_GetDevCountByCode(IN uint32_t dwDevCode)
{
    int32_t i = 0, count = 0, ret = -1;

    int32_t dwCommNum = softdata.dwNDevNum;
    for (i = 0; i < dwCommNum; i++)
    {
        DEV_INFO_EXT_T *pND = softdata.pNDevList + i;
        if (pND->stDevUID.devCode == dwDevCode)
        {
            count++;
            ret = count;
        }
    }

    return  ret;
}

int32_t SDB_GetCommunicationState(INOUT int32_t *value)
{
    *value = softdata.dev_conncomm_value;

    return  0;
}

int32_t SDB_SetCommunicationState(INOUT int32_t *value)
{
    pthread_mutex_lock(&(softdata.sdbLock));
    softdata.dev_conncomm_value = *value;
    pthread_mutex_unlock(&softdata.sdbLock);

    return  0;
}

BOOL SDB_GetUseCoeffFlag()
{
    softdata.isUseCoeffi = TRUE;
    return softdata.isUseCoeffi;
}

int32_t SDB_GetComDevNum()
{
    return softdata.total_commDev_num;
}

int32_t SDB_GetDevNum()
{
    return softdata.total_Dev_num;
}

int32_t SDB_GetNumOfKinds(INOUT uint16_t *numOfKinds)
{
    int32_t i = 0, j = 0, dwCommNum = 0;
    uint16_t len_num = 0;

    COMMDEV_T *tmp_commdev = softdata.commDev;
    if (tmp_commdev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "tmp_commdev == NULL\n");
        return -1;
    }
    dwCommNum = softdata.total_commDev_num;

    for (i = 0; i < dwCommNum; i++)
    {
        UN_COMM_DEV_T *tmp_comm_dev = tmp_commdev->head;
        uint16_t dev_num = tmp_commdev->dev_num;
        for (j = 0; j< dev_num; j++)
        {
            DEV_INFO_T *new_dev = tmp_comm_dev->dev;
            if ((new_dev != NULL) && (new_dev->index == 1))
            {
                len_num++;
            }
            tmp_comm_dev = tmp_comm_dev->next;
        }
        tmp_commdev = tmp_commdev->next;
    }

    *numOfKinds = len_num;

    return 0;
}

int32_t SDB_GetDevPtlType(IN uint16_t devcode, IN uint16_t index)
{
    int32_t i = 0, j = 0;
    uint8_t res = 0;

    int32_t dwCommNum = softdata.total_commDev_num;
    COMMDEV_T *new_commDev = softdata.commDev;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }

    for (i = 0; i< dwCommNum; i++)
    {
        uint16_t dev_num = new_commDev->dev_num;

        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        for (j = 0; j < dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (tmp_newdev == NULL)
            {
                EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "tmp_newdev == NULL\n");
                return -1;
            }
            if ((devcode == tmp_newdev->dev_code) && (index == tmp_newdev->index) && (tmp_newdev->protocol[0] != NULL))
            {
                res = tmp_newdev->protocol[0]->ptl_type;
                break;
            }
            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }

    return res;
}

int16_t SDB_GetNumOfPointName(IN uint16_t devcode, IN uint16_t index, IN char *name, INOUT uint16_t *num)
{
    int32_t i = 0, j = 0, k = 0, m = 0, count = 0;
    PROTOCOL_T *new_protocol = NULL;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }

    for (i = 0; i< dwCommNum; i++)
    {
        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        uint16_t dev_num = new_commDev->dev_num;
        for (j = 0; j < dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (tmp_newdev == NULL)
            {
                EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "tmp_newdev == NULL\n");
                return -1;
            }
            if ((devcode == tmp_newdev->dev_code) && (index == tmp_newdev->index))
            {
                for (m = 0; m < tmp_newdev->dwPtlNum; m++)
                {
                    new_protocol = tmp_newdev->protocol[m];
                    for (k = 0; k< new_protocol->ptl_data_num; k++)
                    {
                        if (0 == strcmp(name, new_protocol->protocol_data[k].data_name))
                        {
                            count++;
                            break;
                        }
                    }
                }
            }

            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }

    *num = count;

    return 0;
}

int16_t SDB_GetPointDataLen(INOUT DEV_DATA_T *data)
{
    int32_t i = 0, j = 0, m = 0, k = 0;
    int16_t res = -1;
    PROTOCOL_T *new_protocol = NULL;

    int32_t dwCommNum = softdata.total_commDev_num;
    COMMDEV_T *new_commDev = softdata.commDev;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return -1;
    }

    for (i = 0; i< dwCommNum; i++)
    {
        uint16_t dev_num = new_commDev->dev_num;

        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        for (j = 0; j < dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (tmp_newdev == NULL)
            {
                EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "tmp_newdev == NULL\n");
                return -1;
            }

            if (data->index > softdata.total_Dev_num)
            {
                EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "index > num\n");
                return -1;
            }
            if ((data->dev_code == tmp_newdev->dev_code) && (data->index == tmp_newdev->index))
            {
                if ((data->data_id > tmp_newdev->max_data_id) || (data->data_id < tmp_newdev->min_data_id))
                {
                    EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "data_id > max_data_id\n");
                    return -1;
                }
                for (m = 0; m < tmp_newdev->dwPtlNum; m++)
                {
                    new_protocol = tmp_newdev->protocol[m];
                    for (k = 0; k< new_protocol->ptl_data_num; k++)
                    {
                        if (data->data_id == new_protocol->protocol_data[k].data_id)
                        {
                            res = new_protocol->protocol_data[k].data_len;
                            break;
                        }
                    }
                }
            }
            tmp_comm_dev = tmp_comm_dev->next;
        }

        new_commDev = new_commDev->next;
    }

    return res;
}

int32_t SDB_GetState()
{
    return softdata.eSDBState;
}

int32_t SDB_GetDevInfoByUID(IN int32_t uid, OUT DEV_INFO_T *dev)
{
    int32_t i = 0, j = 0;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;
    printf("dwCommNum: %d\n", dwCommNum);

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    for (i = 0; i < dwCommNum; i++)
    {
        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        uint16_t dev_num = new_commDev->dev_num;
        for (j = 0; j < dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (tmp_newdev->dbUID == uid)
            {
//                 pthread_mutex_lock(&(softdata.sdbLock));
                memcpy(dev, tmp_newdev, sizeof(DEV_INFO_T));
//                 pthread_mutex_unlock(&softdata.sdbLock);
                return OK;
            }

            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }

    return ERROR_T(ERR_DEFAULT_NOT_FOUND);
}

int32_t SDB_GetDevInfoByName(IN char *pDevName, OUT DEV_INFO_T *dev)
{
    int32_t i = 0, j = 0;

    COMMDEV_T *new_commDev = softdata.commDev;
    int32_t dwCommNum = softdata.total_commDev_num;

    if (new_commDev == NULL)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "new_commDev == NULL\n");
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    for (i = 0; i < dwCommNum; i++)
    {
        UN_COMM_DEV_T *tmp_comm_dev = new_commDev->head;
        uint16_t dev_num = new_commDev->dev_num;
        for (j = 0; j < dev_num; j++)
        {
            DEV_INFO_T *tmp_newdev = tmp_comm_dev->dev;
            if (strcmp(pDevName, tmp_newdev->dev_name) == 0)
            {
                pthread_mutex_lock(&(softdata.sdbLock));
                memcpy(dev, tmp_newdev, sizeof(DEV_INFO_T));
                pthread_mutex_unlock(&softdata.sdbLock);
                return OK;
            }

            tmp_comm_dev = tmp_comm_dev->next;
        }
        new_commDev = new_commDev->next;
    }

    return ERROR_T(ERR_DEFAULT_NOT_FOUND);
}
////////////////////////////////////////////////////
typedef struct dbDevTableInfo_t{
    const char *pcDevTypeName;
    const int32_t devCode;
    const int32_t maxDevNum;
}DEV_TYPE_TABLE_INFO_T;

DEV_TYPE_TABLE_INFO_T g_devTypeTableList[MAX_DEV_KINDS] =
{
    {.pcDevTypeName = "环境监测仪", .devCode = WEATHER_STATION_START_NUM, .maxDevNum = WEATHER_STATION_DEV_MAX_NUM}, //10台
    {.pcDevTypeName = "电能表", .devCode = METER_START_NUM, .maxDevNum = METER_DEV_MAX_NUM}, //28台
    {.pcDevTypeName = "热表", .devCode = HEAT_METER_START_NUM, .maxDevNum = HEAT_METER_DEV_MAX_NUM}, //50台
    {.pcDevTypeName = "光伏", .devCode = INV_START_NUM, .maxDevNum = INV_DEV_MAX_NUM}, //50台
    {.pcDevTypeName = "变压器", .devCode = TRANSFORMER_START_NUM, .maxDevNum = TRANSFORMER_DEV_MAX_NUM}, //50台
    {.pcDevTypeName = "断路器", .devCode = BREAKER_START_NUM, .maxDevNum = BREAKER_DEV_MAX_NUM}, //300台
    {.pcDevTypeName = "母线", .devCode = MUXIAN_START_NUM, .maxDevNum = MUXIAN_DEV_MAX_NUM}, //5台
//     {.pcDevTypeName = "馈线", .devCode = KUIXIAN_START_NUM, .maxDevNum = KUIXIAN_DEV_MAX_NUM},  //10台
    {.pcDevTypeName = "电气设备-充电桩", .devCode = CHARGE_START_NUM, .maxDevNum = CHARGE_DEV_MAX_NUM}, //50台
    {.pcDevTypeName = "储能变流器", .devCode = STORAGE_CONVERTER_START_NUM, .maxDevNum = STORAGE_CONVERTER_DEV_MAX_NUM}, //50台
    {.pcDevTypeName = "风机", .devCode = FAN_START_NUM, .maxDevNum = FAN_DEV_MAX_NUM}, //10台
    {.pcDevTypeName = "发电机", .devCode = GENERATOR_START_NUM, .maxDevNum = GENERATOR_DEV_MAX_NUM}, //5台
};

static void getCodeByType(IN char *devType, OUT int32_t *devCode)
{
    int32_t i = 0;
    *devCode = INVALID_VALUE;
    printf("2682 %d\n", MAX_DEV_KINDS);
    for (i = 0; i < MAX_DEV_KINDS; i++)
    {
        printf("2685 %s %s\n", devType, g_devTypeTableList[i].pcDevTypeName);
        if (strcmp(devType, g_devTypeTableList[i].pcDevTypeName) == 0)
        {
            printf("2688 %d\n", g_devTypeTableList[i].devCode);
            *devCode = g_devTypeTableList[i].devCode;
            break;
        }
    }

    return ;
}

static int32_t getCIByName(IN char *devName, OUT int32_t *devCode, OUT int32_t *devIndex)
{
    //devName: 1#热表
    char *p = strchr(devName, '#');
    printf("%p\n", p);
    if (p == NULL || devCode == NULL || devIndex == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }
    else
    {
        char type[24];
        char index[8];
        strncpy(index, devName, p - devName);
        strcpy(type, p + 1);

        *devIndex = strtoul((const char *)index, NULL, 10);
        printf("2712 %d\n", *devCode);
        getCodeByType(type, devCode);
        printf("2712 devCode:%d\n", *devCode);

        if (*devCode == INVALID_VALUE)
        {
            return ERROR_T(ERR_DEFAULT_INTERNAL_ERROR);
        }

        *devCode += *devIndex;
        *devIndex = 1;
    }

    return OK;
}

static int32_t filledByConf(IN const NORTH_DEV_RECORD_T *pConfRecord, IN const int32_t recordNum)
{
    int32_t ret = OK;
    printf("enter filledByConf\n");

    softdata.pSMappedDevList = calloc(recordNum, sizeof(DEV_INFO_EXT_T));
    softdata.dwSMappedDevNum = recordNum;

    int32_t i = 0;
    const NORTH_DEV_RECORD_T *pDevHead = pConfRecord;
    const NORTH_DEV_RECORD_T *pRecord = pDevHead;
    printf("2735 recordNum:%d\n", recordNum);
    for (i = 0; pRecord != NULL && i < recordNum; i++)
    {
        pRecord = pDevHead + i;
        DEV_INFO_EXT_T *pDevInfoEx = softdata.pSMappedDevList + i;
        DEV_UID_T *pDev = &(pDevInfoEx->stDevUID);

        pDevInfoEx->dwTxSlaveId = pRecord->TxSlaveAddr;
        strcpy(pDev->devName, pRecord->MapName);
        pDev->dbUID = pRecord->DevNo;

        DEV_INFO_T stDevInfo;
        ret = SDB_GetDevInfoByUID(pRecord->DevNo, &stDevInfo);
        printf("2748 ret:%d\n", ret);
        if (ret == OK)
        {
            pDevInfoEx->eCommType = stDevInfo.com_type;
            pDevInfoEx->dwCommId = stDevInfo.com;
            printf("2753 %d %d\n", stDevInfo.com_type, stDevInfo.com);
        }
        printf("2755 %d %d\n", pRecord->MapDevCode, pRecord->MapDevIndex);
        if (pRecord->MapDevCode != 0 && pRecord->MapDevIndex != 0)
        {
            pDev->devCode = pRecord->MapDevCode;
            pDev->devIndex = pRecord->MapDevIndex;
            printf("2760 %d %d\n", pDev->devCode, pDev->devIndex);
        }
        else
        {
            printf("2764 %s %d %d\n", pDev->devName, pDev->devCode, pDev->devIndex);
            ret = getCIByName(pDev->devName, &(pDev->devCode), &(pDev->devIndex));
            printf("2767 ret:%d\n", ret);
        }
        printf("2766\n");
        if (ret == OK)
        {
            //协议
            char protocolPathAndName[128] = {0};
            PROTOCOL_T **ppProtocol = NULL;

            //去掉路径
            char fileName[24] = {0};
            char *p = strrchr(pRecord->MapFile, '/');
            printf("2776\n");
            if (p == NULL)
            {
                printf("2779\n");
                continue;
            }
            else
            {
                printf("2784\n");
                strcpy(fileName, p + 1);
            }

            sprintf(protocolPathAndName, "%s%s", TRANSMIT_POINT_DATA_XML, fileName);
            printf("2783\n");
            BOOL isExist = DirExist(protocolPathAndName);
            printf("%s protocolPathAndName:%s, isExist:%d\n", __func__, protocolPathAndName, isExist);

            if (isExist)
            {
                ppProtocol = &(softdata.pSMappedDevList[i].pProtocol);
                ret = loadPointXml(protocolPathAndName, ppProtocol, &(softdata.pSMappedDevList[i].dwPtlNum));

                int32_t j = 0;
                for (j = 0; j < softdata.pSMappedDevList[i].dwPtlNum; j++)
                {
                    softdata.pSMappedDevList[i].pProtocol[j].dev_code = pDev->devCode;
                }
            }
            else
            {
                EMS_LOG(LL_ERROR, MODULE_C, FALSE, "cannot find north dev xml!!!\n");
            }
        }

    }

    return ret;
}

//使用南向设备信息填充映射设备信息
static int32_t filledByDefault()
{
    int32_t ret = 0;
    int32_t i = 0;
    int32_t dwTotalDevNum = SDB_GetDevNum();

    softdata.dwSMappedDevNum = dwTotalDevNum;
    softdata.pSMappedDevList = calloc(softdata.dwSMappedDevNum, sizeof(DEV_INFO_EXT_T));

    for (i = 0; i < softdata.dwSMappedDevNum; i++)
    {
        DEV_INFO_EXT_T *pDIExt = softdata.pSMappedDevList + i;
        DEV_INFO_T stDI;

        ret = SDB_GetDevInfo(&stDI, i);
        pDIExt->stDevUID.devCode = stDI.dev_code;
        pDIExt->stDevUID.devIndex = stDI.index;
        pDIExt->stDevUID.dbUID = stDI.dbUID;
        strcpy(pDIExt->stDevUID.devName, stDI.dev_name);

        pDIExt->dwPtlNum = stDI.dwPtlNum;
        pDIExt->pProtocol = stDI.protocol[0];
        pDIExt->eCommType = stDI.com_type;
        pDIExt->dwCommId = stDI.com;
    }

    return ret;
}

int32_t SDB_MD_Load()
{
    int32_t ret = OK;

    NORTH_DEV_RECORD_T *pstNDevList = NULL;
    int32_t recordNum = 0;

    do
    {
        ret = sysCfg_Load(CFG_TYPE_NORTH_DEV_LIST, (void **)(&pstNDevList), &recordNum);
        printf("2847 ret:%d\n", ret);
        if (ret != OK || recordNum == 0)
        {
            //填充南向设备映射设备列表
            ret = filledByDefault();
            Mapping_SetUseDefault(TRUE);
            break;
        }

        if (recordNum > 0)
        {
            filledByConf(pstNDevList, recordNum);
            Mapping_SetUseDefault(FALSE);
        }

        sysCfg_Free(pstNDevList);
    }while(0);
    printf("2864\n");
    N2SDev_CreateMap();
    Point_CreateMap();

    return ret;
}

int32_t SDB_MD_UnLoad()
{
    int32_t ret = OK;

    Point_DestroyMap();
    N2SDev_DestroyMap();

    //如果使用默认的南向设备协议，它已经在SDB Destroy() com_dev_info  中释放了
    if (Mapping_GetUseDefault() == FALSE && softdata.pSMappedDevList != NULL)
    {
        int32_t i = 0, j = 0;
        for (i = 0; i < softdata.dwSMappedDevNum; i++)
        {
            DEV_INFO_EXT_T *pDevInfo = softdata.pSMappedDevList + i;
            int32_t dwPtlNum = pDevInfo->dwPtlNum;

            for (j = 0; j < dwPtlNum; j++)
            {
                PROTOCOL_DATA_T *pPtlData = pDevInfo->pProtocol[j].protocol_data;
                HCFREE(pPtlData);
            }

            HCFREE(pDevInfo->pProtocol);
        }

        HCFREE(softdata.pSMappedDevList);
    }

    return ret;
}

DEV_INFO_EXT_T* SDB_MD_GetList()
{
    return softdata.pSMappedDevList;
}

int32_t SDB_MD_GetNum()
{
    return softdata.dwSMappedDevNum;
}

int32_t SDB_MD_GetPointNum(IN DEV_INFO_EXT_T *pDev)
{
    int32_t dwPointNum = 0;
    if (pDev == NULL)
    {
        return dwPointNum;
    }

    int32_t i = 0;
    for (i = 0; i < pDev->dwPtlNum; i++)
    {
        dwPointNum += pDev->pProtocol[i].ptl_data_num;
    }

    return dwPointNum;
}

int32_t SDB_MD_GetKinds()
{
    int32_t num = 0, i = 0;

    for (i = 0; i < softdata.dwSMappedDevNum; i++)
    {
        if (softdata.pSMappedDevList[i].stDevUID.devIndex == 1)
        {
            ++num;
        }
    }

    return num;
}

DEV_INFO_EXT_T* SDB_LD_Load()
{
    DEV_INFO_EXT_T *pLocalDev = NULL;

    PROTOCOL_T *pLocalDevPtl = NULL;
    int32_t dwLocalDevPtlNum = 0;

    if (softdata.pLocalDev != NULL)
    {
        return softdata.pLocalDev;
    }

    char pPathAndFile[128] = {'0'};
    sprintf(pPathAndFile, "%s%s.xml", PLATFOTM_DATA_XML, NATIVE_DEVICE_NAME);

    if (!DirExist(pPathAndFile))
    {
        return pLocalDev;
    }

    int32_t ret = loadPointXml(pPathAndFile, &pLocalDevPtl, &dwLocalDevPtlNum);
    if (ret == OK)
    {
        pLocalDev = malloc(sizeof(DEV_INFO_EXT_T));
        memset(pLocalDev, 0, sizeof(DEV_INFO_EXT_T));

        pLocalDev->dwPtlNum = dwLocalDevPtlNum;
        pLocalDev->pProtocol = pLocalDevPtl;
        pLocalDev->stDevUID.devCode = CEMS_DEV_CODE;
        pLocalDev->stDevUID.devIndex = 1;
        pLocalDev->stDevUID.dbUID = 0;
        strcpy(pLocalDev->stDevUID.devName, NATIVE_DEVICE_NAME);
        pLocalDev->eCommType = COMM_TYPE_MAX;
        pLocalDev->dwTxSlaveId = 1;

        int32_t i = 0, dwMaxDataId = 0;
        for (i = 0; i < dwLocalDevPtlNum; i++)
        {
            pLocalDev->pProtocol[i].dev_code = CEMS_DEV_CODE;

            dwMaxDataId = (dwMaxDataId > pLocalDev->pProtocol[i].max_data_id) ? dwMaxDataId : pLocalDev->pProtocol[i].max_data_id;
        }

        softdata.pLocalDev = pLocalDev;

        DEVMAP_T stDevMap;
        memset(&stDevMap, 0, sizeof(DEVMAP_T));
        strcpy(stDevMap.stDevInfo.cDevName, pLocalDev->stDevUID.devName);
        stDevMap.stDevInfo.ucDevId = pLocalDev->stDevUID.devIndex;
        stDevMap.stDevInfo.uwDevCode = pLocalDev->stDevUID.devCode;
        stDevMap.stDevInfo.ucPointLen = dwMaxDataId + 1;
        stDevMap.stDevInfo.dbUID = pLocalDev->stDevUID.dbUID;

        ShareRTDB_Add(&stDevMap);
    }

    return pLocalDev;
}

int32_t SDB_LD_UnLoad(DEV_INFO_EXT_T *pLocalDev)
{
    if (softdata.pLocalDev != NULL)
    {
        HCFREE(softdata.pLocalDev->pProtocol);
        HCFREE(softdata.pLocalDev);
    }

    return OK;
}

DEV_INFO_EXT_T* SDB_LD_Get()
{
    return softdata.pLocalDev;
}

int32_t SDB_ND_Load()
{
    DEV_INFO_EXT_T *pstNDevList = NULL;

    pthread_mutex_lock(&softdata.sdbLock);
    if (softdata.dwNDevNum != 0)
    {
        pthread_mutex_unlock(&softdata.sdbLock);
        return ERROR_T(ERR_DEFAULT_ALREADY_INIT);
    }

    SDB_LD_Load();
    SDB_MD_Load();

    {
        int32_t dwCount = softdata.dwSMappedDevNum + 1; //本机预留第0位
        pstNDevList = malloc(sizeof(DEV_INFO_EXT_T) * dwCount);

        memcpy(pstNDevList, softdata.pLocalDev, sizeof(DEV_INFO_EXT_T));
        memcpy(pstNDevList + 1, softdata.pSMappedDevList, sizeof(DEV_INFO_EXT_T) * softdata.dwSMappedDevNum);

        softdata.dwNDevNum = dwCount;
        softdata.pNDevList = pstNDevList;
    }

    pthread_mutex_unlock(&softdata.sdbLock);

    return OK;
}

int32_t SDB_ND_UnLoad()
{
    SDB_LD_UnLoad(softdata.pLocalDev);
    SDB_MD_UnLoad();

    if (softdata.pNDevList != NULL)
    {
        HCFREE(softdata.pNDevList);
        softdata.dwNDevNum = 0;
    }

    return OK;
}

int32_t SDB_ND_GetKinds()
{
    int32_t num = 0, i = 0;

    for (i = 0; i < softdata.dwNDevNum; i++)
    {
        if (softdata.pNDevList[i].stDevUID.devIndex == 1)
        {
            ++num;
        }
    }

    return num;
}

int32_t SDB_ND_GetNum()
{
    return softdata.dwNDevNum;
}

DEV_INFO_EXT_T* SDB_ND_GetList()
{
    return softdata.pNDevList;
}

DEV_INFO_EXT_T* SDB_ND_Get(int32_t dwDevCode, int32_t dwDevIndex)
{
    DEV_INFO_EXT_T *pstNDevList = NULL;
    int32_t i = 0;

    for (i = 0; i < softdata.dwNDevNum; i++)
    {
//         printf("i: %d devCode: %d %d devIndex: %d dwNDevNum: %d\n",i, softdata.pNDevList[i].stDevUID.devCode, dwDevCode, softdata.pNDevList[i].stDevUID.devIndex, softdata.dwNDevNum);
        if (softdata.pNDevList[i].stDevUID.devCode == dwDevCode && softdata.pNDevList[i].stDevUID.devIndex == dwDevIndex)
        {
            pstNDevList = softdata.pNDevList + i;
        }
    }

    return pstNDevList;
}

int32_t SDB_ND_GetAddrRange(IN int32_t dwDevCode, IN int32_t dwDevIndex, OUT int32_t *pdwMaxAddr, OUT int32_t *pdwMinAddr)
{
    int32_t ret = OK;
    int32_t i = 0, dwTmpMinAddr = 0, dwTmpMaxAddr = 0, dwMinAddr = 65535, dwMaxAddr = 0;

    DEV_INFO_EXT_T *pstNDevList = SDB_ND_Get(dwDevCode, dwDevIndex);
    if (pstNDevList == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_FOUND);
    }

    for (i = 0; i < pstNDevList->dwPtlNum; i++)
    {
        dwTmpMinAddr = pstNDevList->pProtocol[i].min_address;
        dwTmpMaxAddr = pstNDevList->pProtocol[i].max_address;

        dwMinAddr = (dwMinAddr < dwTmpMinAddr) ? dwMinAddr : dwTmpMinAddr;
        dwMaxAddr = (dwMaxAddr > dwTmpMaxAddr) ? dwMaxAddr : dwTmpMaxAddr;
    }

    *pdwMaxAddr = dwMaxAddr;
    *pdwMinAddr = dwMinAddr;

    return ret;
}

int32_t SDB_ND_GetDataId(IN int32_t dwDevCode, IN int32_t dwDevIndex, IN char *pcDataName)
{
    int32_t ret = INVALID_VALUE, i = 0, j = 0;

    DEV_INFO_EXT_T *pstNDevList = SDB_ND_Get(dwDevCode, dwDevIndex);
    if (pstNDevList == NULL || pcDataName == NULL)
    {
        return ret;
    }

    for (i = 0; i < pstNDevList->dwPtlNum; i++)
    {
        for (j = 0; pstNDevList->pProtocol + i != NULL && j < pstNDevList->pProtocol[i].ptl_data_num; j++)
        {
            if (strcmp(pcDataName, pstNDevList->pProtocol[i].protocol_data[j].data_name) == 0)
            {
                ret = pstNDevList->pProtocol[i].protocol_data[j].data_id;
                break;
            }
        }
    }
    return ret;
}

int32_t SDB_ND_GetDataIdByAddr(IN int32_t dwDevCode, IN int32_t dwDevIndex, IN int32_t dwAddr, IN int32_t dwFuncCode)
{
    int32_t ret = INVALID_VALUE, i = 0, j = 0;

    DEV_INFO_EXT_T *pstNDevList = SDB_ND_Get(dwDevCode, dwDevIndex);
    if (pstNDevList == NULL)
    {
        return ret;
    }

    for (i = 0; i < pstNDevList->dwPtlNum; i++)
    {
        for (j = 0; pstNDevList->pProtocol + i != NULL && j < pstNDevList->pProtocol[i].ptl_data_num; j++)
        {
            //test
//             printf("address: %d  cmd: %d\n", pstNDevList->pProtocol[i].protocol_data[j].address, pstNDevList->pProtocol[i].cmd);
            if (dwAddr == pstNDevList->pProtocol[i].protocol_data[j].address
                && dwFuncCode == pstNDevList->pProtocol[i].cmd)
            {
                ret = pstNDevList->pProtocol[i].protocol_data[j].data_id;
                break;
            }
        }
    }
    return ret;
}

const PROTOCOL_DATA_T* SDB_ND_GetProtocolData(IN int32_t dwDevCode, IN int32_t dwDevIndex, IN int32_t dwDataId)
{
    PROTOCOL_DATA_T *pProtocolData = NULL;
    int32_t i = 0, j = 0;

    DEV_INFO_EXT_T *pstNDevList = SDB_ND_Get(dwDevCode, dwDevIndex);
    if (pstNDevList == NULL)
    {
        return pProtocolData;
    }

    for (i = 0; i < pstNDevList->dwPtlNum; i++)
    {
        for (j = 0; pstNDevList->pProtocol + i != NULL && j < pstNDevList->pProtocol[i].ptl_data_num; j++)
        {
            if (pstNDevList->pProtocol[i].protocol_data[j].data_id == dwDataId)
            {
                pProtocolData = pstNDevList->pProtocol[i].protocol_data + j;
                return pProtocolData;
            }
        }
    }

    return pProtocolData;
}

int32_t SDB_ND_GetConnectState(IN int32_t dwDevCode, IN int32_t dwDevIndex)
{
    if (dwDevCode > MAX_DEV_CODE || dwDevIndex > RTDB_MAX_DEV_NUM)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    int32_t ret;
    DEV_UID_T pN = {dwDevCode, dwDevIndex};
    DEV_UID_T pS;

    ret = N2SDev_GetValue(&pN, &pS);
    if (ret == OK)
    {
        POINT_T stPoint[RTDB_MAX_POINT_NUM];
        uint8_t ucPointCount = RTDB_MAX_POINT_NUM;
        ret = ShareRTDB_Query(pS.devCode, pS.devIndex, stPoint, &ucPointCount);
        if (ret == OK)
        {
            return (stPoint[0].unDataValue.s32 == 1) ? OFF : ON;
        }
    }

    return ERROR_T(ERR_DEFAULT_NOT_FOUND);
}
