#ifndef MAPPING_H_INCLUDED
#define MAPPING_H_INCLUDED

#include "err.h"

typedef struct{
    DEV_UID_T stNorth;
    DEV_UID_T stSouth;
    uint32_t commtype;      //端口类型
    int32_t portID;         //物理端口号
    int32_t mapGrp; //设备所属的组别,“源-网-荷-储”
    int32_t mapType; //设备所属的类型,：光伏、发电...
}N2S_DEV_RECORD_T;

typedef struct {
    int32_t devCode;
    int32_t devIndex;
    int32_t dataId;
} RECORD_KEY_T;


int32_t N2SDev_CreateMap();

int32_t N2SDev_GetValue(IN DEV_UID_T *pNorthDev, INOUT DEV_UID_T *pSouthDev);

int32_t N2SDev_DestroyMap();

int32_t Point_CreateMap();

int32_t Point_DestroyMap();

int32_t Point_PrintMap();

void Mapping_SetUseDefault(BOOL trueOrFalse);

BOOL Mapping_GetUseDefault();

RECORD_KEY_T* N2SPoint_GetValue(IN RECORD_KEY_T *pNorthP);

RECORD_KEY_T** S2NPoint_GetValue(IN RECORD_KEY_T *pSouthP, OUT int32_t *pPointNum);

#endif // MAPPING_H_INCLUDED
