#ifndef SDB_H_INCLUDED
#define SDB_H_INCLUDED

#include <pthread.h>
#include <sqlite3.h>
#include "common.h"
#include "sysCfg.h"
#include "err.h"

#define heat_dev_adress   7

#if DEV_CONFIG
#define PLATFOTM_DATA_XML "./conf/dataprocess/"
#define POINT_DATA_XML "./conf/collect/"
#define TRANSMIT_POINT_DATA_XML "./conf/transmit/"

#define MASTER_XML_NAME "./conf/collect/ModbusMasterConfig.xml"
// #define MASTER_XML_NAME "./conf/collect/ModbusMasterConfigJHTest.xml"
#define APPVERDATA_XML_NAME "./conf/AppVer.xml"
#define DATAPROCESS_XML_NAME "./conf/dataprocess/DataProcessConfig.xml"
#define CONFIGFILEPATH "./conf/transmit/ModbusSlaveConfig.xml"
#define ETH_FILE_PATH "./conf/NetPortConfig.xml"

#else
#define PLATFOTM_DATA_XML "/home/SGComm/conf/dataprocess/"
#define POINT_DATA_XML "/home/SGComm/conf/collect/"
#define TRANSMIT_POINT_DATA_XML "/home/SGComm/conf/transmit/"

#define MASTER_XML_NAME "/home/SGComm/conf/collect/ModbusMasterConfig.xml"
#define APPVERDATA_XML_NAME "/home/SGComm/conf/AppVer.xml"
#define DATAPROCESS_XML_NAME "/home/SGComm/conf/dataprocess/DataProcessConfig.xml"
#define CONFIGFILEPATH "/home/SGComm/conf/transmit/ModbusSlaveConfig.xml"
#define ETH_FILE_PATH "/home/SGComm/conf/NetPortConfig.xml"
#endif

#define NATIVE_DEVICE_NAME "e-FMC"

#define POINT_NAME_MAX_LEN 100
#define MAX_DEV_NUM 1000              //最大从设备数
#define MAX_PROTOCOL_NUM 200           //单个设备最大协议表数量
#define UART_PORT_NUM   6
#define NET_PORT_NUM   2
#define CAN_PORT_NUM   1

typedef enum
{
    SIGN_U = 0,
    SIGN_S,
    SIGN_F,
}DATA_SIGN_E;

typedef enum
{
    TYPE_INT = 1,
    TYPE_F,
}DATA_TYPE_E;

typedef enum
{
    MODBUS = 0,
    DLT645,
    IEC104,
    CJT188,
}PTL_TYPE_E;

typedef enum
{
    LH_BYTE = 0,
    HL_BYTE,
    LH_WORD,
    HL_WORD,
}DATA_SEQ_E;

typedef enum
{
    UART = 0,
    CAN,
    NET,
    SG_METER,
    CJT_188,
    COMM_TYPE_MAX,
}COMMDEV_TYPE_E;

typedef struct platformver_st
{
    uint32_t protocalNo;                   //协议号
    uint8_t protocalVer[4];                //协议版本号
    char softWareVer[9];                   //软件版本号
    char machineModel[8];                  //机器型号
    char machineVer[10];                   //机器版本号
    char PlatformSN[16];
}PLATFORMVER_T;

typedef struct alarm_clock_t
{
    uint32_t start_delay;               //启动延迟
    int32_t timing;                     //定时周期
    int32_t tim_cur;                    //定时剩余时间
    int32_t timeout;                    //接收超时时间
    uint8_t scan_stop;                  //扫描暂停标志//1,暂停扫描,
    uint8_t tim_flag;                   //timing is arrived
    uint8_t timeout_flag;               //timeout is arrived
}ALARM_CLOCK_T;

typedef struct comport_st
{
    uint32_t commtype;      //端口类型
    int32_t uartid;         //串口号
    uint32_t uartbaudrate;  //uart 波特率
    int32_t uartdatabit;    //串口数据位
    char uartstopbit[4];    //uart 停止位
    char uartparity;
    uint8_t ip[4];
    uint16_t netport;       //端口号
    uint32_t canbaudrate;   //can 波特率
    char canframe[32];      //can 帧格式
    int32_t canid_mask;     // can id过滤
}COMPORT_T;

//通信协议点表数据类型
typedef struct protocol_data_t
{
    char data_name[128];         //数据名称
    uint8_t show_id ;            //显示使能
    uint16_t data_id;            //数据ID
    char data_unit[32];          //数据单位
    uint32_t address;            //寄存器地址
    uint32_t iec_address;        //IEC104寄存器地址
    uint32_t datacode;           //数据标识
    uint16_t data_len;           //数据长度
    uint8_t data_type;           //数据类型
    char data_info[32];          //数据信息
    uint8_t data_sign;           //数据符号位
    float32_t coefficient;       //系数
    float32_t unitCoefficient;   //单位里的系数
    int32_t low_limit;           //下限
    int32_t high_limit;          //上限
    int32_t low_limit1;          //下限
    int32_t high_limit1;         //上限
    uint32_t def_value;          //默认值

    uint8_t iecCode;             //IEC(YC YX YT YK)

    char *appendix;              //附录

    uint8_t appendix_enable;     //附录使能

    int32_t dwSouthDataId;
    int32_t dwSouthAddr;

}PROTOCOL_DATA_T;

//点表属性
typedef struct protocol_st
{
    uint8_t id;                         //下位机通信站号
    uint8_t ptl_id;                     //协议id号
    uint8_t ptl_type;                   //协议类型
    uint8_t byte_seq;                   //字节序号
    uint8_t word_seq;                   //字序号
    uint8_t cyc_enable;                 //是否循环采集
    uint8_t cmd;                        //寄存器类型
    uint8_t ctrlcmd;                     //控制码
    uint32_t address;                   //起始地址
    uint32_t max_address;               //最大地址
    uint32_t min_address;               //最小地址
    uint16_t max_data_id;               //最大data_id
    uint16_t min_data_id;               //最小data_id
    uint16_t dev_code;                  //设备编码
    uint16_t len;                       //长度
    PROTOCOL_DATA_T *protocol_data;     //点表起始地址
    uint16_t ptl_data_num;              //测点个数
    uint32_t *map;                      //点表映射表    协议寄存器地址-点表序号
    uint32_t dlt645_07cmd;              //电表命令
    uint32_t dlt645_Re_cmd;

    uint32_t dwRefCount;                //被引用次数
}PROTOCOL_T;

typedef struct dev_info_st
{
    char name[32];                              //设备类型名称 hc100
    uint16_t id;
    uint16_t index;                             //设备索引，一种类型设备编序
    uint8_t  meter_addr[6];                     //电表地址
    uint16_t PT_Pare;
    uint16_t CT_Pare;
    uint8_t Meter_dire;                         //电表方向
    char dev_sn[32];                            //设备序列号
    char position[128];                         //设备位置信息
    uint16_t dev_code;                          //设备类型编码
    char dev_name[MAX_DEV_NAME_LEN];            //设备名称
    uint8_t ucSubType;                          //设备子类
    char dev_address[32];                       // 设备地址
    uint8_t dev_breaker;                        //设备丛属关系
    uint8_t slaverid_modify;                    //设备地址能否改变
    uint16_t cslave_id;                         //通信站号,设备地址
    uint8_t com;                                //从站所在的主站端口
    uint32_t com_type;                          //挂载通信口类型//uart或者can...
    DATA_U *data;                               //设备数据
    VALUE_INFO_T *pValue;
    PROTOCOL_T *protocol[MAX_PROTOCOL_NUM];        //通信协议
    int32_t dwPtlNum;                          //通信协议个数
    uint16_t point_num;                         //设备的测点个数
    uint16_t max_data_id;                       //最大测点号
    uint16_t min_data_id;                       //最小测点号
    int32_t canid_send;
    int32_t canid_rev;
    int32_t heart_type;                         //是否开启心跳
    int32_t heart_time;                         //心跳时间
    int32_t dbUID;                               //
    ALARM_CLOCK_T scan_clock;

    uint32_t *map_id;                           //data_id的映射
    struct dev_info_st *next;
}DEV_INFO_T;

typedef struct under_com_dev_st
{
    DEV_INFO_T *head_dev;
    DEV_INFO_T *end_dev;
    uint16_t total_dev_num;
}DEV_TABLE_T;

//comport dev
typedef struct un_comm_dev_st
{
    DEV_INFO_T *dev;               //链表指针
    struct un_comm_dev_st *next;    //链表指针
}UN_COMM_DEV_T;

typedef struct commdev_st
{
    COMPORT_T comport;
    uint16_t id;
    uint16_t dev_num;
    UN_COMM_DEV_T *head;
    UN_COMM_DEV_T *end;
    struct commdev_st *next;
}COMMDEV_T;

//commport 链表
typedef struct comdev_table_st
{
    COMMDEV_T *head_commDev;
    COMMDEV_T *end_commDev;
    uint16_t total_num;
}COMMDEV_TABLE_T;

typedef struct{
    int32_t devCode;
    int32_t devIndex;
    char devName[MAX_DEV_NAME_LEN];
    int32_t dbUID;
}DEV_UID_T; //设备唯一标志结构体

typedef struct{
    DEV_UID_T stDevUID;
    PROTOCOL_T *pProtocol;
    int32_t dwPtlNum;
    COMMDEV_TYPE_E eCommType;      //端口类型
    int32_t dwCommId;              //端口号
    int32_t dwTxSlaveId;           //北向转发地址
}DEV_INFO_EXT_T;

typedef struct softdatabase_st
{
    PLATFORMVER_T deviceVer;
    COMMDEV_T *commDev;
    uint16_t total_commDev_num;             //设备类型总数
    uint16_t total_Dev_num;                 //南向设备总数
    int32_t dev_conncomm_value;
    uint32_t dataId_modify;                     //设备点表中dataid是否要重新编写
    pthread_mutex_t sdbLock;
    MODULE_STATE_E eSDBState;
    DEV_INFO_EXT_T *pSMappedDevList; // 南向映射设备列表
    int32_t dwSMappedDevNum; //南向映射设备数量
    DEV_INFO_EXT_T *pLocalDev; //本机设备
    DEV_INFO_EXT_T *pNDevList; // 北向设备列表
    int32_t dwNDevNum; //北向设备数量
    BOOL isUseCoeffi; //流通的设备数据是否经过精度转换
}SOFTDATABASE_T;

int32_t SDB_Init();
int32_t SDB_LoadXML(IN char *pcfileNameAndPath);
int32_t SDB_Destory();

int32_t SDB_SetRegisterValue(INOUT DEV_DATA_T *data, IN uint16_t num);
int32_t SDB_GetRegisterValue(INOUT DEV_DATA_T *data, IN uint16_t num);
int32_t SDB_GetSN(IN uint16_t devcode, INOUT char *value);
int32_t SDB_SetSN(INOUT char *value);
int32_t SDB_GetVer(IN uint16_t devcode, INOUT PLATFORMVER_T *value);
int32_t SDB_GetDevPointAttr(IN uint16_t devcode, OUT PROTOCOL_DATA_T** pointAttrList);
int16_t SDB_GetDataIdByName(IN uint16_t devcode, IN char *name);
int32_t SDB_GetComportByNo(INOUT COMPORT_T *comport, INOUT uint16_t *id, IN uint16_t num, INOUT uint16_t *dev_num);
int32_t SDB_GetDevOfComportByNo(INOUT DEV_INFO_T *dev, IN uint16_t id, IN uint16_t num);
int32_t SDB_GetDevNum();
int32_t SDB_GetComDevNum();
int32_t SDB_GetCommunicationState(INOUT int32_t *value);
int32_t SDB_SetCommunicationState(INOUT int32_t *value);

BOOL SDB_GetUseCoeffFlag();

/**
 * @brief  获取南向设备类型的种类数
 * @param
 *
 * @return
 */
int32_t SDB_GetNumOfKinds(INOUT uint16_t *numOfKinds);

int32_t SDB_GetDevInfo(INOUT DEV_INFO_T *dev, IN uint16_t num);

int16_t SDB_GetPointInfoByName(IN uint16_t devcode, INOUT DEV_DATA_T *data, IN char *name, IN uint16_t num);
int32_t SDB_GetDevPtlType(IN uint16_t devcode, IN uint16_t index);
int16_t SDB_GetNumOfPointName(IN uint16_t devcode, IN uint16_t index, IN char *name, INOUT uint16_t *num);
int16_t SDB_GetPointDataLen(INOUT DEV_DATA_T *data);

/**
 * @brief  根据设备编码和设备索引，获取对应设备信息
 * @param
 *
 * @return
 */
int32_t SDB_GetDevInfoByCode(INOUT DEV_INFO_T *dev, IN uint32_t dwDevCode, IN uint32_t dwDevIndex);

/**
 * @brief  根据唯一标识符，获取对应设备信息
 * @param
 *
 * @return
 */
int32_t SDB_GetDevInfoByUID(IN int32_t uid, OUT DEV_INFO_T *dev);

/**
 * @brief  根据设备别名获取对应设备信息
 * @param
 *
 * @return
 */
int32_t SDB_GetDevInfoByName(IN char *pDevName, OUT DEV_INFO_T *dev);

/**
 * @brief  根据设备编码,获取对应设备数量
 * @param
 *
 * @return
 */
int32_t SDB_GetDevCountByCode(IN uint32_t dwDevCode);

/**
 * @brief  加载南向映射设备、协议（不包含本机设备）
 * @param
 *
 * @return
 */
int32_t SDB_MD_Load();

/**
 * @brief  获取南向映射设备列表（不包含本机设备）
 * @param
 *
 * @return
 */
DEV_INFO_EXT_T* SDB_MD_GetList();

/**
 * @brief  获取南向映射设备数量（不包含本机设备）
 * @param
 *
 * @return
 */
int32_t SDB_MD_GetNum();

/**
 * @brief  获取南向映射设备测点数量
 * @param
 *
 * @return
 */
int32_t SDB_MD_GetPointNum(IN DEV_INFO_EXT_T *pDev);

/**
 * @brief  获取南向映射设备种类数量
 * @param
 *
 * @return
 */
int32_t SDB_MD_GetKinds();

/**
 * @brief  加载本机设备
 * @param
 *
 * @return
 */
DEV_INFO_EXT_T* SDB_LD_Load();

/**
 * @brief  获取本机设备
 * @param
 *
 * @return
 */
DEV_INFO_EXT_T* SDB_LD_Get();

/**
 * @brief  释放本机设备
 * @param
 *
 * @return
 */
int32_t SDB_LD_UnLoad(DEV_INFO_EXT_T *pLocalDev);

/**
 * @brief  加载北向设备
 * @param
 *
 * @return
 */
int32_t SDB_ND_Load();

/**
 * @brief  释放北向设备
 * @param
 *
 * @return
 */
int32_t SDB_ND_UnLoad();

/**
 * @brief  获取北向设备种类数量
 * @param
 *
 * @return
 */
int32_t SDB_ND_GetKinds();

/**
 * @brief  获取北向设备数量
 * @param
 *
 * @return
 */
int32_t SDB_ND_GetNum();

/**
 * @brief  获取北向设备列表
 * @param
 *
 * @return
 */
DEV_INFO_EXT_T* SDB_ND_GetList();

/**
 * @brief  获取北向设备
 * @param
 *
 * @return
 */
DEV_INFO_EXT_T* SDB_ND_Get(IN int32_t dwDevCode, IN int32_t dwDevIndex);

/**
 * @brief  根据dwDevCode、dwDevIndex 获取对应设备寄存器地址范围
 * @param
 *
 * @return
 */
int32_t SDB_ND_GetAddrRange(IN int32_t dwDevCode, IN int32_t dwDevIndex, OUT int32_t *pdwMaxAddr, OUT int32_t *pdwMinAddr);

/**
 * @brief  根据测点名称获取data id
 * @param
 *
 * @return 失败返回-1,成功返回data id
 */
int32_t SDB_ND_GetDataId(IN int32_t dwDevCode, IN int32_t dwDevIndex, IN char *pcDataName);

/**
 * @brief  根据测点地址和功能码获取data id
 * @param
 *
 * @return 失败返回-1,成功返回data id
 */
int32_t SDB_ND_GetDataIdByAddr(IN int32_t dwDevCode, IN int32_t dwDevIndex, IN int32_t dwAddr, IN int32_t dwFuncCode);

/**
 * @brief  根据data id获取测点信息
 * @param
 *
 * @return 失败返回NULL,成功返回非NULL
 */
const PROTOCOL_DATA_T* SDB_ND_GetProtocolData(IN int32_t dwDevCode, IN int32_t dwDevIndex, IN int32_t dwDataId);

/**
 * @brief  获取设备在线状态
 * @param
 *
 * @return ON,在线；OFF,离线
 */
int32_t SDB_ND_GetConnectState(IN int32_t dwDevCode, IN int32_t dwDevIndex);

int32_t SDB_GetState();
#endif // SDB_H_INCLUDED
