#ifndef SYSCFG_H_INCLUDED
#define SYSCFG_H_INCLUDED

#include "common.h"
#include "runCfg.h"
#include "err.h"

typedef enum {
    CFG_TYPE_ALGOR,
    CFG_TYPE_RUN_CTRL,
    CFG_TYPE_PROTECT_STORAGE,
    CFG_TYPE_PROTECT_NET,
    CFG_TYPE_NORTH_PARAM,
    CFG_TYPE_IO,
    CFG_TYPE_NORTH_DEV_LIST,
    CFG_TYPE_TIME_CFG,
    CFG_TYPE_MAX
}CFG_TYPE_E;

typedef enum
{
    NONE = 0,
    DEVICE_CATEGORY_INV,
    DEVICE_CATEGORY_PVS,
    DEVICE_CATEGORY_BATTERY, //电池
    DEVICE_CATEGORY_METERE, //电表
    DEVICE_CATEGORY_EM, //环境监测仪
    DEVICE_CATEGORY_GENERATRIX, //母线
    DEVICE_CATEGORY_FEEDER, //馈线
    DEVICE_CATEGORY_BREAKER, //断路器
    DEVICE_CATEGORY_TRANSFORMER, //变压器
    DEVICE_CATEGORY_CHARGING, //充电桩
    DEVICE_CATEGORY_HC_METER, //冷热表
    DEVICE_CATEGORY_MAX,
}DEVICE_CATEGORY_E;

typedef struct {
    CFG_TYPE_E eType;
    void *pvdata;
    int32_t pvdataLen;
}QUERY_DATA_T;
/****************************** 北向通信参数 ****************************************/

typedef struct{
    int32_t CfgSelect; //0：未选择,1：Mqtt,2：Modbus,4：104,3: Mqtt + Modbus,5: Mqtt + 104,6: Modbus + 104,7: Mqtt + Modbus + 104
    char MqttAddr[128]; //mqttIP地址

    int32_t MqttPort;  //mqtt端口
    int32_t MqttMethod; //MQTT上传方式
    int32_t MqttCycle; //MQTT上传周期
    BOOL MqttEncry; //云加密使能,0：关闭,1：开启
    int32_t MqttAlgor; //云加密算法,默认1：AES128
    int32_t ModbusPort; //modbus端口号
    int32_t Port104; //104端口号
    char MqttPubTopic[128]; //mqtt 发布topic
    char MqttSubTopic[128]; //mqtt 订阅topic
    char MqttClientID[128]; //mqtt 订阅topic
    char MqttUser[128]; //mqtt 订阅topic
    char MqttPwd[128]; //mqtt 订阅topic
    char IP1[128];
    int EnDhcp1;
}NORTH_PARAM_T;

/****************************** 数字量IO配置 ****************************************/
typedef enum {
    IO_TYPE_DO,
    IO_TYPE_DI
}IO_TYPE_E;

typedef enum {
    DI_FUNC_DEFAULT, //0：未设置
    DI_FUNC_FAULT, //1：故障
    DI_FUNC_WARN, //2：告警
}DI_FUNC_E;

typedef enum {
    DI_MODE_DEFAULT, //0：未设置
    DI_MODE_ON, //1：常开
    DI_MODE_OFF //2：常闭
}DI_MODE_E;

typedef enum {
    DO_FUNC_DEFAULT, //0：未设置
    DO_FUNC_RUN, //1：运行指示
    DO_FUNC_FAULT, //2：故障指示
    DO_FUNC_WARN //3：告警指示
}DO_FUNC_E;

typedef struct{
    int32_t ID; //IO编号
    char Name[32]; //数字量的别名
    IO_TYPE_E Type; //DI或者DO
    BOOL DIEnable; //1：开启,0：禁止
    DI_FUNC_E DIFunction;
    DI_MODE_E DIMode;
    DO_FUNC_E DOFunction;

}IO_PARAM_T;
/****************************** 北向设备列表 ****************************************/

typedef struct{
    int32_t ID; //主键
    int32_t MapGrp; //北向设备所属的组别,“源-网-荷-储”
    int32_t MapType; //北向设备所属的类型,：光伏、发电...
    char MapName[32]; //北向设备名称
    int32_t TxSlaveAddr; //北向Modbus转发从机地址
    int32_t DevNo; //南向设备编号
    int32_t MapDevCode; //北向设备编码
    int32_t MapDevIndex; //北向设备相同code下索引
    char MapFile[64]; //北向设备名称
}NORTH_DEV_RECORD_T;

/****************************** 时间参数 ****************************************/

typedef struct{
    int32_t ID; //主键
    int32_t SynTimeMode; //对时方式, 1：NTP对时,2：上位机,3：本机,0：未设置
    char NTPAddr[20]; //NTP服务器IP地址
    int32_t NTPPort; //NTP服务IP端口他
}TIME_CFG_T;

/**********************************************************************/

int32_t sysCfg_Load(IN CFG_TYPE_E type, INOUT void **ppvdata, INOUT int32_t *pDataLen);
void sysCfg_Free(IN void *pvdata);

#endif // SYSCFG_H_INCLUDED
