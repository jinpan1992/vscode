#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <pthread.h>
#include "ShareRTDB.h"
#include "logUtil.h"

//实时数据库
typedef struct
{
    uint8_t  ucCountTable;              //设备表数量
    uint8_t  ucSearchMap[MAX_DEV_CODE]; //根根设备编码找到在二维数组的行数
    uint8_t  ucTableNoMap[RTDB_MAX_DEV_NUM][RTDB_MAX_DEV_NUM];    //二维数组，一行代表一种设备编码，列数代表同类设备编码的设备索引；行+列，对应该设备表号
    DEVMAP_T stDevMap[RTDB_MAX_DEV_NUM];   //设备表
}ShareRTDB_T;

ShareRTDB_T *g_pShare = NULL;
static pthread_mutex_t g_Mutex = PTHREAD_MUTEX_INITIALIZER;

/**
 * @brief  查找设备表
 * @param  pucTableNo：返回表号
 * @return OK：成功找到；ERRNO：错误码
 */
static int32_t ShareRTDB_findTable(IN void *p, IN uint32_t uiType, INOUT uint8_t *pucTableNo)
{
    int32_t ret = ERROR_T(ERR_DEFAULT_NOT_EXIST);
    if (p == NULL || pucTableNo == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    DEVINFO_T *psrcDevInfo = (DEVINFO_T*)p;
    *pucTableNo = 0;

    if (uiType == FIND_BY_DEVNAME)
    {
        uint8_t i = 0;
        for (i = 0; i < g_pShare->ucCountTable; i++)
        {
            DEVINFO_T *ptmpDevInfo = &(g_pShare->stDevMap[i].stDevInfo);

            if (strcmp(ptmpDevInfo->cDevName, psrcDevInfo->cDevName) == 0)
            {
                *pucTableNo = i;
                return OK;
            }
        }
    }

    if (uiType == FIND_BY_DEVCODE_AND_INDEX)
    {
        uint8_t ucSearchId = g_pShare->ucSearchMap[psrcDevInfo->uwDevCode];
        *pucTableNo = g_pShare->ucTableNoMap[ucSearchId][psrcDevInfo->ucDevId];
        if (*pucTableNo != INVALID_NO)
        {
            return OK;
        }
    }

    if (uiType == FIND_BY_DBNO)
    {
        uint8_t i = 0;
        for (i = 0; i < g_pShare->ucCountTable; i++)
        {
            DEVINFO_T *ptmpDevInfo = &(g_pShare->stDevMap[i].stDevInfo);

            if (ptmpDevInfo->dbUID == psrcDevInfo->dbUID)
            {
                *pucTableNo = i;
                return OK;
            }
        }
    }

    return ret;
}

/**
 * @brief  获取、关联共享内存
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Init(IN int32_t key)
{
    int32_t ret = OK;
    pthread_mutex_lock(&g_Mutex);

    do{
        if (g_pShare != NULL)
        {
            EMS_LOG(LL_INFO, MODULE_DEFAULT, FALSE, "share mem already init!\n");
            ret = ERROR_T(ERR_DEFAULT_ALREADY_INIT);
            break;
        }

        ShareRTDB_T *pShm = NULL;

        //共享内存check
        int32_t shmid;
        shmid = shmget(key, 0, 0);
        if(shmid != -1)
        {
            EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "shmget key is exist.\n");
//             shmctl(shmid, IPC_RMID, NULL);
        }
        else
        {
            //创建共享内存
            shmid = shmget(key, sizeof(ShareRTDB_T), 0666 | IPC_CREAT);
            if(shmid == -1)
            {
                EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "shmget failed! size:%d\n", sizeof(ShareRTDB_T));

                shmctl(shmid, IPC_RMID, 0);
                ret = ERR;
                break;
            }
        }

        //将共享内存连接到当前进程的地址空间
        pShm = shmat(shmid, 0, 0);
        if(pShm == (void*)-1)
        {
            EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "shmat failed!\n");
            ret = ERR;
            break;
        }

        EMS_LOG(LL_WARNING, MODULE_DEFAULT, FALSE, "Memory attached at %p, shmid:%d\n", pShm, shmid);

        //设置共享内存
        g_pShare = (ShareRTDB_T*)pShm;
        if (g_pShare == NULL)
        {
            EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "shmat failed!\n");
            ret = ERR;
            break;
        }

        memset(g_pShare, 0, sizeof(ShareRTDB_T));
        memset(g_pShare->ucSearchMap, INVALID_NO, sizeof(uint8_t) * MAX_DEV_CODE);
        memset(g_pShare->ucTableNoMap, INVALID_NO, sizeof(uint8_t) * RTDB_MAX_DEV_NUM * RTDB_MAX_DEV_NUM);
    }while(0);

    pthread_mutex_unlock(&g_Mutex);

    return ret;
}

/**
 * @brief  追加设备表
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Add(IN DEVMAP_T *pstDevMap)
{
    int32_t ret = OK, i = 0;

    if (g_pShare == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_INIT);
    }

    pthread_mutex_lock(&g_Mutex);
    DEVINFO_T *psrcDevInfo = &(pstDevMap->stDevInfo);
    POINT_T *psrcPoint = pstDevMap->stPoint;
    uint32_t uiFindType = FIND_BY_DEVNAME;

    do{
        if (strlen(psrcDevInfo->cDevName) == 0)
        {
            if (psrcDevInfo->uwDevCode >= MAX_DEV_CODE || psrcDevInfo->ucDevId > RTDB_MAX_DEV_NUM || psrcDevInfo->ucPointLen > RTDB_MAX_POINT_NUM)
            {
                ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
                break;
            }
            else
            {
                uiFindType = FIND_BY_DEVCODE_AND_INDEX;
            }
        }

        uint8_t uctableNo = 0;

        //检查表是否已经存在
        ret = ShareRTDB_findTable(psrcDevInfo, uiFindType, &uctableNo);
        if (ret == OK)
        {
            ret = ERROR_T(ERR_DEFAULT_ALREADY_EXIST);
            break;
        }

        if (psrcDevInfo->uwDevCode != CEMS_DEV_CODE && g_pShare->ucCountTable == 0)
        {
            printf("please add CEMS table firstly. \n");
            ret = ERR;
            break;
        }

        uctableNo = (psrcDevInfo->uwDevCode == CEMS_DEV_CODE) ? 0 : g_pShare->ucCountTable;
        DEVMAP_T *pstTmpDevMap = &(g_pShare->stDevMap[uctableNo]);

        //填充
        memcpy(&(pstTmpDevMap->stDevInfo), psrcDevInfo, sizeof(DEVINFO_T));
        memcpy(&(pstTmpDevMap->stPoint), psrcPoint, sizeof(POINT_T) * psrcDevInfo->ucPointLen);
        for (i = 0; i <= psrcDevInfo->ucPointLen; i++)
        {
            pstTmpDevMap->stPoint[i].iPointId = i;
        }

        //根据设备编码和设备索引建立查找索引(可以根据设备编码、设备索引找到设备表号)
        if (g_pShare->ucSearchMap[psrcDevInfo->uwDevCode] == INVALID_NO) //第一次插入时，填入表号；相同设备编码，查找索引(ucSearchId)使用第一个设备的表号
        {
            g_pShare->ucSearchMap[psrcDevInfo->uwDevCode] = uctableNo;
        }

        //建立设备编码、设备索引和表号的映射关系
        uint8_t ucSearchId = g_pShare->ucSearchMap[psrcDevInfo->uwDevCode];
        g_pShare->ucTableNoMap[ucSearchId][psrcDevInfo->ucDevId] = uctableNo;

        printf("devname:%s devcode:%d devid:%d searchId:%d uctableNo:%d pointCount:%d \n",
               pstTmpDevMap->stDevInfo.cDevName, pstTmpDevMap->stDevInfo.uwDevCode, pstTmpDevMap->stDevInfo.ucDevId, ucSearchId, uctableNo, pstTmpDevMap->stDevInfo.ucPointLen);
        //设备表个数增加
        g_pShare->ucCountTable++;
    }while(0);

    pthread_mutex_unlock(&g_Mutex);

    return ret;
}

/**
 * @brief  删除设备表
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Delete(IN char *pcDevName, IN uint8_t ucLen)
{
    if (g_pShare == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_INIT);
    }

    if (pcDevName == NULL || ucLen == 0)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pthread_mutex_lock(&g_Mutex);
    DEVINFO_T stTmpDevInfo = {0};
    DEVMAP_T *pstTmpDevMap = NULL;
    uint8_t uctableNo = 0, i = 0;
    uint32_t ret = OK;
    int32_t delDevCode = 0, delDevId = 0;

    do{
        memcpy(stTmpDevInfo.cDevName, pcDevName, sizeof(char) * ucLen);
        ret = ShareRTDB_findTable(&stTmpDevInfo, FIND_BY_DEVNAME, &uctableNo);
        if (ret != OK || uctableNo == g_pShare->ucCountTable)
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_EXIST);
            break;
        }

        pstTmpDevMap = &g_pShare->stDevMap[uctableNo];
        delDevCode = pstTmpDevMap->stDevInfo.uwDevCode;
        delDevId = pstTmpDevMap->stDevInfo.ucDevId;

        uint8_t offsetToEnd = g_pShare->ucCountTable - uctableNo;
        if (offsetToEnd == 1) //需要删除的是最后一张表
        {
            memset(pstTmpDevMap, 0, sizeof(DEVMAP_T));
        }
        else //余下的表往前移动
        {
            memmove(pstTmpDevMap, pstTmpDevMap + 1, sizeof(DEVMAP_T) * (offsetToEnd - 1));
        }

        //查找索引恢复默认值
        uint8_t ucSearchId = g_pShare->ucSearchMap[delDevCode];
        g_pShare->ucTableNoMap[ucSearchId][delDevId] = INVALID_NO;

        //查找 delDevCode 是否还有设备，如果没有，则清除对应的 ucSearchMap; 如果还有设备，则不清除
        for (i = 0; i < RTDB_MAX_DEV_NUM; i++)
        {
            if (g_pShare->ucTableNoMap[ucSearchId][i] != INVALID_NO)
            {
                break;
            }
        }

        if (i == RTDB_MAX_DEV_NUM)
        {
            g_pShare->ucSearchMap[delDevCode] = INVALID_NO;
        }

        g_pShare->ucCountTable--;

    }while(0);


    pthread_mutex_unlock(&g_Mutex);

    return ret;
}

/**
 * @brief  修改设备表内容
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_UpdateByName(char *pcDevName, IN uint8_t ucLen, IN POINT_T *pPoint, IN uint32_t uiPointNum)
{
    uint32_t ret = OK;

    if (g_pShare == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_INIT);
    }

    if (pcDevName == NULL || ucLen == 0 || pPoint == NULL || uiPointNum > RTDB_MAX_POINT_NUM)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pthread_mutex_lock(&g_Mutex);
    DEVINFO_T stTmpDevInfo = {0};
    DEVMAP_T *pstTmpDevMap = NULL;
    uint8_t uctableNo = 0;

    do{
        memcpy(stTmpDevInfo.cDevName, pcDevName, sizeof(char) * ucLen);
        ret = ShareRTDB_findTable(&stTmpDevInfo, FIND_BY_DEVNAME, &uctableNo);
        if (ret != OK)
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_EXIST);
            break;
        }

        pstTmpDevMap = &g_pShare->stDevMap[uctableNo];

        uint8_t i = 0;
        for (i = 0; i < uiPointNum; i++)
        {
            POINT_T *pDest = &(pstTmpDevMap->stPoint[pPoint[i].iPointId]);
            memcpy(pDest, pPoint + i, sizeof(POINT_T));
        }

    }while(0);

    pthread_mutex_unlock(&g_Mutex);

    return ret;
}

/**
 * @brief  根据设备编码、设备索引修改设备表内容
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Update(IN uint16_t uwDevCode, IN uint16_t uwDevId, IN POINT_T *pPoint, IN uint32_t uiPointNum)
{
    uint32_t ret = OK;

    if (g_pShare == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_INIT);
    }

    if (uwDevCode > MAX_DEV_CODE || pPoint == NULL || uiPointNum == 0)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pthread_mutex_lock(&g_Mutex);
    DEVINFO_T stTmpDevInfo = {0};
    DEVMAP_T *pstTmpDevMap = NULL;
    uint8_t uctableNo = 0;

    do{
        stTmpDevInfo.uwDevCode = uwDevCode;
        stTmpDevInfo.ucDevId = uwDevId;
        ret = ShareRTDB_findTable(&stTmpDevInfo, FIND_BY_DEVCODE_AND_INDEX, &uctableNo);
        if (ret != OK)
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_EXIST);
            break;
        }

        pstTmpDevMap = &g_pShare->stDevMap[uctableNo];

        uint8_t i = 0;
        for (i = 0; i < uiPointNum && pPoint[i].iPointId != INVALID_VALUE; i++)
        {
            POINT_T *pDest = &(pstTmpDevMap->stPoint[pPoint[i].iPointId]);
            memcpy(pDest, pPoint + i, sizeof(POINT_T));

//             printf("%s uctableNo:%d PointId:%d PointValue:%f \n", __func__, uctableNo, pPoint[i].iPointId, pPoint[i].dPointValue);
        }

    }while(0);

    pthread_mutex_unlock(&g_Mutex);

//     ShareRTDB_Debug();

    return ret;
}

int32_t ShareRTDB_QueryByDBNO(IN uint32_t dwDBNO, INOUT POINT_T **pptPoint, INOUT uint8_t *pucPointNum)
{
    int32_t ret = OK;

    if (g_pShare == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_INIT);
    }

    if (pucPointNum == NULL || pptPoint == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    *pucPointNum = 0;

    pthread_mutex_lock(&g_Mutex);
    DEVINFO_T stTmpDevInfo;
    DEVMAP_T *pstTmpDevMap = NULL;
    uint8_t uctableNo = 0;

    do{
        memset(&stTmpDevInfo, 0, sizeof(DEVINFO_T));
        stTmpDevInfo.dbUID = dwDBNO;
        ret = ShareRTDB_findTable(&stTmpDevInfo, FIND_BY_DBNO, &uctableNo);
        if (ret != OK)
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_EXIST);
            break;
        }

        pstTmpDevMap = &g_pShare->stDevMap[uctableNo];
        uint32_t uiPointNum = pstTmpDevMap->stDevInfo.ucPointLen;

        *pptPoint = calloc(uiPointNum, sizeof(POINT_T));
        if (*pptPoint != NULL)
        {
            memcpy(*pptPoint, &(pstTmpDevMap->stPoint[0]), sizeof(POINT_T) * uiPointNum);
            *pucPointNum = uiPointNum;
        }
        else
        {
            ret = ERROR_T(ERR_DEFAULT_NO_MEM);
        }

    }while(0);

    pthread_mutex_unlock(&g_Mutex);

    return ret;
}

int32_t ShareRTDB_QueryByName(char *pcDevName, IN uint8_t ucLen, INOUT POINT_T **pptPoint, INOUT uint8_t *pucPointNum)
{
    uint32_t ret = OK;

    if (g_pShare == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_INIT);
    }

    if (pcDevName == NULL || ucLen == 0 ||
        pptPoint == NULL || pucPointNum == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pthread_mutex_lock(&g_Mutex);
    DEVINFO_T stTmpDevInfo = {0};
    DEVMAP_T *pstTmpDevMap = NULL;
    uint8_t uctableNo = 0;

    do{
        memcpy(stTmpDevInfo.cDevName, pcDevName, sizeof(char) * ucLen);
        ret = ShareRTDB_findTable(&stTmpDevInfo, FIND_BY_DEVNAME, &uctableNo);
        if (ret != OK)
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_EXIST);
            break;
        }

        pstTmpDevMap = &g_pShare->stDevMap[uctableNo];
        uint32_t uiPointNum = pstTmpDevMap->stDevInfo.ucPointLen;

        *pptPoint = calloc(uiPointNum, sizeof(POINT_T));

        if (*pptPoint != NULL)
        {
            memcpy(*pptPoint, &(pstTmpDevMap->stPoint[0]), sizeof(POINT_T) * uiPointNum);
            *pucPointNum = uiPointNum;
        }
        else
        {
            ret = ERROR_T(ERR_DEFAULT_NO_MEM);
        }

    }while(0);

    pthread_mutex_unlock(&g_Mutex);

    return ret;
}

/**
 * @brief  根据设备编码、设备索引查询
 * @param  ptPoint:输入不为NULL，pointNo对应的数据值；
 *         pucPointNum：point 个数；
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Query(IN uint16_t uwDevCode, IN uint16_t uwDevId, INOUT POINT_T *ptPoint, INOUT uint8_t *pucPointNum)
{
    uint32_t ret = OK;

    if (g_pShare == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_INIT);
    }
    if (uwDevCode > MAX_DEV_CODE || ptPoint == NULL || pucPointNum == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pthread_mutex_lock(&g_Mutex);
    DEVINFO_T stTmpDevInfo = {0};
    DEVMAP_T *pstTmpDevMap = NULL;
    uint8_t uctableNo = 0;

    do{
        stTmpDevInfo.uwDevCode = uwDevCode;
        stTmpDevInfo.ucDevId = uwDevId;
        ret = ShareRTDB_findTable(&stTmpDevInfo, FIND_BY_DEVCODE_AND_INDEX, &uctableNo);
        if (ret != OK)
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_EXIST);
            break;
        }

        pstTmpDevMap = &g_pShare->stDevMap[uctableNo];
        uint32_t uiPointNum = pstTmpDevMap->stDevInfo.ucPointLen;

        if (*pucPointNum >= uiPointNum)
        {
            memcpy(ptPoint, &(pstTmpDevMap->stPoint[0]), sizeof(POINT_T) * uiPointNum);
        }
        else
        {
            uint8_t i = 0;
            for (i = 0; i < *pucPointNum; i++)
            {
                uint32_t uiNo = ptPoint[i].iPointId;
                ptPoint[i].dPointValue = pstTmpDevMap->stPoint[uiNo].dPointValue;
            }
        }

    }while(0);

    pthread_mutex_unlock(&g_Mutex);

    return ret;
}

/**
 * @brief  取消关联共享内存
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_UnInit()
{
    int32_t ret = OK;

    if (g_pShare == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_INIT);
    }

    pthread_mutex_lock(&g_Mutex);
    ret = shmdt(g_pShare);
    g_pShare = NULL;
    pthread_mutex_unlock(&g_Mutex);

    return (ret == 0) ? OK : ERR;
}

/**
 * @brief  获取设备数量
 * @param  ucCount:输入不为NULL，返回设备数量；
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_GetDevCount(INOUT uint8_t *pucCount)
{
    if (pucCount == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    *pucCount = g_pShare->ucCountTable;
    return OK;
}

/**
 * @brief  获取所有设备信息
 * @param  pucDevCount:所有设备信息数量；
 *          注意：调用该接口后需要释放出参
 * @return 非NULL：成功；NULL：失败
 */
DEVINFO_T* ShareRTDB_GetDevInfo(INOUT uint8_t *pucDevCount, INOUT int32_t *pdwErr)
{
    uint32_t ret = OK;
    DEVINFO_T *pstDevInfo = NULL;

    do
    {
        if (g_pShare == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_INIT);
            break;
        }

        if (pucDevCount == NULL)
        {
            ret = ERROR_T(ERR_DEFAULT_INVALID_PARAM);
            break;
        }

        uint32_t uiDevCount = g_pShare->ucCountTable;
        *pucDevCount = uiDevCount;

        if (pstDevInfo == NULL)
        {
            pstDevInfo = malloc(sizeof(DEVINFO_T) * uiDevCount);
            if (pstDevInfo == NULL)
            {
                ret = ERROR_T(ERR_DEFAULT_NO_MEM);
                break;
            }

            uint8_t i = 0;
            for (i = 0; i < uiDevCount; i++)
            {
                memcpy(pstDevInfo + i, &(g_pShare->stDevMap[i].stDevInfo), sizeof(DEVINFO_T));
            }
        }
    }while(0);

    *pdwErr = ret;

    return pstDevInfo;
}

int32_t ShareRTDB_GetPonitCount(IN char *pcDevName, IN uint8_t ucLen, INOUT int32_t *pPointCount)
{
    uint32_t ret = OK;

    if (g_pShare == NULL)
    {
        return ERROR_T(ERR_DEFAULT_NOT_INIT);
    }

    if (pcDevName == NULL || pPointCount == NULL || ucLen == 0)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    pthread_mutex_lock(&g_Mutex);
    DEVINFO_T stTmpDevInfo = {0};
    DEVMAP_T *pstTmpDevMap = NULL;
    uint8_t uctableNo = 0;

    do{
        memcpy(stTmpDevInfo.cDevName, pcDevName, sizeof(char) * ucLen);
        ret = ShareRTDB_findTable(&stTmpDevInfo, FIND_BY_DEVNAME, &uctableNo);
        if (ret != OK)
        {
            ret = ERROR_T(ERR_DEFAULT_NOT_EXIST);
            break;
        }

        pstTmpDevMap = &g_pShare->stDevMap[uctableNo];
        *pPointCount = pstTmpDevMap->stDevInfo.ucPointLen;

    }while(0);

    pthread_mutex_unlock(&g_Mutex);

    return ret;
}

int32_t ShareRTDB_Free(void *p)
{
    if (p != NULL)
    {
        free(p);
    }

    return OK;
}
/**
 * @brief 打印所有设备表数据
 * @param
 * @return
 */
void ShareRTDB_Debug()
{
    uint8_t i = 0;
    for (i = 0; i < g_pShare->ucCountTable; i++)
    {
        printf("devname:%s,devcode:%d, devid:%d, dbNO:%d, pointcount:%d\n",
               g_pShare->stDevMap[i].stDevInfo.cDevName,
            g_pShare->stDevMap[i].stDevInfo.uwDevCode,
            g_pShare->stDevMap[i].stDevInfo.ucDevId,
            g_pShare->stDevMap[i].stDevInfo.dbUID,
            g_pShare->stDevMap[i].stDevInfo.ucPointLen
        );

        uint8_t j = 0;
        for (j = 0; j < g_pShare->stDevMap[i].stDevInfo.ucPointLen; j++)
        {
            printf("dataid:%d value:%4f ", g_pShare->stDevMap[i].stPoint[j].iPointId, g_pShare->stDevMap[i].stPoint[j].dPointValue);
        }
        printf("\n");
    }
    printf("\n");

    return;
}
