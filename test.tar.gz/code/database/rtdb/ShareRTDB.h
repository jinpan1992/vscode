#ifndef SHARERTDB_H_INCLUDED
#define SHARERTDB_H_INCLUDED

#include <stdio.h>
#include "common.h"
#include "err.h"

#define RTDB_MAX_POINT_NUM 250
#define RTDB_MAX_DEV_NUM 122
#define RTDB_MAX_DEV_NAME_LEN 32

#define SHARE_KEY_FOR_RTDB 111111

#define INVALID_NO 0xFF

//测点结构
typedef struct{
    int32_t    iPointId;         //测点编号
    float32_t  dPointValue;      //测点值
    uint8_t    ucDataType;       //测点数据类型，0：浮点；1：无符号数；2：有符号数
    DATA_U     unDataValue;      //测点值
    uint32_t   uiTicks;          //ticks
}POINT_T;

typedef struct
{
    uint16_t uwDevCode;                       //设备编码
    uint8_t  ucDevId;                         //设备索引
    char     cDevName[RTDB_MAX_DEV_NAME_LEN]; //设备名称（不可重复）
    uint8_t  ucPointLen;                      //有效测点个数
    uint32_t dbUID;                           //数据库唯一编号
}DEVINFO_T;

typedef struct{
    DEVINFO_T stDevInfo;
    POINT_T stPoint[RTDB_MAX_POINT_NUM];
}DEVMAP_T;

enum
{
    FIND_BY_DEVNAME = 0x1,
    FIND_BY_DEVCODE_AND_INDEX,
    FIND_BY_DBNO
};

/**
 * @brief  获取、关联共享内存
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Init(IN int32_t key);

/**
 * @brief  增加设备表（虚拟的边设备需要第一个添加）
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Add(IN DEVMAP_T *pstDevMap);

/**
 * @brief  删除设备表（一个个删除）
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Delete(IN char *pcDevName, IN uint8_t ucLen);

/**
 * @brief  修改设备表内容
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_UpdateByName(IN char *pcDevName, IN uint8_t ucLen, IN POINT_T *pPoint, IN uint32_t uiPointNum);

/**
 * @brief  根据设备编码、设备索引修改设备表内容
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Update(IN uint16_t uwDevCode, IN uint16_t uwDevId, IN POINT_T *pPoint, IN uint32_t uiPointNum);

/**
 * @brief  根据设备数据库唯一编号查找该设备所有测点信息
 * @param  *pptPoint:输入为NULL
 *         *pucPointNum：point 个数；
 * 注意：调用该接口后需要释放*pptPoint
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_QueryByDBNO(IN uint32_t dwDBNO, INOUT POINT_T **pptPoint, INOUT uint8_t *pucPointNum);

/**
 * @brief  根据表名称查询找该设备所有测点信息
 * @param  *pptPoint:输入为NULL；
 *         *pucPointNum：输入不为NULL，返回point 个数；
 * 注意：调用该接口后需要释放*pptPoint
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_QueryByName(char *pcDevName, IN uint8_t ucLen, INOUT POINT_T **pptPoint, INOUT uint8_t *pucPointNum);

/**
 * @brief  根据设备编码、设备索引查询
 * @param  ptPoint:输入不为NULL，pointNo对应的数据值；
 *         *pucPointNum：point 个数；
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_Query(IN uint16_t uwDevCode, IN uint16_t uwDevId, INOUT POINT_T *ptPoint, INOUT uint8_t *pucPointNum);

/**
 * @brief  获取设备数量
 * @param  ucCount:输入不为NULL，返回设备数量；
 *
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_GetDevCount(INOUT uint8_t *ucCount);

/**
 * @brief  获取所有设备信息
 * @param  pucDevCount:所有设备信息数量；
 *          注意：调用该接口后需要释放出参
 * @return 非NULL：成功；NULL：失败
 */
DEVINFO_T* ShareRTDB_GetDevInfo(INOUT uint8_t *pucDevCount, INOUT int32_t *pdwErr);

/**
 * @brief  获取设备测点个数
 * @param  pPointCount:输入不为NULL，返回设备测点个数；
 *         pucPointNum：point 个数；
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_GetPonitCount(IN char *pcDevName, IN uint8_t ucLen, INOUT int32_t *pPointCount);

/**
 * @brief  取消关联共享内存
 * @param
 * @return OK：成功；ERRNO：错误码
 */
int32_t ShareRTDB_UnInit();

/**
 * @brief  释放内存
 * @param
 * @return
 */
int32_t ShareRTDB_Free(void *p);

/**
 * @brief 打印所有设备表数据(未来会扩展)
 * @param
 * @return
 */
void ShareRTDB_Debug();

#endif // SHARERTDB_H_INCLUDED
