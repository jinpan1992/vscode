#include "sdb.h"
#include "mapping.h"
#include "uthash.h"
#include "logUtil.h"

typedef struct {
    RECORD_KEY_T key;
    RECORD_KEY_T value;
    UT_hash_handle hh;
} N2S_RECORD_T;

typedef struct {
    RECORD_KEY_T key;
    int32_t valueNum;
    RECORD_KEY_T *pValue[MAX_MAPPED_POINTS_NUM];
    UT_hash_handle hh;
} S2N_RECORD_T;

static N2S_RECORD_T *g_N2S_POINT = NULL; //北向->南向测点映射表,
static S2N_RECORD_T *g_S2N_POINT = NULL; //南向->北向测点映射表,
static N2S_DEV_RECORD_T *g_pDEV_MAP_N2S = NULL; //北向设备->南向设备映射表
static RECORD_KEY_T *g_pPointN = NULL; //南向->北向测点映射记录

static BOOL g_UseDefaultFlag = TRUE;

int32_t N2SDev_CreateMap()
{
    int32_t ret = OK;

    if (g_UseDefaultFlag == TRUE)
    {
        return ret;
    }

    NORTH_DEV_RECORD_T *pvNDevList = NULL;
    int32_t recordNum = 0;
    ret = sysCfg_Load(CFG_TYPE_NORTH_DEV_LIST, (void**)(&pvNDevList), &recordNum);
    if (recordNum > 0)
    {
        g_pDEV_MAP_N2S = malloc(sizeof(N2S_DEV_RECORD_T) * recordNum);
        DEV_INFO_EXT_T *pDevList = SDB_MD_GetList();

        int32_t i = 0;
        NORTH_DEV_RECORD_T *pDevHead = pvNDevList;
        NORTH_DEV_RECORD_T *pRecord = pDevHead;
        for (i = 0; pRecord != NULL && i < recordNum; i++)
        {
            pRecord = pDevHead + i;
            DEV_UID_T *pDev = &(pDevList[i].stDevUID);
            N2S_DEV_RECORD_T *pDevMapRecord = g_pDEV_MAP_N2S + i;

            memcpy(&(pDevMapRecord->stNorth), pDev, sizeof(DEV_UID_T));
            pDevMapRecord->mapGrp = pRecord->MapGrp;
            pDevMapRecord->mapType = pRecord->MapGrp;

            DEV_INFO_T stSouthDev;
            ret = SDB_GetDevInfoByUID(pRecord->DevNo, &stSouthDev);
            if (ret == OK)
            {
                pDevMapRecord->stSouth.devCode = stSouthDev.dev_code;
                pDevMapRecord->stSouth.devIndex = stSouthDev.index;
                strncpy(pDevMapRecord->stSouth.devName, stSouthDev.dev_name, sizeof(char) * MAX_DEV_NAME_LEN);
                pDevMapRecord->commtype = stSouthDev.com_type;
                pDevMapRecord->portID = stSouthDev.com;
            }

        }
    }

    sysCfg_Free(pvNDevList);
    return ret;
}

int32_t N2SDev_GetValue(IN DEV_UID_T *pNorthDev, INOUT DEV_UID_T *pSouthDev)
{
    int32_t ret = ERROR_T(ERR_DEFAULT_NOT_FOUND);

    if (g_UseDefaultFlag == TRUE)
    {
        return ret;
    }

    if (pNorthDev == NULL || pSouthDev == NULL)
    {
        return ERROR_T(ERR_DEFAULT_INVALID_PARAM);
    }

    if (g_pDEV_MAP_N2S != NULL)
    {
        uint32_t devNum = SDB_MD_GetNum();
        int32_t i = 0;
        for (i = 0; i < devNum; i++)
        {
            N2S_DEV_RECORD_T *pDevMapRecord = g_pDEV_MAP_N2S + i;
            if (pDevMapRecord->stNorth.devCode == pNorthDev->devCode
                && pDevMapRecord->stNorth.devIndex == pNorthDev->devIndex
            )
            {
                pSouthDev->devCode = pDevMapRecord->stSouth.devCode;
                pSouthDev->devIndex = pDevMapRecord->stSouth.devIndex;
                strncpy(pSouthDev->devName, pDevMapRecord->stSouth.devName, sizeof(char) * MAX_DEV_NAME_LEN);
                ret = OK;
                break;
            }
        }
    }

    return ret;
}

int32_t N2SDev_DestroyMap()
{
    HCFREE(g_pDEV_MAP_N2S);

    return OK;
}

////测点映射
int32_t Point_CreateMap()
{
    int32_t i = 0, j = 0, k = 0;
    int32_t ret = OK;

    if (g_pPointN == NULL)
    {
        g_pPointN = calloc(1, sizeof(RECORD_KEY_T));
    }

    if (g_UseDefaultFlag == TRUE)
    {
        return OK;
    }

    DEV_INFO_EXT_T *pDevList = SDB_MD_GetList();
    uint32_t devNum = SDB_MD_GetNum();

    for (i = 0; i < devNum; i++)
    {
        DEV_INFO_EXT_T *pDevInfo = pDevList + i;
        int32_t dwPtlNum = pDevInfo->dwPtlNum;

        for (j = 0; j < dwPtlNum; j++)
        {
            PROTOCOL_T *pPtl = pDevInfo->pProtocol + j;
            int32_t dwPtlDataNum = pPtl->ptl_data_num;

            for (k = 0; k < dwPtlDataNum; k++)
            {
                PROTOCOL_DATA_T *pPtlData = pPtl->protocol_data + k;
                //1. 插入 N2S
                N2S_RECORD_T *pN = malloc(sizeof(N2S_RECORD_T));
                memset(pN, 0, sizeof(RECORD_KEY_T));
                pN->key.devCode = pDevInfo->stDevUID.devCode;
                pN->key.devIndex = pDevInfo->stDevUID.devIndex;
                pN->key.dataId = pPtlData->data_id;

                DEV_UID_T stDevSouth;
                ret = N2SDev_GetValue(&(pDevInfo->stDevUID), &stDevSouth);
                if (ret == OK)
                {
                    pN->value.devCode = stDevSouth.devCode;
                    pN->value.devIndex = stDevSouth.devIndex;
                    pN->value.dataId = pPtlData->dwSouthDataId;

                    HASH_ADD(hh, g_N2S_POINT, key, sizeof(RECORD_KEY_T), pN);

                    //2. 插入 S2N
                    S2N_RECORD_T *pS = malloc(sizeof(S2N_RECORD_T)), *result = NULL;
                    memset(pS, 0, sizeof(S2N_RECORD_T));
                    pS->key.devCode = stDevSouth.devCode;
                    pS->key.devIndex = stDevSouth.devIndex;
                    pS->key.dataId = pPtlData->dwSouthDataId;
                    HASH_FIND(hh, g_S2N_POINT, &pS->key, sizeof(RECORD_KEY_T), result); //查找 S2N
                    if (result == NULL)
                    {
                        pS->pValue[0] = &(pN->key);
                        pS->valueNum = 1;
                    }
                    else{
                        if (result->valueNum >= MAX_MAPPED_POINTS_NUM)
                        {
                            printf("S->N is exceed! \n");
                            continue;
                        }

                        memcpy(pS->pValue, result->pValue, sizeof(RECORD_KEY_T *) * MAX_MAPPED_POINTS_NUM);

                        pS->pValue[result->valueNum] = &(pN->key);
                        pS->valueNum = result->valueNum + 1;

                        //删除原有记录
                        HASH_DEL(g_S2N_POINT, result);
                        HCFREE(result);
                    }

                    HASH_ADD(hh, g_S2N_POINT, key, sizeof(RECORD_KEY_T), pS);
                }
                else
                {
                    EMS_LOG(LL_ERROR, MODULE_SDB, FALSE, "ND(%d,%d,%d) can't find SD.\n", pN->value.devCode, pN->value.devIndex, pN->value.dataId);
                }

            }
        }

    }

    Point_PrintMap();
    return OK;
}

int32_t Point_DestroyMap()
{
    N2S_RECORD_T *pN, *tmpN = NULL;
    HASH_ITER(hh, g_N2S_POINT, pN, tmpN) {
        HASH_DEL(g_N2S_POINT, pN);
        HCFREE(pN);
    }

    S2N_RECORD_T *pS, *tmpS = NULL;
    HASH_ITER(hh, g_S2N_POINT, pS, tmpS) {
        HASH_DEL(g_S2N_POINT, pS);
        HCFREE(pS);
    }

    HCFREE(g_pPointN);

    return OK;
}

int32_t Point_PrintMap()
{
    N2S_RECORD_T *pN, *tmpN = NULL;
    HASH_ITER(hh, g_N2S_POINT, pN, tmpN) {
        printf("N2S key(%d,%d,%d) value(%d,%d,%d) \n",
               pN->key.devCode, pN->key.devIndex, pN->key.dataId,
               pN->value.devCode, pN->value.devIndex, pN->value.dataId
              );
    }

    S2N_RECORD_T *pS, *tmpS = NULL;
    HASH_ITER(hh, g_S2N_POINT, pS, tmpS) {
        printf("S2N key(%d,%d,%d) value(", pS->key.devCode, pS->key.devIndex, pS->key.dataId);
        int32_t i = 0;
        for (i = 0; i < pS->valueNum; i++)
        {
            printf("%d,%d,%d;", pS->pValue[i]->devCode, pS->pValue[i]->devIndex, pS->pValue[i]->dataId);
        }
        printf(")\n");
    }
    return OK;
}

RECORD_KEY_T* N2SPoint_GetValue(IN RECORD_KEY_T *pNorthP)
{
    RECORD_KEY_T *pSouthP = pNorthP;

    if (!g_UseDefaultFlag)
    {
        N2S_RECORD_T *result = NULL;
        HASH_FIND(hh, g_N2S_POINT, pNorthP, sizeof(RECORD_KEY_T), result); //查找
        if (result)
        {
            pSouthP = &(result->value);
        }
    }

    return pSouthP;
}

RECORD_KEY_T** S2NPoint_GetValue(IN RECORD_KEY_T *pSouthP, OUT int32_t *pPointNum)
{
    RECORD_KEY_T **ppPointN = NULL;
    *pPointNum = 0;
    if (!g_UseDefaultFlag)
    {
        S2N_RECORD_T *result = NULL;
        HASH_FIND(hh, g_S2N_POINT, pSouthP, sizeof(RECORD_KEY_T), result); //查找
        if (result)
        {
            ppPointN = result->pValue;
            *pPointNum = result->valueNum;
        }
        else{
            ppPointN = NULL;
            *pPointNum = 0;
        }
    }
    else
    {
        if (g_pPointN != NULL)
        {
            memcpy(g_pPointN, pSouthP, sizeof(RECORD_KEY_T));
            ppPointN = &g_pPointN;
            *pPointNum = 1;
        }
    }

    return ppPointN;
}

void Mapping_SetUseDefault(BOOL trueOrFalse)
{
    g_UseDefaultFlag = trueOrFalse;
}

BOOL Mapping_GetUseDefault()
{
    return g_UseDefaultFlag;
}
