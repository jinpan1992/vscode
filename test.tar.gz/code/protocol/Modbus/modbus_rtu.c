/*
 * Copyright © 2001-2011 Stéphane Raimbault <stephane.raimbault@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>

//HAVE_DECL_TIOCSRS485
#include <sys/ioctl.h>
#include <linux/serial.h>

#include "modbus.h"
#include "modbus_rtu.h"
#include "slist.h"
#include "uart.h"

/* Table of CRC values for high-order byte */
static const uint8_t table_crc_hi[] = {
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
    0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
    0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
    0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
    0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
    0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
    0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
};

/* Table of CRC values for low-order byte */
static const uint8_t table_crc_lo[] = {
    0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06,
    0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD,
    0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
    0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A,
    0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14, 0xD4,
    0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
    0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3,
    0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4,
    0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
    0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29,
    0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED,
    0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
    0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60,
    0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67,
    0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
    0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68,
    0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E,
    0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
    0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71,
    0x70, 0xB0, 0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92,
    0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
    0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B,
    0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B,
    0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
    0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42,
    0x43, 0x83, 0x41, 0x81, 0x80, 0x40
};

/* Define the slave ID of the remote device to talk in master mode or set the
 * internal slave ID in slave mode */
 int ModbusSetSlave(modbus_priv_t *ctx, int slave)
{
    /* Broadcast address is 0 (MODBUS_BROADCAST_ADDRESS) */
    if (slave >= 0 && slave <= 247) {
        ctx->slave = slave;
    } else {
        errno = EINVAL;
        return errno;
    }

    return 0;
}

/* Builds a RTU request header */
 int ModbusRtuBuildRequestBasis(modbus_priv_t *ctx, uint8_t unit_id,
                                      int function, int addr,
                                      int nb, uint8_t *req)
{
    assert(ctx->slave != -1);
    req[0] = unit_id;
    req[1] = function;
    req[2] = addr >> 8;
    req[3] = addr & 0x00ff;
    req[4] = nb >> 8;
    req[5] = nb & 0x00ff;

    return MODBUS_RTU_PRESET_REQ_LENGTH;
}

/* Builds a RTU response header */
static int ModbusRtuBuildResponseBasis(SFT_T *sft, uint8_t *rsp)
{
    /* In this case, the slave is certainly valid because a check is already
     * done in _modbus_rtu_listen */
    rsp[0] = sft->slave;
    rsp[1] = sft->function;

    return _MODBUS_RTU_PRESET_RSP_LENGTH;
}

static uint16_t crc16(uint8_t *buffer, uint16_t buffer_length)
{
    uint8_t crc_hi = 0xFF; /* high CRC byte initialized */
    uint8_t crc_lo = 0xFF; /* low CRC byte initialized */
    unsigned int i; /* will index into CRC lookup */

    /* pass through message buffer */
    while (buffer_length--) {
        i = crc_hi ^ *buffer++; /* calculate the CRC  */
        crc_hi = crc_lo ^ table_crc_hi[i];
        crc_lo = table_crc_lo[i];
    }

    //printf("%p crc_calculated:crc_hi = %d, crc_lo = %d\n", buffer, crc_hi , crc_lo);

    return (crc_hi << 8 | crc_lo);
}

int ModbusRtuPrepareResponseTid(const uint8_t *req, int *req_length)
{
    (*req_length) -= MODBUS_RTU_CHECKSUM_LENGTH;
    /* No TID */
    return 0;
}

int ModbusRtuSendMsgPre(uint8_t *req, int req_length)
{
    uint16_t crc = crc16(req, req_length);
    req[req_length++] = crc >> 8;
    req[req_length++] = crc & 0x00FF;

    return req_length;
}

ssize_t ModbusRtuSend(modbus_priv_t *ctx, const uint8_t *req, int req_length)
{
//     int i=0;
    modbus_rtu_t *pCtxRtu = ctx->backend_data;

    pthread_mutex_lock(&pCtxRtu->mLock);
    ssize_t rc = write(ctx->s, req, req_length);

//     for(i=0;i<req_length;i++)
//     {
//         printf("%x  ", req[i]);
//     }
//     printf("\n");
    //PortUartCanLogWrite (req, req_length, 1);
    pthread_mutex_unlock(&pCtxRtu->mLock);

    return rc;
}

ssize_t ModbusRtuRecv(modbus_priv_t *ctx, uint8_t *rsp, int rsp_length)
{
    int32_t readLenth;
    readLenth = read(ctx->s, rsp, rsp_length);
    return readLenth;

}

int ModbusRtuFlush(modbus_priv_t *ctx)
{
    return tcflush(ctx->s, TCIOFLUSH);
}

/* The check_crc16 function shall return the message length if the CRC is
   valid. Otherwise it shall return -1 and set errno to EMBADCRC. */
int ModbusRtuCheckIntegrity(modbus_priv_t *ctx, uint8_t *msg,
                                const int msg_length)
{
    uint16_t crc_calculated;
    uint16_t crc_received;

    crc_calculated = crc16(msg, msg_length - 2);
    crc_received = (msg[msg_length - 2] << 8) | msg[msg_length - 1];

    /* Check CRC of msg */
    if (crc_calculated == crc_received) {
        return msg_length;
    } else {
        if (ctx->debug) {
            fprintf(stderr, "ERROR CRC received %0X != CRC calculated %0X\n",
                    crc_received, crc_calculated);
        }
        if (ctx->error_recovery & MODBUS_ERROR_RECOVERY_PROTOCOL) {
            ModbusRtuFlush(ctx);
        }

//         if (ctx->debug)
        {
            int i;
            for (i=0; i < msg_length; i++)
                printf("<%.2X>", msg[i]);

            printf("\n");
        }

        errno = EMBBADCRC;
        printf(" .................. CRC Calculate error ...................... \n");
        return -1;

    }
}

/* Sets up a serial port for RTU communications */
int32_t ModbusRtuConnect(modbus_priv_t *ctx)
{
    modbus_rtu_t *ctx_rtu = ctx->backend_data;
    printf("ctx_rtu->uartId:%d %d\n", ctx_rtu->uartId, ctx_rtu->baud);
    ctx->s = OpenComPort(ctx_rtu->uartId, ctx_rtu->baud, ctx_rtu->data_bit, ctx_rtu->stop_bit, ctx_rtu->parity);

    /* The RS232 mode has been set by default */
    ctx_rtu->serial_mode = MODBUS_RTU_RS232;

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s done.\n", __func__);

    return ctx->s;
}

int ModbusRtuSetSerialMode(modbus_priv_t *ctx, int mode)
{
    if (ctx->backend->backend_type == MODBUS_BACKEND_TYPE_RTU)
    {
        modbus_rtu_t *ctx_rtu = ctx->backend_data;
        struct serial_rs485 rs485conf;
        memset(&rs485conf, 0x0, sizeof(struct serial_rs485));

        if (mode == MODBUS_RTU_RS485)
        {
            rs485conf.flags = SER_RS485_ENABLED;
            if (ioctl(ctx->s, TIOCSRS485, &rs485conf) < 0)
            {
                return -1;
            }

            ctx_rtu->serial_mode |= MODBUS_RTU_RS485;
            return 0;
        }
        else if (mode == MODBUS_RTU_RS232)
        {
            if (ioctl(ctx->s, TIOCSRS485, &rs485conf) < 0)
            {
                return -1;
            }

            ctx_rtu->serial_mode = MODBUS_RTU_RS232;
            return 0;
        }

    }

    /* Wrong backend and invalid mode specified */
    errno = EINVAL;
    return -1;
}

int ModbusRtuSelect(modbus_priv_t *ctx, fd_set *rfds,
                       struct timeval *tv, int length_to_read)
{
    int s_rc = 0;

    while ((s_rc = select(ctx->s+1, rfds, NULL, NULL, tv)) == -1)
    {
        if (errno == EINTR)
        {
            if (ctx->debug)
            {
                fprintf(stderr, "A non blocked signal was caught\n");
            }
            /* Necessary after an error */
            FD_ZERO(rfds);
            FD_SET(ctx->s, rfds);
        }
        else
        {
            return -1;
        }
    }

    if (s_rc == 0)
    {
        /* Timeout */
        errno = ETIMEDOUT;
        return -1;
    }
    return s_rc;
}

BOOL ModbusRtuCheckSupport(uint8_t func_code)
{
    BOOL ret = FALSE;

    if (func_code == ReadHoldingRegister || func_code == ReadInputRegister || func_code == ReadInputStatus
        || func_code == WriteSingleRegister || func_code == WriteMultipleRegister
        || func_code == ReadCoilStatus || func_code == WriteSingleCoil || func_code == WriteMultipleCoil)
    {
        ret = TRUE;
    }
    else
    {
        printf("%s func code is not support!\n", __func__);
    }

    return ret;
}

static int32_t ModbusRtuBuildRequest(modbus_priv_t *pCtx, MODBUS_CMD_T* pSendCmd, uint8_t *req)
{
    int32_t req_length;
    int32_t byte_count;
    int32_t i, nb = 0;

    nb = pSendCmd->registerCount;
    if (pSendCmd->cmd == WriteSingleCoil)
    {
        nb = (pSendCmd->data[0] == 0) ? 0 : 0xFF00;
    }

    req_length = ModbusRtuBuildRequestBasis(pCtx, pSendCmd->id, pSendCmd->cmd, pSendCmd->address, nb, req);

    if (pSendCmd->cmd == WriteMultipleRegister)
    {
        byte_count = pSendCmd->registerCount * 2;
        req[req_length++] = byte_count;

        for (i = 0; i < byte_count; i++)
        {
            req[req_length++] = pSendCmd->data[i];
        }
    }

    if (pSendCmd->cmd == WriteMultipleCoil)
    {
        byte_count = (nb / 8) + ((nb % 8) ? 1 : 0);
        req[req_length++] = byte_count;

        int32_t bit_check = 0, pos = 0;
        for (i = 0; i < byte_count; i++)
        {
            int32_t bit = 0x01;
            req[req_length] = 0;

            while ((bit & 0xFF) && (bit_check++ < nb)) {
                if (pSendCmd->data[pos++])
                    req[req_length] |= bit;
                else
                    req[req_length] &=~ bit;

                bit = bit << 1;
            }
            req_length++;
        }
    }

    return req_length;
}

static int32_t ModbusRtuSendCmd(modbus_priv_t *pCtx, MODBUS_CMD_T* pSendCmd)
{
    int32_t req_length;
    uint8_t *req = malloc(sizeof(uint8_t) * MODBUS_RTU_MAX_ADU_LENGTH);
    if (req == NULL || pCtx == NULL || pSendCmd == NULL)
    {
        return -1;
    }

    modbus_priv_t *tmpCTx = pCtx;

    //ModbusRtuBuildRequestBasis(tmpCTx, pSendCmd->id, pSendCmd->cmd, pSendCmd->address, pSendCmd->registerCount, req);
    req_length = ModbusRtuBuildRequest(tmpCTx, pSendCmd, req);
    req_length = ModbusRtuSendMsgPre(req, req_length);
    ModbusRtuSend(tmpCTx, req, req_length);

    if (pCtx->debug)
    {
        int8_t i = 0;
        printf("rtu ");
        for (i = 0; i < req_length; i++)
        {
            printf("0x%2x ", req[i]);
        }
        printf("\n");
    }
    free(req);
    return 0;
}

/* Computes the length to read after the function received */
static uint8_t ComputeMetaLengthAfterFunction(int function,
                                                  MODBUS_MSG_TYPE_E msg_type)
{
    int length;

    if (msg_type ==  MODBUS_MSG_INDICATION)
    {
        if (function <= WriteSingleRegister)
        {
            length = 4;
        }
        else if (function == WriteMultipleCoil || function == WriteMultipleRegister)
        {
            length = 5;
        }
        else if (function == ReadWriteMultiRegister)
        {
            length = 9;
        }
        else
        {
            /* _FC_READ_EXCEPTION_STATUS, _FC_REPORT_SLAVE_ID */
            length = 0;
        }
    }
    else
    {
        /* MSG_CONFIRMATION */
        switch (function)
        {
        case WriteSingleCoil:
        case WriteSingleRegister:
        case WriteMultipleCoil:
        case WriteMultipleRegister:
            length = 4;
            break;
        default:
            length = 1;
        }
    }

    return length;
}

/* Computes the length to read after the meta information (address, count, etc) */
static int ComputeDataLengthAfterMeta(modbus_priv_t *ctx, uint8_t *msg,
                                          MODBUS_MSG_TYPE_E msg_type)
{
    int function = msg[MODBUS_RTU_HEADER_LENGTH];
    int length;

    if (msg_type == MODBUS_MSG_INDICATION)
    {
        switch (function)
        {
        case WriteMultipleCoil:
        case WriteMultipleRegister:
            length = msg[MODBUS_RTU_HEADER_LENGTH + 5];
            break;
        case ReadWriteMultiRegister:
            length = msg[MODBUS_RTU_HEADER_LENGTH + 9];
            break;
        default:
            length = 0;
        }
    }
    else
    {
        /* MSG_CONFIRMATION */
        if (function <= ReadInputRegister || function == ReadWriteMultiRegister)
        {
            length = msg[MODBUS_RTU_HEADER_LENGTH + 1];
        }
        else
        {
            length = 0;
        }
    }

    length += MODBUS_RTU_CHECKSUM_LENGTH;

    return length;
}

static int ReceiveMsg(modbus_priv_t *ctx, uint8_t *msg, MODBUS_MSG_TYPE_E msg_type)
{
    int32_t rc;
    fd_set rfds;
    struct timeval tv;
    struct timeval *p_tv;
    int length_to_read;
    int msg_length = 0;
    _step_t step;

    /* Add a file descriptor to the set */
    FD_ZERO(&rfds);
    FD_SET(ctx->s, &rfds);

    /* We need to analyse the message step by step.  At the first step, we want
     * to reach the function code because all packets contain this
     * information. */
    step = _STEP_FUNCTION;
    length_to_read = MODBUS_RTU_HEADER_LENGTH + 1;  // 2

    if (msg_type == MODBUS_MSG_INDICATION)
    {
        /* Wait for a message, we don't know when the message will be
         * received */
        p_tv = NULL;
    }
    else
    {
        tv.tv_sec = ctx->response_timeout.tv_sec;
        tv.tv_usec = ctx->response_timeout.tv_usec;
        p_tv = &tv;
    }

    while (length_to_read != 0)
    {
        rc = ModbusRtuSelect(ctx, &rfds, p_tv,  length_to_read);
        rc = ModbusRtuRecv(ctx, msg + msg_length, length_to_read);

        if (rc == 0)
        {
            errno = ECONNRESET;
            rc = -1;
        }

        if (rc == -1)
        {
            return -1;
        }

        if (ctx->debug)
        {
            int i;
            for (i=0; i < rc; i++)
                printf("<%.2X>", msg[msg_length + i]);
        }
        /* Sums bytes received */
        msg_length += rc;

        /* Computes remaining bytes */
        length_to_read -= rc;

        if (length_to_read == 0)
        {
            switch (step)
            {
            case _STEP_FUNCTION:   //0
                /* Function code position */
                length_to_read = ComputeMetaLengthAfterFunction(msg[MODBUS_RTU_HEADER_LENGTH], msg_type);
                if (length_to_read != 0)
                {
                    step = _STEP_META;
                    break;
                } /* else switches straight to the next step */
            case _STEP_META:        //1
                length_to_read = ComputeDataLengthAfterMeta(ctx, msg, msg_type);
                if ((msg_length + length_to_read) > MODBUS_RTU_MAX_ADU_LENGTH)
                {
            //         if (ctx->debug)
                    {
                        int i;
                        for (i=0; i < msg_length; i++)
                            printf("<%.2X>", msg[i]);

                        printf("\n");
                    }
                    errno = EMBBADDATA;
                    printf("%s reveive too many data (L%d)\n", __func__, __LINE__);
                    return -1;
                }
                step = _STEP_DATA;
                break;
            default:
                break;
            }
        }

        if (length_to_read > 0 && ctx->byte_timeout.tv_sec != -1)
        {
            /* If there is no character in the buffer, the allowed timeout
               interval between two consecutive bytes is defined by
               byte_timeout */
            tv.tv_sec = ctx->byte_timeout.tv_sec;
            tv.tv_usec = ctx->byte_timeout.tv_usec;
            p_tv = &tv;
        }
    }

    if (ctx->debug)
    {
        printf("\n");
    }

    return ModbusRtuCheckIntegrity(ctx, msg, msg_length);
}

static int32_t ModbusRtuRecvMsg(modbus_priv_t *pCtx, uint8_t* pMsg)
{
    int32_t rc = 0;

    if (pCtx == NULL || pMsg == NULL)
    {
        return -1;
    }

    MODBUS_MSG_TYPE_E msg_type = (pCtx->role == MODBUS_ROLE_MASTER) ? MODBUS_MSG_CONFIRMATION : MODBUS_MSG_INDICATION;
    rc = ReceiveMsg(pCtx, pMsg, msg_type);
    if (rc > 0)
    {
        //PortUartCanLogWrite(pMsg, rc, 0);
    }
    return rc;
}

static int32_t ModbusRtuSet(modbus_priv_t *pCtx, SET_TYPE_E eType, void* pTypeData)
{
    int32_t rc = 0;

    if (pCtx == NULL || pTypeData == NULL)
    {
        return -1;
    }

    return rc;
}

static int32_t ModbusRtuReply(modbus_priv_t *pCtx, uint8_t *resp, int32_t respLen)
{
    int32_t rc = 0;
    modbus_priv_t *tmpCTx = pCtx;

    rc = ModbusRtuSend(tmpCTx, resp, respLen);

    return rc;
}

const MODBUS_BACKEND_T modbus_rtu_backend = {
    MODBUS_BACKEND_TYPE_RTU,
    MODBUS_RTU_HEADER_LENGTH,
    MODBUS_RTU_CHECKSUM_LENGTH,
    MODBUS_RTU_MAX_ADU_LENGTH,
    ModbusRtuCheckSupport,
    ModbusRtuBuildResponseBasis,
    ModbusRtuPrepareResponseTid,
    ModbusRtuSendMsgPre,
    ModbusRtuSendCmd,
    ModbusRtuRecvMsg,
    ModbusRtuSet,
    ModbusRtuReply
};

int32_t ModbusNewRtu(modbus_priv_t *ctx, uint32_t uartId,
                         int baud, char parity, int data_bit,
                         char *stop_bit)
{
    modbus_rtu_t *ctx_rtu;
    size_t dest_size;

    if (ctx == NULL || stop_bit == NULL)
    {
        errno = EINVAL;
        return errno;
    }

    ctx->backend = & modbus_rtu_backend;

    ctx->backend_data = (modbus_rtu_t *) malloc(sizeof(modbus_rtu_t));
    ctx_rtu = (modbus_rtu_t *)ctx->backend_data;

    ctx_rtu->uartId = uartId;
    ctx_rtu->baud = baud;
    if (parity == 'N' || parity == 'E' || parity == 'O') {
        ctx_rtu->parity = parity;
    } else {
        errno = EINVAL;
        return errno;
    }
    ctx_rtu->data_bit = data_bit;

    dest_size = strlen(stop_bit);
    ctx_rtu->stop_bit = calloc(dest_size, sizeof(char));
    strncpy(ctx_rtu->stop_bit, stop_bit, dest_size);
    pthread_mutex_init(&ctx_rtu->mLock, NULL);

    return 0;
}

int32_t ModbusDestroyRtu(modbus_priv_t *ctx)
{
    if (ctx == NULL)
        return INVALID_VALUE;

    modbus_rtu_t *ctx_rtu= ctx->backend_data;
    if (ctx_rtu != NULL)
    {
        if(ctx_rtu->stop_bit != NULL)
        {
            free(ctx_rtu->stop_bit);
        }

        pthread_mutex_destroy(&ctx_rtu->mLock);
        free(ctx_rtu);
        ctx_rtu = NULL;
    }

    return 0;
}

void ModbusRtuClose(modbus_priv_t *ctx)
{
    if (ctx == NULL)
        return;

    modbus_rtu_t *ctx_rtu= ctx->backend_data;
    if (ctx_rtu != NULL)
    {
        tcsetattr(ctx->s, TCSANOW, &(ctx_rtu->old_tios));
    }

    /* Closes the file descriptor in RTU mode */
    CloseComPort(ctx->s);
}
