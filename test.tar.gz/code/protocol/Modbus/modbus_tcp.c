#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include "modbus_tcp.h"
#include "sys.h"

#ifndef HAVE_STRLCPY
/*
 * Copy src to string dest of size dest_size.  At most dest_size-1 characters
 * will be copied.  Always NUL terminates (unless dest_size == 0).  Returns
 * strlen(src); if retval >= dest_size, truncation occurred.
 */
size_t StrLCpy(char *dest, const char *src, size_t dest_size)
{
    register char *d = dest;
    register const char *s = src;
    register size_t n = dest_size;

    /* Copy as many bytes as will fit */
    if (n != 0 && --n != 0) {
        do {
            if ((*d++ = *s++) == 0)
                break;
        } while (--n != 0);
    }

    /* Not enough room in dest, add NUL and traverse rest of src */
    if (n == 0) {
        if (dest_size != 0)
            *d = '\0'; /* NUL-terminate dest */
        while (*s++)
            ;
    }

    return (s - src - 1); /* count does not include NULL */
}
#endif

/* Builds a TCP request header */
static int32_t ModbusTcpBuildRequestBasis(modbus_priv_t *ctx, uint8_t unit_id,
                                    int32_t function, int32_t addr,
                                    int32_t nb, uint8_t *req)
{
    /* Extract from MODBUS Messaging on TCP/IP Implementation Guide V1.0b
       (page 23/46):
       The transaction identifier is used to associate the future response
       with the request. So, at a time, on a TCP connection, this identifier
       must be unique. */
    static uint16_t t_id = 0;

    /* Transaction ID */
    if (t_id < 0xFFFF)
        t_id++;
    else
        t_id = 0;
    req[0] = t_id >> 8;
    req[1] = t_id & 0x00ff;

    /* Protocol Modbus */
    req[2] = 0;
    req[3] = 0;

    /* Length will be defined later by set_req_length_tcp at offsets 4
       and 5 */

    req[6] = unit_id;
    req[7] = function;
    req[8] = addr >> 8;
    req[9] = addr & 0x00ff;
    req[10] = nb >> 8;
    req[11] = nb & 0x00ff;

    return MODBUS_TCP_PRESET_REQ_LENGTH;
}

/* Builds a TCP response header */
static int32_t ModbusTcpBuildResponseBasis(SFT_T *sft, uint8_t *rsp)
{
    /* Extract from MODBUS Messaging on TCP/IP Implementation
       Guide V1.0b (page 23/46):
       The transaction identifier is used to associate the future
       response with the request. */
    rsp[0] = sft->t_id >> 8;
    rsp[1] = sft->t_id & 0x00ff;

    /* Protocol Modbus */
    rsp[2] = 0;
    rsp[3] = 0;

    /* Length will be set later by send_msg (4 and 5) */

    /* The slave ID is copied from the indication */
    rsp[6] = sft->slave;
    rsp[7] = sft->function;

    return MODBUS_TCP_PRESET_RSP_LENGTH;
}

static int32_t ModbusTcpPrepareResponseTid(const uint8_t *req, int32_t *req_length)
{
    return (req[0] << 8) + req[1];
}

static int32_t ModbusTcpSendMsgPre(uint8_t *req, int32_t req_length)
{
    /* Substract the header length to the message length */
    int32_t mbap_length = req_length - 6;

    req[4] = mbap_length >> 8;
    req[5] = mbap_length & 0x00FF;

    return req_length;
}

ssize_t ModbusTcpSend(modbus_priv_t *ctx, const uint8_t *req, int32_t req_length)
{
    ssize_t ret = 0;
    if (ctx == NULL)
    {
        return ret;
    }

    MODBUS_TCP_T *pCtxTcp = (MODBUS_TCP_T*)ctx->backend_data;
    pthread_mutex_lock(&pCtxTcp->mLock);
    /* MSG_NOSIGNAL
       Requests not to send SIGPIPE on errors on stream oriented
       sockets when the other end breaks the connection.  The EPIPE
       error is still returned. */
    ret = send(ctx->s, (const char*)req, req_length, MSG_NOSIGNAL);
    pthread_mutex_unlock(&pCtxTcp->mLock);
    if (ret > 0)
    {
        ctx->statistic.sendCnt++;
    }
    return ret;
}

static ssize_t ModbusTcpRecv(modbus_priv_t *ctx, uint8_t *rsp, int32_t rsp_length) {
    return recv(ctx->s, (char *)rsp, rsp_length, 0);
}

static int32_t ModbusTcpPreCheckConfirmation(modbus_priv_t *ctx, const uint8_t *req,
                                       const uint8_t *rsp, int32_t rsp_length)
{
    /* Check TID */
    if (req[0] != rsp[0] || req[1] != rsp[1]) {
        if (ctx->debug) {
            printf("Invalid TID received 0x%X (not 0x%X)\n",
                    (rsp[0] << 8) + rsp[1], (req[0] << 8) + req[1]);
        }
        errno = EMBBADDATA;
        return -1;
    } else {
        return 0;
    }
}

static int32_t ModbusTcpSetIpv4Option(int32_t s)
{
    int32_t rc;
    int32_t option;

    /* Set the TCP no delay flag */
    /* SOL_TCP = IPPROTO_TCP */
    option = 1;
    rc = setsockopt(s, IPPROTO_TCP, TCP_NODELAY,
                    (const void *)&option, sizeof(int));
    if (rc == -1) {
        return -1;
    }

    /**
     * Cygwin defines IPTOS_LOWDELAY but can't handle that flag so it's
     * necessary to workaround that problem.
     **/
    /* Set the IP low delay option */
    option = IPTOS_LOWDELAY;
    rc = setsockopt(s, IPPROTO_IP, IP_TOS,
                    (const void *)&option, sizeof(int));
    if (rc == -1) {
        return -1;
    }

    return 0;
}

int32_t ModbusTcpConnect(modbus_priv_t *ctx)
{
    int32_t rc = 0;
    struct sockaddr_in addr;
    MODBUS_TCP_T *ctx_tcp = ctx->backend_data;

    ctx->s = socket(PF_INET, SOCK_STREAM, 0);
    if (ctx->s == -1) {
        return -1;
    }

    rc = ModbusTcpSetIpv4Option(ctx->s);
    if (rc == -1) {
        close(ctx->s);
        return -1;
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(ctx_tcp->port);
    addr.sin_addr.s_addr = inet_addr(ctx_tcp->ip);

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s ip:%s port:%d\n", __FUNCTION__, ctx_tcp->ip, ctx_tcp->port);
    rc = connect(ctx->s, (struct sockaddr *)&addr, sizeof(struct sockaddr));
    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s sock:%d connect ret:%d\n", __FUNCTION__, ctx->s, rc);

    if (rc == -1) {
        close(ctx->s);
        return -1;
    }

    ctx_tcp->tcp_state = TCP_STATE_ONLINE;

    return 0;
}

/* Listens for any request from one or many modbus masters in TCP */
int32_t ModbusTcpListen(modbus_priv_t *ctx, int32_t nb_connection)
{
    int32_t new_socket;
    int32_t yes;
    struct sockaddr_in addr;
    MODBUS_TCP_T *ctx_tcp = ctx->backend_data;

    new_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (new_socket == -1) {
        return -1;
    }

    yes = 1;
    if (setsockopt(new_socket, SOL_SOCKET, SO_REUSEADDR,
                   (char *) &yes, sizeof(yes)) == -1) {
        close(new_socket);
        return -1;
    }

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    /* If the modbus port is < to 1024, we need the setuid root. */
    addr.sin_port = htons(ctx_tcp->port);
    addr.sin_addr.s_addr = INADDR_ANY;
    if (bind(new_socket, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
        close(new_socket);
        return -1;
    }

    if (listen(new_socket, nb_connection) == -1) {
        close(new_socket);
        return -1;
    }

    return new_socket;
}

/* On success, the function return a non-negative integer that is a descriptor
   for the accepted socket. On error, -1 is returned, and errno is set
   appropriately. */
int32_t ModbusTcpAccept(modbus_priv_t *ctx, int32_t *socket)
{
    struct sockaddr_in addr;
    socklen_t addrlen;

    addrlen = sizeof(addr);
    ctx->s = accept(*socket, (struct sockaddr *)&addr, &addrlen);
    if (ctx->s == -1) {
        close(*socket);
        *socket = 0;
        return -1;
    }

    if (ctx->debug) {
        printf("The client connection from %s is accepted\n",
               inet_ntoa(addr.sin_addr));
    }

    return ctx->s;
}


/* Closes the network connection and socket in TCP mode */
int32_t ModbusTcpClose(modbus_priv_t *ctx)
{
    int32_t ret = 0;
    ret = shutdown(ctx->s, SHUT_RDWR);
    if (ret != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_MODBUS, FALSE, "%s shutdown ret:%d, err:%s\n", __FUNCTION__, ret, ModbusStrError(errno));
    }
    ret = close(ctx->s);
    if (ret != 0)
    {
        EMS_LOG(LL_ERROR, MODULE_MODBUS, FALSE, "%s close ret:%d, err:%s\n", __FUNCTION__, ret, ModbusStrError(errno));
    }

    return ret;
}

static int32_t ModbusTcpFlush(modbus_priv_t *ctx)
{
    int32_t rc;
    int32_t rc_sum = 0;

    do {
        /* Extract the garbage from the socket */
        char devnull[MODBUS_TCP_MAX_ADU_LENGTH];
        rc = recv(ctx->s, devnull, MODBUS_TCP_MAX_ADU_LENGTH, MSG_DONTWAIT);

        if (rc > 0) {
            rc_sum += rc;
        }
    } while (rc == MODBUS_TCP_MAX_ADU_LENGTH);

    return rc_sum;
}

static int32_t ModbusTcpSelect(modbus_priv_t *ctx, fd_set *rfds, struct timeval *tv, int32_t length_to_read)
{
    int s_rc;
    while ((s_rc = select(ctx->s + 1, rfds, NULL, NULL, tv)) == -1) {
        if (errno == EINTR) {
            if (ctx->debug) {
                fprintf(stderr, "A non blocked signal was caught\n");
            }
            /* Necessary after an error */
            FD_ZERO(rfds);
            FD_SET(ctx->s, rfds);
        } else {
            return -1;
        }
    }

    if (s_rc == 0) {
        errno = ETIMEDOUT;
        return -1;
    }

    return s_rc;
}

/* Builds a TCP request */
static int32_t ModbusTcpBuildRequest(modbus_priv_t *pCtx, MODBUS_CMD_T* pSendCmd, uint8_t *req)
{
    int32_t req_length;
    int32_t byte_count;
    int32_t i, nb = 0;

    nb = pSendCmd->registerCount;
    if (pSendCmd->cmd == WriteSingleCoil)
    {
        nb = (pSendCmd->data[0] == 0) ? 0 : 0xFF00;
    }

    req_length = ModbusTcpBuildRequestBasis(pCtx, pSendCmd->id, pSendCmd->cmd, pSendCmd->address, nb, req);

    if (pSendCmd->cmd == WriteMultipleRegister)
    {
        byte_count = pSendCmd->registerCount * 2;

        req[req_length++] = byte_count;

        for (i = 0; i < byte_count; i++)
        {
            //req[req_length++] = pSendCmd->data[i] >> 8;
            //req[req_length++] = pSendCmd->data[i] & 0x00FF;
            req[req_length++] = pSendCmd->data[i];
        }
    }

    if (pSendCmd->cmd == WriteMultipleCoil)
    {
        byte_count = (nb / 8) + ((nb % 8) ? 1 : 0);
        req[req_length++] = byte_count;

        int32_t bit_check = 0, pos = 0;
        for (i = 0; i < byte_count; i++)
        {
            int32_t bit = 0x01;
            req[req_length] = 0;

            while ((bit & 0xFF) && (bit_check++ < nb)) {
                if (pSendCmd->data[pos++])
                    req[req_length] |= bit;
                else
                    req[req_length] &=~ bit;

                bit = bit << 1;
            }
            req_length++;
        }
    }

    if (pCtx->debug)
    {
        printf("tcp send req: \n");
        for (i = 0; i < req_length; i++)
        {
            printf("0x%x ", req[i]);
        }
        printf("(T:%d)\n", GetTid());
    }

    return req_length;
}

static int32_t ReceiveMsg(modbus_priv_t *pCtx, uint8_t *msg, MODBUS_MSG_TYPE_E msg_type, uint32_t timeout)
{
    struct timeval tv;
    struct timeval *p_tv;
    fd_set rfds;
    int32_t rc;

    FD_ZERO(&rfds);
    FD_SET(pCtx->s, &rfds);

    MODBUS_TCP_T *pCtxTcp = (MODBUS_TCP_T*)pCtx->backend_data;

    if (msg_type == MODBUS_MSG_INDICATION) {
        /* Wait for a message, we don't know when the message will be
         * received */
        p_tv = NULL;
    } else {
        tv.tv_sec = timeout / 1000;
        tv.tv_usec = (timeout % 1000) * 1000;
        p_tv = &tv;
    }

    rc = ModbusTcpSelect(pCtx, &rfds, p_tv, 0);
    if (rc < 0)
    {
        pCtxTcp->tcp_state = TCP_STATE_OFFLINE;
        return rc;
    }

    rc = ModbusTcpRecv(pCtx, msg, sizeof(uint8_t) * MODBUS_TCP_MAX_ADU_LENGTH);

    return rc;
}

static BOOL ModbusTcpCheckSupport(uint8_t func_code)
{
    BOOL ret = FALSE;

    if (func_code == ReadHoldingRegister || func_code == ReadInputRegister || func_code == ReadInputStatus
        || func_code == WriteSingleRegister || func_code == WriteMultipleRegister
        || func_code == ReadCoilStatus || func_code == WriteSingleCoil || func_code == WriteMultipleCoil)
    {
        ret = TRUE;
    }
    else
    {
        printf("func code is not support!\n");
    }

    return ret;
}

static int32_t ModbusTcpSendCmd(modbus_priv_t *pCtx, MODBUS_CMD_T* pSendCmd)
{
    int32_t req_length;
    if (pCtx == NULL || pSendCmd == NULL)
    {
        printf("%s,Invalid Input Parameters.\n",__FUNCTION__);
        return -1;
    }

    MODBUS_TCP_CMD_T *p_tcp_cmd = (MODBUS_TCP_CMD_T *) malloc(sizeof(MODBUS_TCP_CMD_T));
    if (p_tcp_cmd == NULL)
    {
        printf("%s malloc fail.\n",__FUNCTION__);
        return -1;
    }

    memset(p_tcp_cmd, 0, sizeof(MODBUS_TCP_CMD_T));
    req_length = ModbusTcpBuildRequest(pCtx, pSendCmd, (uint8_t*)(&p_tcp_cmd->stAdu));
    p_tcp_cmd->uAduLen = req_length;
    p_tcp_cmd->timeout = pSendCmd->timeout;

    ModbusTcpSendMsgPre((uint8_t*)(&p_tcp_cmd->stAdu), req_length);
    p_tcp_cmd->ePacketType = PACKET_TYPE_NORMAL;

    MODBUS_TCP_T* ctx_tcp = (MODBUS_TCP_T *)pCtx->backend_data;
    ListInsertTail(&ctx_tcp->cmdList, (void*)p_tcp_cmd);

    pCtx->slave = pSendCmd->id;

    return 0;
}

static int32_t ModbusTcpRecvMsg(modbus_priv_t *pCtx, uint8_t* pMsg)
{
    int32_t rc = 0;

    if (pCtx == NULL || pMsg == NULL)
    {
        return -1;
    }

    MODBUS_TCP_T *pCtxTcp = (MODBUS_TCP_T*)pCtx->backend_data;

    if (pCtx->role == MODBUS_ROLE_MASTER)
    {
        if (ListSize(&(pCtxTcp->recvList)) == 0)
        {
            //printf("recvList is empty! \n");
            return -1;
        }

        uint8_t *pTmp = (uint8_t *)ListHeadData(&(pCtxTcp->recvList));
        uint64_t len = sizeof(uint8_t) * MODBUS_TCP_MAX_ADU_LENGTH;
        memcpy(pMsg, pTmp, len);

        ListRemoveHead(&(pCtxTcp->recvList));

        rc = len;
    }
    else{
        rc = ReceiveMsg(pCtx, pMsg, MODBUS_MSG_INDICATION, 0);
    }

    return rc;
}

static int32_t ModbusTcpSet(modbus_priv_t *pCtx, SET_TYPE_E eType, void* pTypeData)
{
    int32_t rc = 0;

    if (pCtx == NULL || pTypeData == NULL)
    {
        return -1;
    }

    MODBUS_TCP_T *pCtxTcp = (MODBUS_TCP_T*)pCtx->backend_data;
    if (pCtxTcp == NULL)
    {
        return -1;
    }

    switch(eType)
    {
        case SET_TYPE_HEART_ENABLE:
            pCtxTcp->heartBeat = *(uint32_t*)pTypeData;
            //pCtxTcp->heartBeat = 1000;
            pCtxTcp->isFirstHeart = (pCtxTcp->heartBeat == INVALID_VALUE) ? FALSE : TRUE;
            EMS_LOG(LL_ERROR, MODULE_MODBUS, FALSE, "set heartBeat:%d\n", pCtxTcp->heartBeat);
            break;
        case SET_TYPE_HEART_DATA:
            {
                MODBUS_CMD_T tmpCmd = *((MODBUS_CMD_T*)pTypeData);
                /*MODBUS_CMD_T tmpCmd;
                tmpCmd.address = 1;
                tmpCmd.cmd = 16;
                tmpCmd.registerCount = 1;
                tmpCmd.data[0] = 0;
                tmpCmd.data[1] = 5;
                tmpCmd.id = 2;*/

                uint16_t req_length = ModbusTcpBuildRequest(pCtx, &tmpCmd, (uint8_t*)(&pCtxTcp->heartData.stAdu));
                pCtxTcp->heartData.uAduLen = req_length;
                pCtxTcp->heartData.timeout = tmpCmd.timeout;
                ModbusTcpSendMsgPre((uint8_t*)(&pCtxTcp->heartData.stAdu), req_length);
                pCtxTcp->heartData.ePacketType = PACKET_TYPE_HEART;
                EMS_LOG(LL_ERROR, MODULE_MODBUS, FALSE, "set SET_TYPE_HEART_DATA.\n");
            }
            break;
        default:
            break;
    }

    return rc;
}

static int32_t ModbusTcpReply(modbus_priv_t *pCtx, uint8_t *resp, int32_t respLen)
{
    int32_t rc = 0;
    if (pCtx == NULL || resp == NULL)
    {
        return -1;
    }

    modbus_priv_t *tmpCTx = pCtx;
    rc = ModbusTcpSend(tmpCTx, resp, respLen);

    return rc;
}

const MODBUS_BACKEND_T modbus_tcp_backend = {
    MODBUS_BACKEND_TYPE_TCP,
    MODBUS_TCP_HEADER_LENGTH,
    MODBUS_TCP_CHECKSUM_LENGTH,
    MODBUS_TCP_MAX_ADU_LENGTH,
    ModbusTcpCheckSupport,
    ModbusTcpBuildResponseBasis,
    ModbusTcpPrepareResponseTid,
    ModbusTcpSendMsgPre,
    ModbusTcpSendCmd,
    ModbusTcpRecvMsg,
    ModbusTcpSet,
    ModbusTcpReply
};

/* Computes the length of the expected response */
static uint32_t ComputeResponseLengthFromRequest(modbus_priv_t *ctx, uint8_t *req)
{
    int length;
    const int offset = ctx->backend->header_length;

    switch (req[offset]) {
    case ReadCoilStatus:
    case ReadInputStatus: {
        /* Header + nb values (code from write_bits) */
        int nb = (req[offset + 3] << 8) | req[offset + 4];
        length = 2 + (nb / 8) + ((nb % 8) ? 1 : 0);
    }
        break;
    case ReadWriteMultiRegister:
    case ReadHoldingRegister:
    case ReadInputRegister:
        /* Header + 2 * nb values */
        length = 2 + 2 * (req[offset + 3] << 8 | req[offset + 4]);
        break;
    default:
        length = 5;
    }

    return offset + length + ctx->backend->checksum_length;
}

static int32_t CheckConfirmation(modbus_priv_t *ctx, uint8_t *req,
                              uint8_t *rsp, int32_t rsp_length)
{
    int32_t rc;
    int32_t rsp_length_computed;
    const int offset = ctx->backend->header_length;

    rc = ModbusTcpPreCheckConfirmation(ctx, req, rsp, rsp_length);
    if (rc == -1) {
        return -1;
    }

    rsp_length_computed = ComputeResponseLengthFromRequest(ctx, req);

    /* Check length */
    if (rsp_length == rsp_length_computed ||
        rsp_length_computed == MSG_LENGTH_UNDEFINED) {
        int req_nb_value;
        int rsp_nb_value;
        const int function = rsp[offset];

        /* Check function code */
        if (function != req[offset]) {
            if (ctx->debug) {
                printf("Received function not corresponding to the request (%d != %d)\n",
                        function, req[offset]);
            }

            errno = EMBBADDATA;
            return -1;
        }

        /* Check the number of values is corresponding to the request */
        switch (function) {
        case ReadCoilStatus:
        case ReadInputStatus:
            /* Read functions, 8 values in a byte (nb
             * of values in the request and byte count in
             * the response. */
            req_nb_value = (req[offset + 3] << 8) + req[offset + 4];
            req_nb_value = (req_nb_value / 8) + ((req_nb_value % 8) ? 1 : 0);
            rsp_nb_value = rsp[offset + 1];
            break;
        case ReadWriteMultiRegister:
        case ReadHoldingRegister:
        case ReadInputRegister:
            /* Read functions 1 value = 2 bytes */
            req_nb_value = (req[offset + 3] << 8) + req[offset + 4];
            rsp_nb_value = (rsp[offset + 1] / 2);
            break;
        case WriteMultipleCoil:
        case WriteMultipleRegister:
            /* N Write functions */
            req_nb_value = (req[offset + 3] << 8) + req[offset + 4];
            rsp_nb_value = (rsp[offset + 3] << 8) | rsp[offset + 4];
            break;
        /*case 0x11:
            // Report slave ID (bytes received)
            req_nb_value = rsp_nb_value = rsp[offset + 1];
            break;*/
        default:
            /* 1 Write functions & others */
            req_nb_value = rsp_nb_value = 1;
        }

        if (req_nb_value == rsp_nb_value) {
            rc = rsp_nb_value;
        } else {
            if (ctx->debug) {
                printf("Quantity not corresponding to the request (%d != %d)\n",
                        rsp_nb_value, req_nb_value);
            }

            errno = EMBBADDATA;
            rc = -1;
        }
    } else if (rsp_length == (offset + 2 + ctx->backend->checksum_length) &&
               req[offset] == (rsp[offset] - 0x80)) {
        /* EXCEPTION CODE RECEIVED */

        int exception_code = rsp[offset + 1];
        if (exception_code < MODBUS_EXCEPTION_MAX) {
            errno = MODBUS_ENOBASE + exception_code;
        } else {
            errno = EMBBADEXC;
        }

        rc = -1;
    } else {
        if (ctx->debug) {
            printf("Message length not corresponding to the computed length (%d != %d)\n",
                    rsp_length, rsp_length_computed);
        }

        errno = EMBBADDATA;
        rc = -1;
    }

    return rc;
}

static BOOL isTimeForHeart(MODBUS_TCP_T *pCtxTcp)
{
    BOOL ret = FALSE;
    struct timeval tE, tS;

    if (pCtxTcp->heartBeat != INVALID_VALUE)
    {
        if (pCtxTcp->isFirstHeart)
        {
            gettimeofday(&pCtxTcp->heartData.tStartSend, NULL);
            pCtxTcp->isFirstHeart = FALSE;
        }

        gettimeofday(&tE, NULL);
        tS = pCtxTcp->heartData.tStartSend;
        int32_t tmp = tE.tv_sec * 1000 + tE.tv_usec / 1000 - tS.tv_sec * 1000 - tS.tv_usec / 1000;
        if (tmp >= pCtxTcp->heartBeat)
        {
            //gettimeofday(&pCtxTcp->heartData.tStartSend, NULL);
            ret = TRUE;
        }

        if (pCtxTcp->debug)
            printf("%s tE(%ld %ld) tS(%ld %ld) delta(%d) ret:%d.(L%d,T:%d)\n",
                   __func__, tE.tv_sec, tE.tv_usec, tS.tv_sec, tS.tv_usec, tmp, ret,__LINE__, GetTid());
    }

    return ret;
}

static MODBUS_TCP_CMD_T* chooseCmd(MODBUS_TCP_T *pCtxTcp)
{
    MODBUS_TCP_CMD_T* tmp = NULL;
    if (ListSize(&pCtxTcp->cmdList))
    {
        tmp = ListHeadData(&pCtxTcp->cmdList);
    }

    if (pCtxTcp->heartData.isSended == TRUE)
    {
        tmp = &pCtxTcp->heartData;
    }
    else if (isTimeForHeart(pCtxTcp))
    {
        if (pCtxTcp->debug)
        {
            printf("%s heat time is reach.(L%d,T:%d)\n", __func__, __LINE__, GetTid());
            if (tmp != NULL)
            {
                printf("%s heat time is reach.type:%d, isSended:%d (L%d,T:%d)\n", __func__, tmp->ePacketType, tmp->isSended,__LINE__, GetTid());
            }
        }

        if (tmp == NULL || (tmp != NULL && tmp->isSended == FALSE))
        {
            tmp = &pCtxTcp->heartData;
        }
    }

    return tmp;
}

void ErrorPrint(modbus_priv_t *ctx, const char *context)
{
    if (ctx->debug) {
        fprintf(stderr, "ERROR %s", ModbusStrError(errno));
        if (context != NULL) {
            fprintf(stderr, ": %s\n", context);
        } else {
            fprintf(stderr, "\n");
        }
    }
}

void ProcessFunc(void* arg)
{
    modbus_priv_t *pCtx = (modbus_priv_t*)arg;
    MODBUS_TCP_T *pCtxTcp = NULL;
    int32_t rc;
    int32_t ret;
    BOOL hasKeeped = FALSE;
    struct timeval tStart, tEnd;

    if (pCtx != NULL)
    {
        pCtxTcp = (MODBUS_TCP_T*)pCtx->backend_data;
    }

    if (pCtx == NULL || pCtxTcp == NULL)
    {
        return;
    }

    gettimeofday(&tStart, NULL);
    prctl(PR_SET_NAME, "MODBUS_PROCESS_THREAD");
    while(pCtxTcp->run)
    {
        if (pCtx == NULL || pCtxTcp == NULL)
        {
            break;
        }

        if (pCtxTcp->tcp_state == TCP_STATE_OFFLINE)
        {
            if (pCtx->error_recovery & MODBUS_ERROR_RECOVERY_LINK) {
                if ((errno == EBADF || errno == ECONNRESET || errno == EPIPE)) {
                    ModbusTcpClose(pCtx);
                    ModbusTcpConnect(pCtx);
                } else {
                    ModbusTcpFlush(pCtx);
                }
            }
        }

        pCtxTcp->pCurCmd = chooseCmd(pCtxTcp);
        if (pCtxTcp->pCurCmd != NULL)
        {
            MODBUS_TCP_CMD_T *tmpCmd = pCtxTcp->pCurCmd;
            if (!tmpCmd->isSended)
            {
                rc = ModbusTcpSend(pCtx, (uint8_t*)(&tmpCmd->stAdu), tmpCmd->uAduLen);
                if (rc == -1)
                {
                    ErrorPrint(pCtx, "send");
                    pCtx->statistic.sendFailCnt++;
                    pCtxTcp->tcp_state = TCP_STATE_OFFLINE;
                    ListRemoveHead(&pCtxTcp->cmdList);
                }
                else
                {
                    tmpCmd->isSended = TRUE;
                    gettimeofday(&tmpCmd->tStartSend, NULL);
                    if (pCtx->debug)
                        printf("%s CurCmd:%p type:%d is send at (%ld %ld).(L%d,T:%d)\n",
                               __func__, tmpCmd, tmpCmd->ePacketType, tmpCmd->tStartSend.tv_sec, tmpCmd->tStartSend.tv_usec,
                               __LINE__, GetTid());
                }
            }
            else
            {
                gettimeofday(&tEnd, NULL);
                int32_t tmpMs = tEnd.tv_sec * 1000 + tEnd.tv_usec / 1000 - tmpCmd->tStartSend.tv_sec * 1000 - tmpCmd->tStartSend.tv_usec / 1000;

                if (pCtx->debug)
                    printf("%s CurCmd:%p type:%d at (%ld %ld, delta:%d).(L%d,T:%d)\n",
                            __func__, tmpCmd, tmpCmd->ePacketType, tEnd.tv_sec, tEnd.tv_usec, tmpMs,
                            __LINE__, GetTid());

                if (tmpMs >= 300)
                {
                    pCtx->statistic.sendFailCnt++;
                    if (pCtxTcp->pCurCmd->ePacketType == PACKET_TYPE_HEART)
                    {
                        pCtxTcp->pCurCmd->isSended = FALSE;

                        if (pCtx->debug)
                            printf("Reset heart cmd since recv timeout!!!! cmd size:%d (T:%d)\n", ListSize(&pCtxTcp->cmdList), GetTid());
                    }
                    else
                    {
                        ListRemoveHead(&pCtxTcp->cmdList);

                        if (pCtx->debug)
                            printf("Remove cmd since recv timeout!!!! cmd size:%d (T:%d)\n", ListSize(&pCtxTcp->cmdList), GetTid());
                    }
                    continue;
                }

            }
        }

        //if (tcp_cmd != NULL)
        {
            uint8_t *p_rsp = (uint8_t*)malloc(sizeof(uint8_t) * MODBUS_TCP_MAX_ADU_LENGTH);
            hasKeeped = FALSE;
            rc = ReceiveMsg(pCtx, p_rsp, MODBUS_MSG_CONFIRMATION, 20);
            if (rc > 0)
            {
                MODBUS_TCP_CMD_T *tcp_cmd = pCtxTcp->pCurCmd;

                if (tcp_cmd != NULL && tcp_cmd->isSended)
                {
                    ret = CheckConfirmation(pCtx, (uint8_t *)(&tcp_cmd->stAdu), p_rsp, rc);

                    if (pCtx->debug)
                    {
                        struct timeval tRecv;
                        gettimeofday(&tRecv, NULL);
                        printf("%s CurCmd:%p type:%d ReceiveMsg rc:%d at (%ld %ld) cmdList size:%d cost:%ld (L%d,T:%d)\n",
                               __func__, tcp_cmd, tcp_cmd->ePacketType, rc,
                               tRecv.tv_sec, tRecv.tv_usec,
                               ListSize(&pCtxTcp->cmdList),
                               tRecv.tv_sec * 1000 + tRecv.tv_usec / 1000 - tcp_cmd->tStartSend.tv_sec * 1000 - tcp_cmd->tStartSend.tv_usec / 1000,
                               __LINE__, GetTid());
                    }

                    if (ret == -1 &&
                        (errno < MODBUS_ENOBASE || errno > EMBXGTAR)
                    )
                    {
                        if (pCtx->debug)
                        {
                            printf("CheckConfirmation fail: %s. (T:%d)\n", ModbusStrError(errno), GetTid());
                        }
                        continue;
                    }

                    if (tcp_cmd->ePacketType == PACKET_TYPE_NORMAL)
                    {
                        ListInsertTail(&pCtxTcp->recvList, (void*)p_rsp);
                        ListRemoveHead(&pCtxTcp->cmdList);
                        hasKeeped = TRUE;
                    }
                    else
                    {
                        tcp_cmd->isSended = FALSE;
                    }

                    pCtx->statistic.revCnt++;
                }
            }

            if (!hasKeeped)
            {
                if (p_rsp != NULL)
                {
                    free(p_rsp);
                    p_rsp = NULL;
                }
            }
        }

        if (pCtx->debug)
        {
            gettimeofday(&tEnd, NULL);
            if (tEnd.tv_sec - tStart.tv_sec > 1)
            {
                gettimeofday(&tStart, NULL);
                printf("statistic, appSendCnt:%u, sendCnt:%u, revCnt:%u, sendFailCnt:%u.(T:%d)\n",
                    pCtx->statistic.appSendCnt, pCtx->statistic.sendCnt, pCtx->statistic.revCnt, pCtx->statistic.sendFailCnt,
                    GetTid());
            }
        }

    }

    //printf("%s exit! \n", __FUNCTION__);
    return;
}

static void CreateThread(modbus_priv_t *pCtx)
{
    int32_t res;
    pthread_attr_t thread_attr;
    size_t stacksize;

    MODBUS_TCP_T *pCtxTcp = (MODBUS_TCP_T*)pCtx->backend_data;

    res = pthread_attr_init(&thread_attr);
    if (res != 0) {
        perror("Attribute creation failed");
        exit(EXIT_FAILURE);
    }

    stacksize = 512*1024;/* 512KB 栈空间 */
    res = pthread_attr_setstacksize(&thread_attr, stacksize);

    res = pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
    if (res != 0) {
        perror("Setting detached attribute failed");
        exit(EXIT_FAILURE);
    }

    res = pthread_create(&(pCtxTcp->pid), &thread_attr, (void*)ProcessFunc, (void *)pCtx);
    if (res != 0) {
        perror("Thread MODBUS_PROCESS_THREAD creation failed");
        exit(EXIT_FAILURE);
    }

    (void)pthread_attr_destroy(&thread_attr);
}

int32_t ModbusNewTcp(modbus_priv_t *ctx, const char *ip, int32_t port)
{
    MODBUS_TCP_T *ctx_tcp;
    size_t dest_size;
    size_t ret_size;

    if (ctx == NULL)
    {
        errno = EINVAL;
        return errno;
    }

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s ip:%s port:%d\n", __FUNCTION__, ip, port);

    ctx->backend = &(modbus_tcp_backend);

    ctx->backend_data = (MODBUS_TCP_T *) malloc(sizeof(MODBUS_TCP_T));
    memset(ctx->backend_data, 0 , sizeof(MODBUS_TCP_T ));
    ctx_tcp = (MODBUS_TCP_T *)ctx->backend_data;

    dest_size = sizeof(char) * 16;
    ret_size = StrLCpy(ctx_tcp->ip, ip, dest_size);
    if (ret_size == 0) {
        fprintf(stderr, "The IP string is empty\n");
        errno = EINVAL;
        return errno;
    }

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s ctx_tcp->ip:%s\n",__FUNCTION__,ctx_tcp->ip);

    if (ret_size >= dest_size) {
        fprintf(stderr, "The IP string has been truncated.\n");
        errno = EINVAL;
        return errno;
    }

    ctx_tcp->debug = FALSE;
    ctx_tcp->port = port;
    ctx_tcp->heartBeat = INVALID_VALUE;

    //int32_t v = 1000;
    //ModbusTcpSet(ctx, SET_TYPE_HEART_ENABLE, &v);
    //ModbusTcpSet(ctx, SET_TYPE_HEART_DATA, &v);

    if (ctx->role == MODBUS_ROLE_MASTER)
    {
        ListInit(&ctx_tcp->cmdList);
        ListInit(&ctx_tcp->recvList);

        ctx_tcp->run = true;
        CreateThread(ctx);
    }

    pthread_mutex_init(&ctx_tcp->mLock, NULL);

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s done.\n",__FUNCTION__);

    return 0;
}

int32_t ModbusDestroyTcp(modbus_priv_t *pCtx)
{
    if (pCtx == NULL)
        return -1;

    void *rtest;

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s \n", __FUNCTION__);

    MODBUS_TCP_T *pCtxTcp = (MODBUS_TCP_T*)pCtx->backend_data;
    if (pCtxTcp != NULL)
    {
        pCtxTcp->run = false;
        if (pCtxTcp->pid)
        {
            pthread_join(pCtxTcp->pid, &rtest);
        }

        ListDestroy(&pCtxTcp->cmdList);
        ListDestroy(&pCtxTcp->recvList);

        pthread_mutex_destroy(&pCtxTcp->mLock);

        free(pCtxTcp);
        pCtxTcp = NULL;
    }

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s done.\n", __FUNCTION__);

    return 0;
}
