#!/bin/sh
make clean_c

make
exit 0
