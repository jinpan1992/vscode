#include <string.h>
#include<stdlib.h>
#include <unistd.h>
#include <sys/syscall.h>
#include "modbus.h"
//#include "modbus_tcp.h"
#include "modbus_rtu.h"
#include <errno.h>


#define SLAVER_ID   1
/*00 01 00 00 00 06 01 03 0A 0C 00 02

* 00 01 00 00 00 07 01 03 04 00 06 00 08
*/

int32_t addregdata(uint8_t *req, int req_length,  uint8_t data)
{
    req[req_length++] = data;
    return req_length;
}

# if 0
int main()
{
#if 0
    START_INFO_T start_info;
    char c[] = "127.0.0.1";
    //char c[] = "192.168.27.17";
    //char c[] = "192.168.28.88";

    strncpy(start_info.sIp, c, sizeof(c));
    start_info.iPort = 502;
    start_info.type = MODBUS_BACKEND_TYPE_TCP;
    //start_info.slave = MODBUS_TCP_SLAVE;

    printf("start_info.sIp:%s \n", start_info.sIp);
    uintptr_t fd = ModbusOpen(start_info);

    MODBUS_CMD_T cmd;
    cmd.transaction = 1;
    cmd.protocolType = 0;
    cmd.id = 1;
    cmd.cmd = 0x03;
    cmd.address = 99;
    cmd.registerCount = 1;

    ModbusSend(fd, &cmd);

    /*uint8_t req[] = {0x00, 0x01, 0x00, 0x00, 0x00, 0x06, 0x01, 0x03, 0x0a, 0x0c, 0x00, 0x02};
    for (int i = 0; i < 4; i++)
    {
        ModbusTcpSend((modbus_priv_t*)fd, (const uint8_t *)req, sizeof(req));
        sleep(1);
    }*/

    sleep(5);

    uint8_t msg[MODBUS_TCP_MAX_ADU_LENGTH];
    ModbusRecv(fd, msg);
    printf("main recv:\n");
    for (int j = 0; j < 13; j++)
    {
        printf(" 0x%2x ", msg[j]);
    }
    printf(".\n");

    ModbusClose(fd);

    printf("main done.\n");

    return 0;
#endif
      int32_t req_length;
      uint8_t rc, i;
      uint8_t value[256] = {0};
      struct timeval tv;
      struct timeval *p_tv=NULL;
      fd_set rfds;
     modbus_priv_t *ctx = NULL;
     ctx = (modbus_priv_t *) malloc(sizeof(modbus_priv_t));
     uint8_t *req = malloc(sizeof(uint8_t) * MODBUS_RTU_MAX_ADU_LENGTH);
     memset(req, 0 , sizeof(uint8_t) * MODBUS_RTU_MAX_ADU_LENGTH);

     tv.tv_sec = 1;
     tv.tv_usec = 0;
     p_tv = &tv;

     /*RTU*/
     ModbusNewRtu(ctx, "/dev/ttyO1", 9600, 'N', 8, 1);
     ModbusSetSlave(ctx,SLAVER_ID);
     //设置串口工作模式
     ModbusRtuSetSerialMode(ctx, MODBUS_RTU_RS485);

     if (ModbusRtuConnect(ctx) == -1) {
        fprintf(stderr, "Rtu Connect failed: %s\n", ModbusStrError(errno));
        //ModbusDestroyTcp(ctx);
        free(ctx);
        ctx = NULL;
       }


     req_length = ModbusRtuBuildRequestBasis(ctx, 1, 3, 27500, 80, req);
     req_length = ModbusRtuSendMsgPre(req, MODBUS_RTU_PRESET_REQ_LENGTH);
     ModbusRtuSend(ctx, req, MODBUS_RTU_PRESET_REQ_LENGTH+2);

    for (i = 0; i < req_length; i++)
    {
        printf("req[%d]=%d ", i, req[i]);
    }
    printf(" send  OK \n");
    sleep(1);



     rc = ModbusRtuSelect(ctx, &rfds, p_tv, 0);
     printf(".... select =%d (L:%d)\n...",rc, __LINE__);
     rc =  ModbusRtuRecv(ctx, value, rc);
     printf(".... recv =%d (L:%d)\n...",rc, __LINE__);
      for(i=0;i<rc;i++)
     {
      printf("  value[%d]=%d  ", i, value[i]);
     }


     ModbusRtuClose(ctx);
     free(req);

     return 0;
}


#if 0
pid_t gettid()
{
    return syscall(SYS_gettid);

}

void threadMain(void *arg)
{
    uintptr_t fd = *(uintptr_t*)arg;

    printf("%s fd:%lu (L%d,pid:%d)\n", __func__, fd, __LINE__, gettid());

    MODBUS_CMD_T cmd;
    cmd.transaction = 1;
    cmd.protocolType = 0;
    cmd.id = 1;
    cmd.cmd = 0x03;
    cmd.address = 99;
    cmd.registerCount = 1;
    printf("%s fd:%lu (L%d,pid:%d)\n", __func__, fd, __LINE__, gettid());
    ModbusSend(fd, &cmd);
    printf("%s fd:%lu (L%d,pid:%d)\n", __func__, fd, __LINE__, gettid());
    /*uint8_t req[] = {0x00, 0x01, 0x00, 0x00, 0x00, 0x06, 0x01, 0x03, 0x0a, 0x0c, 0x00, 0x02};
    for (int i = 0; i < 4; i++)
    {
        ModbusTcpSend((modbus_priv_t*)fd, req, sizeof(req));
        sleep(1);
    }*/

    usleep(5000000);

    uint8_t req[MODBUS_TCP_MAX_ADU_LENGTH];
    ModbusRecv(fd, req);
    /*printf("main recv:\n");
    for (int j = 0; j < 13; j++)
    {
        printf(" 0x%2x ", req[j]);
    }
    printf(".\n");
    */
    printf("%s fd:%lu (L%d,pid:%d)\n", __func__, fd, __LINE__, gettid());

    ModbusClose(fd);
    printf("%s fd:%lu (L%d,pid:%d) end.\n", __func__, fd, __LINE__, getgid());
}

int main()
{
    int i = 0;
    int res;
    pthread_t pid[10];
    pthread_attr_t thread_attr;
    size_t stacksize;

    res = pthread_attr_init(&thread_attr);
    if (res != 0) {
        printf("Attribute creation failed");
    }

    stacksize = 512*1024;/* 512KB 栈空间 */
    res = pthread_attr_setstacksize(&thread_attr, stacksize);

    res = pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
    if (res != 0) {
        printf("Setting detached attribute failed");
    }

    for (i = 0; i < 10; i++)
    {
        START_INFO_T start_info;
        char c[] = "127.0.0.1";
        //char c[] = "192.168.27.17";
        //char c[] = "192.168.28.88";

        strncpy(start_info.sIp, c, sizeof(c));
        start_info.iPort = 502;
        start_info.type = MODBUS_BACKEND_TYPE_TCP;
        start_info.slave = MODBUS_TCP_SLAVE;

        printf("start_info.sIp:%s \n", start_info.sIp);
        uintptr_t fd = ModbusOpen(start_info);

        res = pthread_create(&(pid[i]), &thread_attr, (void*)threadMain, (void*)(&fd));
        if (res != 0) {
            printf("Thread creation failed");
        }

    }

    while(1)
    {
        sleep(1);
    }
    return 0;
}
#endif
#endif


