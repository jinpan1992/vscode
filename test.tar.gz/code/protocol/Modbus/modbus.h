#ifndef MODBUS_H_INCLUDED
#define MODBUS_H_INCLUDED

#include <stdio.h>
#include <stdint.h>
#include <sys/time.h>
#include <sys/types.h>
#include "common.h"
#include "logUtil.h"

#define MODBUS_TCP_DEFAULT_PORT   502

#define MODBUS_BROADCAST_ADDRESS    0

/* Modbus_Application_Protocol_V1_1b.pdf (chapter 6 section 1 page 12)
 * Quantity of Coils to read (2 bytes): 1 to 2000 (0x7D0)
 * (chapter 6 section 11 page 29)
 * Quantity of Coils to write (2 bytes): 1 to 1968 (0x7B0)
 */
#define MODBUS_MAX_READ_BITS              2000
#define MODBUS_MAX_WRITE_BITS             1968

/* Modbus_Application_Protocol_V1_1b.pdf (chapter 6 section 3 page 15)
 * Quantity of Registers to read (2 bytes): 1 to 125 (0x7D)
 * (chapter 6 section 12 page 31)
 * Quantity of Registers to write (2 bytes) 1 to 123 (0x7B)
 * (chapter 6 section 17 page 38)
 * Quantity of Registers to write in R/W registers (2 bytes) 1 to 121 (0x79)
 */
#define MODBUS_MAX_READ_REGISTERS          125
#define MODBUS_MAX_WRITE_REGISTERS         123
#define MODBUS_MAX_RW_WRITE_REGISTERS      121

#define EMBXILFUN  (MODBUS_ENOBASE + MODBUS_EXCEPTION_ILLEGAL_FUNCTION)
#define EMBXILADD  (MODBUS_ENOBASE + MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS)
#define EMBXILVAL  (MODBUS_ENOBASE + MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE)
#define EMBXSFAIL  (MODBUS_ENOBASE + MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE)
#define EMBXACK    (MODBUS_ENOBASE + MODBUS_EXCEPTION_ACKNOWLEDGE)
#define EMBXSBUSY  (MODBUS_ENOBASE + MODBUS_EXCEPTION_SLAVE_OR_SERVER_BUSY)
#define EMBXNACK   (MODBUS_ENOBASE + MODBUS_EXCEPTION_NEGATIVE_ACKNOWLEDGE)
#define EMBXMEMPAR (MODBUS_ENOBASE + MODBUS_EXCEPTION_MEMORY_PARITY)
#define EMBXGPATH  (MODBUS_ENOBASE + MODBUS_EXCEPTION_GATEWAY_PATH)
#define EMBXGTAR   (MODBUS_ENOBASE + MODBUS_EXCEPTION_GATEWAY_TARGET)

/* Native libmodbus error codes */
#define EMBBADCRC  (EMBXGTAR + 1)
#define EMBBADDATA (EMBXGTAR + 2)
#define EMBBADEXC  (EMBXGTAR + 3)
#define EMBUNKEXC  (EMBXGTAR + 4)
#define EMBMDATA   (EMBXGTAR + 5)

/* Random number to avoid errno conflicts */
#define MODBUS_ENOBASE 112345678

/* Timeouts in microsecond (0.5 s) */
#define RESPONSE_TIMEOUT    700000
#define BYTE_TIMEOUT        500000

/* Protocol exceptions */
enum
{
    MODBUS_EXCEPTION_ILLEGAL_FUNCTION = 0x01,
    MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS,
    MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE,
    MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE,
    MODBUS_EXCEPTION_ACKNOWLEDGE,
    MODBUS_EXCEPTION_SLAVE_OR_SERVER_BUSY,
    MODBUS_EXCEPTION_NEGATIVE_ACKNOWLEDGE,
    MODBUS_EXCEPTION_MEMORY_PARITY,
    MODBUS_EXCEPTION_NOT_DEFINED,
    MODBUS_EXCEPTION_GATEWAY_PATH,
    MODBUS_EXCEPTION_GATEWAY_TARGET,
    MODBUS_EXCEPTION_MAX
};

/*定义Modbus的操作功能码*/
typedef enum
{
  ReadCoilStatus         = 0x01,    /*读线圈状态（读多个输出位的状态）*/
  ReadInputStatus        = 0x02,    /*读输入位状态（读多个输入位的状态）*/
  ReadHoldingRegister    = 0x03,    /*读保持寄存器（读多个保持寄存器的数值）*/
  ReadInputRegister      = 0x04,    /*读输入寄存器（读多个输入寄存器的数值）*/
  WriteSingleCoil        = 0x05,    /*写单个线圈（强制单个输出位的状态）*/
  WriteSingleRegister    = 0x06,    /*写单个保持寄存器（设定一个寄存器的数值）*/
  WriteMultipleCoil      = 0x0F,    /*写多个线圈（强制多个输出位的状态）*/
  WriteMultipleRegister  = 0x10,    /*写多个寄存器（设定多个寄存器的数值）*/
  ReadFileRecord         = 0x14,    /*读文件记录*/
  WriteFileRecord        = 0x15,    /*写文件记录*/
  MaskWriteRegister      = 0x16,    /*屏蔽写寄存器*/
  ReadWriteMultiRegister = 0x17,    /*读写多个寄存器*/
  ReadDeviceID           = 0x2B     /*读设备识别码*/
}FUNCTION_CODE_E;

typedef enum
{
    MODBUS_BACKEND_TYPE_TCP = 0,
    MODBUS_BACKEND_TYPE_RTU
}MODBUS_BACKEND_TYPE_E;

/*
    ---------- Request     Indication ----------
    | Client | ---------------------->| Server |
    ---------- Confirmation  Response ----------
*/
typedef enum
{
    MODBUS_MSG_INDICATION,     /* Request message on the server side */
    MODBUS_MSG_CONFIRMATION    /* Request message on the client side */
} MODBUS_MSG_TYPE_E;

typedef struct MODBUS_PRIV_T modbus_priv_t;

typedef enum
{
    MODBUS_ERROR_RECOVERY_NONE          = 0,
    MODBUS_ERROR_RECOVERY_LINK          = (1 << 1),
    MODBUS_ERROR_RECOVERY_PROTOCOL      = (1 << 2),
}MODBUS_ERROR_RECOVERY_MODE_E;

typedef enum
{
    MODBUS_ROLE_NONE   = 0,
    MODBUS_ROLE_MASTER = (1 << 1),
    MODBUS_ROLE_SLAVE  = (1 << 2),
}MODBUS_ROLE_E;

typedef enum
{
    SET_TYPE_HEART_ENABLE,
    SET_TYPE_HEART_DATA
} SET_TYPE_E;

typedef enum
{
    PACKET_TYPE_NORMAL,
    PACKET_TYPE_HEART
} PACKET_TYPE_E;

typedef struct
{
    int32_t nb_bits;
    int32_t nb_input_bits;
    int32_t nb_input_registers;
    int32_t nb_registers;
    uint8_t *tab_bits;
    uint8_t *tab_input_bits;
    uint16_t *tab_input_registers;
    uint16_t *tab_registers;
} MODBUS_MAPPING_T;

typedef struct
{
    MODBUS_BACKEND_TYPE_E type; /* 0:tcp,1:rtu */
    char sIp[32]; /* ip address */
    int32_t iPort; /* port */
    MODBUS_ROLE_E role;

    uint32_t uartId; /*uart id*/
    uint32_t baud; /*波特率*/
    char parity; /*极性*/
    int32_t data_bit; /*数据位*/
    char stop_bit[4]; /*停止位*/
    uint8_t metertype;//设备类型
    uint8_t devAddr[7];//*设备地址
	int32_t fd;
}START_INFO_T;

/* This structure reduces the number of params in functions and so
 * optimizes the speed of execution (~ 37%). */
typedef struct
{
    int32_t slave;
    int32_t function;
    int32_t t_id;
} SFT_T;

typedef struct
{
    uint32_t appSendCnt;
    uint32_t sendCnt;
    uint32_t revCnt;
    uint32_t sendFailCnt;
} STATISTICS_T;

typedef struct
{
    uint32_t backend_type;
    uint32_t header_length;
    uint32_t checksum_length;
    uint32_t max_adu_length;
    BOOL (*CheckSupport)(uint8_t func_code);
    int32_t (*BuildResponseBasis) (SFT_T *sft, uint8_t *rsp);
    int32_t (*PrepareResponseTid) (const uint8_t *req, int32_t *req_length);
    int32_t (*SendMsgPre) (uint8_t *req, int32_t req_length);
    int32_t (*SendCmd)(modbus_priv_t *ctx, MODBUS_CMD_T *pSendCmd);
    int32_t (*RecvMsg)(modbus_priv_t *ctx, uint8_t* msg);
    int32_t (*Set)(modbus_priv_t *ctx, SET_TYPE_E eType, void* pTyepData);
    int32_t (*Reply)(modbus_priv_t *ctx, uint8_t *resp, int32_t respLen);
} MODBUS_BACKEND_T;

struct MODBUS_PRIV_T
{
    int32_t slave;
    int32_t s;    /* Socket or file descriptor */
    int32_t debug;
    int32_t error_recovery;
    MODBUS_ROLE_E role;
    struct timeval response_timeout;
    struct timeval byte_timeout;
    const MODBUS_BACKEND_T *backend;
    void *backend_data;
    STATISTICS_T statistic;
};

#ifndef HAVE_STRLCPY
size_t StrLCpy(char *dest, const char *src, size_t dest_size);
#endif

const char *ModbusStrError(int32_t errnum);

uintptr_t ModbusOpen(START_INFO_T start_info);/* 返回modbus 协议栈上下文 */
int32_t ModbusSend(uintptr_t ctx, MODBUS_CMD_T *pSendCmd); /* ctx: modbus 协议栈上下文 */
int32_t ModbusRecv(uintptr_t ctx, uint8_t *pMsg); /* response len = sizeof(uint8_t) * MODBUS_TCP_MAX_ADU_LENGTH) */
int32_t ModbusReply(uintptr_t ctx, const uint8_t *resp, int32_t respLen);
int32_t ModbusClose(uintptr_t ctx);
int32_t ModbusSet(uintptr_t ctx, SET_TYPE_E eType, void* pTypeData);

//for test
MODBUS_MAPPING_T* ModbusMappingNew(int32_t nb_bits, int32_t nb_input_bits,
                                     int32_t nb_registers, int32_t nb_input_registers);
void ModbusMappingFree(MODBUS_MAPPING_T *mb_mapping);
//int32_t ModbusReply(uintptr_t ctx, const uint8_t *req, int32_t req_length, MODBUS_MAPPING_T *mb_mapping);

#endif // MODBUS_H_INCLUDED
