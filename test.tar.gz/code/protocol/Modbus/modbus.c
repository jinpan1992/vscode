#include <errno.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

#include "modbus.h"
#include "modbus_tcp.h"
#include "modbus_rtu.h"

const char *ModbusStrError(int32_t errnum) {
    switch (errnum) {
    case EMBXILFUN:
        return "Illegal function";
    case EMBXILADD:
        return "Illegal data address";
    case EMBXILVAL:
        return "Illegal data value";
    case EMBXSFAIL:
        return "Slave device or server failure";
    case EMBXACK:
        return "Acknowledge";
    case EMBXSBUSY:
        return "Slave device or server is busy";
    case EMBXNACK:
        return "Negative acknowledge";
    case EMBXMEMPAR:
        return "Memory parity error";
    case EMBXGPATH:
        return "Gateway path unavailable";
    case EMBXGTAR:
        return "Target device failed to respond";
    case EMBBADCRC:
        return "Invalid CRC";
    case EMBBADDATA:
        return "Invalid data";
    case EMBBADEXC:
        return "Invalid exception code";
    case EMBMDATA:
        return "Too many data";
    default:
        return strerror(errnum);
    }
}

static int32_t modbus_init_common(modbus_priv_t *ctx)
{
    /* socket are initialized to -1 */
    ctx->s = -1;

    ctx->role = MODBUS_ROLE_MASTER;

    ctx->debug = FALSE;
    ctx->error_recovery = MODBUS_ERROR_RECOVERY_NONE;

    ctx->response_timeout.tv_sec = 0;
    ctx->response_timeout.tv_usec = RESPONSE_TIMEOUT;

    ctx->byte_timeout.tv_sec = 0;
    ctx->byte_timeout.tv_usec = BYTE_TIMEOUT;

    memset(&ctx->statistic, 0, sizeof(STATISTICS_T));

    return 0;
}

uintptr_t ModbusOpen(START_INFO_T start_info)
{
    uint8_t u8Backend;
    modbus_priv_t *ctx = NULL;
    int socket;

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s type:%d\n", __FUNCTION__, start_info.type);
    ctx = (modbus_priv_t *) malloc(sizeof(modbus_priv_t));
    if (ctx == NULL)
    {
        return INVALID_VALUE;
    }

    modbus_init_common(ctx);
    ctx->role = start_info.role;
    //ctx->debug = FALSE;

    u8Backend = start_info.type;
    if (u8Backend == MODBUS_BACKEND_TYPE_TCP) {
        ModbusNewTcp(ctx, start_info.sIp, start_info.iPort);

        if (ctx->role == MODBUS_ROLE_MASTER)
        {
            if (ModbusTcpConnect(ctx) == -1) {
                // EMS_LOG(LL_ERROR, MODULE_MODBUS, FALSE, "TCP Connect failed: %s\n", ModbusStrError(errno));
                ModbusDestroyTcp(ctx);
                free(ctx);
                ctx = NULL;
            }
        }
        else{
            socket = ModbusTcpListen(ctx, 100);
            if (socket > 0)
            {
                ModbusTcpAccept(ctx, &socket);
            }
        }

    }
    else if (u8Backend == MODBUS_BACKEND_TYPE_RTU){
        ModbusNewRtu(ctx, start_info.uartId, start_info.baud, start_info.parity, start_info.data_bit, start_info.stop_bit);

        //设置串口工作模式
	    ModbusRtuSetSerialMode(ctx, MODBUS_RTU_RS485);

        if ((ctx->role == MODBUS_ROLE_MASTER) ||(ctx->role == MODBUS_ROLE_SLAVE))
        {
            if (ModbusRtuConnect(ctx) == -1) {
                EMS_LOG(LL_ERROR, MODULE_MODBUS, FALSE, "Rtu Connect failed: %s\n", ModbusStrError(errno));
                ModbusDestroyRtu(ctx);
                free(ctx);
                ctx = NULL;
            }
        }

    }

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s done.\n", __FUNCTION__);

    return (ctx == NULL) ? (INVALID_VALUE) : ((uintptr_t)ctx);
}

int32_t ModbusSend(uintptr_t ctx, MODBUS_CMD_T* pSendCmd)
{
    int32_t ret = 0;

    modbus_priv_t *pCtx = (modbus_priv_t*)ctx;
    if (pCtx == NULL || pSendCmd == NULL || ctx == INVALID_VALUE)
    {
        printf("%s,Invalid Input Parameters.\n", __FUNCTION__);
        return -1;
    }

    if (pCtx->backend->CheckSupport(pSendCmd->cmd))
    {
        pCtx->statistic.appSendCnt++;
        ret = pCtx->backend->SendCmd(pCtx, pSendCmd);
    }

    return ret;
}

int32_t ModbusRecv(uintptr_t ctx, uint8_t *pMsg)
{
    int32_t rc = 0;
    modbus_priv_t *pCtx = (modbus_priv_t*)ctx;
    int i;
    if (pCtx == NULL || pMsg == NULL || ctx == INVALID_VALUE)
    {
        //printf("%s,Invalid Input Parameters.\n",__FUNCTION__);
        return -1;
    }

    rc = pCtx->backend->RecvMsg(pCtx, pMsg);
    if (pCtx->debug && rc > 0)
    {
        printf("%s slave:%d:\n", __FUNCTION__, pCtx->slave);
        for (i = 0; i < 12; i++)
        {
            printf(" 0x%2x ", pMsg[i]);
        }
        printf("\n");
    }

    return rc;
}

int32_t ModbusClose(uintptr_t ctx)
{
    modbus_priv_t *pCtx = (modbus_priv_t*)ctx;
    int32_t ret = 0;
    if (pCtx == NULL || ctx == INVALID_VALUE)
    {
        printf("%s,Invalid Input Parameters.\n",__FUNCTION__);
        return -1;
    }

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s fd:%d.\n", __FUNCTION__, pCtx->s);

    if (pCtx->backend != NULL)
    {
        if (pCtx->backend->backend_type == MODBUS_BACKEND_TYPE_TCP)
        {
            ret = ModbusTcpClose(pCtx);
            ModbusDestroyTcp(pCtx);
        }
        else if(pCtx->backend->backend_type == MODBUS_BACKEND_TYPE_RTU)
        {
            ModbusRtuClose(pCtx);
            ModbusDestroyRtu(pCtx);
        }
    }

    if (ret != 0)
        EMS_LOG(LL_ERROR, MODULE_MODBUS, FALSE, "ModbusClose ret:%d, err:%s\n", ret, ModbusStrError(errno));

    //free(pCtx->backend_data);
    free(pCtx);
    //pCtx->backend_data = NULL;
    pCtx = NULL;

    return ret;
}

int32_t ModbusSet(uintptr_t ctx, SET_TYPE_E eType, void* pTypeData)
{
    modbus_priv_t *pCtx = (modbus_priv_t*)ctx;
    if (pCtx == NULL || ctx == INVALID_VALUE)
    {
        printf("%s,Invalid Input Parameters.\n", __FUNCTION__);
        return -1;
    }

    EMS_LOG(LL_INFO, MODULE_MODBUS, FALSE, "%s type:%d.\n", __FUNCTION__, eType);

    if (pCtx->backend != NULL)
    {
        pCtx->backend->Set(pCtx, eType, pTypeData);
    }

    return 0;
}

/*****************************************************     for test         *****************************************/

/* Allocates 4 arrays to store bits, input bits, registers and inputs
   registers. The pointers are stored in modbus_mapping structure.

   The ModbusMappingNew() function shall return the new allocated structure if
   successful. Otherwise it shall return NULL and set errno to ENOMEM. */
MODBUS_MAPPING_T* ModbusMappingNew(int nb_bits, int nb_input_bits,
                                     int nb_registers, int nb_input_registers)
{
    MODBUS_MAPPING_T *mb_mapping;

    mb_mapping = (MODBUS_MAPPING_T *)malloc(sizeof(MODBUS_MAPPING_T));
    if (mb_mapping == NULL) {
        return NULL;
    }

    /* 0X */
    mb_mapping->nb_bits = nb_bits;
    if (nb_bits == 0) {
        mb_mapping->tab_bits = NULL;
    } else {
        /* Negative number raises a POSIX error */
        mb_mapping->tab_bits =
            (uint8_t *) malloc(nb_bits * sizeof(uint8_t));
        if (mb_mapping->tab_bits == NULL) {
            free(mb_mapping);
            return NULL;
        }
        memset(mb_mapping->tab_bits, 0xFF, nb_bits * sizeof(uint8_t));
    }

    /* 1X */
    mb_mapping->nb_input_bits = nb_input_bits;
    if (nb_input_bits == 0) {
        mb_mapping->tab_input_bits = NULL;
    } else {
        mb_mapping->tab_input_bits =
            (uint8_t *) malloc(nb_input_bits * sizeof(uint8_t));
        if (mb_mapping->tab_input_bits == NULL) {
            free(mb_mapping->tab_bits);
            free(mb_mapping);
            return NULL;
        }
        memset(mb_mapping->tab_input_bits, 0XFF, nb_input_bits * sizeof(uint8_t));
    }

    /* 4X */
    mb_mapping->nb_registers = nb_registers;
    if (nb_registers == 0) {
        mb_mapping->tab_registers = NULL;
    } else {
        mb_mapping->tab_registers =
            (uint16_t *) malloc(nb_registers * sizeof(uint16_t));
        if (mb_mapping->tab_registers == NULL) {
            free(mb_mapping->tab_input_bits);
            free(mb_mapping->tab_bits);
            free(mb_mapping);
            return NULL;
        }
        memset(mb_mapping->tab_registers, 0XFF, nb_registers * sizeof(uint16_t));
    }

    /* 3X */
    mb_mapping->nb_input_registers = nb_input_registers;
    if (nb_input_registers == 0) {
        mb_mapping->tab_input_registers = NULL;
    } else {
        mb_mapping->tab_input_registers =
            (uint16_t *) malloc(nb_input_registers * sizeof(uint16_t));
        if (mb_mapping->tab_input_registers == NULL) {
            free(mb_mapping->tab_registers);
            free(mb_mapping->tab_input_bits);
            free(mb_mapping->tab_bits);
            free(mb_mapping);
            return NULL;
        }
        memset(mb_mapping->tab_input_registers, 0XFF,
               nb_input_registers * sizeof(uint16_t));
    }

    return mb_mapping;
}

/* Frees the 4 arrays */
void ModbusMappingFree(MODBUS_MAPPING_T *mb_mapping)
{
    if (mb_mapping == NULL) {
        return;
    }

    free(mb_mapping->tab_input_registers);
    free(mb_mapping->tab_registers);
    free(mb_mapping->tab_input_bits);
    free(mb_mapping->tab_bits);
    free(mb_mapping);
}

/* Sets many bits from a table of bytes (only the bits between index and
   index + nb_bits are set) */
void ModbusSetBitsFromBytes(uint8_t *dest, int index, unsigned int nb_bits,
                                const uint8_t *tab_byte)
{
    unsigned int i;
    int shift = 0;

    for (i = index; i < index + nb_bits; i++) {
        dest[i] = tab_byte[(i - index) / 8] & (1 << shift) ? 1 : 0;
        /* gcc doesn't like: shift = (++shift) % 8; */
        shift++;
        shift %= 8;
    }
}
#if 0
static int ResponseIOStatus(int address, int nb,
                              uint8_t *tab_io_status,
                              uint8_t *rsp, int offset)
{
    int shift = 0;
    int byte = 0;
    int i;

    for (i = address; i < address+nb; i++) {
        byte |= tab_io_status[i] << shift;
        if (shift == 7) {
            /* Byte is full */
            rsp[offset++] = byte;
            byte = shift = 0;
        } else {
            shift++;
        }
    }

    if (shift != 0)
        rsp[offset++] = byte;

    return offset;
}

/* Build the exception response */
static int ResponseException(modbus_priv_t *ctx, SFT_T *sft,
                              int32_t exception_code, uint8_t *rsp)
{
    int rsp_length;

    sft->function = sft->function + 0x80;
    rsp_length = ctx->backend->BuildResponseBasis(sft, rsp);

    /* Positive exception code */
    rsp[rsp_length++] = exception_code;

    return rsp_length;
}

/* Send a response to the received request.
   Analyses the request and constructs a response.

   If an error occurs, this function construct the response
   accordingly.
*/
int32_t ModbusReply(uintptr_t ctx, const uint8_t *req, int32_t req_length, MODBUS_MAPPING_T *mb_mapping)
{
    modbus_priv_t *pCtx = (modbus_priv_t*)ctx;
    if (pCtx == NULL)
    {
        printf("%s,Invalid Input Parameters.\n",__FUNCTION__);
        return -1;
    }

    int32_t offset = pCtx->backend->header_length;
    int32_t slave = req[offset - 1];
    int32_t function = req[offset];
    uint16_t address = (req[offset + 1] << 8) + req[offset + 2];
    uint8_t rsp[MODBUS_TCP_MAX_ADU_LENGTH];
    int32_t rsp_length = 0;
    SFT_T sft;
    int k;

    sft.slave = slave;
    sft.function = function;
    sft.t_id = pCtx->backend->PrepareResponseTid(req, &req_length);

    switch (function) {
    case ReadCoilStatus: {
        int nb = (req[offset + 3] << 8) + req[offset + 4];

        if (nb < 1 || MODBUS_MAX_READ_BITS < nb) {
            if (pCtx->debug) {
                fprintf(stderr,
                        "Illegal nb of values %d in read_bits (max %d)\n",
                        nb, MODBUS_MAX_READ_BITS);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE, rsp);
        } else if ((address + nb) > mb_mapping->nb_bits) {
            if (pCtx->debug) {
                fprintf(stderr, "Illegal data address %0X in read_bits\n",
                        address + nb);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS, rsp);
        } else {
            rsp_length = pCtx->backend->BuildResponseBasis(&sft, rsp);
            rsp[rsp_length++] = (nb / 8) + ((nb % 8) ? 1 : 0);
            rsp_length = ResponseIOStatus(address, nb,
                                            mb_mapping->tab_bits,
                                            rsp, rsp_length);
        }
    }
        break;
    case ReadInputStatus: {
        /* Similar to coil status (but too many arguments to use a
         * function) */
        int nb = (req[offset + 3] << 8) + req[offset + 4];

        if (nb < 1 || MODBUS_MAX_READ_BITS < nb) {
            if (pCtx->debug) {
                fprintf(stderr,
                        "Illegal nb of values %d in read_input_bits (max %d)\n",
                        nb, MODBUS_MAX_READ_BITS);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE, rsp);
        } else if ((address + nb) > mb_mapping->nb_input_bits) {
            if (pCtx->debug) {
                fprintf(stderr, "Illegal data address %0X in read_input_bits\n",
                        address + nb);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS, rsp);
        } else {
            rsp_length = pCtx->backend->BuildResponseBasis(&sft, rsp);
            rsp[rsp_length++] = (nb / 8) + ((nb % 8) ? 1 : 0);
            rsp_length = ResponseIOStatus(address, nb,
                                            mb_mapping->tab_input_bits,
                                            rsp, rsp_length);
        }
    }
        break;
    case ReadHoldingRegister: {
        int nb = (req[offset + 3] << 8) + req[offset + 4];

        if (nb < 1 || MODBUS_MAX_READ_REGISTERS < nb) {
            if (pCtx->debug) {
                fprintf(stderr,
                        "Illegal nb of values %d in read_holding_registers (max %d)\n",
                        nb, MODBUS_MAX_READ_REGISTERS);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE, rsp);
        } else if ((address + nb) > mb_mapping->nb_registers) {
            if (pCtx->debug) {
                fprintf(stderr, "Illegal data address %0X in read_registers\n",
                        address + nb);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS, rsp);
        } else {
            int i;

            rsp_length = pCtx->backend->BuildResponseBasis(&sft, rsp);
            rsp[rsp_length++] = nb << 1;
            for (i = address; i < address + nb; i++) {
                rsp[rsp_length++] = mb_mapping->tab_registers[i] >> 8;
                rsp[rsp_length++] = mb_mapping->tab_registers[i] & 0xFF;
            }
        }
    }
        break;
    case ReadInputRegister: {
        /* Similar to holding registers (but too many arguments to use a
         * function) */
        int nb = (req[offset + 3] << 8) + req[offset + 4];

        if (nb < 1 || MODBUS_MAX_READ_REGISTERS < nb) {
            if (pCtx->debug) {
                fprintf(stderr,
                        "Illegal number of values %d in read_input_registers (max %d)\n",
                        nb, MODBUS_MAX_READ_REGISTERS);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE, rsp);
        } else if ((address + nb) > mb_mapping->nb_input_registers) {
            if (pCtx->debug) {
                fprintf(stderr, "Illegal data address %0X in read_input_registers\n",
                        address + nb);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS, rsp);
        } else {
            int i;

            rsp_length = pCtx->backend->BuildResponseBasis(&sft, rsp);
            rsp[rsp_length++] = nb << 1;
            for (i = address; i < address + nb; i++) {
                rsp[rsp_length++] = mb_mapping->tab_input_registers[i] >> 8;
                rsp[rsp_length++] = mb_mapping->tab_input_registers[i] & 0xFF;
            }
        }
    }
        break;
    case WriteSingleCoil:
        if (address >= mb_mapping->nb_bits) {
            if (pCtx->debug) {
                fprintf(stderr, "Illegal data address %0X in write_bit\n",
                        address);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS, rsp);
        } else {
            int data = (req[offset + 3] << 8) + req[offset + 4];

            if (data == 0xFF00 || data == 0x0) {
                mb_mapping->tab_bits[address] = (data) ? 1 : 0;
                memcpy(rsp, req, req_length);
                rsp_length = req_length;
            } else {
                if (pCtx->debug) {
                    fprintf(stderr,
                            "Illegal data value %0X in write_bit request at address %0X\n",
                            data, address);
                }
                rsp_length = ResponseException(
                    pCtx, &sft,
                    MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE, rsp);
            }
        }
        break;
    case WriteSingleRegister:
        if (address >= mb_mapping->nb_registers) {
            if (pCtx->debug) {
                fprintf(stderr, "Illegal data address %0X in write_register\n",
                        address);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS, rsp);
        } else {
            int data = (req[offset + 3] << 8) + req[offset + 4];

            mb_mapping->tab_registers[address] = data;
            memcpy(rsp, req, req_length);
            rsp_length = req_length;
        }
        break;
    case WriteMultipleCoil: {
        int nb = (req[offset + 3] << 8) + req[offset + 4];
        int nb_bits = req[offset + 5];

        if (nb < 1 || MODBUS_MAX_WRITE_BITS < nb || nb_bits * 8 < nb) {
            if (pCtx->debug) {
                fprintf(stderr,
                        "Illegal number of values %d in write_bits (max %d)\n",
                        nb, MODBUS_MAX_WRITE_BITS);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE, rsp);
        } else if ((address + nb) > mb_mapping->nb_bits ) {
            if (pCtx->debug) {
                fprintf(stderr, "Illegal data address %0X in write_bits\n",
                        address + nb);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS, rsp);
        } else {
            /* 6 = byte count */
            ModbusSetBitsFromBytes(mb_mapping->tab_bits, address, nb, &req[offset + 6]);

            rsp_length = pCtx->backend->BuildResponseBasis(&sft, rsp);
            /* 4 to copy the bit address (2) and the quantity of bits */
            memcpy(rsp + rsp_length, req + rsp_length, 4);
            rsp_length += 4;
        }
    }
        break;
    case WriteMultipleRegister: {
        int nb = (req[offset + 3] << 8) + req[offset + 4];
        int nb_bytes = req[offset + 5];

        if (nb < 1 || MODBUS_MAX_WRITE_REGISTERS < nb || nb_bytes != 2 * nb) {
            if (pCtx->debug) {
                fprintf(stderr,
                        "Illegal number of values %d in write_registers (max %d)\n",
                        nb, MODBUS_MAX_WRITE_REGISTERS);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE, rsp);
        } else if ((address + nb) > mb_mapping->nb_registers) {
            if (pCtx->debug) {
                fprintf(stderr, "Illegal data address %0X in write_registers\n",
                        address + nb);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS, rsp);
        } else {
            int i, j;
            for (i = address, j = 6; i < address + nb; i++, j += 2) {
                /* 6 and 7 = first value */
                mb_mapping->tab_registers[i] =
                    (req[offset + j] << 8) + req[offset + j + 1];
            }

            rsp_length = pCtx->backend->BuildResponseBasis(&sft, rsp);
            /* 4 to copy the address (2) and the no. of registers */
            memcpy(rsp + rsp_length, req + rsp_length, 4);
            rsp_length += 4;
        }
    }
        break;

    case ReadWriteMultiRegister: {
        int nb = (req[offset + 3] << 8) + req[offset + 4];
        uint16_t address_write = (req[offset + 5] << 8) + req[offset + 6];
        int nb_write = (req[offset + 7] << 8) + req[offset + 8];
        int nb_write_bytes = req[offset + 9];

        if (nb_write < 1 || MODBUS_MAX_RW_WRITE_REGISTERS < nb_write ||
            nb < 1 || MODBUS_MAX_READ_REGISTERS < nb ||
            nb_write_bytes != nb_write * 2) {
            if (pCtx->debug) {
                fprintf(stderr,
                        "Illegal nb of values (W%d, R%d) in write_and_read_registers (max W%d, R%d)\n",
                        nb_write, nb,
                        MODBUS_MAX_RW_WRITE_REGISTERS, MODBUS_MAX_READ_REGISTERS);
            }
            rsp_length = ResponseException(
                pCtx, &sft,
                MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE, rsp);
        } else if ((address + nb) > mb_mapping->nb_registers ||
                   (address_write + nb_write) > mb_mapping->nb_registers) {
            if (pCtx->debug) {
                fprintf(stderr,
                        "Illegal data read address %0X or write address %0X write_and_read_registers\n",
                        address + nb, address_write + nb_write);
            }
            rsp_length = ResponseException(pCtx, &sft,
                                            MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS, rsp);
        } else {
            int i, j;
            rsp_length = pCtx->backend->BuildResponseBasis(&sft, rsp);
            rsp[rsp_length++] = nb << 1;

            /* Write first.
               10 and 11 are the offset of the first values to write */
            for (i = address_write, j = 10; i < address_write + nb_write; i++, j += 2) {
                mb_mapping->tab_registers[i] =
                    (req[offset + j] << 8) + req[offset + j + 1];
            }

            /* and read the data for the response */
            for (i = address; i < address + nb; i++) {
                rsp[rsp_length++] = mb_mapping->tab_registers[i] >> 8;
                rsp[rsp_length++] = mb_mapping->tab_registers[i] & 0xFF;
            }
        }
    }
        break;

    default:
        rsp_length = ResponseException(pCtx, &sft,
                                        MODBUS_EXCEPTION_ILLEGAL_FUNCTION,
                                        rsp);
        break;
    }

    rsp_length = pCtx->backend->SendMsgPre(rsp, rsp_length);

    if (pCtx->debug)
    {
        printf("%s rsp_length:%d \n", __FUNCTION__, rsp_length);
        for (k = 0; k < rsp_length; k++)
        {
            printf(" 0x%2x ", rsp[k]);
        }
        printf("\n");
    }

    return ModbusTcpSend(pCtx, rsp, rsp_length);
}
#endif

int32_t ModbusReply(uintptr_t ctx, const uint8_t *resp, int32_t respLen)
{
    int32_t ret = 0;

    modbus_priv_t *pCtx = (modbus_priv_t*)ctx;
    if (pCtx == NULL || resp == NULL || ctx == INVALID_VALUE)
    {
        printf("%s,Invalid Input Parameters.\n", __FUNCTION__);
        return -1;
    }

    ret = pCtx->backend->Reply(pCtx, (uint8_t*)resp, respLen);

    return ret;
}
