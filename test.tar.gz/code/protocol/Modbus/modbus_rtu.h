/*
 * Copyright © 2001-2011 Stéphane Raimbault <stephane.raimbault@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

#ifndef _MODBUS_RTU_H_
#define _MODBUS_RTU_H_

#include <stdint.h>
#include <termios.h>
#include "modbus.h"
#include "slist.h"

/* Modbus_Application_Protocol_V1_1b.pdf Chapter 4 Section 1 Page 5
 * RS232 / RS485 ADU = 253 bytes + slave (1 byte) + CRC (2 bytes) = 256 bytes
 */
#define MODBUS_RTU_MAX_ADU_LENGTH  256
#define MODBUS_RTU_HEADER_LENGTH      1
#define MODBUS_RTU_PRESET_REQ_LENGTH  6
#define _MODBUS_RTU_PRESET_RSP_LENGTH  2
#define MODBUS_RTU_CHECKSUM_LENGTH    2
#define MODBUS_RTU_RS232 0
#define MODBUS_RTU_RS485 1
#define MAXQUEUES  100

typedef enum {
    _STEP_FUNCTION,
    _STEP_META,
    _STEP_DATA
} _step_t;

typedef enum
{
    RTU_STATE_CLOSE = 0x00,
    RTU_STATE_ONLINE,
    RTU_STATE_OFFLINE
}RTU_STATE_E;

/* ModbusTCP 数据帧 = 报文头MBAP + 帧结构PDU
 * 帧结构PDU = 功能码 + 数据
 */
typedef struct
{
    /*MBAP*/
    uint16_t transcation_meta_id; /* 事物元标识符 */
    uint16_t protocol_type; /* 协议标识符，0=MODBUS协议 */
    uint16_t len; /* 下一个域的字节数，包括单元标识符和数据域 */
    uint8_t unit_id; /* 单元标识符 */

    /*PDU*/
    uint8_t func_code; /* 功能码 */
    uint16_t register_addr; /* 寄存器地址 */
    uint16_t register_num; /* 寄存器数量 */
    uint8_t data[256];  /* 数据 */
}MODBUS_RTU_ADU_T;

typedef struct
{
    MODBUS_RTU_ADU_T stAdu;
    uint16_t uAduLen;
    uint16_t retry_time;  /* 重传次数 */
    uint32_t timeout;
    BOOL isSended; /*sended or not*/
    struct timeval tStartSend;
}MODBUS_RTU_CMD_T;

typedef struct _modbus_rtu {
    /* Device: "/dev/ttyS0", "/dev/ttyUSB0" or "/dev/tty.USA19*" on Mac OS X for
       KeySpan USB<->Serial adapters this string had to be made bigger on OS X
       as the directory+file name was bigger than 19 bytes. Making it 67 bytes
       for now, but OS X does support 256 byte file names. May become a problem
       in the future. */
    uint32_t uartId;
    /* Bauds: 9600, 19200, 57600, 115200, etc */
    int baud;
    /* Data bit */
    uint8_t data_bit;
    /* Stop bit */
    char *stop_bit;
    /* Parity: 'N', 'O', 'E' */
    char parity;
    /* Save old termios settings */
    struct termios old_tios;
    int serial_mode; /* TIOCSRS485 */

    RTU_STATE_E RTU_state;

    pthread_mutex_t mLock;

} modbus_rtu_t;

int32_t ModbusNewRtu(modbus_priv_t *ctx, uint32_t uartId, int baud, char parity, int data_bit, char *stop_bit);
int ModbusSetSlave(modbus_priv_t *ctx, int slave);
int32_t ModbusRtuConnect(modbus_priv_t *ctx);
int32_t ModbusDestroyRtu(modbus_priv_t *ctx);
int ModbusRtuSetSerialMode(modbus_priv_t *ctx, int mode);
int modbus_rtu_get_serial_mode(modbus_priv_t *ctx);
int ModbusRtuBuildRequestBasis(modbus_priv_t *ctx, uint8_t unit_id,int function, int addr,int nb, uint8_t *req);
int ModbusRtuSendMsgPre(uint8_t *req, int req_length);
ssize_t ModbusRtuSend(modbus_priv_t *ctx, const uint8_t *req, int req_length);
void ModbusRtuClose(modbus_priv_t *ctx);
int ModbusRtuSelect(modbus_priv_t *ctx, fd_set *rfds,struct timeval *tv, int length_to_read);
ssize_t ModbusRtuRecv(modbus_priv_t *ctx, uint8_t *rsp, int rsp_length);

#endif /* _MODBUS_RTU_H_ */
