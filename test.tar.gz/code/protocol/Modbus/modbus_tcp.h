#ifndef MODBUS_TCP_H_INCLUDED
#define MODBUS_TCP_H_INCLUDED

#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include "modbus.h"
#include "slist.h"

/* Modbus_Application_Protocol_V1_1b.pdf Chapter 4 Section 1 Page 5
 * TCP MODBUS ADU = 253 bytes + MBAP (7 bytes) = 260 bytes
 */
#define MODBUS_TCP_MAX_ADU_LENGTH  260

#define MAXTRANSACTIONID  65535
#define RETRYTIME  4

#define MODBUS_TCP_HEADER_LENGTH      7
#define MODBUS_TCP_PRESET_REQ_LENGTH 12
#define MODBUS_TCP_PRESET_RSP_LENGTH  8

#define MODBUS_TCP_CHECKSUM_LENGTH    0

#define MSG_LENGTH_UNDEFINED (-1)

typedef enum
{
    TCP_STATE_CLOSE = 0x00,
    TCP_STATE_ONLINE,
    TCP_STATE_OFFLINE
}TCP_STATE_E;

/* ModbusTCP 数据帧 = 报文头MBAP + 帧结构PDU
 * 帧结构PDU = 功能码 + 数据
 */
typedef struct
{
    /*MBAP*/
    uint16_t transcation_meta_id; /* 事物元标识符 */
    uint16_t protocol_type; /* 协议标识符，0=MODBUS协议 */
    uint16_t len; /* 下一个域的字节数，包括单元标识符和数据域 */
    uint8_t unit_id; /* 单元标识符 */

    /*PDU*/
    uint8_t func_code; /* 功能码 */
    uint16_t register_addr; /* 寄存器地址 */
    uint16_t register_num; /* 寄存器数量 */
    uint8_t data[256];  /* 数据 */
}MODBUS_TCP_ADU_T;

typedef struct
{
    MODBUS_TCP_ADU_T stAdu;
    uint16_t uAduLen;
    uint16_t retry_time;  /* 重传次数 */
    uint32_t timeout;
    BOOL isSended; /*sended or not*/
    struct timeval tStartSend;
    PACKET_TYPE_E ePacketType;
}MODBUS_TCP_CMD_T;

typedef struct
{
    int32_t port;    /* TCP port */
    char ip[16];    /* IP address */
    SLIST_T cmdList;
    SLIST_T recvList;
    pthread_t pid;
    TCP_STATE_E tcp_state;
    BOOL run;
    uint32_t heartBeat; /* ms */
    BOOL isFirstHeart;
    MODBUS_TCP_CMD_T heartData;
    MODBUS_TCP_CMD_T* pCurCmd;
    pthread_mutex_t mLock;
    BOOL debug;
} MODBUS_TCP_T;

int32_t ModbusNewTcp(modbus_priv_t *ctx, const char *ip, int32_t port);
int32_t ModbusDestroyTcp(modbus_priv_t *pCtx);

int32_t ModbusTcpConnect(modbus_priv_t *ctx);
int32_t ModbusTcpClose(modbus_priv_t *ctx);

int32_t ModbusTcpListen(modbus_priv_t *ctx, int32_t nb_connection);
int32_t ModbusTcpAccept(modbus_priv_t *ctx, int32_t *socket);
ssize_t ModbusTcpSend(modbus_priv_t *ctx, const uint8_t *req, int32_t req_length);

#endif // MODBUS_TCP_H_INCLUDED
