/*
 * Copyright © 2008-2010 Stéphane Raimbault <stephane.raimbault@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "modbus.h"
#include "modbus_tcp.h"

#if 0
int main()
{
    int32_t rc = 0;
    MODBUS_MAPPING_T *mb_mapping;

    START_INFO_T start_info;
    char c[] = "127.0.0.1";
    //char c[] = "192.168.27.17";

    strncpy(start_info.sIp, c, sizeof(c));
    start_info.iPort = 1502;
    start_info.type = MODBUS_BACKEND_TYPE_TCP;
    start_info.slave = 1;

    printf("start_info.sIp:%s \n", start_info.sIp);
    uintptr_t fd = ModbusOpen(start_info);

    mb_mapping = ModbusMappingNew(MODBUS_MAX_READ_BITS, MODBUS_MAX_READ_BITS,
                                    MODBUS_MAX_READ_REGISTERS, MODBUS_MAX_READ_REGISTERS);
    if (mb_mapping == NULL) {
        fprintf(stderr, "Failed to allocate the mapping: %s\n",
                ModbusStrError(errno));
        ModbusClose(fd);
        return -1;
    }

    for(;;) {
        uint8_t query[MODBUS_TCP_MAX_ADU_LENGTH];

        rc = ModbusRecv(fd, query);
        if (rc >= 0) {
            rc = ModbusReply(fd, query, rc, mb_mapping);
            if (rc < 0)
            {
                printf("%s rc:%d (L%d)\n", __func__, rc, __LINE__);
                break;
            }
        } else {
            /* Connection closed by the client */
            printf("%s rc:%d\n", __func__, rc);
            break;
        }

        sleep(1);
    }

    printf("Quit the loop: %s\n", ModbusStrError(errno));

    ModbusMappingFree(mb_mapping);
    ModbusClose(fd);

    printf("main done.\n");

    return 0;
}
#endif

