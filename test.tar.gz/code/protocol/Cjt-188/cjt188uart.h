#ifndef CJT188UART_H_INCLUDED
#define CJT188UART_H_INCLUDED

#include "stdint.h"
#include <stdio.h>
#include <unistd.h> //配置串口通用头文件
#include <termios.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <asm-generic/ioctls.h>
#include <sys/ioctl.h>
#include <string.h>
#include "protocol.h"
#include "modbus.h"

#define CTR_0_01 0x01 //??????
#define CTR_0_09 0x09 //??????

#define CTR_1_81 0x81//??????????
#define CTR_1_89 0x89 //??????????


#define CTR_2_C1 0xC1 //??????????


#define CTR_3_04 0x04 //??????
#define CTR_3_0C 0x0C //??????


#define CTR_4_84 0x84 //??????????
#define CTR_4_8C 0x8C //??????????


#define CTR_5_C4 0xC4 //??????????

typedef struct
{
    uint8_t type;//????
    uint16_t dataIdentify;//????
    uint8_t devAddr[7];//????
    int32_t fd;//????
    BOOL debug;
}CJT188_CTX_T;

uintptr_t Cjt188Open(START_INFO_T startinfo);
int32_t Cjt188Close (uintptr_t ctx);
uint8_t Cjt188DataCheck(uint8_t *buf, uint8_t buflen);
int32_t Cjt188Send(uintptr_t ctx, MODBUS_CMD_T *cmd_t);
int32_t Cjt188Recv(uintptr_t ctx, uint8_t *rsq);
int32_t Cjt188RespCheck(uintptr_t ctx, uint8_t *rsq, uint8_t length);

#endif
