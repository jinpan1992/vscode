#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include "cjt188uart.h"
#include "uart.h"
#include "time.h"
#include "sms4.h"

static struct termios termios_old;
static uint8_t g_SER = 0 ;//定义序列号


//Open串口(1-6)
uintptr_t Cjt188Open(START_INFO_T startinfo)
{
    CJT188_CTX_T *pCtx = (CJT188_CTX_T*)calloc(1, sizeof(CJT188_CTX_T));
	if (pCtx == NULL)
    {
        return INVALID_VALUE;
    }

    pCtx->fd = OpenComPort(startinfo.uartId,startinfo.baud,startinfo.data_bit, startinfo.stop_bit,startinfo.parity);
    pCtx->type = startinfo.metertype == 0 ? 0x27 : startinfo.metertype;
    pCtx->devAddr[0] = startinfo.devAddr[0];
    pCtx->devAddr[1] = startinfo.devAddr[1];
    pCtx->devAddr[2] = startinfo.devAddr[2];
    pCtx->devAddr[3] = startinfo.devAddr[3];
    pCtx->devAddr[4] = startinfo.devAddr[4];
    pCtx->devAddr[5] = startinfo.devAddr[5];
    pCtx->devAddr[6] = startinfo.devAddr[6];

    pCtx->debug = TRUE;

    return (pCtx == NULL) ? (INVALID_VALUE) : ((uintptr_t)pCtx);
}

/* close serial port by use of file descriptor fd */
int32_t Cjt188Close (uintptr_t ctx)
{
    /* flush output data before close and restore old attribute */
	CJT188_CTX_T *pCtx = (CJT188_CTX_T*)ctx;
    if (ctx == INVALID_VALUE || pCtx == NULL || pCtx->fd == INVALID_VALUE )
    {
        return INVALID_VALUE;
    }
    tcsetattr (pCtx->fd, TCSADRAIN, &termios_old);
    close (pCtx->fd);
	free(pCtx);

	return 0;
}

uint8_t Cjt188DataCheck(uint8_t *buf, uint8_t buflen)
{
    uint16_t sum = 0;
    uint8_t i = 0;

    for ( i = 0; i < buflen; i++)
    {
        sum = sum + buf[i];
    }

    while (sum > 0xFF)
    {
        sum = sum - 256;
    }

    return (sum & 0xFF);
}

int32_t Cjt188Send(uintptr_t ctx , MODBUS_CMD_T *cmd_t)
{

    uint16_t k = 0, i=0,j=0;
    int32_t writeLen;
    uint8_t req[256] = {0};
    CJT188_CTX_T *pCtx = (CJT188_CTX_T*)ctx;
    //SM4
    uint8_t buffer[256];
    uint8_t sms4len;
    time_t now;
    struct tm *timenow;
    //向量
    uint8_t iv[16] = {pCtx->type,pCtx->devAddr[0],pCtx->devAddr[1],pCtx->devAddr[2],pCtx->devAddr[3],pCtx->devAddr[4],pCtx->devAddr[5],pCtx->devAddr[6],0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55};
    //密钥
    uint8_t key[16] = {0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF,0xFE,0xDC,0xBA,0x98,0x76,0x54,0x32,0x10};
    sms4_key_t sms4_key_enc;
    unsigned char enc_text[256] = {0};

    if (ctx == INVALID_VALUE || pCtx == NULL)// || pCtx->fd == INVALID_VALUE )
    {
        return INVALID_VALUE;
    }
    req[k++] =  0xFE;
    req[k++] =  0xFE;
	req[k++] =  0x68;
	req[k++] =  pCtx->type;
	req[k++] =  pCtx->devAddr[0];
	req[k++] =  pCtx->devAddr[1];
	req[k++] =  pCtx->devAddr[2];
	req[k++] =  pCtx->devAddr[3];
	req[k++] =  pCtx->devAddr[4];
	req[k++] =  pCtx->devAddr[5];
	req[k++] =  pCtx->devAddr[6];
    req[k++] =  cmd_t->ctrlcmd;

    // if SM4
    if(cmd_t->ctrlcmd&0x8)
    {
        time(&now);
        timenow = localtime(&now);

        buffer[j++] = timenow->tm_sec;
        buffer[j++] = timenow->tm_min;
        buffer[j++] = timenow->tm_hour;
        buffer[j++] = timenow->tm_mday;
        buffer[j++] = timenow->tm_mon+1;
        buffer[j++] = timenow->tm_year-((timenow->tm_year)/100)*100;

        //test code
//         buffer[j++] = 0x07;
//         buffer[j++] = 0x06;
//         buffer[j++] = 0x12;
//         buffer[j++] = 0x01;
//         buffer[j++] = 0x02;
//         buffer[j++] = 0x20;

        // if write data
        if((cmd_t->ctrlcmd == CTR_3_04) || (cmd_t->ctrlcmd == CTR_3_0C))
        {
            while((cmd_t->buf_len)>0)
            {
                buffer[j++] =cmd_t->data[i++];
                cmd_t->buf_len--;
            }
        }
        memset(sms4_key_enc.rk, 0, sizeof(sms4_key_enc.rk));
        sms4_set_encrypt_key(&sms4_key_enc,key);
        sms4len=sms4_cbc_encrypt((const unsigned char*)buffer,enc_text,j,&sms4_key_enc,iv,1);
        //data len= 密文长度+3
        req[k++] = sms4len+3;
    }
    else
    {
        req[k++] = cmd_t->buf_len+3;
    }

    //数据标识符
    req[k++] = ((cmd_t->address) & 0xFF);
    req[k++] = ((cmd_t->address >> 8) & 0xFF);

    //序列号
	g_SER++;
    while (g_SER > 0xFF)
    {
        g_SER = g_SER - 256;
    }
	req[k++] = g_SER;

    // if SM4
    if(cmd_t->ctrlcmd&0x8)
    {
//         for(i = 0; i < sms4len; i++)
//         {
//             printf("enc_text[%d]=0x%x ", i,enc_text[i]);
//         }
//         printf("\n");
        //加密报文填充到发送报文中
        memcpy(req+k,enc_text,sms4len);
    }

    //校验码
    uint16_t len = k+sms4len;
	req[sms4len+k++] = Cjt188DataCheck(req+2, len-2);
    //结束符
	req[sms4len+k++] = 0x16;
    //数据标识符保存
    pCtx->dataIdentify =cmd_t->address;

    if (pCtx->debug)
    {
        for(i = 0; i < k + sms4len; i++)
        {
            printf("req[%d]=0x%x  ",i, req[i]);
        }
        printf("\n");
        printf("\n");
    }

    writeLen = write (pCtx->fd, req , k+sms4len);

    return writeLen;
}

//得到了一个完整的数据帧
int32_t Cjt188Recv(uintptr_t ctx , uint8_t *rsq)
{
    //SM4
    uint8_t plain_text[256];
    uint8_t enc_text[256];
    uint8_t sms4_decrypt_len;
    sms4_key_t sms4_key_decrypt;
    uint8_t iv[16] = {0x27,0x78,0x39,0x22,0x42,0x00,0x8F,0x41,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55};
    uint8_t key[16] = {0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF,0xFE,0xDC,0xBA,0x98,0x76,0x54,0x32,0x10};

    CJT188_CTX_T *pCtx = (CJT188_CTX_T*)ctx;
    if (ctx == INVALID_VALUE || pCtx == NULL || pCtx->fd == INVALID_VALUE )
    {

        return INVALID_VALUE;

    }

    int  size_i = 0,i = 0,j=0,k=0,inbit=1;
    uint8_t rsq_length = 0;
    uint8_t datalen = 0;
    uint32_t recverror = 0;

    while(1)
    {
        i = read(pCtx->fd, rsq + size_i, 300);
        if (i > 0)
        {
            size_i += i;

            if (size_i > 14)
            {
                //Count up 0xFE
                if(inbit==1)
                {
                    for(j=0;j<size_i;j++)
                    {
                        //printf("rsq1[%d]=0x%x ", j,rsq[j]);
                        if(rsq[j] == 0xFE)
                        {k++;}
                        if(rsq[j+1] == 0x68)
                        break;
                    }

                    inbit=0;
                }
                datalen = rsq[10+k];
            }
            else
            {
                continue ;//no test?
            }
            //接收到的数据总和=数据域长度+13（帧头+仪表类型+地址域+控制码+数据域长度字节+校验码+帧结束符）+前导字节
            //表示接受完成。
            if ((size_i == (datalen + 13 + k))&&(rsq[size_i-1]==0x16))
            {
                for(j=0;j<size_i-k;j++)
                {
                    rsq[j] = rsq[j+k];
                }

                size_i=size_i-k;
                recverror = 0;
                /*printf("size_i1 = %d\n",size_i);

                printf("rsq1=");
                for(i = 0; i < size_i; i++)
                {
                    printf("%x ",rsq[i]);
                }
                printf("\n");*/
                memset(sms4_key_decrypt.rk,0,sizeof(sms4_key_decrypt.rk));
                sms4_set_decrypt_key(&sms4_key_decrypt,key);
                if(rsq[9]&0x08)
                {
                    for(i = 0;i<rsq[10]-3;i++)
                    {
                        enc_text[i] = rsq[14+i];
                    }
                    sms4_decrypt_len = sms4_cbc_encrypt(enc_text,plain_text,rsq[10]-3,&sms4_key_decrypt,iv,0);
                    for(i = 0;i<sms4_decrypt_len;i++)
                    {
                        rsq[14+i] = plain_text[i];
                    }
                    rsq[10] = sms4_decrypt_len + 3;
                    rsq[13+sms4_decrypt_len+1] = Cjt188DataCheck(rsq,13+sms4_decrypt_len+1);
                    rsq[13+sms4_decrypt_len+2] = 0x16;
                    size_i = 16+sms4_decrypt_len;
                }

                rsq_length = size_i;

                if (pCtx->debug)
                {
                    printf("size_i2 = %d\n",size_i);
                    printf("rsq2=");
                    for(i = 0; i < size_i; i++)
                    {
                        printf("%x ",rsq[i]);
                    }
                    printf("\n");
                }

                return rsq_length;
            }
        }
        else if (size_i == 0)
        {
            recverror++;

            if((recverror % 300) == 0)
            {
                return -1;
            }
        }
    }
}

int32_t Cjt188RespCheck(uintptr_t ctx ,uint8_t *rsq,uint8_t length)
{
    CJT188_CTX_T *pCtx = (CJT188_CTX_T*)ctx;
    if (ctx == INVALID_VALUE || pCtx == NULL || pCtx->fd == INVALID_VALUE )
    {
        return INVALID_VALUE;
    }
    if(rsq[2] != pCtx->devAddr[0] ||
        rsq[3]!=pCtx->devAddr[1] ||
        rsq[4]!=pCtx->devAddr[2] ||
        rsq[5]!=pCtx->devAddr[3] ||
        rsq[6]!=pCtx->devAddr[4] ||
        rsq[7]!=pCtx->devAddr[5] ||
        rsq[8]!=pCtx->devAddr[6]
    )
    {
        printf("devAddr ERROR\n");
        return -1;
    }
	if(rsq[13] != g_SER)
	{
        printf("SER ERROR g_SER:%d rsq:%d\n", g_SER, rsq[13]);
// 		return -1;
	}
	if(rsq[11]!=((pCtx->dataIdentify) & 0xFF)||rsq[12]!=((pCtx->dataIdentify >> 8) & 0xFF))
	{
        printf("dataIdentify ERROR\n");
		return -1;
	}

	if((Cjt188DataCheck(rsq,length-2))!=rsq[length-2])
	{
        printf("(Cjt188DataCheck(rsq,length-2)=%x  rsq[length-2]= %x\n",Cjt188DataCheck(rsq,length-2),rsq[length-2]);
        printf("Cjt188DataCheck ERROR\n");
		return -1;
	}
	if(rsq[9]==CTR_2_C1||rsq[9]==CTR_5_C4)
	{
        printf("CTR ERROR\n");
		return -1;
	}
	return 0;
}
