#ifndef _IEC_SLAVE_SERVICE_H_
#define _IEC_SLAVE_SERVICE_H_

#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "cs104_slave.h"
#include "hal_thread.h"
#include "hal_time.h"
#include "lib_memory.h"
#include "iec_slave_config.h"
#include "sdb.h"
#include "iec_mapping_sqlite_db.h"

#define IEC_SLAVE_SERVICE_TICK_MS   50
#define IEC_SLAVE_SERVICE_YC_UPLOAD_PERIOD_IN_MS  5000
#define YC_PATTERN (1 << 3)
#define YX_PATTERN (1 << 2)
#define YT_PATTERN (1 << 1)
#define YK_PATTERN (1 << 0)

#define USE_DEFAULT_IEC104_MAPPING_TABLE 0

#define TYPE_YX 1  // 遥信
#define TYPE_YC 2  // 遥测
#define TYPE_YK 3  // 遥控
#define TYPE_YT 4  // 遥调




#define DEVICE_SEQUENCE \
{ \
    {.deviceCode = 2304, .index = 1}, \
    {.deviceCode = 60000, .index = 1}, \
    {.deviceCode = 60001, .index = 1}, \
    {.deviceCode = 60003, .index = 1}, \
}

typedef struct
{
    uint16_t deviceCode; /* 设备类型编码 */
    uint16_t index;      /* 同类设备下第几台 */
}DEV_NODE_T;

//#define USE_DEFAULT_TABLE

#define DEBUGPRINT 1

typedef struct _IEC104SlaveConfig
{
    uint16_t yx_minAddr;
    uint16_t yx_maxAddr;
    uint16_t yc_minAddr;
    uint16_t yc_maxAddr;
    uint16_t yk_minAddr;
    uint16_t yk_maxAddr;
    uint16_t yt_minAddr;
    uint16_t yt_maxAddr;
    uint16_t ym_minAddr;
    uint16_t ym_maxAddr;

    uint32_t port;
    const char *allowLinkIp;
}IEC104SlaveConfig;


typedef struct _YXPoint
{
    uint16_t dataId;     /* 测点编码 */
    uint16_t deviceCode; /* 设备类型编码 */
    uint16_t index;      /* 同类设备下索引 */
    uint16_t iecAddr;
    int32_t dataLen;
    bool bitValue;
	int8_t bitOffset;
    int32_t valMin;
    int32_t valMax;
    uint32_t registerAddr;
    char pointName[POINT_NAME_MAX_LEN];
}YXPoint;

typedef struct _YXCSPoint
{
	bool bitValue;
	uint16_t iecAddr;
}YXCSPoint;

typedef struct _YCPoint
{
    uint16_t dataId;     /* 测点编码 */
    uint16_t deviceCode; /* 设备类型编码 */
    uint16_t index;      /* 同类设备下索引 */
    uint16_t iecAddr;
    int32_t dataLen;
    int32_t value;
    int32_t valMin;
    int32_t valMax;
    uint32_t registerAddr;
    char pointName[POINT_NAME_MAX_LEN];
}YCPoint;

typedef struct _YCCSPoint
{
	int32_t value;
	uint16_t iecAddr;
}YCCSPoint;

typedef struct _YKPoint
{
    uint16_t dataId;     /* 测点编码 */
    uint16_t deviceCode; /* 设备类型编码 */
    uint16_t index;      /* 同类设备下索引 */
    uint16_t iecAddr;
    int32_t dataLen;
    bool bitValue;
	int8_t bitOffset;
    int32_t valMin;
    int32_t valMax;
    uint32_t registerAddr;
    char pointName[POINT_NAME_MAX_LEN];
}YKPoint;

typedef struct _YTPoint
{
    uint16_t dataId;     /* 测点编码 */
    uint16_t deviceCode; /* 设备类型编码 */
    uint16_t index;      /* 同类设备下索引 */
    uint16_t iecAddr;
    int32_t dataLen;
    int32_t value;
    int32_t valMin;
    int32_t valMax;
    uint32_t registerAddr;
    char pointName[POINT_NAME_MAX_LEN];
}YTPoint;

typedef struct _IEC104SlaveHandler
{
    CS104_Slave slave;
    sCS101_StaticASDU asdu;
	uint8_t ioBuf[250];
	CS101_AppLayerParameters alParams;

    IEC104SlaveConfig *config;

    YXPoint *YXPointTable;
    uint32_t YXStartAddr;
    uint32_t YXTotalNum;

    YCPoint *YCPointTable;
    uint32_t YCStartAddr;
    uint32_t YCTotalNum;

    YKPoint *YKPointTable;
    uint32_t YKStartAddr;
    uint32_t YKTotalNum;

    YTPoint *YTPointTable;
    uint32_t YTStartAddr;
    uint32_t YTTotalNum;

	bool *YXPointValueRecord;
	YXCSPoint *YXCSPointValue;     /* 遥信变位值 */
	uint32_t YXCSNum;              /* 遥信变位个数 */

	int32_t *YCPointValueRecord;
	YCCSPoint *YCCSPointValue;     /* 遥测变化值 */
	uint32_t YCCSNum;              /* 遥测变位个数 */

    int32_t (*ReadPointData)(void *dataOut, uint16_t deviceCode, uint16_t index, uint16_t dataId);
    int32_t (*WritePointData)(int32_t value, uint16_t deviceCode, uint16_t index, uint16_t dataId);

    Thread runTh;
    bool isRuning;
}IEC104SlaveHandler;

extern IEC104SlaveConfig SlaveConfigTable[];
/*
extern YXPoint YXPointTable[];
extern YCPoint YCPointTable[];
extern YKPoint YKPointTable[];
extern YTPoint YTPointTable[];
*/
/**
 * IECSlaveService_Init: 可根据传入的不同配置参数初始化IEC104 slave 服务
 * @Config: 相关配置参数，包括端口号，允许客户端的IP地址等
 * 返回IEC104 slave服务句柄指针
 */
IEC104SlaveHandler *IECSlaveService_Init(IEC104SlaveConfig *config);

/**
 * IEC104SlaveService_Destroy: IEC104 slave 服务相关内存释放
 * @slaveHandler: 相关配置参数，包括端口号，允许客户端的IP地址等
 *
 */
void IEC104SlaveService_Destroy(IEC104SlaveHandler *slaveHandler);

/**
 * IEC104SlaveService_YXUploadChangeSignal: IEC104 slave 遥信数据变位上传
 * @slaveHandler: IEC104 slave服务句柄指针
 * 注意遥信
 */
void IEC104SlaveService_YXUploadChangeSignal(IEC104SlaveHandler *slaveHandler);

/**
 * IEC104SlaveService_YCUploadChangeSigal: IEC104 slave 遥测数据变化上传
 * @slaveHandler: IEC104 slave服务句柄指针
 * 注意遥信
 */
void IEC104SlaveService_YCUploadChangeSigal(IEC104SlaveHandler *slaveHandler);

/**
 * IEC104SlaveService_YCUploadRemoteSignal: IEC104 slave 遥测数据定时上传
 * @slaveHandler: IEC104 slave服务句柄指针
 * 注意遥测数据统一采用浮点数遥测，不带时标
 */
void IEC104SlaveService_YCUploadRemoteSignal(IEC104SlaveHandler *slaveHandler);

/**
 * IEC104SlaveService_TickFunc: IEC104 slave 协议定时调用服务，
 * @slaveHandler: IEC104 slave服务句柄指针
 *
 */
void IEC104SlaveService_TickFunc(IEC104SlaveHandler *slaveHandler);


/**
 * IEC104AddrToRegisterAddr: 通过IEC104地址查询注册地址
 * @slaveHandler: IEC104 slave服务句柄指针
 *
 */
uint32_t IEC104AddrToRegisterAddr(IEC104SlaveHandler *slaveHandler,int);

/**
 * RegisterAddrToIEC104Addr: 通过注册地址和比特位查询IEC104地址
 * @slaveHandler: IEC104 slave服务句柄指针
 *
 */
int RegisterAddrToIEC104Addr(IEC104SlaveHandler *slaveHandler,int,int,int);


IEC104SlaveConfig *IEC104SlaveConfigInit(IEC104SlaveHandler *slaveHandler);



#endif
