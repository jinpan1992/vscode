
#include "iec_slave_service.h"
#include "transmit.h"
#include <sys/time.h>

IEC104SlaveConfig SlaveConfigTable[] = SLAVE_CONFIG_TABLE;

#ifdef USE_DEFAULT_TABLE
static YXPoint YXPointTable[] = YX_POINT_TABLE;
static YCPoint YCPointTable[] = YC_POINT_TABLE;
static YKPoint YKPointTable[] = YK_POINT_TABLE;
static YTPoint YTPointTable[] = YT_POINT_TABLE;
#endif


static float32_t recvCmdCount104 = 0.0;
static float32_t total_time104 = 0;
static struct timeval start_time104;
static struct timeval end_time104;

#define MAX_LOW_PRIO_QUEUE_SIZE 300
#define MAX_HIGH_PRIO_QUEUE_SIZE 300

static bool _GetYCData(IEC104SlaveHandler *slaveHandler);

static bool _WriteYKData(IEC104SlaveHandler *slaveHandler, uint16_t iecAddrCur, bool bitValue);

static bool _WriteYTData(IEC104SlaveHandler *slaveHandler, uint16_t iecAddrCur, int32_t value);

static bool _GetYXData(IEC104SlaveHandler *slaveHandler);

void printCP56Time2a(CP56Time2a time) {
    printf("%02i:%02i:%02i %02i/%02i/%04i", CP56Time2a_getHour(time),
           CP56Time2a_getMinute(time),
           CP56Time2a_getSecond(time),
           CP56Time2a_getDayOfMonth(time),
           CP56Time2a_getMonth(time),
           CP56Time2a_getYear(time) + 2000);
}

/* Callback handler to log sent or received messages (optional) */
/*static void rawMessageHandler(void* parameter, IMasterConnection conneciton, uint8_t* msg, int msgSize, bool sent)
{
    if (sent)
        printf("SEND: ");
    else
        printf("RCVD: ");

    int i;
    for (i = 0; i < msgSize; i++) {
        printf("%02x ", msg[i]);
    }

    printf("\n");
}*/

static bool clockSyncHandler(void *parameter, IMasterConnection connection, CS101_ASDU asdu, CP56Time2a newTime) {
    IEC104SlaveHandler *slaveHandler = (IEC104SlaveHandler *) parameter;

    printf("Process time sync command with time ");
    printCP56Time2a(newTime);
    printf("\n");

    slaveHandler->WritePointData(CP56Time2a_getYear(newTime) + 2000, 2304, 1, 70);
    slaveHandler->WritePointData(CP56Time2a_getMonth(newTime), 2304, 1, 71);
    slaveHandler->WritePointData(CP56Time2a_getDayOfMonth(newTime), 2304, 1, 72);
    slaveHandler->WritePointData(CP56Time2a_getHour(newTime), 2304, 1, 73);
    slaveHandler->WritePointData(CP56Time2a_getMinute(newTime), 2304, 1, 74);
    slaveHandler->WritePointData(CP56Time2a_getSecond(newTime), 2304, 1, 75);

    return true;
}


static bool interrogationHandler(void *parameter, IMasterConnection connection, CS101_ASDU asdu, uint8_t qoi) {
    //printf("Received interrogation for group %i\n", qoi);

    IEC104SlaveHandler *slaveHandler = (IEC104SlaveHandler *) parameter;

    if (qoi == 20) { /* only handle station interrogation */
        IMasterConnection_sendACT_CON(connection, asdu, false);

        /* -------------------总召唤遥测数据----------------------------------------- */
        if (!_GetYCData(slaveHandler)) {
            IMasterConnection_sendACT_TERM(connection, asdu); /* 结束总召唤 */
            return true;
        }

        CS101_ASDU newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, true,
                                                         CS101_COT_INTERROGATED_BY_STATION,
                                                         0, 1, false, false);
        int32_t i;
        /* 注意：信息体超过ASDU一次满载，需要多次发送，其中信息体最大字节为255-2-10 = 243 */
        for (i = 0; i < slaveHandler->YCTotalNum; i++) {
            InformationObject io = (InformationObject) MeasuredValueShort_create(
                    (MeasuredValueShort) &slaveHandler->ioBuf,
                    slaveHandler->YCPointTable[i].iecAddr,
                    slaveHandler->YCPointTable[i].value,
                    IEC60870_QUALITY_GOOD);
            /* 判断一次ASDU编码信息体载荷是否满载 */
            if (!CS101_ASDU_addInformationObject(newAsdu, io)) {
                /* ASDU 满载后先发送一次 */
                IMasterConnection_sendASDU(connection, newAsdu);
                /* 为剩余信息体重新初始化ASDU */
                newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, true,
                                                      CS101_COT_INTERROGATED_BY_STATION,
                                                      0, 1, false, false);
                /* 回退一次循环 */
                i -= 1;
            }
        }
        /* 发送最后一次ASDU */
        IMasterConnection_sendASDU(connection, newAsdu);

        /* -------------------总召唤遥信数据----------------------------------------- */
        if (!_GetYXData(slaveHandler)) {
            IMasterConnection_sendACT_TERM(connection, asdu); /* 结束总召唤 */
            return true;
        }
        /* 注意：遥信响应总召唤 信息体连续 */
        newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, true,
                                              CS101_COT_INTERROGATED_BY_STATION,
                                              0, 1, false, false);

        /* 注意：信息体超过ASDU一次满载，需要多次发送，其中信息体最大字节为255-2-10 = 243 */
        for (i = 0; i < slaveHandler->YXTotalNum; i++) {
            InformationObject io = (InformationObject) SinglePointInformation_create(
                    (SinglePointInformation) &slaveHandler->ioBuf,
                    slaveHandler->YXPointTable[i].iecAddr,
                    slaveHandler->YXPointTable[i].bitValue,
                    IEC60870_QUALITY_GOOD);
            /* 判断一次ASDU编码信息体载荷是否满载 */
            if (!CS101_ASDU_addInformationObject(newAsdu, io)) {
                /* ASDU 满载后先发送一次 */
                IMasterConnection_sendASDU(connection, newAsdu);
                /* 为剩余信息体重新初始化ASDU */
                newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, true,
                                                      CS101_COT_INTERROGATED_BY_STATION,
                                                      0, 1, false, false);
                /* 回退一次循环 */
                i -= 1;
            }
        }
        IMasterConnection_sendASDU(connection, newAsdu);
        /* ----------------数据传输完成，结束总召唤------------------------------ */
        IMasterConnection_sendACT_TERM(connection, asdu);
    } else {
        IMasterConnection_sendACT_CON(connection, asdu, true);
    }

    return true;
}

static bool asduHandler(void *parameter, IMasterConnection connection, CS101_ASDU asdu) {
    IEC104SlaveHandler *slaveHandler = (IEC104SlaveHandler *) parameter;

    if (CS101_ASDU_getTypeID(asdu) == C_SC_NA_1) {
        printf("received single command\n");

        if (CS101_ASDU_getCOT(asdu) == CS101_COT_ACTIVATION) {
            InformationObject io = CS101_ASDU_getElement(asdu, 0);
            uint16_t iecAddrCur = InformationObject_getObjectAddress(io);
            SingleCommand sc = (SingleCommand) io;
            bool bitValue = SingleCommand_getState(sc);

            if (_WriteYKData(slaveHandler, iecAddrCur, bitValue)) {
                CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
            } else {
                CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_IOA);
            }

            InformationObject_destroy(io);
        } else {
            CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_COT);
        }

        IMasterConnection_sendASDU(connection, asdu);

        return true;
    } else if (CS101_ASDU_getTypeID(asdu) == C_SE_NC_1) {
        printf("received float command\n");
        gettimeofday(&start_time104, NULL);
        printf("接受数据\n");

        if (CS101_ASDU_getCOT(asdu) == CS101_COT_ACTIVATION) {
            InformationObject io = CS101_ASDU_getElement(asdu, 0);
            uint16_t iecAddrCur = InformationObject_getObjectAddress(io);
            MeasuredValueShort mvs = (MeasuredValueShort) io;
            int32_t value = (int32_t) MeasuredValueShort_getValue(mvs);

            if (_WriteYTData(slaveHandler, iecAddrCur, value)) {
                CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
            } else {
                CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_IOA);
            }

            InformationObject_destroy(io);
        } else {
            CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_COT);
        }

        IMasterConnection_sendASDU(connection, asdu);
        recvCmdCount104++;
        if (recvCmdCount104 < 1000) {
            gettimeofday(&end_time104, NULL);
            float ms = end_time104.tv_sec * 1000000 + end_time104.tv_usec - start_time104.tv_sec * 1000000 -
                       start_time104.tv_usec;
            total_time104 = total_time104 + ms;
            printf("recvCmdCount104:%f,end_time104 tv_sec:%ld tv_usec:%ld, start_time104 tv_sec:%ld tv_usec:%ld, cost time104:%f us, total_time104 :%f.\n",
                   recvCmdCount104, end_time104.tv_sec, end_time104.tv_usec, start_time104.tv_sec,
                   start_time104.tv_usec, ms, total_time104);
        }
        return true;
    }

    return false;
}

static bool connectionRequestHandler(void *parameter, const char *ipAddress) {
    printf("New connection request from %s\n", ipAddress);

#if 0
    if (strcmp(ipAddress, "127.0.0.1") == 0) {
        printf("Accept connection\n");
        return true;
    }
    else {
        printf("Deny connection\n");
        return false;
    }
#else
    return true;
#endif
}

static void connectionEventHandler(void *parameter, IMasterConnection con, CS104_PeerConnectionEvent event) {
    if (event == CS104_CON_EVENT_CONNECTION_OPENED) {
        printf("Connection opened (%p)\n", con);
    } else if (event == CS104_CON_EVENT_CONNECTION_CLOSED) {
        printf("Connection closed (%p)\n", con);
    } else if (event == CS104_CON_EVENT_ACTIVATED) {
        printf("Connection activated (%p)\n", con);
    } else if (event == CS104_CON_EVENT_DEACTIVATED) {
        printf("Connection deactivated (%p)\n", con);
    }
}

static bool _GetYXData(IEC104SlaveHandler *slaveHandler) {
    slaveHandler->YXCSNum = 0;

    int32_t i;
    for (i = 0; i < slaveHandler->YXTotalNum; i++) {
        int32_t valueTemp;
        if (0 != slaveHandler->ReadPointData(&valueTemp,
                                             slaveHandler->YXPointTable[i].deviceCode,
                                             slaveHandler->YXPointTable[i].index,
                                             slaveHandler->YXPointTable[i].dataId)) {
            printf("invalid YX point deviceCode = %d index = %d dataId = %d\n",
                   slaveHandler->YXPointTable[i].deviceCode,
                   slaveHandler->YXPointTable[i].index,
                   slaveHandler->YXPointTable[i].dataId);
            return false;
        }

        slaveHandler->YXPointTable[i].bitValue = (bool) ((valueTemp >> slaveHandler->YXPointTable[i].bitOffset) & 0x01);

        if (slaveHandler->YXPointTable[i].bitValue != slaveHandler->YXPointValueRecord[i]) {
            slaveHandler->YXCSPointValue[slaveHandler->YXCSNum].bitValue = slaveHandler->YXPointTable[i].bitValue;
            slaveHandler->YXCSPointValue[slaveHandler->YXCSNum].iecAddr = slaveHandler->YXPointTable[i].iecAddr;
            slaveHandler->YXCSNum++;
            slaveHandler->YXPointValueRecord[i] = slaveHandler->YXPointTable[i].bitValue;/* 一一备份遥信值 */
        }
    }

    return true;
}

static bool _GetYCData(IEC104SlaveHandler *slaveHandler) {
    int32_t i;

    for (i = 0; i < slaveHandler->YCTotalNum; i++) {
        if (0 != slaveHandler->ReadPointData(&slaveHandler->YCPointTable[i].value,
                                             slaveHandler->YCPointTable[i].deviceCode,
                                             slaveHandler->YCPointTable[i].index,
                                             slaveHandler->YCPointTable[i].dataId)) {
            printf("invalid YC point deviceCode = %d index = %d dataId = %d\n",
                   slaveHandler->YCPointTable[i].deviceCode,
                   slaveHandler->YCPointTable[i].index,
                   slaveHandler->YCPointTable[i].dataId);

            return false;
        }
#if 0
        /* 变化大于千分之二，作为遥测值变化上传依据 */
        if(abs(slaveHandler->YCPointTable[i].value - slaveHandler->YCPointValueRecord[i])
           > abs(slaveHandler->YCPointValueRecord[i]*0.002))
#endif
        if (slaveHandler->YCPointTable[i].value != slaveHandler->YCPointValueRecord[i]) {
            slaveHandler->YCCSPointValue[slaveHandler->YCCSNum].value = slaveHandler->YCPointTable[i].value;
            slaveHandler->YCCSPointValue[slaveHandler->YCCSNum].iecAddr = slaveHandler->YCPointTable[i].iecAddr;
            slaveHandler->YCCSNum++;
            slaveHandler->YCPointValueRecord[i] = slaveHandler->YCPointTable[i].value;/* 一一备份遥测值 */
        }
    }

    return true;
}

static bool _WriteYKData(IEC104SlaveHandler *slaveHandler, uint16_t iecAddrCur, bool bitValue) {
    int32_t i;

    for (i = 0; i < slaveHandler->YKTotalNum; i++) {
        if (slaveHandler->YKPointTable[i].iecAddr == iecAddrCur) {
            int32_t valueTemp;
            if (0 != slaveHandler->ReadPointData(&valueTemp,
                                                 slaveHandler->YKPointTable[i].deviceCode,
                                                 slaveHandler->YKPointTable[i].index,
                                                 slaveHandler->YKPointTable[i].dataId)) {
                printf("invalid YK point deviceCode = %d index = %d dataId = %d\n",
                       slaveHandler->YKPointTable[i].deviceCode,
                       slaveHandler->YKPointTable[i].index,
                       slaveHandler->YKPointTable[i].dataId);
                return false;
            }

            if (bitValue != (bool) ((valueTemp >> slaveHandler->YKPointTable[i].bitOffset) & 0x01)) {/* 比较要设置的遥控位是否变化 */
                if (bitValue) {
                    valueTemp |= (1 << slaveHandler->YKPointTable[i].bitOffset);/* 置位 */
                } else {
                    valueTemp &= ~(1 << slaveHandler->YKPointTable[i].bitOffset);/* 清零 */
                }

                if (0 != slaveHandler->WritePointData(valueTemp,
                                                      slaveHandler->YKPointTable[i].deviceCode,
                                                      slaveHandler->YKPointTable[i].index,
                                                      slaveHandler->YKPointTable[i].dataId)) {
                    return false;
                }
            }

            break;
        }
    }

    return true;
}

static bool _WriteYTData(IEC104SlaveHandler *slaveHandler, uint16_t iecAddrCur, int32_t value) {
    int32_t i;

    for (i = 0; i < slaveHandler->YTTotalNum; i++) {
        if (slaveHandler->YTPointTable[i].iecAddr == iecAddrCur) {
            if (0 != slaveHandler->WritePointData(value,
                                                  slaveHandler->YTPointTable[i].deviceCode,
                                                  slaveHandler->YTPointTable[i].index,
                                                  slaveHandler->YTPointTable[i].dataId)) {
                printf("invalid YT point deviceCode = %d index = %d dataId = %d\n",
                       slaveHandler->YTPointTable[i].deviceCode,
                       slaveHandler->YTPointTable[i].index,
                       slaveHandler->YTPointTable[i].dataId);
                return false;
            }

            break;
        }
    }

    return true;
}

static int32_t generateIECAddrTable(IEC104SlaveHandler *slaveHandler) {
    int32_t i = 0, j = 0, k = 0;
    int32_t len = 0;
    int32_t ycTotalNum = 0;
    int32_t yxTotalNum = 0;
    int32_t ytTotalNum = 0;
    int32_t ykTotalNum = 0;
    int32_t allDevPointNum = 0;
    PROTOCOL_DATA_T *pointAttr = NULL;

    DEV_NODE_T devSeq[] = DEVICE_SEQUENCE;
    int8_t totalDevNum = sizeof(devSeq) / sizeof(devSeq[0]);

    for (i = 0; i < totalDevNum; i++) {
        allDevPointNum += SDB_GetDevPointAttr(devSeq[i].deviceCode, &pointAttr);
        HCFREE(pointAttr);
    }

    YCPoint *ycPoint = malloc(sizeof(YCPoint) * allDevPointNum);
    YXPoint *yxPoint = malloc(sizeof(YXPoint) * allDevPointNum * 32);
    YTPoint *ytPoint = malloc(sizeof(YTPoint) * allDevPointNum * 32);
    YKPoint *ykPoint = malloc(sizeof(YKPoint) * allDevPointNum);

    for (i = 0; i < totalDevNum; i++) {
        int32_t pointNum = SDB_GetDevPointAttr(devSeq[i].deviceCode, &pointAttr);
        for (j = 0; j < pointNum; j++) {
            if (pointAttr[j].iecCode & YC_PATTERN) {
                ycPoint[ycTotalNum].dataId = pointAttr[j].data_id;
                ycPoint[ycTotalNum].deviceCode = devSeq[i].deviceCode;
                ycPoint[ycTotalNum].registerAddr = pointAttr[j].address;
                ycPoint[ycTotalNum].index = devSeq[i].index;
                ycPoint[ycTotalNum].valMin = 0;
                ycPoint[ycTotalNum].valMax = 0xFFFF;
                memcpy(ycPoint[ycTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                ycTotalNum++;
            }

            if (pointAttr[j].iecCode & YX_PATTERN) {
                for (k = 0; k < pointAttr[j].data_len * 8; k++) {
                    yxPoint[yxTotalNum].dataId = pointAttr[j].data_id;
                    yxPoint[yxTotalNum].deviceCode = devSeq[i].deviceCode;
                    yxPoint[yxTotalNum].registerAddr = pointAttr[j].address;
                    yxPoint[yxTotalNum].index = devSeq[i].index;
                    yxPoint[yxTotalNum].bitOffset = k;
                    yxPoint[yxTotalNum].valMin = 0;
                    yxPoint[yxTotalNum].valMax = 1;
                    memcpy(yxPoint[yxTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                    yxTotalNum++;
                }
            }

            if (pointAttr[j].iecCode & YT_PATTERN) {
                ytPoint[ytTotalNum].dataId = pointAttr[j].data_id;
                ytPoint[ytTotalNum].deviceCode = devSeq[i].deviceCode;
                ytPoint[ytTotalNum].registerAddr = pointAttr[j].address;
                ytPoint[ytTotalNum].index = devSeq[i].index;
                ytPoint[ytTotalNum].valMin = 0;
                ytPoint[ytTotalNum].valMax = 0xFFFF;
                memcpy(ytPoint[ytTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                ytTotalNum++;
            }

            if (pointAttr[j].iecCode & YK_PATTERN) {
                for (k = 0; k < pointAttr[j].data_len * 8; k++) {
                    ykPoint[ykTotalNum].dataId = pointAttr[j].data_id;
                    ykPoint[ykTotalNum].deviceCode = devSeq[i].deviceCode;
                    ykPoint[ykTotalNum].registerAddr = pointAttr[j].address;
                    ykPoint[ykTotalNum].index = devSeq[i].index;
                    ykPoint[ykTotalNum].bitOffset = k;
                    ykPoint[ykTotalNum].valMin = 0;
                    ykPoint[ykTotalNum].valMax = 1;
                    memcpy(ykPoint[ykTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                    ykTotalNum++;
                }
            }
        }
        HCFREE(pointAttr);
    }

    FILE *fp = NULL;
    char content[4096];
    if (DEBUGPRINT) {
        sprintf(content, "IEC\tDevCode\tIndex\tName\t\t\tDataId\tModbusAddr\tIECAddr\tBit\n");
        fp = fopen("104.txt", "w");
        if (fp != NULL) {
            fprintf(fp, "%s", content);
        }
        printf("%s", content);
    }

    len = sizeof(YCPoint) * ycTotalNum;
    slaveHandler->YCPointTable = malloc(len);
    memcpy(slaveHandler->YCPointTable, ycPoint, len);
    slaveHandler->YCTotalNum = ycTotalNum;
    slaveHandler->YCStartAddr = slaveHandler->config->yc_minAddr;
    for (i = 0; i < slaveHandler->YCTotalNum; i++) {/* 自动编码YC IEC104地址 */
        slaveHandler->YCPointTable[i].iecAddr = slaveHandler->YCStartAddr + i;

        //if (DEBUGPRINT)
        {
            sprintf(content, "YC\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\n",
                    slaveHandler->YCPointTable[i].deviceCode,
                    slaveHandler->YCPointTable[i].index,
                    slaveHandler->YCPointTable[i].pointName,
                    slaveHandler->YCPointTable[i].dataId,
                    slaveHandler->YCPointTable[i].registerAddr,
                    slaveHandler->YCPointTable[i].iecAddr);

            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == slaveHandler->YCTotalNum - 1)
                printf("\n");
        }
    }

    len = sizeof(YXPoint) * yxTotalNum;
    slaveHandler->YXPointTable = malloc(len);
    memcpy(slaveHandler->YXPointTable, yxPoint, len);
    slaveHandler->YXTotalNum = yxTotalNum;
    slaveHandler->YXStartAddr = slaveHandler->config->yx_minAddr;
    for (i = 0; i < slaveHandler->YXTotalNum; i++) {/* 自动编码YX IEC104地址 */
        slaveHandler->YXPointTable[i].iecAddr = slaveHandler->YXStartAddr + i;

        //if (DEBUGPRINT)
        {
            sprintf(content, "YX\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\t%3d\n",
                    slaveHandler->YXPointTable[i].deviceCode,
                    slaveHandler->YXPointTable[i].index,
                    slaveHandler->YXPointTable[i].pointName,
                    slaveHandler->YXPointTable[i].dataId,
                    slaveHandler->YXPointTable[i].registerAddr,
                    slaveHandler->YXPointTable[i].iecAddr,
                    slaveHandler->YXPointTable[i].bitOffset);
            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == slaveHandler->YXTotalNum - 1)
                printf("\n");
        }
    }

    len = sizeof(YTPoint) * ytTotalNum;
    slaveHandler->YTPointTable = malloc(len);
    memcpy(slaveHandler->YTPointTable, ytPoint, len);
    slaveHandler->YTTotalNum = ytTotalNum;
    slaveHandler->YTStartAddr = slaveHandler->config->yt_minAddr;
    for (i = 0; i < slaveHandler->YTTotalNum; i++) {/* 自动编码YT IEC104地址 */
        slaveHandler->YTPointTable[i].iecAddr = slaveHandler->YTStartAddr + i;

        if (DEBUGPRINT) {
            sprintf(content, "YT\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\n",
                    slaveHandler->YTPointTable[i].deviceCode,
                    slaveHandler->YTPointTable[i].index,
                    slaveHandler->YTPointTable[i].pointName,
                    slaveHandler->YTPointTable[i].dataId,
                    slaveHandler->YTPointTable[i].registerAddr,
                    slaveHandler->YTPointTable[i].iecAddr);

            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == slaveHandler->YTTotalNum - 1)
                printf("\n");
        }
    }

    len = sizeof(YKPoint) * ykTotalNum;
    slaveHandler->YKPointTable = malloc(len);
    memcpy(slaveHandler->YKPointTable, ykPoint, len);
    slaveHandler->YKTotalNum = ykTotalNum;
    slaveHandler->YKStartAddr = slaveHandler->config->yk_minAddr;
    for (i = 0; i < slaveHandler->YKTotalNum; i++) {/* 自动编码YK IEC104地址 */
        slaveHandler->YKPointTable[i].iecAddr = slaveHandler->YKStartAddr + i;

        if (DEBUGPRINT) {
            sprintf(content, "YK\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\t%3d\n\n",
                    slaveHandler->YKPointTable[i].deviceCode,
                    slaveHandler->YKPointTable[i].index,
                    slaveHandler->YKPointTable[i].pointName,
                    slaveHandler->YKPointTable[i].dataId,
                    slaveHandler->YKPointTable[i].registerAddr,
                    slaveHandler->YKPointTable[i].iecAddr,
                    slaveHandler->YKPointTable[i].bitOffset);

            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == slaveHandler->YKTotalNum - 1)
                printf("\n");
        }
    }

    if (DEBUGPRINT && fp != NULL) {
        fclose(fp);
    }

    return 0;
}


/********************************************
* Function name ：generateIECAddrTableFromDB
* Description   : 创建IEC104点表的完整过程
* Parameter     ：
* Return        ：
*********************************************/
// TODO 新的创建IEC104点表
static int32_t generateIECAddrTableFromDB(IEC104SlaveHandler *slaveHandler) {
    int32_t i = 0, j = 0, k = 0, n = 0;
    int32_t ycTotalNum = 0, yxTotalNum = 0, ytTotalNum = 0, ykTotalNum = 0;
    int16_t YCMinAddr = -1, YXMinAddr = -1, YKMinAddr = -1, YTMinAddr = -1;

    // ---------------------------------------------------------------------------
    int32_t devNum, devCode, devIndex;
    uint16_t dataId;
    uint32_t dataAddr;            // modbus的地址

    int8_t bit[16];               // modbus的比特位
    uint32_t iecAddr[16];         // 查询到的IEC104的地址
    uint16_t iecType;             // 查询到的四遥类型
    uint16_t dataNum;             // 数据库返回的数据条数

    DEV_INFO_EXT_T *devList = NULL;

    devNum = SDB_ND_GetNum();     // 北向设备数量
    devList = SDB_ND_GetList();   // 北向设备列表

    // 统计有多少个测点
    int32_t allDevPointNum = 0;
    for (i = 0; i < devNum; ++i) {
        for (j = 0; j < devList[i].dwPtlNum; ++j) {
            allDevPointNum += devList[i].pProtocol[j].ptl_data_num;   // pProtocol:点表属性, ptl_data_num:测点个数
        }
    }

    // 分配四遥的内存空间
    YCPoint *ycPoint = malloc(sizeof(YCPoint) * allDevPointNum);
    YXPoint *yxPoint = malloc(sizeof(YXPoint) * allDevPointNum * 32);
    YTPoint *ytPoint = malloc(sizeof(YTPoint) * allDevPointNum);
    YKPoint *ykPoint = malloc(sizeof(YKPoint) * allDevPointNum * 32);

    // 打开数据库
    int32_t errCode = OK;
    char sql_str[256] = {0};
    sqlite3 *db = NULL;
    errCode = dbOpen(&db);
    if (errCode == ERR_DB_NOT_EXIST) {
        printf("The sqlite database file:%s doesn't exist\n", IEC104DbPath);
        return ERR;
    }

    if (errCode == ERR_OPEN_FAIL) {
        printf("Can't open sqlite database\n");
        return ERR;
    }

    // 遍历所有的测点
    for (i = 0; i < devNum; ++i) {                                          // 遍历设备
        devCode = devList[i].stDevUID.devCode;
        devIndex = devList[i].stDevUID.devIndex;

        int32_t dwPtlNum = devList[i].dwPtlNum;
        printf("%s i:%d devCode:%d(L%d)\n", __func__, i, devCode, __LINE__);
        for (j = 0; j < dwPtlNum; ++j) {                         // 遍历表

            PROTOCOL_T *pProtocol = devList[i].pProtocol + j;

            for (k = 0; k < pProtocol->ptl_data_num; ++k) {    // 遍历测点

                PROTOCOL_DATA_T *pProtocolData = pProtocol->protocol_data + k;
                dataId = pProtocolData->data_id;
                dataAddr = pProtocolData->address;
                char *dataName = pProtocolData->data_name;

                // 查询IEC104-Modbus映射数据库
                sprintf(sql_str,
                        "select IEC104Address,bit,IECType from summary_table where modbusAddress ='%d'", dataAddr);

                errCode = dbQuery(db, sql_str, iecAddr, bit, &iecType, &dataNum);
                if (errCode == ERR_ITEM_NOT_EXIST) {
                    printf("i:%d devCode:%d dataAddr:%d sqlite database query item is not exist (L%d).\n", i, devCode,dataAddr, __LINE__);
                    continue;
                }
                if (errCode == ERR_TABLE_NOT_EXIST) {
                    printf("sqlite database table is not exist.\n");
                    return ERR;
                }

                // 数据库查询到的数据数量
//                 printf("IECType:%d dataNum:%d\n", iecType, dataNum);
                for (n = 0; n < dataNum; n++) {

                    //printf("iecAddr: %d\n", iecAddrFromDB[i]);
                    //printf("bit: %d\n", bit[i]);

                    switch (iecType) {
                        // 遥信
                        case TYPE_YX: {
                            yxPoint[yxTotalNum].dataId = dataId;
                            yxPoint[yxTotalNum].deviceCode = devCode;
                            yxPoint[yxTotalNum].registerAddr = dataAddr;
                            yxPoint[yxTotalNum].index = devIndex;
                            yxPoint[yxTotalNum].bitOffset = bit[n];
                            yxPoint[yxTotalNum].valMin = 0;
                            yxPoint[yxTotalNum].valMax = 1;
                            memcpy(yxPoint[yxTotalNum].pointName, dataName, sizeof(char) * POINT_NAME_MAX_LEN);
                            yxPoint[yxTotalNum].iecAddr = iecAddr[n];
                            yxTotalNum++;

                            YXMinAddr = (YXMinAddr == -1) ? iecAddr[n] : YXMinAddr;
                            slaveHandler->YXStartAddr = (YXMinAddr > iecAddr[n]) ? iecAddr[n] : YXMinAddr;

                            break;
                        }
                            // 遥测
                        case TYPE_YC: {
                            ycPoint[ycTotalNum].dataId = dataId;
                            ycPoint[ycTotalNum].deviceCode = devCode;
                            ycPoint[ycTotalNum].registerAddr = dataAddr;
                            ycPoint[ycTotalNum].index = devIndex;
                            ycPoint[ycTotalNum].valMin = 0;
                            ycPoint[ycTotalNum].valMax = 0xFFFF;
                            memcpy(ycPoint[ycTotalNum].pointName, dataName, sizeof(char) * POINT_NAME_MAX_LEN);
                            ycPoint[ycTotalNum].iecAddr = iecAddr[n];
                            ycTotalNum++;

                            YCMinAddr = (YCMinAddr == -1) ? iecAddr[n] : YCMinAddr;
                            slaveHandler->YCStartAddr = (YCMinAddr > iecAddr[n]) ? iecAddr[n] : YCMinAddr;
                            break;
                        }
                            // 遥控
                        case TYPE_YK: {
                            ykPoint[ykTotalNum].dataId = dataId;
                            ykPoint[ykTotalNum].deviceCode = devCode;
                            ykPoint[ykTotalNum].registerAddr = dataAddr;
                            ykPoint[ykTotalNum].index = devIndex;
                            ykPoint[ykTotalNum].bitOffset = bit[n];
                            ykPoint[ykTotalNum].valMin = 0;
                            ykPoint[ykTotalNum].valMax = 1;
                            memcpy(ykPoint[ykTotalNum].pointName, dataName, sizeof(char) * POINT_NAME_MAX_LEN);
                            ykPoint[ykTotalNum].iecAddr = iecAddr[n];
                            ykTotalNum++;

                            YKMinAddr = (YKMinAddr == -1) ? iecAddr[n] : YKMinAddr;
                            slaveHandler->YKStartAddr = (YKMinAddr > iecAddr[n]) ? iecAddr[n] : YKMinAddr;
                            break;
                        }
                            // 遥调
                        case TYPE_YT: {
                            ytPoint[ytTotalNum].dataId = dataId;
                            ytPoint[ytTotalNum].deviceCode = devCode;
                            ytPoint[ytTotalNum].registerAddr = dataAddr;
                            ytPoint[ytTotalNum].index = devIndex;
                            ytPoint[ytTotalNum].valMin = 0;
                            ytPoint[ytTotalNum].valMax = 0xFFFF;
                            memcpy(ytPoint[ytTotalNum].pointName, dataName, sizeof(char) * POINT_NAME_MAX_LEN);
                            ytPoint[ytTotalNum].iecAddr = iecAddr[n];
                            ytTotalNum++;

                            YTMinAddr = (YTMinAddr == -1) ? iecAddr[n] : YTMinAddr;
                            slaveHandler->YTStartAddr = (YTMinAddr > iecAddr[n]) ? iecAddr[n] : YTMinAddr;
                            break;
                        }
                        default:
                            break;
                    }
                }

            }
        }
    }
    dbDestory(db);  // 关闭数据库

    printf("ycTotalNum:%d yxTotalNum:%d ykTotalNum:%d ytTotalNum:%d\n", ycTotalNum, yxTotalNum, ykTotalNum, ytTotalNum);
    printf("YCStartAddr:%d YXStartAddr:%d YKStartAddr:%d YTStartAddr:%d\n",
           slaveHandler->YCStartAddr, slaveHandler->YXStartAddr, slaveHandler->YKStartAddr, slaveHandler->YTStartAddr);
    // 记录文件
    FILE *fp = NULL;
    char content[4096];
    if (DEBUGPRINT) {
        sprintf(content, "IEC\tDevCode\tIndex\tName\t\t\tDataId\tModbusAddr\tIECAddr\tBit\n");
        fp = fopen("./eFMC_IEC104_Modbus_Map.txt", "w");
        if (fp != NULL) {
            fprintf(fp, "%s", content);
        }
//         printf("%s", content);
    }

    // 遥测赋值给slaveHandler
    int32_t ycLen = sizeof(YCPoint) * ycTotalNum;
    slaveHandler->YCPointTable = malloc(ycLen);
    memcpy(slaveHandler->YCPointTable, ycPoint, ycLen);    // 将上面的创建的遥测内存空间，复制给当前的遥测映射表
    slaveHandler->YCTotalNum = ycTotalNum;

    // 控制台打印遥测信息
    if (DEBUGPRINT) {
        for (i = 0; i < slaveHandler->YCTotalNum; i++) {
            sprintf(content, "YC\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\n",
                    slaveHandler->YCPointTable[i].deviceCode,
                    slaveHandler->YCPointTable[i].index,
                    slaveHandler->YCPointTable[i].pointName,
                    slaveHandler->YCPointTable[i].dataId,
                    slaveHandler->YCPointTable[i].registerAddr,
                    slaveHandler->YCPointTable[i].iecAddr);  // 打印的时候是使用16进制的

            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
//             printf("%s", content);
//
//             if (i == slaveHandler->YCTotalNum - 1)
//                 printf("\n");
        }
    }

    // 遥信赋值给slaveHandler
    int32_t yxLen = sizeof(YXPoint) * yxTotalNum;
    slaveHandler->YXPointTable = malloc(yxLen);
    memcpy(slaveHandler->YXPointTable, yxPoint, yxLen);
    slaveHandler->YXTotalNum = yxTotalNum;

    // 控制台打印遥信信息
    if (DEBUGPRINT) {
        for (i = 0; i < slaveHandler->YXTotalNum; i++) {
            sprintf(content, "YX\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\t%3d\n",
                    slaveHandler->YXPointTable[i].deviceCode,
                    slaveHandler->YXPointTable[i].index,
                    slaveHandler->YXPointTable[i].pointName,
                    slaveHandler->YXPointTable[i].dataId,
                    slaveHandler->YXPointTable[i].registerAddr,
                    slaveHandler->YXPointTable[i].iecAddr,
                    slaveHandler->YXPointTable[i].bitOffset);
            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
//             printf("%s", content);
//
//             if (i == slaveHandler->YXTotalNum - 1)
//                 printf("\n");
        }
    }

    // 遥调赋值给slaveHandler
    int32_t ytLen = sizeof(YTPoint) * ytTotalNum;
    slaveHandler->YTPointTable = malloc(ytLen);
    memcpy(slaveHandler->YTPointTable, ytPoint, ytLen);
    slaveHandler->YTTotalNum = ytTotalNum;

    // 控制台打印遥调信息
    if (DEBUGPRINT) {
        for (i = 0; i < slaveHandler->YTTotalNum; i++) {
            sprintf(content, "YT\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\n",
                    slaveHandler->YTPointTable[i].deviceCode,
                    slaveHandler->YTPointTable[i].index,
                    slaveHandler->YTPointTable[i].pointName,
                    slaveHandler->YTPointTable[i].dataId,
                    slaveHandler->YTPointTable[i].registerAddr,
                    slaveHandler->YTPointTable[i].iecAddr);

            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
//             printf("%s", content);
//
//             if (i == slaveHandler->YTTotalNum - 1)
//                 printf("\n");
        }
    }

    // 遥控赋值给slaveHandler
    int32_t ykLen = sizeof(YKPoint) * ykTotalNum;
    slaveHandler->YKPointTable = malloc(ykLen);
    memcpy(slaveHandler->YKPointTable, ykPoint, ykLen);
    slaveHandler->YKTotalNum = ykTotalNum;

    // 控制台打印遥控信息
    if (DEBUGPRINT) {
        for (i = 0; i < slaveHandler->YKTotalNum; i++) {
            sprintf(content, "YK\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\t%3d\n",
                    slaveHandler->YKPointTable[i].deviceCode,
                    slaveHandler->YKPointTable[i].index,
                    slaveHandler->YKPointTable[i].pointName,
                    slaveHandler->YKPointTable[i].dataId,
                    slaveHandler->YKPointTable[i].registerAddr,
                    slaveHandler->YKPointTable[i].iecAddr,
                    slaveHandler->YKPointTable[i].bitOffset);

            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
//             printf("%s", content);
//
//             if (i == slaveHandler->YKTotalNum - 1)
//                 printf("\n");
        }
    }

    if (DEBUGPRINT && fp != NULL) {
        fclose(fp);
    }
    return 0;
}


static int32_t generateIECAddrTableFromDBBak(IEC104SlaveHandler *slaveHandler) {
    int32_t i = 0, j = 0, k = 0;
    int32_t len = 0;
    int32_t ycTotalNum = 0;
    int32_t yxTotalNum = 0;
    int32_t ytTotalNum = 0;
    int32_t ykTotalNum = 0;
    int32_t allDevPointNum = 0;
    PROTOCOL_DATA_T *pointAttr = NULL;

    DEV_NODE_T devSeq[] = DEVICE_SEQUENCE;
    int8_t totalDevNum = sizeof(devSeq) / sizeof(devSeq[0]);  //totalDevNum设备种类：4


    for (i = 0; i < totalDevNum; i++) {
        // 所有类别设备的测点个数
        allDevPointNum += SDB_GetDevPointAttr(devSeq[i].deviceCode, &pointAttr);
        HCFREE(pointAttr);
    }

    // 分配四遥的内存空间          ---> 空间创建过大了
    YCPoint *ycPoint = malloc(sizeof(YCPoint) * allDevPointNum);
    YXPoint *yxPoint = malloc(sizeof(YXPoint) * allDevPointNum * 32);
    YTPoint *ytPoint = malloc(sizeof(YTPoint) * allDevPointNum * 32);
    YKPoint *ykPoint = malloc(sizeof(YKPoint) * allDevPointNum);

    for (i = 0; i < totalDevNum; i++)  // 4
    {
        // 4种类型的设备的测点个数
        int32_t pointNum = SDB_GetDevPointAttr(devSeq[i].deviceCode, &pointAttr);
        for (j = 0; j < pointNum; j++) {
            if (pointAttr[j].iecCode & YC_PATTERN) {       // 通过IECcode，将YC的点找出来
                ycPoint[ycTotalNum].dataId = pointAttr[j].data_id;
                ycPoint[ycTotalNum].deviceCode = devSeq[i].deviceCode;
                ycPoint[ycTotalNum].registerAddr = pointAttr[j].address;
                ycPoint[ycTotalNum].index = devSeq[i].index;
                ycPoint[ycTotalNum].valMin = 0;
                ycPoint[ycTotalNum].valMax = 0xFFFF;
                memcpy(ycPoint[ycTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                ycTotalNum++;
            }

            if (pointAttr[j].iecCode & YX_PATTERN) {
                for (k = 0; k < pointAttr[j].data_len * 8; k++) {
                    yxPoint[yxTotalNum].dataId = pointAttr[j].data_id;
                    yxPoint[yxTotalNum].deviceCode = devSeq[i].deviceCode;
                    yxPoint[yxTotalNum].registerAddr = pointAttr[j].address;
                    yxPoint[yxTotalNum].index = devSeq[i].index;
                    yxPoint[yxTotalNum].bitOffset = k;
                    yxPoint[yxTotalNum].valMin = 0;
                    yxPoint[yxTotalNum].valMax = 1;
                    memcpy(yxPoint[yxTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                    yxTotalNum++;
                }
            }

            if (pointAttr[j].iecCode & YT_PATTERN) {
                ytPoint[ytTotalNum].dataId = pointAttr[j].data_id;
                ytPoint[ytTotalNum].deviceCode = devSeq[i].deviceCode;
                ytPoint[ytTotalNum].registerAddr = pointAttr[j].address;
                ytPoint[ytTotalNum].index = devSeq[i].index;
                ytPoint[ytTotalNum].valMin = 0;
                ytPoint[ytTotalNum].valMax = 0xFFFF;
                memcpy(ytPoint[ytTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                ytTotalNum++;
            }

            if (pointAttr[j].iecCode & YK_PATTERN) {
                for (k = 0; k < pointAttr[j].data_len * 8; k++) {
                    ykPoint[ykTotalNum].dataId = pointAttr[j].data_id;
                    ykPoint[ykTotalNum].deviceCode = devSeq[i].deviceCode;
                    ykPoint[ykTotalNum].registerAddr = pointAttr[j].address;
                    ykPoint[ykTotalNum].index = devSeq[i].index;
                    ykPoint[ykTotalNum].bitOffset = k;
                    ykPoint[ykTotalNum].valMin = 0;
                    ykPoint[ykTotalNum].valMax = 1;
                    memcpy(ykPoint[ykTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                    ykTotalNum++;
                }
            }
        }
        HCFREE(pointAttr);
    }

    /* 记录文件 */
    FILE *fp = NULL;
    char content[4096];
    if (DEBUGPRINT) {
        sprintf(content, "IEC\tDevCode\tIndex\tName\t\t\tDataId\tModbusAddr\tIECAddr\tBit\n");
        fp = fopen("./104.txt", "w");
        if (fp != NULL) {
            fprintf(fp, "%s", content);
        }
        printf("%s", content);
    }

    // TODO 遥测标记位
    /*----------------------------------遥测-------------------------------------*/
    len = sizeof(YCPoint) * ycTotalNum;
    slaveHandler->YCPointTable = malloc(len);
    memcpy(slaveHandler->YCPointTable, ycPoint, len);    // 将上面的创建的遥测内存空间，复制给当前的遥测映射表
    slaveHandler->YCTotalNum = ycTotalNum;

    int32_t errCode = OK;
    char sql_str[256] = {0};
    sqlite3 *db = NULL;
    errCode = dbOpen(&db);
    if (errCode == ERR_DB_NOT_EXIST) {
        printf("The sqlite database file:%s doesn't exist\n", IEC104DbPath);
        return ERR;
    }

    if (errCode == ERR_OPEN_FAIL) {
        printf("Can't open sqlite database\n");
        return ERR;
    }

    // IEC104遥测地址数组
    uint16_t YCIecAddrArr[slaveHandler->YCTotalNum];

    for (i = 0; i < slaveHandler->YCTotalNum; i++) {

        sprintf(sql_str, "select IEC104Address from yc_table where modbusAddress ='%d'",
                slaveHandler->YCPointTable[i].registerAddr);

        // 测试用sql语句
//        sprintf(sql_str, "select IEC104Address from yc_table where modbusAddress ='%d'",
//                32);

        // 查询数据库
        int32_t YCIecAddrFromDB;
        errCode = dbQueryBak(db, sql_str, &YCIecAddrFromDB);
        if (errCode == ERR_TABLE_NOT_EXIST) {
            printf("sqlite database table is not exist.\n");
            return ERR;
        }
        if (errCode == ERR_ITEM_NOT_EXIST) {
            printf("sqlite database query item is not exist.(L%d)\n", __LINE__);
            return ERR;
        }

        slaveHandler->YCPointTable[i].iecAddr = YCIecAddrFromDB;

        // 将所有的IEC104地址保存下来,获取最小的IEC104地址
        YCIecAddrArr[i] = YCIecAddrFromDB;

        if (DEBUGPRINT)
            // 控制台打印遥测信息的位置
        {
            sprintf(content, "YC\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\n",
                    slaveHandler->YCPointTable[i].deviceCode,
                    slaveHandler->YCPointTable[i].index,
                    slaveHandler->YCPointTable[i].pointName,
                    slaveHandler->YCPointTable[i].dataId,
                    slaveHandler->YCPointTable[i].registerAddr,
                    slaveHandler->YCPointTable[i].iecAddr);  // 打印的时候是使用16进制的

            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == slaveHandler->YCTotalNum - 1)
                printf("\n");
        }
    }
    // 获取最小的IEC104地址的值
    uint16_t YCMinAddr = YCIecAddrArr[0];
    for (i = 0; i < slaveHandler->YCTotalNum; i++) {
        if (YCMinAddr > YCIecAddrArr[i]) {
            YCMinAddr = YCIecAddrArr[i];
        }
    }
    slaveHandler->YCStartAddr = YCMinAddr;

    /* ---------------------------------遥信--------------------------------- */
    len = sizeof(YXPoint) * yxTotalNum;
    slaveHandler->YXPointTable = malloc(len);
    memcpy(slaveHandler->YXPointTable, yxPoint, len);
    slaveHandler->YXTotalNum = yxTotalNum;

    int32_t YXIecAddrFromDB;

    // IEC104遥信地址数组
    uint16_t YXIecAddrArr[slaveHandler->YXTotalNum];

    for (i = 0; i < slaveHandler->YXTotalNum; i++) {
        sprintf(sql_str, "select IEC104Address from yx_table where modbusAddress = '%d' and bit = '%d'",
                slaveHandler->YXPointTable[i].registerAddr, slaveHandler->YXPointTable[i].bitOffset);
        // 查询数据库
        errCode = dbQueryBak(db, sql_str, &YXIecAddrFromDB);
        if (errCode == ERR_TABLE_NOT_EXIST) {
            printf("sqlite database table is not exist.\n");
            return ERR;
        }
        if (errCode == ERR_ITEM_NOT_EXIST) {
            printf("sqlite database query item is not exist. (L%d)\n", __LINE__);
            return ERR;
        }

        slaveHandler->YXPointTable[i].iecAddr = YXIecAddrFromDB;

        YXIecAddrArr[i] = YXIecAddrFromDB;

        if (DEBUGPRINT)
            // 控制台打印遥信信息的位置
        {
            sprintf(content, "YX\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\t%3d\n",
                    slaveHandler->YXPointTable[i].deviceCode,
                    slaveHandler->YXPointTable[i].index,
                    slaveHandler->YXPointTable[i].pointName,
                    slaveHandler->YXPointTable[i].dataId,
                    slaveHandler->YXPointTable[i].registerAddr,
                    slaveHandler->YXPointTable[i].iecAddr,
                    slaveHandler->YXPointTable[i].bitOffset);
            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == slaveHandler->YXTotalNum - 1)
                printf("\n");
        }
    }

    // 获取最小的IEC104地址的值
    uint16_t YXMinAddr = YXIecAddrArr[0];
    for (i = 0; i < slaveHandler->YXTotalNum; i++) {
        if (YXMinAddr > YXIecAddrArr[i]) {
            YXMinAddr = YXIecAddrArr[i];
        }
    }
    slaveHandler->YXStartAddr = YXMinAddr;

    /* ----------------------------------遥调------------------------------ */
    len = sizeof(YTPoint) * ytTotalNum;
    slaveHandler->YTPointTable = malloc(len);
    memcpy(slaveHandler->YTPointTable, ytPoint, len);
    slaveHandler->YTTotalNum = ytTotalNum;

    int32_t YTIecAddrFromDB;

    // IEC104遥信地址数组
    uint16_t YTIecAddrArr[slaveHandler->YTTotalNum];

    for (i = 0; i < slaveHandler->YTTotalNum; i++) {
        sprintf(sql_str, "select IEC104Address from yt_table where modbusAddress = '%d'",
                slaveHandler->YTPointTable[i].registerAddr);
        // 查询数据库
        errCode = dbQueryBak(db, sql_str, &YTIecAddrFromDB);
        if (errCode == ERR_TABLE_NOT_EXIST) {
            printf("sqlite database table is not exist.\n");
            return ERR;
        }
        if (errCode == ERR_ITEM_NOT_EXIST) {
            printf("sqlite database query item is not exist.(L%d)\n", __LINE__);
            return ERR;
        }

        slaveHandler->YTPointTable[i].iecAddr = YTIecAddrFromDB;

        YTIecAddrArr[i] = YTIecAddrFromDB;

        if (DEBUGPRINT) {
            // 控制台打印遥调信息的位置
            sprintf(content, "YT\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\n",
                    slaveHandler->YTPointTable[i].deviceCode,
                    slaveHandler->YTPointTable[i].index,
                    slaveHandler->YTPointTable[i].pointName,
                    slaveHandler->YTPointTable[i].dataId,
                    slaveHandler->YTPointTable[i].registerAddr,
                    slaveHandler->YTPointTable[i].iecAddr);

            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == slaveHandler->YTTotalNum - 1)
                printf("\n");
        }
    }
    // 获取最小的IEC104地址的值
    uint16_t YTMinAddr = YTIecAddrArr[0];
    for (i = 0; i < slaveHandler->YTTotalNum; i++) {
        if (YTMinAddr > YTIecAddrArr[i]) {
            YTMinAddr = YTIecAddrArr[i];
        }
    }
    slaveHandler->YTStartAddr = YTMinAddr;

    /* -------------------------------------遥控-------------------------------- */
    len = sizeof(YKPoint) * ykTotalNum;
    slaveHandler->YKPointTable = malloc(len);
    memcpy(slaveHandler->YKPointTable, ykPoint, len);
    slaveHandler->YKTotalNum = ykTotalNum;

    int32_t YKIecAddrFromDB;

    // IEC104遥信地址数组
    uint16_t YKIecAddrArr[slaveHandler->YKTotalNum];

    for (i = 0; i < slaveHandler->YKTotalNum; i++) {

        sprintf(sql_str, "select IEC104Address from yk_table where modbusAddress = '%d' and bit = '%d'",
                slaveHandler->YKPointTable[i].registerAddr, slaveHandler->YKPointTable[i].bitOffset);
        // 查询数据库
        errCode = dbQueryBak(db, sql_str, &YKIecAddrFromDB);
        if (errCode == ERR_TABLE_NOT_EXIST) {
            printf("sqlite database table is not exist.\n");
            return ERR;
        }
        if (errCode == ERR_ITEM_NOT_EXIST) {
            printf("sqlite database query item is not exist.(L%d)\n", __LINE__);
            return ERR;
        }
        slaveHandler->YKPointTable[i].iecAddr = YKIecAddrFromDB;

        YKIecAddrArr[i] = YKIecAddrFromDB;

        if (DEBUGPRINT) {
            // 控制台打印遥控信息的位置
            sprintf(content, "YK\t%d\t%d\t%-24s\t%d\t%d\t\t0x%x\t%3d\n",
                    slaveHandler->YKPointTable[i].deviceCode,
                    slaveHandler->YKPointTable[i].index,
                    slaveHandler->YKPointTable[i].pointName,
                    slaveHandler->YKPointTable[i].dataId,
                    slaveHandler->YKPointTable[i].registerAddr,
                    slaveHandler->YKPointTable[i].iecAddr,
                    slaveHandler->YKPointTable[i].bitOffset);

            if (fp != NULL) {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == slaveHandler->YKTotalNum - 1)
                printf("\n");
        }
    }

    // 获取最小的IEC104地址的值
    uint16_t YKMinAddr = YKIecAddrArr[0];
    for (i = 0; i < slaveHandler->YKTotalNum; i++) {
        if (YKMinAddr > YKIecAddrArr[i]) {
            YKMinAddr = YKIecAddrArr[i];
        }
    }
    slaveHandler->YKStartAddr = YKMinAddr;

    if (DEBUGPRINT && fp != NULL) {
        fclose(fp);
    }

    return 0;
}

void *IECSlaveThread(void *arg) {
    IEC104SlaveHandler *slaveHandler = (IEC104SlaveHandler *)arg;
    if (slaveHandler == NULL) {
        return NULL;
    }

    while (slaveHandler->isRuning) {
        /* 周期性处理连接请求和信息，发送队列事件 */
        IEC104SlaveService_TickFunc(slaveHandler);

        IEC104SlaveService_YXUploadChangeSignal(slaveHandler);

        IEC104SlaveService_YCUploadChangeSigal(slaveHandler);

        // 104和注册地址相互查询的接口方法
        //RegisterAddrToIEC104Addr(slaveHandler,4,32010,9);
        //IEC104AddrToRegisterAddr(slaveHandler,12);
#if 0
        //    uint32_t nextSendCount = 0;
        if (nextSendCount > (IEC_SLAVE_SERVICE_YC_UPLOAD_PERIOD_IN_MS / IEC_SLAVE_SERVICE_TICK_MS))
        {
            nextSendCount = 0;
            IEC104SlaveService_YCUploadRemoteSignal(slaveHandler);
        }
        nextSendCount++;
#endif
        Thread_sleep(IEC_SLAVE_SERVICE_TICK_MS);
    }

    return NULL;
}

IEC104SlaveHandler *IECSlaveService_Init(IEC104SlaveConfig *config) {
    IEC104SlaveHandler *slaveHandler = (IEC104SlaveHandler *) GLOBAL_CALLOC(1, sizeof(IEC104SlaveHandler));
    int32_t errCode = OK;
    do {
        if (slaveHandler != NULL) {

#ifdef USE_DEFAULT_TABLE
            int32_t count;
        slaveHandler->YCPointTable = &YCPointTable[0];
        slaveHandler->YCStartAddr = slaveHandler->config->yc_minAddr;
        slaveHandler->YCTotalNum = sizeof(YCPointTable) / sizeof(YCPointTable[0]);

        slaveHandler->YCPointValueRecord = (int32_t *) GLOBAL_CALLOC(slaveHandler->YCTotalNum, sizeof(int32_t));
        slaveHandler->YCCSPointValue = (YCCSPoint *) GLOBAL_CALLOC(slaveHandler->YCTotalNum, sizeof(YCCSPoint));
        slaveHandler->YCCSNum = 0;
        for(count = 0; count < slaveHandler->YCTotalNum; count++)
        {/* 自动编码YC IEC104地址 */
            YCPointTable[count].iecAddr = slaveHandler->YCStartAddr + count;
        }

        slaveHandler->YXPointTable = &YXPointTable[0];
        slaveHandler->YXStartAddr = slaveHandler->config->yx_minAddr;
        slaveHandler->YXTotalNum = sizeof(YXPointTable) / sizeof(YXPointTable[0]);

        slaveHandler->YXPointValueRecord = (bool *) GLOBAL_CALLOC(slaveHandler->YXTotalNum, sizeof(bool));
        slaveHandler->YXCSPointValue = (YXCSPoint *) GLOBAL_CALLOC(slaveHandler->YXTotalNum, sizeof(YXCSPoint));
        slaveHandler->YXCSNum = 0;
        for(count = 0; count < slaveHandler->YXTotalNum; count++)
        {/* 自动编码YX IEC104地址 */
            YXPointTable[count].iecAddr = slaveHandler->YXStartAddr + count;
        }

        slaveHandler->YKPointTable = &YKPointTable[0];
        slaveHandler->YKStartAddr = slaveHandler->config->yk_minAddr;
        slaveHandler->YKTotalNum = sizeof(YKPointTable) / sizeof(YKPointTable[0]);
        for(count = 0; count < slaveHandler->YKTotalNum; count++)
        {/* 自动编码YK IEC104地址 */
            YKPointTable[count].iecAddr = slaveHandler->YKStartAddr + count;
        }

        slaveHandler->YTPointTable = &YTPointTable[0];
        slaveHandler->YTStartAddr = slaveHandler->config->yt_minAddr;
        slaveHandler->YTTotalNum = sizeof(YTPointTable) / sizeof(YTPointTable[0]);
        for(count = 0; count < slaveHandler->YTTotalNum; count++)
        {/* 自动编码YT IEC104地址 */
            YTPointTable[count].iecAddr = slaveHandler->YTStartAddr + count;
        }
#else
            // 原本创建IEC104点表的方法
#if USE_DEFAULT_IEC104_MAPPING_TABLE
            generateIECAddrTable(slaveHandler);
        /* ---------iec配置初始化-------------------- */
        slaveHandler->config = config;

#else
            errCode = generateIECAddrTableFromDB(slaveHandler);  // 通过数据库查询的方式创建IEC104点表的方式
            if (errCode != OK)
                break;

            /* iec配置初始化 */
            IEC104SlaveConfig *Config = IEC104SlaveConfigInit(slaveHandler);
            slaveHandler->config = Config;
#endif
            slaveHandler->YCPointValueRecord = (int32_t *) GLOBAL_CALLOC(slaveHandler->YCTotalNum, sizeof(int32_t));
            slaveHandler->YCCSPointValue = (YCCSPoint *) GLOBAL_CALLOC(slaveHandler->YCTotalNum, sizeof(YCCSPoint));
            slaveHandler->YCCSNum = 0;

            slaveHandler->YXPointValueRecord = (bool *) GLOBAL_CALLOC(slaveHandler->YXTotalNum, sizeof(bool));
            slaveHandler->YXCSPointValue = (YXCSPoint *) GLOBAL_CALLOC(slaveHandler->YXTotalNum, sizeof(YXCSPoint));
            slaveHandler->YXCSNum = 0;
#endif

            slaveHandler->ReadPointData = ReadPointData;
            slaveHandler->WritePointData = WritePointCommand;

            /* ---------iec协议初始化---------------------------- */
            slaveHandler->slave = CS104_Slave_create(MAX_LOW_PRIO_QUEUE_SIZE, MAX_HIGH_PRIO_QUEUE_SIZE);

            CS104_Slave_setLocalAddress(slaveHandler->slave, "0.0.0.0");
            CS104_Slave_setServerMode(slaveHandler->slave, CS104_MODE_CONNECTION_IS_REDUNDANCY_GROUP);
            slaveHandler->alParams = CS104_Slave_getAppLayerParameters(slaveHandler->slave);

            /* 注册iec协议回调函数 */
            CS104_Slave_setClockSyncHandler(slaveHandler->slave, clockSyncHandler, slaveHandler);
            CS104_Slave_setInterrogationHandler(slaveHandler->slave, interrogationHandler, slaveHandler);
            CS104_Slave_setASDUHandler(slaveHandler->slave, asduHandler, slaveHandler);
            CS104_Slave_setConnectionRequestHandler(slaveHandler->slave, connectionRequestHandler, NULL);
            CS104_Slave_setConnectionEventHandler(slaveHandler->slave, connectionEventHandler, NULL);

            CS104_Slave_startThreadless(slaveHandler->slave);

            if (CS104_Slave_isRunning(slaveHandler->slave) == false) {
                printf("Starting server failed!\n");
                CS104_Slave_destroy(slaveHandler->slave);
                return NULL;
            }

            slaveHandler->runTh = Thread_create(IECSlaveThread, (void*) slaveHandler, false);
            Thread_start(slaveHandler->runTh);
            slaveHandler->isRuning = TRUE;
        }
    } while (0);

    if (errCode != OK) {
        GLOBAL_FREEMEM(slaveHandler);
        slaveHandler = NULL;
    }
    return slaveHandler;
}

void IEC104SlaveService_Destroy(IEC104SlaveHandler *slaveHandler) {
    if (slaveHandler != NULL) {
        slaveHandler->isRuning = FALSE;
        Thread_destroy(slaveHandler->runTh);

        if (slaveHandler->slave != NULL) {
            CS104_Slave_destroy(slaveHandler->slave);
        }

        if (slaveHandler->YCCSPointValue != NULL) {
            GLOBAL_FREEMEM(slaveHandler->YCCSPointValue);
        }

        if (slaveHandler->YXCSPointValue != NULL) {
            GLOBAL_FREEMEM(slaveHandler->YXCSPointValue);
        }

        if (slaveHandler->YXPointValueRecord != NULL) {
            GLOBAL_FREEMEM(slaveHandler->YXPointValueRecord);
        }

        if (slaveHandler->YCPointValueRecord != NULL) {
            GLOBAL_FREEMEM(slaveHandler->YCPointValueRecord);
        }

        GLOBAL_FREEMEM(slaveHandler);
    }

    printf("%s done. \n", __func__);
}

void IEC104SlaveService_YXUploadChangeSignal(IEC104SlaveHandler *slaveHandler) {
    if (!_GetYXData(slaveHandler)) {
        return;
    }

    if (slaveHandler->YXCSNum == 0) {
        return;
    }
    /* 遥信变位上送 信息体不连续 */
    CS101_ASDU newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, false,
                                                     CS101_COT_SPONTANEOUS,
                                                     0, 1, false, false);
    int32_t i;
    for (i = 0; i < slaveHandler->YXCSNum; i++) {
        InformationObject io = (InformationObject) SinglePointInformation_create(
                (SinglePointInformation) &slaveHandler->ioBuf,
                slaveHandler->YXCSPointValue[i].iecAddr,
                slaveHandler->YXCSPointValue[i].bitValue,
                IEC60870_QUALITY_GOOD);

        if (!CS101_ASDU_addInformationObject(newAsdu, io)) {
            CS104_Slave_enqueueASDU(slaveHandler->slave, newAsdu);

            CS101_ASDU newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, false,
                                                             CS101_COT_SPONTANEOUS,
                                                             0, 1, false, false);
            i -= 1;
        }
    }

    CS104_Slave_enqueueASDU(slaveHandler->slave, newAsdu);

    slaveHandler->YXCSNum = 0;
    return;
}

void IEC104SlaveService_YCUploadChangeSigal(IEC104SlaveHandler *slaveHandler) {
    if (!_GetYCData(slaveHandler)) {
        return;
    }

    if (slaveHandler->YCCSNum == 0) {
        return;
    }
    /* 遥测变化上送 信息体不连续 */
    CS101_ASDU newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, false,
                                                     CS101_COT_SPONTANEOUS,
                                                     0, 1, false, false);
    int32_t i;
    for (i = 0; i < slaveHandler->YCCSNum; i++) {
        InformationObject io = (InformationObject) MeasuredValueShort_create((MeasuredValueShort) &slaveHandler->ioBuf,
                                                                             slaveHandler->YCCSPointValue[i].iecAddr,
                                                                             slaveHandler->YCCSPointValue[i].value,
                                                                             IEC60870_QUALITY_GOOD);
        if (!CS101_ASDU_addInformationObject(newAsdu, io)) {
            CS104_Slave_enqueueASDU(slaveHandler->slave, newAsdu);

            CS101_ASDU newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, false,
                                                             CS101_COT_SPONTANEOUS,
                                                             0, 1, false, false);
            i -= 1;
        }
    }

    CS104_Slave_enqueueASDU(slaveHandler->slave, newAsdu);

    slaveHandler->YCCSNum = 0;
    return;
}


void IEC104SlaveService_YCUploadRemoteSignal(IEC104SlaveHandler *slaveHandler) {
    if (!_GetYCData(slaveHandler)) {
        return;
    }

    CS101_ASDU newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, true,
                                                     CS101_COT_PERIODIC,
                                                     0, 1, false, false);

    int32_t i;
    /* 注意：信息体超过ASDU一次满载，需要多次发送，其中信息体最大字节为255-2-10 = 243 */
    for (i = 0; i < slaveHandler->YCTotalNum; i++) {
        InformationObject io = (InformationObject) MeasuredValueShort_create((MeasuredValueShort) &slaveHandler->ioBuf,
                                                                             slaveHandler->YCPointTable[i].iecAddr,
                                                                             slaveHandler->YCPointTable[i].value,
                                                                             IEC60870_QUALITY_GOOD);
        /* 判断一次ASDU编码信息体载荷是否满载 */
        if (!CS101_ASDU_addInformationObject(newAsdu, io)) {
            /* ASDU 满载后先发送一次 */
            CS104_Slave_enqueueASDU(slaveHandler->slave, newAsdu);
            /* 为剩余信息体重新初始化ASDU */
            newAsdu = CS101_ASDU_initializeStatic(&slaveHandler->asdu, slaveHandler->alParams, true, CS101_COT_PERIODIC,
                                                  0, 1, false, false);
            /* 回退一次循环 */
            i -= 1;
        }
    }
    /* 发送最后一次ASDU */
    CS104_Slave_enqueueASDU(slaveHandler->slave, newAsdu);
}

void IEC104SlaveService_TickFunc(IEC104SlaveHandler *slaveHandler) {
    CS104_Slave_tick(slaveHandler->slave);
}


// 104协议查询对应的注册地址
uint32_t IEC104AddrToRegisterAddr(IEC104SlaveHandler *slaveHandler, int iecAddr) {
    uint32_t i;
    uint32_t registerAddr;
    char LSB;
    for (i = 0; i < slaveHandler->YCTotalNum; i++) {
        if (slaveHandler->YCPointTable[i].iecAddr == iecAddr) {
            registerAddr = slaveHandler->YCPointTable[i].registerAddr;
            printf("查询到的Register地址是: %d\n", registerAddr);
            return registerAddr;
        }
    }

    for (i = 0; i < slaveHandler->YXTotalNum; i++) {
        if (slaveHandler->YXPointTable[i].iecAddr == iecAddr) {
            registerAddr = slaveHandler->YXPointTable[i].registerAddr;
            LSB = slaveHandler->YXPointTable[i].bitOffset;
            printf("查询到的Register地址是: %d,比特位是：%d\n", registerAddr, LSB);
            return registerAddr;
        }
    }

    for (i = 0; i < slaveHandler->YTTotalNum; i++) {
        if (slaveHandler->YTPointTable[i].iecAddr == iecAddr) {
            registerAddr = slaveHandler->YTPointTable[i].registerAddr;
            printf("查询到的Register地址是: %d\n", registerAddr);
            return registerAddr;
        }
    }
    for (i = 0; i < slaveHandler->YKTotalNum; i++) {
        if (slaveHandler->YKPointTable[i].iecAddr == iecAddr) {
            registerAddr = slaveHandler->YKPointTable[i].registerAddr;
            LSB = slaveHandler->YKPointTable[i].bitOffset;
            printf("查询到的Register地址是: %d,比特位是：%d\n", registerAddr, LSB);
            return registerAddr;
        }
    }
    return 0;
}

// 注册地址查询对应的104协议
int RegisterAddrToIEC104Addr(IEC104SlaveHandler *slaveHandler, int pattern, int registerAddr, int LSB) {
    uint32_t i;
    int iecValue;

    if (pattern == YC_PATTERN) {
        for (i = 0; i < slaveHandler->YCTotalNum; i++) {
            if (slaveHandler->YCPointTable[i].registerAddr == registerAddr) {
                iecValue = slaveHandler->YCPointTable[i].iecAddr;
                printf("查询到的IEC104地址是: %d\n", iecValue);
                return iecValue;
            }
        }
    }
    if (pattern == YX_PATTERN) {
        for (i = 0; i < slaveHandler->YXTotalNum; i++) {
            if ((slaveHandler->YXPointTable[i].registerAddr == registerAddr) &&
                (slaveHandler->YXPointTable[i].bitOffset == LSB)) {
                iecValue = slaveHandler->YXPointTable[i].iecAddr;
                printf("查询到的IEC104地址是: %d\n", iecValue);
                return iecValue;
            }
        }
    }
    if (pattern == YT_PATTERN) {
        for (i = 0; i < slaveHandler->YTTotalNum; i++) {
            if (slaveHandler->YTPointTable[i].registerAddr == registerAddr) {
                iecValue = slaveHandler->YTPointTable[i].iecAddr;
                printf("查询到的IEC104地址是: %d\n", iecValue);
                return iecValue;
            }
        }
    }
    if (pattern == YK_PATTERN) {
        for (i = 0; i < slaveHandler->YKTotalNum; i++) {
            if (slaveHandler->YKPointTable[i].registerAddr == registerAddr) {
                iecValue = slaveHandler->YKPointTable[i].iecAddr;
                printf("查询到的IEC104地址是: %d\n", iecValue);
                return iecValue;
            }
        }
    }
    return -1;
}


IEC104SlaveConfig *IEC104SlaveConfigInit(IEC104SlaveHandler *slaveHandler) {
    IEC104SlaveConfig *config = NULL;
    config = (IEC104SlaveConfig *) malloc(sizeof(IEC104SlaveConfig));

    config->yc_minAddr = slaveHandler->YCStartAddr;
    config->yc_maxAddr = slaveHandler->YCStartAddr + slaveHandler->YCTotalNum;

    config->yx_minAddr = slaveHandler->YXStartAddr;
    config->yx_maxAddr = slaveHandler->YXStartAddr + slaveHandler->YXTotalNum;

    config->yt_minAddr = slaveHandler->YTStartAddr;
    config->yt_maxAddr = slaveHandler->YTStartAddr + slaveHandler->YTTotalNum;

    config->yk_minAddr = slaveHandler->YKStartAddr;
    config->yk_maxAddr = slaveHandler->YKStartAddr + slaveHandler->YKTotalNum;

    config->port = 2404;
    config->allowLinkIp = "0.0.0.0";

//    printf("YC:%d\n",slaveHandler->YCStartAddr+slaveHandler->YCTotalNum);
//    printf("YX:%d\n",slaveHandler->YXStartAddr);
//    printf("YT:%d\n",slaveHandler->YTStartAddr);
//    printf("YK:%d\n",slaveHandler->YKStartAddr);

    return config;
}
