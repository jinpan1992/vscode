#ifndef _IEC_MASTER_SERVICE_H_
#define _IEC_MASTER_SERVICE_H_

#include "cs104_connection.h"
#include "hal_time.h"
#include "hal_thread.h"

#include <stdio.h>
#include <stdlib.h>
#include "iec_slave_service.h"
#include "common.h"

typedef struct _IEC104MasterConfig
{
    uint16_t yx_minAddr;
    uint16_t yx_maxAddr;
    uint16_t yc_minAddr;
    uint16_t yc_maxAddr;
    uint16_t yk_minAddr;
    uint16_t yk_maxAddr;
    uint16_t yt_minAddr;
    uint16_t yt_maxAddr;
    uint16_t ym_minAddr;
    uint16_t ym_maxAddr;

    uint16_t deviceCode; /* 设备类型编码 */
    uint16_t index;      /* 同类设备下第几台 */
    uint32_t port;
    const char *serverIp;
}IEC104MasterConfig;


typedef enum
{
    IEC104_MASTER_STATUS_START = 0,
    IEC104_MASTER_STATUS_ONLINE,
    IEC104_MASTER_STATUS_OFFLINE,
}IEC104MasterStatus;

typedef struct _IEC104MasterHandler
{
    CS104_Connection con;
    bool isConnect;

    IEC104MasterStatus curState;
    IEC104MasterConfig *config;

    YXPoint *YXPointTable;
    uint32_t YXStartAddr;
    uint32_t YXTotalNum;

    YCPoint *YCPointTable;
    uint32_t YCStartAddr;
    uint32_t YCTotalNum;

    YKPoint *YKPointTable;
    uint32_t YKStartAddr;
    uint32_t YKTotalNum;

    YTPoint *YTPointTable;
    uint32_t YTStartAddr;
    uint32_t YTTotalNum;

    int32_t (*WritePointData)(DEV_DATA_T *data, uint16_t num);
    int32_t (*ReadPointData)(DEV_DATA_T *data, uint16_t num);

}IEC104MasterHandler;


/**
 * IECMasterService_Init: 可根据传入的不同配置参数初始化IEC104 master 服务
 * @Config: 相关配置参数，包括端口号，目标服务器的IP地址等
 * 返回IEC104 master服务句柄指针
 */
IEC104MasterHandler *IECMasterService_Init(IEC104MasterConfig *config);

/**
 * IEC104_MasterSendCommand: 发送命令到IEC104主站命令队列
 * @masterHandler: IEC104 master服务句柄指针
 * @devData: 命令数据
 *返回：0成功 -1失败
 */
int32_t IECMasterService_SendCommand(IEC104MasterHandler *masterHandler, DEV_DATA_T *devData);

/**
 * IECMasterService_IsConnect: 查询ECMaster是否连接
 * @masterHandler: IEC104 master服务句柄指针
 * @devData: 命令数据
 *返回：0断开 1连接
 */
bool IECMasterService_IsConnect(IEC104MasterHandler *masterHandler);

/**
 * IECMasterService_Destroy: IEC104 master 服务相关内存释放
 * @masterHandler: IEC104 master服务句柄指针
 */
void IECMasterService_Destroy(IEC104MasterHandler *masterHandler);

/**
 * IECMasterThread: IECMaster服务线程
 * arg: IEC104 master服务句柄指针
 *返回：
 */
void *IECMasterThread(void *arg);

#endif
