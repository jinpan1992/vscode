//
// Created by root on 1/13/23.
//

#ifndef C_SQLITE_SQLITE_DB_H
#define C_SQLITE_SQLITE_DB_H

#include "stdio.h"
#include "unistd.h"
#include "common.h"
#include "sqlite3.h"

#define IEC104DbPath "./conf/eFMC_IEC104_Modbus_Map.db"

typedef enum {
    SUCCESS_DB,
    ERR_DB_NOT_EXIST,
    ERR_OPEN_FAIL,
    ERR_TABLE_NOT_EXIST,
    ERR_ITEM_NOT_EXIST,
} SQLITE_ERR_CODE;

int dbOpen(sqlite3 **);
int32_t dbQuery(sqlite3 *db, char *sql, uint32_t *iecAddr, int8_t *bit, uint16_t *iecType, uint16_t *dataNum);
int32_t dbQueryBak(sqlite3 *db, char *sql, int *value);
void dbDestory(sqlite3 *);

#endif //C_SQLITE_SQLITE_DB_H
