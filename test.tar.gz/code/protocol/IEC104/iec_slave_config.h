#ifndef	_IEC_SLAVE_CONFIG_H_
#define _IEC_SLAVE_CONFIG_H_

#define CONFIG_DEBUG 1

#if (CONFIG_DEBUG == 1)
#define DEBUG(format, ...) printf (format, ##__VA_ARGS__)
#else
#define DEBUG(format, ...)
#endif

#define SLAVE_CONFIG_TABLE														\
{																				\
    {0x0001, 0x4000, 0x4001, 0x6000, 0x6001, 0x6200, 0x6201, 0x6400, 0x6401, 0x7000, 2404, "0.0.0.0"},	\
}

#define MASTER_CONFIG_TABLE														\
{																				\
    {0x0001, 0x4000, 0x4001, 0x6000, 0x6001, 0x6200, 0x6201, 0x6400, 0x6401, 0x7000, 60000, "12.12.12.12"},	\
}
/* pem for all 只有一个电源*/
#if 0
#define YC_POINT_TABLE  \
{                                                                                                                               \
    /* PLC 遥测点表 */                                                                                                           \
    { .deviceCode = 60000, .index = 1, .dataId = 221, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 222, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 223, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 224, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 225, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 226, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 227, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 228, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 229, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 230, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 231, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 232, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 233, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 234, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 235, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 236, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 237, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 238, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 239, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 240, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 241, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 242, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 243, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 244, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 245, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 246, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 247, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 248, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 249, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 250, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 251, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 252, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 253, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 254, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 255, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 256, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 257, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 258, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 259, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 260, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 261, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 262, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 263, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 264, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 265, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 266, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 267, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 268, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 269, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 270, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 271, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 272, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 273, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 274, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 275, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 276, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 277, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 278, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 279, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 280, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 281, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 282, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 283, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 284, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 285, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 286, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 287, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 288, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 289, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 290, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 138, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 139, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 140, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 141, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 142, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 143, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 144, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 145, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 146, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 147, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 148, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 149, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 150, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 151, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 152, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 153, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 154, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 155, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 156, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 157, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 158, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 159, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 160, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 161, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 162, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 163, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 164, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 165, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 166, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 167, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 168, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 169, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 170, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 171, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 172, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 173, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 174, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 175, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 176, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 177, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 178, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 179, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 180, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 184, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 185, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 186, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 190, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* 系统EMS 遥测点表 */                                                                                                        \
    { .deviceCode = 2304, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* ACDC 遥测点表 */                                                                                     \
    { .deviceCode = 60001, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
}


#define YX_POINT_TABLE                                                                                                                  \
{																																\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 }, \
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 }, \
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 }, \
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
}

#define YK_POINT_TABLE																											\
{																																\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
}

#define YT_POINT_TABLE                                                                                                          \
{																																\
    { .deviceCode = 60000, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 138, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 139, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 140, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 141, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 142, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 143, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 144, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 145, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 146, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 147, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 148, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 149, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 150, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 151, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 152, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 153, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 154, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 155, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 156, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 157, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 158, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 159, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 160, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 161, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 162, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 163, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 164, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 165, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 166, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 167, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 168, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 169, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 170, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 171, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 172, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 173, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 174, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 175, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 176, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 177, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 178, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 179, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 180, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 184, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 185, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 186, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 190, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
}

#endif
/* pem for all*/
#if 0
#define YC_POINT_TABLE  \
{                                                                                                                               \
    /* PLC 遥测点表 */                                                                                                           \
    { .deviceCode = 60000, .index = 1, .dataId = 221, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 222, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 223, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 224, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 225, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 226, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 227, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 228, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 229, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 230, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 231, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 232, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 233, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 234, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 235, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 236, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 237, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 238, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 239, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 240, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 241, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 242, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 243, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 244, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 245, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 246, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 247, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 248, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 249, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 250, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 251, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 252, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 253, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 254, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 255, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 256, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 257, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 258, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 259, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 260, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 261, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 262, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 263, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 264, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 265, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 266, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 267, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 268, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 269, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 270, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 271, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 272, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 273, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 274, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 275, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 276, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 277, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 278, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 279, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 280, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 281, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 282, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 283, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 284, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 285, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 286, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 287, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 288, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 289, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 290, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 138, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 139, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 140, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 141, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 142, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 143, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 144, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 145, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 146, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 147, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 148, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 149, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 150, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 151, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 152, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 153, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 154, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 155, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 156, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 157, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 158, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 159, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 160, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 161, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 162, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 163, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 164, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 165, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 166, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 167, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 168, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 169, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 170, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 171, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 172, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 173, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 174, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 175, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 176, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 177, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 178, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 179, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 180, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 184, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 185, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 186, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 190, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* 系统EMS 遥测点表 */                                                                                                        \
    { .deviceCode = 2304, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* ACDC 遥测点表 */                                                                                     \
    { .deviceCode = 60001, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* ACDC-2 遥测点表 */                                                                                     \
    { .deviceCode = 60001, .index = 2, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* ACDC-3 遥测点表 */                                                                                     \
    { .deviceCode = 60001, .index = 3, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* ACDC-4 遥测点表 */                                                                                     \
    { .deviceCode = 60001, .index = 4, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
}


#define YX_POINT_TABLE                                                                                                                  \
{																																\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 191,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 192,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 }, \
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 }, \
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 }, \
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 2, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 3, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 4, .dataId = 82,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
}

#define YK_POINT_TABLE																											\
{																																\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
}

#define YT_POINT_TABLE                                                                                                          \
{																																\
    { .deviceCode = 60000, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 138, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 139, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 140, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 141, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 142, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 143, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 144, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 145, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 146, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 147, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 148, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 149, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 150, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 151, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 152, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 153, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 154, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 155, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 156, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 157, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 158, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 159, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 160, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 161, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 162, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 163, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 164, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 165, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 166, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 167, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 168, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 169, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 170, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 171, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 172, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 173, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 174, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 175, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 176, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 177, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 178, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 179, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 180, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 184, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 185, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 186, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 190, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 2, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 3, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 4, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
}

#endif

/*****************************************************************************************************************************/
/* SC500 */
#if 1
#define YC_POINT_TABLE																											\
{                                                                                                                               \
    /* PLC 遥测点表 */                                                                                                           \
    { .deviceCode = 60000, .index = 1, .dataId = 211, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 215, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 221, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 222, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 223, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 224, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 225, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 226, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 227, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 228, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 229, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 230, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 231, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 232, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 233, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 234, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 235, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 236, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 237, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 238, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 239, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 240, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 241, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 242, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 243, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 244, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 245, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 246, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 247, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 248, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 249, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 250, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 251, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 252, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 253, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 254, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 255, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 256, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 257, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 258, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 259, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 260, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 261, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 262, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 263, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 264, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 265, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 266, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 267, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 268, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 269, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 270, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 271, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 272, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 273, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 274, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 275, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 138, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 139, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 140, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 141, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 142, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 143, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 144, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 145, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 146, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 147, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 148, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 149, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 150, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 151, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 152, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 153, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 154, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 155, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 156, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 157, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 158, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 159, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 160, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 161, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 162, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 163, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 164, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 165, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 166, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 167, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 168, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 169, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 170, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 171, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 172, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 173, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 174, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 175, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 176, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 177, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 178, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 179, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 180, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* 系统EMS 遥测点表 */                                                                                                        \
    { .deviceCode = 2304, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* ACDC 遥测点表 */                                                                                     \
    { .deviceCode = 60001, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
}

#define YX_POINT_TABLE																											\
{																																\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 198,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 204,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 209,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
}

#define YK_POINT_TABLE																											\
{																																\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
}

#define YT_POINT_TABLE																											\
{																																\
    { .deviceCode = 60000, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 138, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 139, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 140, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 141, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 142, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 143, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 144, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 145, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 146, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 147, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 148, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 149, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 150, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 151, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 152, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 153, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 154, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 155, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 156, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 157, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 158, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 159, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 160, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 161, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 162, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 163, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 164, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 165, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 166, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 167, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 168, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 169, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 170, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 171, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 172, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 173, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 174, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 175, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 176, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 177, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 178, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 179, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 180, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
}

#endif


#if 0

#define YC_POINT_TABLE																											\
{                                                                                                                               \
    /* PLC 遥测点表 */                                                                                                           \
    { .deviceCode = 60000, .index = 1, .dataId = 209, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 210, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 211, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 212, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 213, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 214, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 215, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 216, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 217, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 218, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 219, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 220, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 221, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 222, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 223, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 224, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 225, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 226, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 227, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 228, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 229, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 230, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 231, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 232, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 233, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 234, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 235, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 236, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 237, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 238, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 239, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 240, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 241, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 242, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 243, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 244, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 245, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 246, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 247, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 248, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 249, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 250, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 251, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 252, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 253, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 254, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 255, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 256, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 257, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 258, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 259, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 260, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 261, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 262, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 263, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 264, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 265, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 266, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 267, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 268, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 269, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 270, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 271, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 272, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 273, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 138, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 139, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 140, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 141, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 142, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 143, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 144, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 145, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 146, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 147, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 148, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 149, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 150, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 151, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 152, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 153, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 154, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 155, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 156, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 157, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 158, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 159, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 160, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 161, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 162, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 163, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 164, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 165, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 166, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 167, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 168, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 169, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 170, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 171, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 172, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 173, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 174, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 175, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 176, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 177, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 178, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 179, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* 系统EMS 遥测点表 */                                                                                                        \
    { .deviceCode = 2304, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    /* ACDC 遥测点表 */                                                                                     \
    { .deviceCode = 60001, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 148, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 149, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 150, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 151, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 152, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 153, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 154, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 155, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 156, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 157, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 158, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 159, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 160, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 161, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 162, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 163, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 164, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 165, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 166, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 167, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 168, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 181, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 182, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 183, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 184, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 185, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 186, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 187, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 188, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 189, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 190, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 191, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 192, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 193, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 194, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 195, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 196, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 197, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 198, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 199, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 200, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 201, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 202, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 203, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 204, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 205, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 206, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 207, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 208, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 209, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 210, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 211, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 212, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 213, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 214, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 215, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 216, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 217, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 218, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 219, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 220, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 221, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 222, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
}

#define YX_POINT_TABLE																											\
{																																\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 181,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 182,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 183,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 187,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 188,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 189,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 193,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 194,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 195,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 196,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 197,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 201,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 202,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 203,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 207,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60000, .index = 1, .dataId = 208,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 43,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 45,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 2304, .index = 1, .dataId = 47,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 70,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 71,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 72,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 73,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 74,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 75,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 76,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 77,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 78,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 79,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 80,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 81,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },  \
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 103,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 104,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 105,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 106,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6, endif .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 107,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2, endifendif .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5, endif .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 108,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 109,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3, endif .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 110,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2, endif .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 111,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 112,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 113,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8, endif .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 114,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 136,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9, endif .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 137,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,endif  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 138,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 139,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 140,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 141,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 142,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 143,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 144,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 145,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 146,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 147,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 169,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 170,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 171,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 172,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 173,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 174,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 175,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 176,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 177,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 178,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 179,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 0,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 2,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 3,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 4,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 6,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 7,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 8,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 9,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 10,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 11,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 12,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 13,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 14,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 180,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 15,  .valMin = 0, .valMax = 1 },	\
}

#define YK_POINT_TABLE																											\
{																																\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 1,  .valMin = 0, .valMax = 1 },	\
    { .deviceCode = 60001, .index = 1, .dataId = 1,  .iecAddr = 0, .dataLen = 4, .bitValue = 0, .bitOffset = 5,  .valMin = 0, .valMax = 1 },	\
}

#define YT_POINT_TABLE																											\
{																																\
    { .deviceCode = 60000, .index = 1, .dataId = 1, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 2, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 3, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 4, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 5, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 6, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 7, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 8, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 9, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 10, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 11, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 12, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 13, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 14, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 15, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 16, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 17, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 18, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 19, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 20, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 21, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 22, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 23, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 24, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 25, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 26, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 27, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 28, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 29, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 30, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 31, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 32, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 33, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 34, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 35, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 36, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 37, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 38, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 39, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 40, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 41, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 42, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 43, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 44, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 45, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 46, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 47, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 48, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 49, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 50, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 51, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 52, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 53, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 54, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 55, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 56, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 57, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 58, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 59, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 138, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 139, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 140, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 141, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 142, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 143, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 144, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 145, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 146, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 147, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 148, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 149, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 150, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 151, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 152, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 153, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 154, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 155, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 156, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 157, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 158, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 159, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 160, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 161, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 162, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 163, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 164, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 165, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 166, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 167, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 168, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 169, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 170, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 171, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 172, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 173, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 174, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 175, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 176, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 177, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 178, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 179, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60000, .index = 1, .dataId = 180, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 60, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 61, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 62, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 63, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 64, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 65, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 66, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 67, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 68, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 69, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 70, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 71, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 72, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 73, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 74, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 75, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 76, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 77, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 78, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 79, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 80, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 81, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 82, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 83, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 84, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 85, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 86, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 87, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 88, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 89, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 90, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 91, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 92, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 93, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 94, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 95, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 96, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 97, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 98, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 99, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 100, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 101, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 102, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 103, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 104, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 105, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 106, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 107, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 108, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 109, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 110, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 111, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 112, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 113, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 114, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 115, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 116, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 117, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 118, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 119, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 120, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 121, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 122, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 123, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 124, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 125, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 126, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 127, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 128, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 129, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 130, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 131, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 132, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 133, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 134, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 135, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 136, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 2304, .index = 1, .dataId = 137, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 184, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 185, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 186, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 187, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 188, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 189, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 190, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 191, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 192, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 193, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 194, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 195, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 196, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 197, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 198, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 199, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 200, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 201, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 202, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 203, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 204, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 205, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 206, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 207, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 208, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 209, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 210, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 211, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 212, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 213, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 214, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 215, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 216, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 217, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 218, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 219, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 220, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 221, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
    { .deviceCode = 60001, .index = 1, .dataId = 222, .iecAddr = 0, .dataLen = 4, .value = 0, .valMin = 0, .valMax = 0xFFFF },	\
}

#endif



#endif
