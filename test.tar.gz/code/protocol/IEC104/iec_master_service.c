#if 1
#include "cs104_connection.h"
#include "hal_time.h"
#include "hal_thread.h"

#include <stdio.h>
#include <stdlib.h>

#include "iec_master_service.h"
#include "transmit.h"
#include "SGQueue.h"
#include "common.h"
#include "logUtil.h"


IEC104MasterConfig MasterConfigTable[];

/*

static YXPoint YXPointTable[] = YX_POINT_TABLE;
static YCPoint YCPointTable[] = YC_POINT_TABLE;
static YKPoint YKPointTable[] = YK_POINT_TABLE;
static YTPoint YTPointTable[] = YT_POINT_TABLE
*/
Q_EXTERN(DEV_DATA_T, dataInQ);

static bool _WriteMasterYCData(IEC104MasterHandler *masterHandler, uint16_t iecAddrCur, int32_t value);
static bool _WriteMasterYXData(IEC104MasterHandler *masterHandler, uint16_t iecAddrCur, bool bitValue);

/* Callback handler to log sent or received messages (optional) */
/*static void rawMessageHandler (void* parameter, uint8_t* msg, int msgSize, bool sent)
{
    if (sent)
        printf("SEND: ");
    else
        printf("RCVD: ");

    int i;
    for (i = 0; i < msgSize; i++) {
        printf("%02x ", msg[i]);
    }

    printf("\n");
}
*/
/* Connection event handler */
static void connectionHandler (void* parameter, CS104_Connection connection, CS104_ConnectionEvent event)
{
    IEC104MasterHandler *masterHandler = (IEC104MasterHandler *)parameter;

    switch (event) {
    case CS104_CONNECTION_OPENED:
        printf("Connection established\n");
        masterHandler->isConnect = true;
        break;
    case CS104_CONNECTION_CLOSED:
        masterHandler->isConnect = false;
        printf("Connection closed\n");
        break;
    case CS104_CONNECTION_STARTDT_CON_RECEIVED:
        printf("Received STARTDT_CON\n");
        break;
    case CS104_CONNECTION_STOPDT_CON_RECEIVED:
        printf("Received STOPDT_CON\n");
        break;
    }
}

/*
 * CS101_ASDUReceivedHandler implementation
 *
 * For CS104 the address parameter has to be ignored
 */
static bool asduReceivedHandler (void* parameter, int address, CS101_ASDU asdu)
{
    DEBUG("RECVD ASDU type: %s(%i) elements: %i\n",
            TypeID_toString(CS101_ASDU_getTypeID(asdu)),
            CS101_ASDU_getTypeID(asdu),
            CS101_ASDU_getNumberOfElements(asdu));

    IEC104MasterHandler *masterHandler = (IEC104MasterHandler *)parameter;

    if (CS101_ASDU_getTypeID(asdu) == M_ME_NC_1)
    {

        //printf("  float values without timestamp:\n");

        int i;

        for (i = 0; i < CS101_ASDU_getNumberOfElements(asdu); i++) {

            MeasuredValueShort io = (MeasuredValueShort) CS101_ASDU_getElement(asdu, i);

            _WriteMasterYCData(masterHandler,
                               InformationObject_getObjectAddress((InformationObject) io),
                               (int32_t)MeasuredValueShort_getValue((MeasuredValueShort) io));

            DEBUG("IOA: %i value: %i\n", InformationObject_getObjectAddress((InformationObject) io),
                                        (int32_t)MeasuredValueShort_getValue((MeasuredValueShort) io));

            MeasuredValueShort_destroy(io);
        }
    }
    else if (CS101_ASDU_getTypeID(asdu) == M_SP_NA_1)
    {
        DEBUG("  single point information:\n");

        int i;

        for (i = 0; i < CS101_ASDU_getNumberOfElements(asdu); i++) {

            SinglePointInformation io = (SinglePointInformation) CS101_ASDU_getElement(asdu, i);

            _WriteMasterYXData(masterHandler,
                               InformationObject_getObjectAddress((InformationObject) io),
                               SinglePointInformation_getValue((SinglePointInformation) io));

            DEBUG("    IOA: %i value: %i\n",
                    InformationObject_getObjectAddress((InformationObject) io),
                    SinglePointInformation_getValue((SinglePointInformation) io)
            );

            SinglePointInformation_destroy(io);
        }
    }
    else if (CS101_ASDU_getTypeID(asdu) == C_TS_TA_1)
    {
        DEBUG("  test command with timestamp\n");
    }

    return true;
}

static bool _WriteMasterYCData(IEC104MasterHandler *masterHandler, uint16_t iecAddrCur, int32_t value)
{
    bool ret = false;
    int32_t i;
    DEV_DATA_T devData;

    for(i = 0; i < masterHandler->YCTotalNum; i++)
    {
        if(masterHandler->YCPointTable[i].iecAddr == iecAddrCur)
        {
            devData.value.data.s32 = value;
            devData.data_type = S_INT_T;
            devData.dev_code = masterHandler->YCPointTable[i].deviceCode;
            devData.moduleID = MODULE_T;
            devData.data_id = masterHandler->YCPointTable[i].dataId;
            devData.index = masterHandler->YCPointTable[i].index;

            masterHandler->WritePointData(&devData, 1);

            if (!Q_FULL(dataInQ))
            {
                Q_INSERT_WAIT(dataInQ, devData);
                ret = true;
            }
            else
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "dataInQ is full!.\n");
                ret = false;
            }
            break;
        }
    }

    return ret;
}

static bool _WriteMasterYXData(IEC104MasterHandler *masterHandler, uint16_t iecAddrCur, bool bitValue)
{
    bool ret = false;
    int32_t i;

    for(i = 0; i < masterHandler->YXTotalNum; i++)
    {
        if(masterHandler->YXPointTable[i].iecAddr == iecAddrCur)
        {
            int32_t valueTemp;
            DEV_DATA_T devData;

            devData.data_type = S_INT_T;
            devData.moduleID = MODULE_T;
            devData.dev_code = masterHandler->YXPointTable[i].deviceCode;
            devData.index = masterHandler->YXPointTable[i].index;
            devData.data_id = masterHandler->YXPointTable[i].dataId;

            if(0 != masterHandler->ReadPointData(&devData,1))
            {
                printf("invalid master YX point deviceCode = %d index = %d dataId = %d\n",
                       masterHandler->YXPointTable[i].deviceCode,
                       masterHandler->YXPointTable[i].index,
                       masterHandler->YXPointTable[i].dataId);

                ret = false;
                break;
            }

            valueTemp = devData.value.data.s32;

            if(bitValue != (bool)((valueTemp >> masterHandler->YXPointTable[i].bitOffset) & 0x01))
            {/* 比较要设置的遥控位是否变化 */
                if(bitValue)
                {
                    valueTemp |= (1 << masterHandler->YXPointTable[i].bitOffset);/* 置位 */
                }
                else
                {
                    valueTemp &= ~(1 << masterHandler->YXPointTable[i].bitOffset);/* 清零 */
                }

                devData.value.data.s32 = valueTemp;

                masterHandler->WritePointData(&devData, 1);

                if (!Q_FULL(dataInQ))
                {
                    Q_INSERT_WAIT(dataInQ,devData);
                    ret = true;
                }
                else
                {
                    EMS_LOG(LL_ERROR, MODULE_C, false, "dataInQ is full!.\n");
                    ret = false;
                }
            }

            break;
        }
    }

	return ret;
}


static int32_t _SendMasterYTCommand(IEC104MasterHandler *masterHandler, uint16_t iecaddr, uint32_t value)
{
    InformationObject scs = (InformationObject)SetpointCommandShort_create(NULL, iecaddr, value, false, 0);

    DEBUG("Send control command C_SE_NC_1\n");
    CS104_Connection_sendProcessCommandEx(masterHandler->con, CS101_COT_ACTIVATION, 1, scs);

    InformationObject_destroy(scs);

    return 0;
}

static int32_t generateIECMasterAddrTable(IEC104MasterHandler *masterHandler)
{
    int32_t i = 0, j = 0, k = 0;
    int32_t len = 0;
    int32_t ycTotalNum = 0;
    int32_t yxTotalNum = 0;
    int32_t ytTotalNum = 0;
    int32_t ykTotalNum = 0;

    PROTOCOL_DATA_T *pointAttr = NULL;

    int32_t pointNum = SDB_GetDevPointAttr(masterHandler->config->deviceCode, &pointAttr);

    YCPoint *ycPoint = malloc(sizeof(YCPoint) * pointNum);
    YXPoint *yxPoint = malloc(sizeof(YXPoint) * pointNum * 32);
    YTPoint *ytPoint = malloc(sizeof(YTPoint) * pointNum );
    YKPoint *ykPoint = malloc(sizeof(YKPoint) * pointNum* 32);

    for (j = 0; j < pointNum; j++)
    {
        if (pointAttr[j].iecCode & YC_PATTERN)
        {
            ycPoint[ycTotalNum].dataId = pointAttr[j].data_id;
            ycPoint[ycTotalNum].deviceCode = masterHandler->config->deviceCode;
            ycPoint[ycTotalNum].registerAddr = pointAttr[j].address;
            ycPoint[ycTotalNum].iecAddr = pointAttr[j].iec_address;//masterHandler->config->yc_minAddr+ycTotalNum;//TODO:采集设备需要另外定义
            ycPoint[ycTotalNum].index = masterHandler->config->index;
            ycPoint[ycTotalNum].valMin = 0;
            ycPoint[ycTotalNum].valMax = 0xFFFF;
            memcpy(ycPoint[ycTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
            ycTotalNum++;
        }

        if (pointAttr[j].iecCode & YX_PATTERN)
        {
            for (k = 0; k < pointAttr[j].data_len * 8; k++)
            {
                yxPoint[yxTotalNum].dataId = pointAttr[j].data_id;
                yxPoint[yxTotalNum].deviceCode = masterHandler->config->deviceCode;
                yxPoint[yxTotalNum].registerAddr = pointAttr[j].address;
                yxPoint[yxTotalNum].iecAddr = pointAttr[j].iec_address+k;//masterHandler->config->yx_minAddr+yxTotalNum;//TODO:采集设备需要另外定义
                yxPoint[yxTotalNum].index = masterHandler->config->index;
                yxPoint[yxTotalNum].bitOffset = k;
                yxPoint[yxTotalNum].valMin = 0;
                yxPoint[yxTotalNum].valMax = 1;
                memcpy(yxPoint[yxTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                yxTotalNum++;
            }
        }

        if (pointAttr[j].iecCode & YT_PATTERN)
        {
            ytPoint[ytTotalNum].dataId = pointAttr[j].data_id;
            ytPoint[ytTotalNum].deviceCode = masterHandler->config->deviceCode;
            ytPoint[ytTotalNum].registerAddr = pointAttr[j].address;
            ytPoint[ytTotalNum].iecAddr = pointAttr[j].iec_address;//masterHandler->config->yt_minAddr + ytTotalNum;//TODO:采集设备需要另外定义
            ytPoint[ytTotalNum].index = masterHandler->config->index;
            ytPoint[ytTotalNum].valMin = 0;
            ytPoint[ytTotalNum].valMax = 0xFFFF;
            memcpy(ytPoint[ytTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
            ytTotalNum++;
        }

        if (pointAttr[j].iecCode & YK_PATTERN)
        {
            for (k = 0; k < pointAttr[j].data_len * 8; k++)
            {
                ykPoint[ykTotalNum].dataId = pointAttr[j].data_id;
                ykPoint[ykTotalNum].deviceCode = masterHandler->config->deviceCode;
                ykPoint[ykTotalNum].registerAddr = pointAttr[j].address;
                ykPoint[ykTotalNum].iecAddr = pointAttr[j].iec_address+k;//TODO:采集设备需要另外定义
                ykPoint[ykTotalNum].index = masterHandler->config->index;
                ykPoint[ykTotalNum].bitOffset = k;
                ykPoint[ykTotalNum].valMin = 0;
                ykPoint[ykTotalNum].valMax = 1;
                memcpy(ykPoint[ykTotalNum].pointName, pointAttr[j].data_name, sizeof(char) * POINT_NAME_MAX_LEN);
                ykTotalNum++;
            }
        }
    }

    HCFREE(pointAttr);

    FILE *fp;
    char content[500];
    char masterTxtName[30];
    if (DEBUGPRINT)
    {
        sprintf(content, "IEC\tDevCode\tIndex\tName\t\t\tDataId\tModbusAddr\tIECAddr\tBit\n");
        sprintf(masterTxtName, "104master-%d.txt\n",masterHandler->config->deviceCode);
        fp = fopen(masterTxtName, "w");
        if (fp != NULL)
        {
            fprintf(fp, "%s", content);
        }
        printf("%s", content);
    }

    len = sizeof(YCPoint) * ycTotalNum;
    masterHandler->YCPointTable = malloc(len);
    memcpy(masterHandler->YCPointTable, ycPoint, len);
    free(ycPoint);
    masterHandler->YCTotalNum = ycTotalNum;
    masterHandler->YCStartAddr = masterHandler->config->yc_minAddr;
    for(i = 0; i < masterHandler->YCTotalNum; i++)
    {
        if (DEBUGPRINT)
        {
            sprintf(content,"YC\t%d\t\t%d\t%-24s\t%d\t%d\t\t0x%x\n",
                masterHandler->YCPointTable[i].deviceCode,
                masterHandler->YCPointTable[i].index,
                masterHandler->YCPointTable[i].pointName,
                masterHandler->YCPointTable[i].dataId,
                masterHandler->YCPointTable[i].registerAddr,
                masterHandler->YCPointTable[i].iecAddr);

            if (fp != NULL)
            {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == masterHandler->YCTotalNum - 1)
                printf("\n");
        }
    }

    len = sizeof(YXPoint) * yxTotalNum;
    masterHandler->YXPointTable = malloc(len);
    memcpy(masterHandler->YXPointTable, yxPoint, len);
    free(yxPoint);
    masterHandler->YXTotalNum = yxTotalNum;
    masterHandler->YXStartAddr = masterHandler->config->yx_minAddr;
    for(i = 0; i < masterHandler->YXTotalNum; i++)
    {
        if (DEBUGPRINT)
        {
            sprintf(content, "YX\t%d\t\t%d\t%-24s\t%d\t%d\t\t0x%x\t\t%3d\n",
                masterHandler->YXPointTable[i].deviceCode,
                masterHandler->YXPointTable[i].index,
                masterHandler->YXPointTable[i].pointName,
                masterHandler->YXPointTable[i].dataId,
                masterHandler->YXPointTable[i].registerAddr,
                masterHandler->YXPointTable[i].iecAddr,
                masterHandler->YXPointTable[i].bitOffset);
            if (fp != NULL)
            {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == masterHandler->YXTotalNum - 1)
                printf("\n");
        }
    }

    len = sizeof(YTPoint) * ytTotalNum;
    masterHandler->YTPointTable = malloc(len);
    memcpy(masterHandler->YTPointTable, ytPoint, len);
    free(ytPoint);
    masterHandler->YTTotalNum = ytTotalNum;
    masterHandler->YTStartAddr = masterHandler->config->yt_minAddr;
    for(i = 0; i < masterHandler->YTTotalNum; i++)
    {
        if (DEBUGPRINT)
        {
            sprintf(content, "YT\t%d\t\t%d\t%-24s\t%d\t%d\t\t0x%x\n",
                masterHandler->YTPointTable[i].deviceCode,
                masterHandler->YTPointTable[i].index,
                masterHandler->YTPointTable[i].pointName,
                masterHandler->YTPointTable[i].dataId,
                masterHandler->YTPointTable[i].registerAddr,
                masterHandler->YTPointTable[i].iecAddr);

            if (fp != NULL)
            {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == masterHandler->YTTotalNum - 1)
                printf("\n");
        }
    }

    len = sizeof(YKPoint) * ykTotalNum;
    masterHandler->YKPointTable = malloc(len);
    memcpy(masterHandler->YKPointTable, ykPoint, len);
    free(ykPoint);
    masterHandler->YKTotalNum = ykTotalNum;
    masterHandler->YKStartAddr = masterHandler->config->yk_minAddr;
    for(i = 0; i < masterHandler->YKTotalNum; i++)
    {

        if (DEBUGPRINT)
        {
            sprintf(content, "YK\t%d\t\t%d\t%-24s\t%d\t%d\t\t0x%x\t\t%3d\n\n",
                masterHandler->YKPointTable[i].deviceCode,
                masterHandler->YKPointTable[i].index,
                masterHandler->YKPointTable[i].pointName,
                masterHandler->YKPointTable[i].dataId,
                masterHandler->YKPointTable[i].registerAddr,
                masterHandler->YKPointTable[i].iecAddr,
                masterHandler->YKPointTable[i].bitOffset);

            if (fp != NULL)
            {
                fprintf(fp, "%s", content);
            }
            printf("%s", content);

            if (i == masterHandler->YKTotalNum - 1)
                printf("\n");
        }
    }

    if (DEBUGPRINT && fp != NULL)
    {
        fclose(fp);
    }

    return 0;
}


IEC104MasterHandler *IECMasterService_Init(IEC104MasterConfig *config)
{
    IEC104MasterHandler *masterHandler = (IEC104MasterHandler *) GLOBAL_CALLOC(1, sizeof(IEC104MasterHandler));

    if(masterHandler != NULL)
    {
        /* ---------iec配置初始化---------------------------- */
        masterHandler->config = config;

        generateIECMasterAddrTable(masterHandler);

#if 0
        masterHandler->YCPointTable = config->YCPointTableConfig;
        masterHandler->YCStartAddr = masterHandler->config->yc_minAddr;
        masterHandler->YCTotalNum = config->YCTotalNumConfig;

        for(count = 0; count < masterHandler->YCTotalNum; count++)
        {/* 自动编码YC IEC104地址 */
            masterHandler->YCPointTable[count].iecAddr = masterHandler->YCStartAddr + count;
        }

        masterHandler->YXPointTable = config->YXPointTableConfig;
        masterHandler->YXStartAddr = masterHandler->config->yx_minAddr;
        masterHandler->YXTotalNum = config->YXTotalNumConfig;

        for(count = 0; count < masterHandler->YXTotalNum; count++)
        {/* 自动编码YX IEC104地址 */
            masterHandler->YXPointTable[count].iecAddr = masterHandler->YXStartAddr + count;
        }

        masterHandler->YKPointTable = config->YKPointTableConfig;
        masterHandler->YKStartAddr = masterHandler->config->yk_minAddr;
        masterHandler->YKTotalNum = config->YKTotalNumConfig;
        for(count = 0; count < masterHandler->YKTotalNum; count++)
        {/* 自动编码YK IEC104地址 */
            masterHandler->YKPointTable[count].iecAddr = masterHandler->YKStartAddr + count;
        }

        masterHandler->YTPointTable = &YTPointTable[0];
        masterHandler->YTStartAddr = masterHandler->config->yt_minAddr;
        masterHandler->YTTotalNum = sizeof(YTPointTable) / sizeof(YTPointTable[0]);
        for(count = 0; count < masterHandler->YTTotalNum; count++)
        {/* 自动编码YT IEC104地址 */
            YTPointTable[count].iecAddr = masterHandler->YTStartAddr + count;
        }

#endif

        masterHandler->ReadPointData = SDB_GetRegisterValue;
        masterHandler->WritePointData = SDB_SetRegisterValue;

        masterHandler->curState = IEC104_MASTER_STATUS_START;
        masterHandler->isConnect = false;

        /* ---------iec协议初始化---------------------------- */
        const char* ip = config->serverIp;
        uint16_t port = config->port;

        printf("IECMasterService_Init Connecting to: %s:%i\n", ip, port);
        masterHandler->con = CS104_Connection_create(ip, port);

        CS101_AppLayerParameters alParams = CS104_Connection_getAppLayerParameters(masterHandler->con);
        alParams->originatorAddress = 3;

        CS104_Connection_setConnectionHandler(masterHandler->con, connectionHandler, masterHandler);
        CS104_Connection_setASDUReceivedHandler(masterHandler->con, asduReceivedHandler, masterHandler);
    }

	return masterHandler;
}


int32_t IECMasterService_SendCommand(IEC104MasterHandler *masterHandler, DEV_DATA_T *devData)
{

    /* IEC master 在线状态才允许发送数据 */
    if(masterHandler->curState != IEC104_MASTER_STATUS_ONLINE)
    {
        return -1;
    }

    if((devData->dev_code != masterHandler->config->deviceCode)
        || (devData->index != masterHandler->config->index))
    {
        return -1;
    }

    int i;
    for(i = 0; i < masterHandler->YTTotalNum; i++)
    {
        if(devData->data_id == masterHandler->YTPointTable[i].dataId)
        {
            masterHandler->YTPointTable[i].value = devData->value.data.s32;
            _SendMasterYTCommand(masterHandler, masterHandler->YTPointTable[i].iecAddr, masterHandler->YTPointTable[i].value);
            return 0;
        }
    }

    return -1;
}

bool IECMasterService_IsConnect(IEC104MasterHandler *masterHandler)
{
    return masterHandler->isConnect;
}

void IECMasterService_Destroy(IEC104MasterHandler *masterHandler)
{
    if(masterHandler != NULL)
    {
        if(masterHandler->con != NULL)
        {
            CS104_Connection_destroy(masterHandler->con);
        }

        if(masterHandler->YCPointTable != NULL)
        {
            GLOBAL_FREEMEM(masterHandler->YCPointTable);
        }
        if(masterHandler->YXPointTable != NULL)
        {
            GLOBAL_FREEMEM(masterHandler->YXPointTable);
        }
        if(masterHandler->YTPointTable != NULL)
        {
            GLOBAL_FREEMEM(masterHandler->YTPointTable);
        }
        if(masterHandler->YKPointTable != NULL)
        {
            GLOBAL_FREEMEM(masterHandler->YKPointTable);
        }
        GLOBAL_FREEMEM(masterHandler);
    }
}




void *IECMasterThread(void *arg)
{
    IEC104MasterHandler *masterHandler = (IEC104MasterHandler*)arg;
    int sendcount = 0;
    bool first = true;

    while(1)
    {
        switch(masterHandler->curState)
        {
            case IEC104_MASTER_STATUS_START:
            {/* */
                DEBUG(">>>>>>>>>>>>>>>>>>>IEC104_MASTER_STATUS_START\n");
                if (CS104_Connection_connect(masterHandler->con))
                {
                    masterHandler->curState = IEC104_MASTER_STATUS_ONLINE;
                    first = true;
                }
                else
                {
                    masterHandler->curState = IEC104_MASTER_STATUS_OFFLINE;
                }
            }
            break;

            case IEC104_MASTER_STATUS_ONLINE:
            {/*  */
                DEBUG(">>>>>>>>>>>>>>>>>>>IEC104_MASTER_STATUS_ONLINE\n");
                if(first)
                {
                    CS104_Connection_sendStartDT(masterHandler->con);

                    Thread_sleep(2000);

                    CS104_Connection_sendInterrogationCommand(masterHandler->con, CS101_COT_ACTIVATION, 1, IEC60870_QOI_STATION);
                    sendcount = 0;
                    first = false;
                }

                Thread_sleep(2000);
                sendcount++;

                if(sendcount > 10)
                {
                    /* 总召唤 */
                    CS104_Connection_sendInterrogationCommand(masterHandler->con, CS101_COT_ACTIVATION, 1, IEC60870_QOI_STATION);
                    sendcount = 0;
                }

                if(!masterHandler->isConnect)
                {
                    Thread_sleep(1000);
                    masterHandler->curState = IEC104_MASTER_STATUS_OFFLINE;
                }
            }
            break;

            case IEC104_MASTER_STATUS_OFFLINE:
            {
                DEBUG(">>>>>>>>>>>>>>>>>>>IEC104_MASTER_STATUS_OFFLINE\n");
                if (CS104_Connection_connect(masterHandler->con))
                {
                    masterHandler->curState = IEC104_MASTER_STATUS_ONLINE;
                    first = true;
                }

                Thread_sleep(3000);
            }
            break;

            default:
            break;
        }
    }
}


void IECMASTER(void)
{
//    IEC104MasterHandler *masterHandlerTest = IECMasterService_Init(&MasterConfigTable[0]);

//    IECMasterThread(masterHandlerTest);

#if 0
    DEV_DATA_T devDataTest;
    devDataTest.dev_code = 60000;
    devDataTest.index = 1;
    devDataTest.data_id = 7;
    devDataTest.data.s32 = 50;

    IECMasterService_SendCommand(masterHandlerTest, &devDataTest);
#endif
}



#if 0

#include "cs104_connection.h"
#include "hal_time.h"
#include "hal_thread.h"

#include <stdio.h>
#include <stdlib.h>

#include "iec_master_service.h"
#include "transmit.h"
#include "SGQueue.h"
#include "common.h"
#include "logUtil.h"

IEC104MasterConfig MasterConfigTable[] = MASTER_CONFIG_TABLE;

Q_DEFINE(DEV_DATA_T, iecmasterDataQ, Queue_NUM);
Q_DEFINE(DEV_DATA_T, iecmasterCmdQ, Queue_NUM);

static YXPoint YXPointTable[] = YX_POINT_TABLE;
static YCPoint YCPointTable[] = YC_POINT_TABLE;
static YKPoint YKPointTable[] = YK_POINT_TABLE;
static YTPoint YTPointTable[] = YT_POINT_TABLE;

static bool _WriteMasterYCData(IEC104MasterHandler *masterHandler, uint16_t iecAddrCur, int32_t value);
static bool _WriteMasterYXData(IEC104MasterHandler *masterHandler, uint16_t iecAddrCur, bool bitValue);

/* Callback handler to log sent or received messages (optional) */
static void rawMessageHandler (void* parameter, uint8_t* msg, int msgSize, bool sent)
{
    if (sent)
        printf("SEND: ");
    else
        printf("RCVD: ");

    int i;
    for (i = 0; i < msgSize; i++) {
        printf("%02x ", msg[i]);
    }

    printf("\n");
}

/* Connection event handler */
static void connectionHandler (void* parameter, CS104_Connection connection, CS104_ConnectionEvent event)
{
    IEC104MasterHandler *masterHandler = (IEC104MasterHandler *)parameter;

    switch (event) {
    case CS104_CONNECTION_OPENED:
        printf("Connection established\n");
        masterHandler->isConnect = true;
        break;
    case CS104_CONNECTION_CLOSED:
        masterHandler->isConnect = false;
        printf("Connection closed\n");
        break;
    case CS104_CONNECTION_STARTDT_CON_RECEIVED:
        printf("Received STARTDT_CON\n");
        break;
    case CS104_CONNECTION_STOPDT_CON_RECEIVED:
        printf("Received STOPDT_CON\n");
        break;
    }
}

/*
 * CS101_ASDUReceivedHandler implementation
 *
 * For CS104 the address parameter has to be ignored
 */
static bool asduReceivedHandler (void* parameter, int address, CS101_ASDU asdu)
{
    DEBUG("RECVD ASDU type: %s(%i) elements: %i\n",
            TypeID_toString(CS101_ASDU_getTypeID(asdu)),
            CS101_ASDU_getTypeID(asdu),
            CS101_ASDU_getNumberOfElements(asdu));

    IEC104MasterHandler *masterHandler = (IEC104MasterHandler *)parameter;

    if (CS101_ASDU_getTypeID(asdu) == M_ME_NC_1)
    {

        //printf("  float values without timestamp:\n");

        int i;

        for (i = 0; i < CS101_ASDU_getNumberOfElements(asdu); i++) {

            MeasuredValueShort io = (MeasuredValueShort) CS101_ASDU_getElement(asdu, i);

            _WriteMasterYCData(masterHandler,
                               InformationObject_getObjectAddress((InformationObject) io),
                               (int32_t)MeasuredValueShort_getValue((MeasuredValueShort) io));

            DEBUG("    IOA: %i value: %i\n",
                    InformationObject_getObjectAddress((InformationObject) io),
                    (int32_t)MeasuredValueShort_getValue((MeasuredValueShort) io)
            );

            MeasuredValueShort_destroy(io);
        }
    }
    else if (CS101_ASDU_getTypeID(asdu) == M_SP_NA_1)
    {
        DEBUG("  single point information:\n");

        int i;

        for (i = 0; i < CS101_ASDU_getNumberOfElements(asdu); i++) {

            SinglePointInformation io = (SinglePointInformation) CS101_ASDU_getElement(asdu, i);

            _WriteMasterYXData(masterHandler,
                               InformationObject_getObjectAddress((InformationObject) io),
                               SinglePointInformation_getValue((SinglePointInformation) io));

            DEBUG("    IOA: %i value: %i\n",
                    InformationObject_getObjectAddress((InformationObject) io),
                    SinglePointInformation_getValue((SinglePointInformation) io)
            );

            SinglePointInformation_destroy(io);
        }
    }
    else if (CS101_ASDU_getTypeID(asdu) == C_TS_TA_1)
    {
        DEBUG("  test command with timestamp\n");
    }

    return true;
}

Q_EXTERN(DEV_DATA_T, iecmasterDataQ);
Q_EXTERN(DEV_DATA_T, iecmasterCmdQ);

int32_t IEC104_MasterSendCommand(DEV_DATA_T *devData, uint32_t num)
{
    int32_t i;

    for(i = 0; i < num; i++)
    {
        if (!Q_FULL(iecmasterCmdQ))
        {
            Q_INSERT_WAIT(iecmasterCmdQ, devData[i]);
        }
        else
        {
            EMS_LOG(LL_ERROR, MODULE_C, false, "iecmasterCmdQ is full!.\n");
            return -1;
        }
    }

    return 0;

//    Q_INSERT_WAIT_N(iecmasterCmdQ, devData, num);
}

uint32_t IEC104_MasterGetRcvDataNum(void)
{
    return Q_NUMS(iecmasterDataQ);
}

int32_t IEC104_MasterRcvData(DEV_DATA_T *devData, int num)
{
    int32_t i;

    if(Q_NUMS(iecmasterDataQ) < num)
    {
        EMS_LOG(LL_ERROR, MODULE_C, false, "iecmasterDataQ OUT num overflow!.\n");
        return -1;
    }

    Q_OUT_N(iecmasterDataQ, devData, num);

    return 0;
}

bool IEC104_MasterIsConnect(void)
{
    return ;
}

static bool _WriteMasterYCData(IEC104MasterHandler *masterHandler, uint16_t iecAddrCur, int32_t value)
{
    bool ret = false;
    int32_t i;
    DEV_DATA_T devData;

    for(i = 0; i < masterHandler->YCTotalNum; i++)
    {
        if(masterHandler->YCPointTable[i].iecAddr == iecAddrCur)
        {
            devData.data.s32 = value;
            devData.data_type = S_INT_T;
            devData.dev_code = masterHandler->YCPointTable[i].deviceCode;
            devData.moduleID = MODULE_T;
            devData.data_id = masterHandler->YCPointTable[i].dataId;
            devData.index = masterHandler->YCPointTable[i].index;

            if (!Q_FULL(iecmasterDataQ))
            {
                Q_INSERT_WAIT(iecmasterDataQ, devData);
                ret = true;
            }
            else
            {
                EMS_LOG(LL_ERROR, MODULE_C, false, "iecmasterDataQ is full!.\n");
                ret = false;
            }

            break;
        }
    }

    return ret;
}

static bool _WriteMasterYXData(IEC104MasterHandler *masterHandler, uint16_t iecAddrCur, bool bitValue)
{
    bool ret = false;
    int32_t i;

    for(i = 0; i < masterHandler->YXTotalNum; i++)
    {
        if(masterHandler->YXPointTable[i].iecAddr == iecAddrCur)
        {
            int32_t valueTemp;
            if(0 != masterHandler->ReadPointData(&valueTemp,
                                                masterHandler->YXPointTable[i].deviceCode,
                                                masterHandler->YXPointTable[i].index,
                                                masterHandler->YXPointTable[i].dataId))
            {
                printf("invalid master YX point deviceCode = %d index = %d dataId = %d\n",
                       masterHandler->YXPointTable[i].deviceCode,
                       masterHandler->YXPointTable[i].index,
                       masterHandler->YXPointTable[i].dataId);

                ret = false;
                break;
            }

            if(bitValue != (bool)((valueTemp >> masterHandler->YXPointTable[i].bitOffset) & 0x01))
            {/* 比较要设置的遥控位是否变化 */
                if(bitValue)
                {
                    valueTemp |= (1 << masterHandler->YXPointTable[i].bitOffset);/* 置位 */
                }
                else
                {
                    valueTemp &= ~(1 << masterHandler->YXPointTable[i].bitOffset);/* 清零 */
                }

                DEV_DATA_T devData;

                devData.data.s32 = valueTemp;
                devData.data_type = S_INT_T;
                devData.dev_code = masterHandler->YXPointTable[i].deviceCode;
                devData.moduleID = MODULE_T;
                devData.data_id = masterHandler->YXPointTable[i].dataId;
                devData.index = masterHandler->YXPointTable[i].index;

                if (!Q_FULL(iecmasterDataQ))
                {
                    Q_INSERT_WAIT(iecmasterDataQ,devData);
                    ret = true;
                }
                else
                {
                    EMS_LOG(LL_ERROR, MODULE_C, false, "iecmasterDataQ is full!.\n");
                    ret = false;
                }
            }

            break;
        }
    }

	return ret;
}

int32_t _SendMasterYTCommand(IEC104MasterHandler *masterHandler, uint16_t iecaddr, uint32_t value)
{
    InformationObject scs = (InformationObject)SetpointCommandShort_create(NULL, iecaddr, value, false, 0);

    DEBUG("Send control command C_SE_NC_1\n");
    CS104_Connection_sendProcessCommandEx(masterHandler->con, CS101_COT_ACTIVATION, 1, scs);

    InformationObject_destroy(scs);
}


IEC104MasterHandler *IECMasterService_Init(IEC104MasterConfig *config)
{
	int32_t count;
    IEC104MasterHandler *masterHandler = (IEC104MasterHandler *) GLOBAL_CALLOC(1, sizeof(IEC104MasterHandler));

    if(masterHandler != NULL)
    {
        /* ---------iec配置初始化---------------------------- */
        masterHandler->config = config;

        masterHandler->YCPointTable = &YCPointTable[0];
        masterHandler->YCStartAddr = masterHandler->config->yc_minAddr;
        masterHandler->YCTotalNum = sizeof(YCPointTable) / sizeof(YCPointTable[0]);

        for(count = 0; count < masterHandler->YCTotalNum; count++)
        {/* 自动编码YC IEC104地址 */
            YCPointTable[count].iecAddr = masterHandler->YCStartAddr + count;
        }

        masterHandler->YXPointTable = &YXPointTable[0];
        masterHandler->YXStartAddr = masterHandler->config->yx_minAddr;
        masterHandler->YXTotalNum = sizeof(YXPointTable) / sizeof(YXPointTable[0]);

        for(count = 0; count < masterHandler->YXTotalNum; count++)
        {/* 自动编码YX IEC104地址 */
            YXPointTable[count].iecAddr = masterHandler->YXStartAddr + count;
        }

        masterHandler->YKPointTable = &YKPointTable[0];
        masterHandler->YKStartAddr = masterHandler->config->yk_minAddr;
        masterHandler->YKTotalNum = sizeof(YKPointTable) / sizeof(YKPointTable[0]);
        for(count = 0; count < masterHandler->YKTotalNum; count++)
        {/* 自动编码YK IEC104地址 */
            YKPointTable[count].iecAddr = masterHandler->YKStartAddr + count;
        }

        masterHandler->YTPointTable = &YTPointTable[0];
        masterHandler->YTStartAddr = masterHandler->config->yt_minAddr;
        masterHandler->YTTotalNum = sizeof(YTPointTable) / sizeof(YTPointTable[0]);
        for(count = 0; count < masterHandler->YTTotalNum; count++)
        {/* 自动编码YT IEC104地址 */
            YTPointTable[count].iecAddr = masterHandler->YTStartAddr + count;
        }

        masterHandler->ReadPointData = ReadPointData;
//        masterHandler->WritePointData = WritePointData;

        masterHandler->curState = IEC104_MASTER_STATUS_START;

        /* ---------iec协议初始化---------------------------- */
        const char* ip = "12.12.12.12";
        uint16_t port = IEC_60870_5_104_DEFAULT_PORT;

        printf("Connecting to: %s:%i\n", ip, port);
        masterHandler->con = CS104_Connection_create(ip, port);

        CS101_AppLayerParameters alParams = CS104_Connection_getAppLayerParameters(masterHandler->con);
        alParams->originatorAddress = 3;

        CS104_Connection_setConnectionHandler(masterHandler->con, connectionHandler, masterHandler);
        CS104_Connection_setASDUReceivedHandler(masterHandler->con, asduReceivedHandler, masterHandler);

        Q_INIT(iecmasterDataQ, Queue_NUM);
        Q_INIT(iecmasterCmdQ, Queue_NUM);
    }

	return masterHandler;
}


void IECMasterService_Destroy(IEC104MasterHandler *masterHandler)
{
    if(masterHandler != NULL)
    {
        if(masterHandler->con != NULL)
        {
            CS104_Connection_destroy(masterHandler->con);
        }

        GLOBAL_FREEMEM(masterHandler);
        Q_DESTROY(iecmasterDataQ);
        Q_DESTROY(iecmasterCmdQ);
    }
}


void *IecMasterCommandQHandler(void *arg)
{
    IEC104MasterHandler *masterHandler = (IEC104MasterHandler *)arg;

    DEV_DATA_T devData;
    uint32_t num = 0;
    int32_t i,j;

    while (1)
    {
        Q_WAIT(iecmasterCmdQ);

        if(masterHandler->curState != IEC104_MASTER_STATUS_ONLINE)
        {
            continue;
        }

        num = Q_NUMS(iecmasterCmdQ);//计算队列中元素个数，一次性读取全部

        for(i = 0; i < Q_NUMS(iecmasterCmdQ); i++)
        {
            Q_OUT(iecmasterCmdQ, devData);

            if(masterHandler->curState != IEC104_MASTER_STATUS_ONLINE)
            {
                break;
            }

            for(j = 0; j < masterHandler->YCTotalNum; j++)
            {
                if((devData.dev_code == masterHandler->YCPointTable[j].deviceCode)
                    && (devData.index == masterHandler->YCPointTable[j].index)
                    && (devData.data_id == masterHandler->YCPointTable[j].dataId))
                {
                    masterHandler->YCPointTable[j].value = devData.data.s32;
                    _SendMasterYTCommand(masterHandler, masterHandler->YCPointTable[j].iecAddr, masterHandler->YCPointTable[j].value);
                    break;
                }
            }
        }
    }
}

void *IECMasterThread(void *arg)
{
    IEC104MasterHandler *masterHandler = IECMasterService_Init(&MasterConfigTable[0]);
    int sendcount = 0;
    bool first = true;
    Thread DataQMaster;

    DataQMaster = Thread_create(IecMasterCommandQHandler, (void*) masterHandler, false);
    Thread_start(DataQMaster);

    while(1)
    {
        switch(masterHandler->curState)
        {
            case IEC104_MASTER_STATUS_START:
            {/* */
                DEBUG(">>>>>>>>>>>>>>>>>>>IEC104_MASTER_STATUS_START\n");
                if (CS104_Connection_connect(masterHandler->con))
                {
                    masterHandler->curState = IEC104_MASTER_STATUS_ONLINE;
                    first = true;
                }
                else
                {
                    masterHandler->curState = IEC104_MASTER_STATUS_OFFLINE;
                }
            }
            break;

            case IEC104_MASTER_STATUS_ONLINE:
            {/*  */
                DEBUG(">>>>>>>>>>>>>>>>>>>IEC104_MASTER_STATUS_ONLINE\n");
                if(first)
                {
                    CS104_Connection_sendStartDT(masterHandler->con);

                    Thread_sleep(2000);

                    CS104_Connection_sendInterrogationCommand(masterHandler->con, CS101_COT_ACTIVATION, 1, IEC60870_QOI_STATION);
                    sendcount = 0;
                    first = false;
                }

                Thread_sleep(2000);
                sendcount++;

                if(sendcount > 10)
                {
                    CS104_Connection_sendInterrogationCommand(masterHandler->con, CS101_COT_ACTIVATION, 1, IEC60870_QOI_STATION);
                    sendcount = 0;
                }

                if(!masterHandler->isConnect)
                {
                    Thread_sleep(1000);
                    masterHandler->curState = IEC104_MASTER_STATUS_OFFLINE;
                }
            }
            break;

            case IEC104_MASTER_STATUS_OFFLINE:
            {
                DEBUG(">>>>>>>>>>>>>>>>>>>IEC104_MASTER_STATUS_OFFLINE\n");
                if (CS104_Connection_connect(masterHandler->con))
                {
                    masterHandler->curState = IEC104_MASTER_STATUS_ONLINE;
                    first = true;
                }

                Thread_sleep(3000);
            }
            break;

            default:
            break;
        }
    }
}

#endif

#endif
