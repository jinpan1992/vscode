//
// Created by root on 1/6/23.
//
#include "iec_mapping_sqlite_db.h"

static int callback(void *NotUsed, int argc, char **argv, char **azColName) {
    int i = 0;
    for (i = 0; i < argc; i++) {
        printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
    }

    printf("\n");
    return 0;
}

void dbShowVersion() {
    printf("%s\n", sqlite3_libversion());
}

int dbQueryWithCallBack(sqlite3 *db, char *sql) {
    char *zErrMsg = 0;
    int rc;

    rc = sqlite3_exec(db, sql, callback, 0, &zErrMsg);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "SQL error: %s\n", zErrMsg);
        sqlite3_free(zErrMsg);
    } else {
        fprintf(stdout, "Operation done successfully\n");
    }
    return 0;
}

// 通过数据库查询数据
int32_t dbQuery(sqlite3 *db, char *sql, uint32_t *iecAddr, int8_t *bit, uint16_t *iecType, uint16_t *dataNum) {
    char **result, *errmsg;
    int nrow, ncolumn, i, j, index;

    if (sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg) != SQLITE_OK) {
        printf("sqlite query error : %s\n", errmsg);
        sqlite3_free(errmsg);
        return ERR_TABLE_NOT_EXIST;
    }

    // 获取第一个查询到的值
    if (*result == NULL) {
        return ERR_ITEM_NOT_EXIST;
    }

    if (nrow > 1) {
        *dataNum = nrow - 1;
    } else {
        *dataNum = nrow;
    }

    index = ncolumn;
    for (i = 0; i < *dataNum; i++) {
        for (j = 0; j < ncolumn; j++) {
            // printf("%-8s : %-8s\n", result[j], result[index]);

            if (strcmp(result[j], "IEC104Address") == 0) {
                *(iecAddr + i) = atoi(result[index]);
            }
            if (strcmp(result[j], "bit") == 0) {
                *(bit + i) = atoi(result[index]);
            }
            if (strcmp(result[j], "IECType") == 0) {
                *iecType = atoi(result[index]);
            }
            index++;
        }
    }
    sqlite3_free_table(result);
    sqlite3_free(errmsg);

    return SUCCESS_DB;
}

int32_t dbQueryBak(sqlite3 *db, char *sql, int *value) {
    char **result, *errmsg;
    int32_t nrow, ncolumn;

    if (sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg) != SQLITE_OK) {
        printf("sqlite query error : %s\n", errmsg);
        sqlite3_free(errmsg);
        return ERR_TABLE_NOT_EXIST;
    }

    // 获取第一个查询到的值
    if (*result == NULL) {
        return ERR_ITEM_NOT_EXIST;
    }

    *value = atoi(result[1]);

    // 打印所有的查询结果
//    int32_t i, j, index;
//    index = ncolumn;
//    for (i = 0; i < nrow; i++) {
//        for (j = 0; j < ncolumn; j++) {
//            printf("%s : %s\n", result[j], result[index]);
//            index++;
//        }
//    }
    sqlite3_free_table(result);
    return SUCCESS_DB;
}

void dbDestory(sqlite3 *db) {
    sqlite3_close(db);  //关闭数据库
    sqlite3_shutdown(); //关闭SQLite
}

int dbOpen(sqlite3 **db) {
    //sqlite3 *db;
    int rc;
    sqlite3_initialize();  //初始化SQLite

    /* 判断sqlite.db文件是否存在 */
    if (access(IEC104DbPath, 0) == -1) {
        return ERR_DB_NOT_EXIST;
    }

    rc = sqlite3_open(IEC104DbPath, db);
    if (rc) {
        return ERR_OPEN_FAIL;
    }
    return SUCCESS_DB;
}

//int main(void)
//{
//    char sql_str[256] = {0};
//    sprintf(sql_str, "select * from %s where addressName ='%s'","yc_table","YC_1");
//
//    dbShowVersion();
//    sqlite3 *db=dbOpen();
//    dbQuery(db,sql_str);
//    dbDestory(db);
//    return 0;
//}
