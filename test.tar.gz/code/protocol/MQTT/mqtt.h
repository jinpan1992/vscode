#ifndef MQTT_H
#define MQTT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "MQTTClient.h"
#include "common.h"
#include "mqtt_en_de_json.h"
#include "mqtt_ens_cypt.h"
#include "transmit.h"
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>


int sockfd; // 套接字描述符
struct sockaddr_in serv_addr;


// mqtt错误码
typedef enum {
    SUCCESS_MQTT,
    ERR_MQTT_CREATE_CLIENT,
    ERR_MQTT_SET_CALLBACK,
    ERR_MQTT_CONNECT_FAIL,
    ERR_MQTT_CONNECT_LOST,
    ERR_MQTT_SUBSCRIBE,
    ERR_MQTT_PUBLISH,
} MQTT_ERR_CODE;

// MQTT报文注册错误码
typedef enum {
    SUCCESS_REG,      //
    NOT_YET_REG_REPLY,    // 云端回复错误
} REG_ERR_CODE;

// 运行数据发送错误码
typedef enum {
    SUCCESS_PUB,
    ERR_PUB,
} RUN_DATA_ERR_CODE;


// 从web获取消息结构体
typedef struct {
    char mqtt_addr[50];       // mqtt服务器地址
    int32_t mqtt_port;          // mqtt服务器端口
    BOOL is_use_mqtt;            // 是否开启MQTT功能
    BOOL is_encrypt;             // 是否开启秘钥交互
    int32_t encryAlgor;          //云加密算法,默认1：AES128
    BOOL upload_method;          // 是否是变化上传（1：变化上环，0：全量上传）
    uint32_t all_upload_period;  // 全量上传周期
    char pubTopic[128]; //mqtt 发布topic
    char subTopic[128]; //mqtt 订阅topic
    char clientId[128];
    char username[128];
    char pwd[128];
    char ip[128];
    int port;
} WEB_CONFIG_MQTT;

WEB_CONFIG_MQTT g_webConfigMqttNew; // 获取web中mqtt相关参数的全局变量
WEB_CONFIG_MQTT g_webConfigMqttOld; // 获取web中mqtt相关参数的全局变量

BOOL mqttRegSucFlag;               // 注册成功标志位
MQTTClient g_MQTT_CLIENT;          // 全局的一个mqtt client

BOOL IS_MQTT_DISCONNECT;
BOOL IS_TCP_DISCONNECT;
int32_t sysPingDetect();
//new net ping method 2021/9/6
int32_t DetectNet();

char *getTime();

int32_t createMqttClient(MQTTClient *);

int32_t mqttPub(MQTTClient *, char *, char *);

int32_t mqttSub(MQTTClient *, char *);

int32_t mqttThreadInit();

int32_t mqttInit();

int32_t mqttThreadUnInit();

int32_t mqttUnInit();

int32_t tcpInit();

int32_t tcpConnStus();


void fillDataWebConfigMqtt(WEB_CONFIG_MQTT *);

// 获取mqtt相关配置参数的接口函数
char *getMqttAddr();

int32_t getMqttPort();

BOOL getIsUseMqtt();

BOOL getIsEncrypt();

BOOL getUploadMethod();

uint32_t getAllUploadPeriod();

char* getClientId();

char* getPubTopic();

char* getSubTopic();

int32_t getTcpPort();

char* getTcpIp();



#endif //MQTT_H
