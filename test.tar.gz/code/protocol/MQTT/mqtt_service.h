#ifndef MYCEMS_MQTT_SERVICE_H
#define MYCEMS_MQTT_SERVICE_H
#include <sys/prctl.h>
#include "mqtt.h"
#include "mqtt_run_data_pub.h"
#include "mqtt_secret_key_registration.h"

#define MAX_FILE_SIZE 1024*1024*50 // test 文件大小限制
#define MAX_TXT_NUM   40 //文件个数

#define TCP_MAX_TXT_NUM 40
#define TCP_MAX_FILE_SIZE 1025*1024*50
#define TCP_RECV_SIZE 2048


void updateMqttParameters(WEB_CONFIG_MQTT *mqttConfig);
void *mqttThread(void *arg);
void *history_mqttThread(void *arg);

void *tcpThread(void *arg);
void *history_tcpThread(void *arg);
void *tcpRecvThread(void *);
void tcpWriteValue(char *message);

int FileCnt;//最旧文件索引
int FileMaxCnt;//最大文件索引
int TcpFileCnt;//最旧文件索引
int TcpFileMaxCnt;//最大文件索引

#endif //MYCEMS_MQTT_SERVICE_H
