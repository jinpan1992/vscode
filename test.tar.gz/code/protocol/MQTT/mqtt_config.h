#ifndef MYCEMS_MQTT_CONFIG_H
#define MYCEMS_MQTT_CONFIG_H



//datacode与value
typedef struct DATACODE_PARA
{
    uint32_t datacode;
    int32_t value;
}DATACODE_PARA_T;

//每个元素的结构体
typedef struct DATA_PARA
{
    uint32_t deviceKey;
    DATACODE_PARA_T *datacodepara;
    uint16_t datacodeparacount;//DATACODE_PARA_T开辟的个数
}DATA_PARA_T;

//单次收到平台的信息
typedef struct MQTT_DATA
{
    uint32_t deviceId;
    DATA_PARA_T *para;
    uint16_t dataparacount;//DATA_PARA_T开辟的个数
    uint16_t datacodeall;//所有datacode个数
}MQTT_DATA_T;



        typedef struct MQTT_DATA_PARA
        {
            int32_t deviceKey;
            int32_t datacode;
            int32_t value;
            int32_t address;
            int32_t data_id;
            int32_t devcode;
            int32_t cmd;

        }MQTT_DATA_PARA_T;


        typedef struct MQTT_DATA_OUTPARA
        {
            int32_t deviceId;
            MQTT_DATA_PARA_T *outpara;
            uint16_t count;
        }MQTT_DATA_OUTPARA_T;

// 数据的结构体
typedef struct
{
    int32_t deviceCode;   // 设备的类型
    int32_t index;        // 设备的编号
    int32_t dataId;       // 设备测点
    DATA_U data;        // 测点的值
    int32_t  mqttdeviceid;    //mqtt分配的设备id
    int32_t gatewayid;       //网关id
    int32_t datacode;       //测点编码
    uint8_t ucDataType;       /* 数据类型 */
} ONCE_DATA_T;

typedef struct
{
    /*变化上传*/
    uint32_t total_num;        // 数据的数量

    ONCE_DATA_T * p;           // 数据结构体指针
    pthread_mutex_t mLock;     // 锁
    sem_t rwlock1;             // 信号量1
    sem_t rwlock2;             // 信号量2
    BOOL exist_value;          // 结构体已存储数据

    /*全量上传*/
    uint32_t total_num_all;        // 数据的数量
    ONCE_DATA_T * p_all;           // 数据结构体指针

    BOOL isRunning;
    uint32_t MqttDeviceIdNums;
    uint32_t *MqttDeviceIdKind;
    int32_t (*WritePointData)(int32_t value, uint16_t deviceCode, uint16_t index, uint16_t dataId);

} MQTT_HANDLE_T, *PMQTT_HANDLE_T;
MQTT_HANDLE_T g_mqtt_handle;     // mqtt结构体的全局变量


// 是否启用MQTT
#define IS_USE_MQTT 1

// 加密使能
#define IS_ENCRYPT 1

// 变化上传或全量上传
#define IS_CHANGE 1

// 数据上传周期
#define PUB_PERIOD 5


#define MQTT_XML  "/home/SGComm/conf/transmit/mqtt.xml"

#define MQTT_Uri     "tcp://192.168.67.88:31000"
//#define MQTT_Uri    "tcp://broker.emqx.io:1883" // MQTT服务器的地址和端口号
//#define MQTT_Uri    "tcp://broker.hivemq.com:1883" // MQTT服务器的地址和端口号

/*15楼运营测试环境参数*/
// #define ClientId    "ihcxX0Gpr2L.MxJIfx9MM6pUf5dqpji0|securemode=2,signmethod=hmacsha256,timestamp=1691551895168|"     // clientID
// #define UserName    "MxJIfx9MM6pUf5dqpji0&ihcxX0Gpr2L"            // 用户名
// #define PassWord    "14c2ad29fb7e868aaab6ebfb356eb57510fdb151fbfc36a45d2b6cc2c06d1e5c"            // 用户名对应的密码

/*15楼运营正式环境参数*/
// #define ClientId    "hhqnUCMvLur.hcbYq7nFu4nOzYjUdWdB|securemode=2,signmethod=hmacsha256,timestamp=1691999456301|"     // clientID
// #define UserName    "hcbYq7nFu4nOzYjUdWdB&hhqnUCMvLur"            // 用户名
// #define PassWord    "8f57e80d3298ee99d3d81dd789bc48d57c4340735699c43c6c7ed47b32e7baf1"            // 用户名对应的密码

/*其他测试环境参数*/
// #define ClientId    "emqx_test"                  // clientID
// #define UserName    "mqttx"            // 用户名
// #define PassWord    "Sungrow!@#20230720"            // 用户名对应的密码


#define TIMEOUT     10000L

// 秘钥注册topic
#define Topic_Sub_Reg  "eFMCSubReg"
#define Topic_Pub_Reg  "eFMCPubReg"

// 接收mqtt命令topic
// #define Topic_Sub_Command  "/ihcxX0Gpr2L/MxJIfx9MM6pUf5dqpji0/user/get"
// #define Topic_Sub_Command  "/hhqnUCMvLur/hcbYq7nFu4nOzYjUdWdB/user/get"
// #define Topic_Sub_Command  "data/device_id"            //测试用


// 发送运行数据(变化上传)topic
#define Topic_Pub_RunData_change  "eFMCPubRunDataChange"

// 发送运行数据(全量数据)topic
// #define Topic_Pub_RunData_all  "/ihcxX0Gpr2L/MxJIfx9MM6pUf5dqpji0/user/update"
//  #define Topic_Pub_RunData_all  "/hhqnUCMvLur/hcbYq7nFu4nOzYjUdWdB/user/update"

//  #define Topic_Pub_RunData_all  "pub/device_id"       //测试用



#define AES_BLOCK_SIZE 16
#define BUFFSIZE   1024

// RSA非对称加密的公钥和私钥
#define PUBLICKEY  "./conf/rsa_public.pem"

#define SN "hhqnGEYTish.k6KnkfuWPpZYBP3KJsT5|securemode=2,signmethod=hmacsha256,timestamp=1691049325529|"
#define MAGIC_STRING "54321"    // 和云端保持一致的magic_string，一般不会改变
char SESSION_KEY[128];

#endif //MYCEMS_MQTT_CONFIG_H
