#ifndef MYCEMS_RUN_DATA_PUB_H
#define MYCEMS_RUN_DATA_PUB_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "mqtt.h"
#include "mqtt_config.h"
#include "sdb.h"
#include "GlobalData.h"

void getAllRunData();

typedef struct mqtt_st
{
	char devname[128];			//设备名称
	uint32_t date_type;        //1:read,2:write,3:read and write.
	uint16_t data_id;            //数据ID
	uint32_t address;            //寄存器地址
	uint16_t slave_id;            //数据ID
    uint32_t  mqttdeviceid;    //mqtt分配的设备id
    uint32_t gatewayid;       //网关id
    uint32_t datacode;
    uint32_t devcode;
    uint32_t devindex;
    uint32_t dataid;
    uint32_t cmd;
}MQTT_T;


int32_t runDataChangePub();
int32_t runDataTimerPub();
int32_t runDataPub();
int32_t ParseMqttFromXml(char *configfilePATH,MQTT_T *mqtt_info);
uint32_t GetMqttPonitFromXml(char *configfilePATH, int *idount);
void runDataProduct(DEV_DATA_T *devData, uint32_t num);
int32_t runDataTcpSend();

#endif //MYCEMS_RUN_DATA_PUB_H
