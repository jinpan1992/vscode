#include "mqtt.h"
#include <sys/wait.h>
#include<fcntl.h>
#include "mqtt_run_data_pub.h"
#include "mqtt_config.h"
// #include <sys/socket.h>
// #include <arpa/inet.h>
// #include <netinet/in.h>
#include "persist.h"

BOOL IS_MQTT_DISCONNECT = FALSE;
BOOL IS_TCP_DISCONNECT = FALSE;

int rethj ;

int32_t DetectNet()
{
    int sockfd;
    struct sockaddr_in servaddr;
//     char buffer[1024];

    // 初始化服务器地址结构体
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(80); // 设置端口号为80，测试HTTP连接
    inet_pton(AF_INET, "180.76.76.76", &servaddr.sin_addr); // 将IP地址转换为二进制格式

    // 创建套接字并连接到服务器
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket");
        return ERR;
    }
    if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) == -1) {
        perror("connect");
        return ERR;
    }

    // 如果连接成功，输出连接成功的信息
    printf("Connected to server!\n");

    // 关闭套接字
    close(sockfd);
    memset(&sockfd, 0, sizeof(int));

    return OK;
}

int32_t sysPingDetect() {
//     char baidu[14] = "www.baidu.com";
    char baidu_dns[13] = "180.76.76.76";
//     char baidu_dns[15] = "183.2.172.185";
    int status;
    pid_t pid;

    int fd;
    fd = open("/dev/null",O_WRONLY|O_TRUNC|O_CREAT,0644);
    if(fd < 0){
        perror("open error\n");
        exit(1);
    }

    // 新建一个进程来执行ping命令
    if ((pid = vfork()) < 0) {
        printf("vfork error");
        close(fd);
        return ERR;
    }

    if (pid == 0) {
        // 执行ping命令
        dup2(fd,STDOUT_FILENO);
        dup2(fd,STDERR_FILENO);
        if (execlp("ping", "ping", "-c", "1", baidu_dns, (char *) 0) < 0)
        {
            printf("ping baidu execlp error\n");

            if (execlp("ping", "ping", "-c", "1", g_webConfigMqttNew.mqtt_addr, (char *) 0) < 0)
            {
                printf("ping mqtt address execlp error\n");
                return ERR;
            }
            return OK;
        }
        return OK;
    }
    else {
        //status存储子进程退出的状态值
        waitpid(pid, &status, 0);   // 当指定等待的子进程已经停止运行或结束了，则waitpid()会立即返回
        close(fd);
        // 相等说明正常
        if (status == 0) {
            // printf("网络已连接.\n");
            return OK;
        } else {
            // printf("网络已断开.\n");
            sleep(2);
            return ERR;
        }
    }

}




/********************************************
* Function name ：
* Description   : mqtt配套的回调函数
* Parameter     ：
* Return        ：
*********************************************/
void connectLost(void *context, char *cause) {
    printf("mqtt broker connection lost,The reason: network disconnection\n");
    free(context);
     IS_MQTT_DISCONNECT = TRUE;
//     g_mqtt_handle.isRunning = FALSE;
}

void connectLostBak(void *context, char *cause) {
    printf("Connection lost,The reason: %s \n", cause);
    free(context);
}

// 收到主题信息回调函数
int32_t messageArrived(void *context, char *topicName, int topicLen, MQTTClient_message *message) {
    //数据库记录参数初始化
    PERSIST_NODE_INFO_T runLog;
    time_t now;
    struct tm *timenow;
    char timedata[30] = {0};
    BOOL isEncrypt = getIsEncrypt();
    unsigned char *res;
    // 如果是云端下发的指令,需要解密和解码
    if (strcmp(topicName, Topic_Sub_Reg) == 0) {
        printf("222Receive topic: %s\n", topicName);
        printf("message data: %.*s\n", message->payloadlen, (char *) message->payload);

        // json 解码
        char *content = SubMessageDecodeJson(message->payload);
        // printf("json解码结果: %s\n", content);

        // AES解密
        int32_t outLen = 0;
        unsigned char *res = aesDecrypt((unsigned char *) content, (int32_t) strlen(content),
                                        (unsigned char *) SESSION_KEY,
                                        &outLen);
        printf("AES decryption result: %s \r\n", res);

        // 与本地保存的Magic_String比对是否一致
        if (strcmp((const char *) res, MAGIC_STRING) == 0) {
            mqttRegSucFlag = TRUE;       // mqtt注册成功标志位
        } else {
            printf("Comparison result is inconsistent, continue to listen for reply messages from the cloud center by MQTT.\n");
        }

        free(context);
        free(res);

        MQTTClient_freeMessage(&message);
        //MQTTClient_free(topicName);

        return 1;
    }
        // 接收指令回调函数
    else if (strcmp(topicName, g_webConfigMqttNew.subTopic) == 0) {
        printf("Receive subtopic: %s\n", topicName);
        printf("message data: %.*s\n", message->payloadlen, (char *) message->payload);

//         strcpy(runLog.pcDescription, (char *)message->payload);
//         time(&now);
//         timenow = localtime(&now);
//         sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
//         strcpy(runLog.date,timedata);
//         strcpy( runLog.arrcDevName, "zero carbon gateway");
//         Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);

//         // json 解码密文
//         char *content = SubMessageDecodeJson(message->payload);
//
//         // AES解密
//         int32_t outLen = 0;
//         unsigned char *res = aesDecrypt((unsigned char *) content, (int32_t) strlen(content),
//                                         (unsigned char *) SESSION_KEY,
//                                         &outLen);
//
//         // json解码获取具体参数信息
//         int *ret = SubCommandDecodeJson((char *) res);
        if(TRUE == isEncrypt)
        {
            printf("AES解密...%d\n", isEncrypt);
            // AES解密
            int32_t outLen = 0;
            printf("%d %d\n", strlen(message->payload), message->payloadlen);
            res = aesDecrypt((unsigned char *) message->payload, strlen(message->payload), (unsigned char *) SESSION_KEY, &outLen);
//             aesDecryptData = res;
            printf("AES解密后: %.*s\n", outLen, res);
        }


    int i, j, k1=0,m;
    int b[500] = {0};
    int idcount;

    //SE500 code
    MQTT_DATA_T *mqtt_data =(MQTT_DATA_T *)malloc(sizeof(MQTT_DATA_T)*(1));
    extern int Mqtt_point_num;
    extern MQTT_T *mqtt_info1;
    mqtt_data->datacodeall = Mqtt_point_num;
    mqtt_data->deviceId = mqtt_info1[0].gatewayid;
    mqtt_data->dataparacount = g_mqtt_handle.MqttDeviceIdNums;
    mqtt_data->para = (DATA_PARA_T *)calloc(g_mqtt_handle.MqttDeviceIdNums, sizeof(DATA_PARA_T));

    for(i=0;i<g_mqtt_handle.MqttDeviceIdNums;i++)
    {
        for(j=0;j<Mqtt_point_num;j++)
        {
            if(mqtt_info1[j].mqttdeviceid == g_mqtt_handle.MqttDeviceIdKind[i])
            {
                mqtt_data->para[i].datacodeparacount++;
            }
        }

    }
    uint16_t *times = (uint16_t *)calloc(g_mqtt_handle.MqttDeviceIdNums,sizeof(uint16_t));

    for(i=0;i<g_mqtt_handle.MqttDeviceIdNums;i++)
    {
        mqtt_data->para[i].deviceKey = g_mqtt_handle.MqttDeviceIdKind[i];
        mqtt_data->para[i].datacodepara =calloc(mqtt_data->para[i].datacodeparacount,sizeof(DATACODE_PARA_T));
        for(j=0;j<Mqtt_point_num;j++)
        {
            if(mqtt_info1[j].mqttdeviceid == g_mqtt_handle.MqttDeviceIdKind[i])
            {
                    mqtt_data->para[i].datacodepara[times[i]] .datacode = mqtt_info1[j].datacode;
                    times[i]++;
            }
        }
    }

    MQTT_DATA_OUTPARA_T *mqtt_data_out  = NULL;

    if(TRUE == isEncrypt)
    {
        mqtt_data_out = MqttAnlysisJson((char *) res, mqtt_data);
    }
    else
    {
        mqtt_data_out = MqttAnlysisJson((char *) message->payload, mqtt_data);
    }

    //MqttAnlysisJson解析完后释放开辟内存空间
    for(i=0;i<g_mqtt_handle.MqttDeviceIdNums;i++)
    {
        free(mqtt_data->para[i].datacodepara);
    }

    if (mqtt_data_out != NULL && mqtt_data_out->count != 0)
    {
        MQTT_DATA_PARA_T *mqtt_data_para  = (MQTT_DATA_PARA_T *)calloc(mqtt_data_out->count, sizeof(MQTT_DATA_PARA_T));

        for(i = 0; i < mqtt_data_out->count; i++)
        {
            mqtt_data_para[i]=mqtt_data_out->outpara[i];
        }

        for(j=0; j < mqtt_data_out->count; j++)
        {
            for(i=0; i< Mqtt_point_num; i++)
            {
                if(mqtt_info1[i].date_type == 2 || mqtt_info1[i].date_type == 3)
                {
                    if((mqtt_data_para[j].datacode == mqtt_info1[i].datacode)&&(mqtt_data_para[j].deviceKey==mqtt_info1[i].mqttdeviceid))
                    {
                        mqtt_data_para[j].address = mqtt_info1[i].address;
                        mqtt_data_para[j].devcode = mqtt_info1[i].devcode;
                        mqtt_data_para[j].cmd = mqtt_info1[i].cmd;
                        mqtt_data_para[j].data_id = SDB_ND_GetDataIdByAddr(mqtt_data_para[j].devcode, 1, mqtt_data_para[j].address, mqtt_data_para[j].cmd);
                    }
                }
            }
        }

        for(j = 0; j < mqtt_data_out->count; j++)
        {
            WritePointCommand( mqtt_data_para[j].value, mqtt_data_para[j].devcode, 1, mqtt_data_para[j].data_id);
        }
        free(mqtt_data_para);
    }
    else
    {
        MQTTClient_freeMessage(&message);
        MQTTClient_free(topicName);
        free(mqtt_data->para);
        free(mqtt_data);
        free(times);
        return -1;
    }

    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    free(mqtt_data_out->outpara);
    free(mqtt_data_out);
    free(mqtt_data->para);
    free(mqtt_data);
    free(times);

    return 1;





/**********根据SE500代码修改，注释以下代码，若接受下发写测点有问题，需放开**********/
/********************修改时间：2024-04-24 by jinpan*********************************/

//     int Mqtt_point_num1 = GetMqttPonitFromXml(MQTT_XML, &idcount);
//
//     MQTT_T *mqtt_info2 = malloc(Mqtt_point_num1 * sizeof(MQTT_T));
//     memset(mqtt_info2, 0, sizeof(Mqtt_point_num1 * sizeof(MQTT_T)));
//     Mqtt_point_num1 = ParseMqttFromXml(MQTT_XML,mqtt_info2);
//     for(i=0;i<Mqtt_point_num1-1;i++)
//         for(j=i+1;j<Mqtt_point_num1;j++)
//         {
//             if(mqtt_info2[i].mqttdeviceid == mqtt_info2[j].mqttdeviceid)
//             {
//                 b[k1] = j;
//                 for(m=0;m<k1;m++)
//                 {
//                     if(b[k1] == b[m])
//                         k1--;
//                 }
//                 k1++;
//
//             }
//
//         }
//
//             uint32_t  *MqttDeviceIdKind = (uint32_t *)malloc(sizeof(uint32_t)*(Mqtt_point_num1-k1));
//             uint32_t MqttDeviceIdNums =Mqtt_point_num1-k1;
//
//             int n =0,q=0;
//             for(i=0;i<Mqtt_point_num1;i++)
//             {
//                 for(j=0;j<k1;j++)
//                 {
//                     if(i!=b[j])
//                     {
//                         n++;
//                         if(n == k1)
//                         {
//                              MqttDeviceIdKind[q] =  mqtt_info2[i].mqttdeviceid;
//                             n=0;
//                             q++;
//                         }
//                     }
//                     else
//                     {
//                         n=0;
//                         break;
//                     }
//                 }
//
//             }

//             MQTT_DATA_T *mqtt_data = (MQTT_DATA_T *)malloc(sizeof(MQTT_DATA_T)*(1));
//             mqtt_data->datacodeall = Mqtt_point_num1;
//             mqtt_data->deviceId = mqtt_info2[0].gatewayid;
//             mqtt_data->dataparacount = MqttDeviceIdNums;
//             mqtt_data->para  = (DATA_PARA_T *)malloc(sizeof(DATA_PARA_T)*(mqtt_data->dataparacount));

//             for(i = 0;i < MqttDeviceIdNums;i++)
//             {
//                 mqtt_data->para[i].datacodeparacount = 0;
//             }
//             for(i=0;i<MqttDeviceIdNums;i++)
//             {
//                 for(j=0;j<Mqtt_point_num1;j++)
//                 {
//                     if(mqtt_info2[j].mqttdeviceid == MqttDeviceIdKind[i])
//                     {
//                         mqtt_data->para[i].datacodeparacount++;
//                     }
//                 }
//
//             }

//             uint16_t *times = (uint16_t *)calloc(MqttDeviceIdNums,sizeof(uint16_t));

//             for(i=0;i<MqttDeviceIdNums;i++)
//             {
//                 mqtt_data->para[i].deviceKey = MqttDeviceIdKind[i];
//                 mqtt_data->para[i].datacodepara =calloc(mqtt_data->para[i].datacodeparacount,sizeof(DATACODE_PARA_T));
//                 for(j=0;j<Mqtt_point_num1;j++)
//                 {
//                     if(mqtt_info2[j].mqttdeviceid == MqttDeviceIdKind[i])
//                     {
//                          mqtt_data->para[i].datacodepara[times[i]] .datacode = mqtt_info2[j].datacode;
//                          times[i]++;
//                     }
//                 }
//             }

//             MQTT_DATA_OUTPARA_T *mqtt_data_out = NULL;
//             mqtt_data_out = MqttAnlysisJson((char *) message->payload,mqtt_data);
//             if(mqtt_data_out == NULL)
//             {
//                 printf("下发写测点不存在!\n");
//                 return -1;
//             }
//             MQTT_DATA_PARA_T *mqtt_data_para = (MQTT_DATA_PARA_T *)malloc(sizeof(MQTT_DATA_PARA_T)*(mqtt_data_out->count));
//             for(i=0; i< mqtt_data_out->count; i++)
//             {
//                 mqtt_data_para[i]=mqtt_data_out->outpara[i];
//             }

//             for(j=0; j < mqtt_data_out->count; j++)
//             {
//                 for(i=0; i< Mqtt_point_num1; i++)
//                 {
//                     if(mqtt_info2[i].date_type == 2||mqtt_info2[i].date_type == 3)
//                     {
//                         if((mqtt_data_para[j].datacode == mqtt_info2[i].datacode)&&(mqtt_data_para[j].deviceKey==mqtt_info2[i].mqttdeviceid))
//                         {
//                             mqtt_data_para[j].address = mqtt_info2[i].address;
//                             mqtt_data_para[j].devcode = mqtt_info2[i].devcode;
//                             mqtt_data_para[j].cmd = mqtt_info2[i].cmd;
//                             mqtt_data_para[j].data_id = SDB_ND_GetDataIdByAddr(mqtt_data_para[j].devcode, 1, mqtt_data_para[j].address, mqtt_data_para[j].cmd);
//                         }
//                     }
//                 }
//             }
//             for(j=0; j <mqtt_data_out->count; j++)
//             {
//                 WritePointCommand( mqtt_data_para[j].value, mqtt_data_para[j].devcode, 1, mqtt_data_para[j].data_id);
//             }

            //old version for e-FMC
        // 将接收到的MQTT消息写入系统
//         WritePointCommand(ret[3], ret[0], ret[1], ret[2]);

        // 将接收到的MQTT消息写入系统
//        int32_t deviceCode = 2849;
//        int32_t index = 1;
//        int32_t dataId = 1;
//        int32_t value = 666;
//        WritePointCommand(value, deviceCode, index, dataId);

//         MQTTClient_freeMessage(&message);
//         MQTTClient_free(topicName);
//         free(mqtt_data_out->outpara);
//         free(mqtt_data_out);
//         free(mqtt_info2);
//         free(MqttDeviceIdKind);
//         free(mqtt_data->para);
//         free(mqtt_data);
//         free(mqtt_data_para);
//         return 1;
    } else {
        // 其他的回调类型
        printf("Other Receive Topic: %s\n", topicName);
//
//         MQTTClient_freeMessage(&message);
//         printf("Receive topic: %s (L%d)\n", topicName, __LINE__);
//         MQTTClient_free(topicName);
//         printf("Receive topic: %s (L%d)\n", topicName, __LINE__);
        return 0;
    }
}


// 主题发布成功回调函数
void deliveryComplete(void *context, MQTTClient_deliveryToken dt) {
    printf("publish topic success,token = %d \n", dt);
    //free(context);
}

int32_t createMqttClient(MQTTClient *client) {
    // 1、定义一个MQTT客户端结构体指针
    char *mqttAddr = getMqttAddr();
    int32_t mqttPort = getMqttPort();

    PERSIST_NODE_INFO_T runLog;
    time_t now;
    struct tm *timenow;
    char timedata[30] = {0};

    char mqttUri[strlen(mqttAddr) + 8];
    sprintf(mqttUri, "%s:%d", mqttAddr, mqttPort);
    printf("The MQTT address of the new connection is:%s\n", mqttUri);

    // 2、创建一个MQTT客户端
    if (MQTTClient_create(client, mqttUri, g_webConfigMqttNew.clientId, MQTTCLIENT_PERSISTENCE_NONE, NULL) !=
        MQTTCLIENT_SUCCESS) {
        runLog.pcDescription = "Failed to create the mqtt client";
        time(&now);
        timenow = localtime(&now);
        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
        strcpy(runLog.date,timedata);
        strcpy( runLog.arrcDevName, "zero carbon gateway");
        Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
        return ERR_MQTT_CREATE_CLIENT;
    }

    // 3、创建一个MQTT连接配置结构体，并配置其参数
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;

    conn_opts.username = g_webConfigMqttNew.username;          // 用户名
    conn_opts.password = g_webConfigMqttNew.pwd;          // 用户名对应的密码
    conn_opts.keepAliveInterval = 60;       // 心跳时间
    conn_opts.cleansession = 0;             // 清除会话
//     conn_opts.maxInflightMessages = 1024 * 1024;
//     conn_opts.MQTTVersion = MQTTVERSION_5;

    // 4.设置MQTT连接时的回调函数
    if (MQTTClient_setCallbacks(*client, NULL, connectLost, messageArrived, deliveryComplete) !=
        MQTTCLIENT_SUCCESS) {
        runLog.pcDescription = "Failed to set the mqtt callback";
        time(&now);
        timenow = localtime(&now);
        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
        strcpy(runLog.date,timedata);
        strcpy( runLog.arrcDevName, "zero carbon gateway");
        Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
        return ERR_MQTT_SET_CALLBACK;
    }

    // 5、开始连接到MQTT服务器
    if (MQTTClient_connect(*client, &conn_opts) != MQTTCLIENT_SUCCESS) {
        runLog.pcDescription = "Failed to connect the mqtt broker";
        time(&now);
        timenow = localtime(&now);
        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
        strcpy(runLog.date,timedata);
        strcpy( runLog.arrcDevName, "zero carbon gateway");
        Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);

        return ERR_MQTT_CONNECT_FAIL;
    }
    printf("The MQTT server is connected successfully.\n");

    runLog.pcDescription = "MQTT server connected successfully";
    time(&now);
    timenow = localtime(&now);
    sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
    strcpy(runLog.date,timedata);
    strcpy( runLog.arrcDevName, "zero carbon gateway");
    Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);

    return SUCCESS_MQTT;
}

/********************************************
* Function name ：MqttPub
* Description   : 推送mqtt消息
* Parameter     ：
* Return        ：
*********************************************/
int32_t mqttPub(MQTTClient *client, char *jsonStr, char *topic) {

    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    pubmsg.payload = jsonStr;
    pubmsg.payloadlen = (int) strlen(jsonStr);
//     pubmsg.payloadlen = 1024*1024;
    pubmsg.qos = 1;
    pubmsg.retained = 0;
    MQTTClient_deliveryToken token;
//     sleep(5);
    printf("%d\n", pubmsg.payloadlen);
    rethj = MQTTClient_publishMessage(*client, topic, &pubmsg, &token);
    printf("%d\n", rethj);
    if ( rethj != MQTTCLIENT_SUCCESS) {
        const char* errorMessage = MQTTClient_strerror(rethj);
        printf("Failed to publish message, return code %d: %s\n", rethj, errorMessage);
        return ERR_MQTT_PUBLISH;
    }
    int ret = MQTTClient_waitForCompletion(*client, token, TIMEOUT);

    if(ret != 0)
    {
        printf("failed to wait for completion\n");
        return ERR_MQTT_PUBLISH;
    }
    return SUCCESS_MQTT;
}

/********************************************
* Function name ：MqttSub
* Description   : 接收mqtt消息
* Parameter     ：
* Return        ：
*********************************************/
int32_t mqttSub(MQTTClient *client, char *topic) {
    // 订阅主题
    if (MQTTClient_subscribe(*client, topic, 1) != MQTTCLIENT_SUCCESS) {
        return ERR_MQTT_SUBSCRIBE;
    }
    return SUCCESS_MQTT;
}

/********************************************
* Function name ：MqttInit
* Description   : mqtt模块的初始化工作
* Parameter     ：
* Return        ：
*********************************************/
int32_t mqttInit() {
    int32_t errCode = OK;

    errCode = createMqttClient(&g_MQTT_CLIENT);
    if (ERR_MQTT_CREATE_CLIENT == errCode) {
        printf("Failed to create the mqtt client. \n");
        return ERR;
    }
    if (ERR_MQTT_SET_CALLBACK == errCode) {
        printf("Failed to set the mqtt callback. \n");
        return ERR;
    }
    if (ERR_MQTT_CONNECT_FAIL == errCode) {
        printf("Failed to connect the mqtt broker. \n");
        return ERR;
    }

    mqttRegSucFlag = FALSE;  //mqtt注册成功标志位
    g_mqtt_handle.exist_value = FALSE;
    printf("******mqtt init ok!******\n");
    return 0;
}

int32_t mqttThreadInit() {

    int32_t nRetValue;
    nRetValue = pthread_mutex_init(&g_mqtt_handle.mLock, NULL);
    if (nRetValue < 0) {
        fprintf(stderr, "mutex init error:%s\n", strerror(errno));
        return nRetValue;
    }

    nRetValue = sem_init(&g_mqtt_handle.rwlock1, 0, 0);   //第二个参数0表示在一个进程间共享信号量,第三个参数表示信号量的初始值
    if (nRetValue < 0) {
        fprintf(stderr, "sem1 init error:%s\n", strerror(errno));
        return nRetValue;
    }

    nRetValue = sem_init(&g_mqtt_handle.rwlock2, 0, 1);
    if (nRetValue < 0) {
        fprintf(stderr, "sem2 init error:%s\n", strerror(errno));
        return nRetValue;
    }

    // 必须在信号量的初始化后面
    g_mqtt_handle.isRunning = TRUE;
    printf("Execute the MQTT initialization function.\n");
    return 0;
}

/********************************************
* Function name ：MqttUnInit
* Description   : mqtt模块的销毁工作
* Parameter     ：
* Return        ：
*********************************************/
int32_t mqttUnInit(void) {
    g_mqtt_handle.exist_value = FALSE;
    int32_t rc;

    // 判断mqtt客户端是否已连接
    int32_t isMqttConnected = MQTTClient_isConnected(g_MQTT_CLIENT);//   0：连接上     1：断开
//     printf("isMqttConnected:%d\n", isMqttConnected);
    if (TRUE == isMqttConnected)
    {
        printf("%s >>> MQTTClient_disconnect (L%d)\n", __func__, __LINE__);
        if ((rc = MQTTClient_disconnect(g_MQTT_CLIENT, 10000)) != MQTTCLIENT_SUCCESS)
        {
            printf("Failed to disconnect, return code %d\n", rc);
            rc = EXIT_FAILURE;
            return ERR;
        }
        MQTTClient_destroy(&g_MQTT_CLIENT);
        printf("Execute the MQTT client destroy.\n");
    }
    return 0;
}

int32_t mqttThreadUnInit() {
    g_mqtt_handle.isRunning = FALSE;
    g_mqtt_handle.exist_value = FALSE;

    int32_t rc;
    if ((rc = MQTTClient_disconnect(g_MQTT_CLIENT, 10000)) != MQTTCLIENT_SUCCESS) {
        printf("Failed to disconnect, return code %d\n", rc);
        rc = EXIT_FAILURE;
    }
    MQTTClient_destroy(&g_MQTT_CLIENT);

    int32_t nRetValue;
    nRetValue = pthread_mutex_destroy(&g_mqtt_handle.mLock);
    if (nRetValue < 0) {
        fprintf(stderr, "mutex destroy error:%s\n", strerror(errno));
        return nRetValue;
    }

    nRetValue = sem_destroy(&g_mqtt_handle.rwlock1);
    if (nRetValue < 0) {
        fprintf(stderr, "sem destroy error:%s\n", strerror(errno));
        return nRetValue;
    }

    nRetValue = sem_destroy(&g_mqtt_handle.rwlock2);
    if (nRetValue < 0) {
        fprintf(stderr, "sem destroy error:%s\n", strerror(errno));
        return nRetValue;
    }

    printf("Execute the MQTT thread destructor.\n");
    return 0;
}


// 填充MQTT数据,来自于Web.
void fillDataWebConfigMqtt(WEB_CONFIG_MQTT *temp) {

    // 记录上次的参数
    strcpy(g_webConfigMqttOld.mqtt_addr, g_webConfigMqttNew.mqtt_addr);
    g_webConfigMqttOld.mqtt_port = g_webConfigMqttNew.mqtt_port;
    g_webConfigMqttOld.is_use_mqtt = g_webConfigMqttNew.is_use_mqtt;
    g_webConfigMqttOld.is_encrypt = g_webConfigMqttNew.is_encrypt;
    g_webConfigMqttOld.upload_method = g_webConfigMqttNew.upload_method;
    g_webConfigMqttOld.all_upload_period = g_webConfigMqttNew.all_upload_period;
    memcpy(g_webConfigMqttOld.pubTopic, g_webConfigMqttNew.pubTopic, 128 * sizeof(char));
    memcpy(g_webConfigMqttOld.subTopic, g_webConfigMqttNew.subTopic, 128 * sizeof(char));
    memcpy(g_webConfigMqttOld.clientId, g_webConfigMqttNew.clientId, 128 * sizeof(char));
    memcpy(g_webConfigMqttOld.username, g_webConfigMqttNew.username, 128 * sizeof(char));
    memcpy(g_webConfigMqttOld.pwd, g_webConfigMqttNew.pwd, 128 * sizeof(char));

    // 获取最新的参数
    strcpy(g_webConfigMqttNew.mqtt_addr, temp->mqtt_addr);
    g_webConfigMqttNew.mqtt_port = temp->mqtt_port;
    g_webConfigMqttNew.is_use_mqtt = temp->is_use_mqtt;
    g_webConfigMqttNew.is_encrypt = temp->is_encrypt;
    g_webConfigMqttNew.upload_method = temp->upload_method;
    memcpy(g_webConfigMqttNew.pubTopic, temp->pubTopic, 128 * sizeof(char));
    memcpy(g_webConfigMqttNew.subTopic, temp->subTopic, 128 * sizeof(char));
    memcpy(g_webConfigMqttNew.clientId, temp->clientId, 128 * sizeof(char));
    memcpy(g_webConfigMqttNew.username, temp->username, 128 * sizeof(char));
    memcpy(g_webConfigMqttNew.pwd, temp->pwd, 128 * sizeof(char));
    memcpy(g_webConfigMqttNew.ip, temp->ip, 128 * sizeof(char));
    g_webConfigMqttNew.port = temp->port;

    g_webConfigMqttNew.all_upload_period = temp->all_upload_period;//(temp->all_upload_period == 0) ? 60 : 5;

//    printf("##################### 旧的mqtt地址：%s\n", g_webConfigMqttOld.mqtt_addr);
//    printf("##################### 旧的mqtt端口：%d\n", g_webConfigMqttOld.mqtt_port);
//    printf("##################### 旧的使用mqtt?：%d\n", g_webConfigMqttOld.is_use_mqtt);
//    printf("##################### 旧的是否加密?：%d\n", g_webConfigMqttOld.is_encrypt);
//    printf("##################### 旧的数据上传方式?：%d\n", g_webConfigMqttOld.upload_method);
//    printf("##################### 旧的数据上传周期?：%d\n", g_webConfigMqttOld.all_upload_period);
//
//    printf("********************* 新的mqtt地址：%s\n", g_webConfigMqttNew.mqtt_addr);
//    printf("********************* 新的mqtt端口：%d\n", g_webConfigMqttNew.mqtt_port);
//    printf("********************* 新的使用mqtt?：%d\n", g_webConfigMqttNew.is_use_mqtt);
//    printf("********************* 新的是否加密?：%d\n", g_webConfigMqttNew.is_encrypt);
//    printf("********************* 新的数据上传方式?：%d\n", g_webConfigMqttNew.upload_method);
//    printf("********************* 新的数据上传周期?：%d\n", g_webConfigMqttNew.all_upload_period);
    printf("************ receive mqtt parameters ************\n");
    printf("mqtt addr：%s\n", g_webConfigMqttNew.mqtt_addr);
    printf("mqtt port：%d\n", g_webConfigMqttNew.mqtt_port);
    printf("is use mqtt：%d\n", g_webConfigMqttNew.is_use_mqtt);
    printf("is encrypt：%d\n", g_webConfigMqttNew.is_encrypt);
    printf("upload_method：%d\n", g_webConfigMqttNew.upload_method);
    printf("upload_period：%d\n", g_webConfigMqttNew.all_upload_period);
    printf("pub topic：%s\n", g_webConfigMqttNew.pubTopic);
    printf("sub topic：%s\n", g_webConfigMqttNew.subTopic);
    printf("client id：%s\n", g_webConfigMqttNew.clientId);
    printf("username：%s\n", g_webConfigMqttNew.username);
    printf("password：%s\n", g_webConfigMqttNew.pwd);
    printf("ip:%s\n", g_webConfigMqttNew.ip);
    printf("port：%d\n", g_webConfigMqttNew.port);
    printf("*************************************************\n\n");

}

//tcp init

int32_t tcpInit()
{
//     struct sockaddr_in serv_addr;
    int ret;

    while(1)
    {
        // 创建套接字
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) {
            perror("ERROR opening socket");
            return -1;
        }
        //获取tcp ip port
        char *tcp_ip = getTcpIp();
        int32_t tcp_port = getTcpPort();

        // 设置服务器地址
        memset(&serv_addr, 0, sizeof(serv_addr));
        serv_addr.sin_family = AF_INET;
        serv_addr.sin_port = htons(tcp_port);
        if (inet_pton(AF_INET, tcp_ip, &serv_addr.sin_addr) <= 0) {
            perror("Invalid address");
            return -2;
        }

        // 连接服务器
        ret = connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr));
        if(ret < 0)
        {
            perror("connect fail");
            sleep(1);
//             continue;
            return -3;
        }
        printf("Successfully connected to TCP server[%s][%d]\n",tcp_ip, tcp_port);
        break;
    }
    return 0;
}

int32_t tcpConnStus()
{
    struct tcp_info info;
    int val_size;

//     while (1)
    {
    	 // 获取TCP信息
        val_size = sizeof(info);
        if (getsockopt(sockfd, IPPROTO_TCP, TCP_INFO, &info, &val_size) < 0) {
            perror("getsockopt failed");
            close(sockfd);
            return -1;
        }

        // 检查TCP状态
        if (info.tcpi_state != TCP_ESTABLISHED)
        {
            printf("The connection is not established or has been closed.\n");
            return -1;
        }
        else
        {
            printf("The connection is established.\n");
            return 0;
        }
//         if(info.tcpi_state != TCP_ESTABLISHED)
//         {
//             printf("Connection lost. Attempting to reconnect...\n");

            // 关闭并清理套接字
//             close(sockfd);
//             sockfd = -1;

            // 等待一段时间后重连
//             sleep(1);

            // 重连到服务器
//             sockfd = socket(AF_INET, SOCK_STREAM, 0);
//             if (sockfd < 0) {
//                 perror("ERROR opening socket");
//                 return -2;
//             }
//             if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
//                 perror("ERROR connecting");
//                 return -3;
//             }
            //获取tcp ip port
//             char *tcp_ip = getTcpIp();
//             int32_t tcp_port = getTcpPort();
//
//             printf("Reconnected to tcp server [%s][%d].\n", tcp_ip, tcp_port);
//         }
    }
//     return 0;
}


// 获取数据的接口函数
char *getMqttAddr() {
    return g_webConfigMqttNew.mqtt_addr;
}

int32_t getMqttPort() {
    return g_webConfigMqttNew.mqtt_port;
}

BOOL getIsUseMqtt() {
    return g_webConfigMqttNew.is_use_mqtt;
}

BOOL getIsEncrypt() {
    return g_webConfigMqttNew.is_encrypt;
}

BOOL getUploadMethod() {
    return g_webConfigMqttNew.upload_method;
}

uint32_t getAllUploadPeriod() {
    return g_webConfigMqttNew.all_upload_period;
}
char* getClientId() {
    return g_webConfigMqttNew.clientId;
}

char* getPubTopic() {
    return g_webConfigMqttNew.pubTopic;
}

char* getSubTopic() {
    return g_webConfigMqttNew.subTopic;
}

int32_t getTcpPort() {
    return g_webConfigMqttNew.port;
}

char* getTcpIp() {
    return g_webConfigMqttNew.ip;
}


//===============================未使用的函数===========================================================
//
//MQTT_HANDLE_T* MqttInit()
//{
//    MQTT_HANDLE_T *mqttHandle= (MQTT_HANDLE_T *)malloc(sizeof(MQTT_HANDLE_T));
//    if (mqttHandle == NULL)
//    {
//        return NULL;
//    }
//    mqttHandle->isRunning = TRUE;
//
//    // 创建mqtt数据发送线程
//    int32_t res = 0;
//    res = pthread_create(&mqttHandle->subThread, NULL, creatMqttThread, mqttHandle);
//    if (res != 0)
//    {
//        perror("Thread mqttThread creation failed");
//        exit(EXIT_FAILURE);
//    }
//
//    return mqttHandle;
//}
//
//
//int32_t MqttUninit(MQTT_HANDLE_T*handle)
//{
//    MQTT_HANDLE_T *mqttHandle = (MQTT_HANDLE_T *)handle;
//    if (mqttHandle == NULL || handle == INVALID_VALUE)
//    {
//        return -1;
//    }
//
//    mqttHandle->isRunning = FALSE;
//
//    void *rtest;
//    if (mqttHandle->pubThread)
//    {
//        pthread_join(mqttHandle->pubThread, &rtest);
//        printf("pubThread join done.\n");
//    }
//
//    if (mqttHandle->subThread)
//    {
//        pthread_join(mqttHandle->subThread, &rtest);
//        printf("subThread join done.\n");
//    }
//    return 0;
//
//}

