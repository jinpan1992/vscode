/********************************************************************************
* @File name: secret_key_registration.c
* @Author:
* @Version: 1.0
* @Date: 2022/11/22 3:29 PM
* @Description: 秘钥交互相关函数过程
****************************************************************************/

#include "mqtt_secret_key_registration.h"

char SESSION_KEY[128] = "1234567890123456 ";

/********************************************
* Function name ：create_registration
* Description   : 边设备发起注册请求
* Parameter：
* Return：加密后的密文
*********************************************/
char *createRegistration() {
    //使用session_key对称加密magic_string
    int outLen = 0;
    unsigned char *aes_enc_magic_string = aesEncrypt((unsigned char *) MAGIC_STRING, strlen(MAGIC_STRING),
                                                     (unsigned char *) SESSION_KEY, &outLen);
    // printf("session_key加密magic_string: %s\r\n", aes_enc_magic_string);

    // 注册报文拼接字符串
    char *timeStr = getTime();
    char *reg_message = (char *) malloc(
            strlen(SN) + strlen(SESSION_KEY) + strlen((const char *) aes_enc_magic_string) + strlen(timeStr) + 4);
    sprintf(reg_message, "%s_%s_%s_%s", SN, SESSION_KEY, aes_enc_magic_string, timeStr);
    // printf("注册报文: %s\r\n", reg_message);

    // 使用RSA非对称加密整体的注册报文
    int num = 0;
    BOOL newLine = FALSE;
    char *ptr_en;
    ptr_en = rsaEncrypt(reg_message, PUBLICKEY);

    // daisy 实际长度（不可使用strlen求取，字符串中可能含有结束符等）
    // 简单粗暴的方法。判断从当前指针指向的字符开始，往后3位均为空，则判定当前到达字符串末尾
    while (!((*(ptr_en + num) == '\0') && (*(ptr_en + num + 1) == '\0') \
 && (*(ptr_en + num + 2) == '\0') && (*(ptr_en + num + 3) == '\0'))) {
        num++;
    }
    // base64编码
    char *rsa_base64_encode = base64Encode(ptr_en, num, newLine);
    // printf("rsa加密,base64编码后:%s\n", rsa_base64_encode);

    if (ptr_en != NULL) {
        free(ptr_en);
    }
    free(timeStr);
    timeStr = NULL;
    return rsa_base64_encode;
}

/********************************************
* Function name ：create_registration
* Description   : 边设备发送注册报文
* Parameter：
* Return：
*********************************************/
int32_t pubMessage() {
    // 注册加密
    char *regMessage = createRegistration();

    // 转化为json格式
    char *jsonStr = PubMessageEncodeJson(regMessage);

    // 通过mqtt发送出去
    int32_t errCode = OK;
    errCode = mqttPub(&g_MQTT_CLIENT, jsonStr, Topic_Pub_Reg);
    if (ERR_MQTT_PUBLISH == errCode) {
        printf("Failed to send registration packets by the mqtt protocol.\n");
        return ERR;
    }
    //printf("发送出去的注册报文: %s\n", jsonStr);

    // 释放返回json字符串的内存
    free(jsonStr);
    jsonStr = NULL;
    return 0;
}



