//
// Created by root on 11/22/22.
//

#ifndef MYCEMS_SECRET_KEY_REGISTRATION_H
#define MYCEMS_SECRET_KEY_REGISTRATION_H
#include "mqtt.h"
#include "mqtt_config.h"

int32_t pubMessage();
char* createRegistration();

#endif //MYCEMS_SECRET_KEY_REGISTRATION_H
