#include "mqtt_ens_cypt.h"

/*************************************AES*********************************************************/
//char * base64Encode(const char *buffer, int length, int newLine);
char * base64Decode(char *input, int length, int newLine);

void handleOpenSSLErrors(void)
{
    unsigned long errCode;
    errCode = 0;

    printf("An error occurred\n");
    while(errCode == ERR_get_error()) {
        char *err = ERR_error_string(errCode, NULL);
        printf("%s\n", err);
    }
    //abort();
}

/********************************************
* Function name ：AES_CBC_PKCS5_BASE64_Encrypt
* Description : AES_CBC_PKCS5_BASE64
* Parameter ：* src:明文
              * srcLen:明文长度
              * key:密钥 长度只能是16/24/32字节 否则OPENSSL会对key进行截取或PKCS0填充
              * keyLen:密钥长度
* Return ：密文base64后的字符串，使用后请free
*********************************************/
unsigned char *aesEncrypt(unsigned char *src, int srcLen, unsigned char *key, int *outLen)
{
    //int keyLen=16;
    unsigned char iv[17] = "0000000000000000";
    EVP_CIPHER_CTX *ctx = NULL;
    char * res = NULL;
    int blockCount;
    int quotient = srcLen / AES_BLOCK_SIZE;
    int mod = srcLen % AES_BLOCK_SIZE;
    blockCount = quotient + 1;

    int padding = AES_BLOCK_SIZE - mod;
    char *in = (char *)malloc(AES_BLOCK_SIZE*blockCount);
    memset(in, padding, AES_BLOCK_SIZE*blockCount);
    memcpy(in, src, srcLen);

    //out
    char *out = (char *)malloc(AES_BLOCK_SIZE*blockCount);
    memset(out, 0x00, AES_BLOCK_SIZE*blockCount);
    *outLen = AES_BLOCK_SIZE*blockCount;

    do {
        if(!(ctx = EVP_CIPHER_CTX_new())) {
            handleOpenSSLErrors();
            break;
        }

//         if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv)) {
        if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_128_ecb(), NULL, key, NULL)) {
            handleOpenSSLErrors();
            break;
        }

        if(1 != EVP_EncryptUpdate(ctx, (unsigned char*)out, outLen, (const unsigned char *)in, AES_BLOCK_SIZE*blockCount)) {
            handleOpenSSLErrors();
            break;
        }
        res = base64Encode(out, *outLen, 0);
    }while(0);

    free(in);
    free(out);
    if (ctx != NULL)
        EVP_CIPHER_CTX_free(ctx);

    return (unsigned char*)res;
}

/********************************************
* Function name ：AES_CBC_PKCS5_BASE64_Decrypt
* Description : AES解密函数
* Parameter ：* src:base64编码后的密文
              * srcLen:密文长度
              * key:密钥 长度只能是16/24/32字节 否则OPENSSL会对key进行截取或PKCS0填充
              * keyLen:密钥长度
              * outLen:明文长度
* Return ：明文,使用后请free
*********************************************/
unsigned char *aesDecrypt(unsigned char *src, int srcLen, unsigned char *key,  int *outLen)
{
    //int keyLen=16;
    unsigned char iv[17] = "0000000000000000";
    EVP_CIPHER_CTX *ctx = NULL;
    char *in = base64Decode((char *)src, srcLen, 0);
    unsigned char *out = (unsigned char*)malloc(srcLen);
    do {
        /* Create and initialise the context */
        if(!(ctx = EVP_CIPHER_CTX_new())) {
            handleOpenSSLErrors();
            break;
        }

        /* Initialise the encryption operation. IMPORTANT - ensure you use a key
        * and IV size appropriate for your cipher
        * In this example we are using 256 bit AES (i.e. a 256 bit key). The
        * IV size for *most* modes is the same as the block size. For AES this
        * is 128 bits */
//         if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv)) {
        if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_128_ecb(), NULL, key, NULL)) {
            handleOpenSSLErrors();
            break;
        }

        if(1 != EVP_DecryptUpdate(ctx, out, outLen, (unsigned char *)in, srcLen*3/4)) {
            handleOpenSSLErrors();
            break;
        }
    }while(0);
    free(in);
    if (ctx != NULL)
        EVP_CIPHER_CTX_free(ctx);

    //PKCS5 UNPADDING
    int unpadding = out[*outLen - 1];
    *outLen = *outLen - unpadding;
    out[*outLen] = '\0';
    return (unsigned char*)out;
}

//int aes_main(int argc, char *argv[])
//{
//    int outLen = 0;
//    unsigned char data[] = "12345";          //原始数据
//    char strKey[128] = "7854156156611111";   // 秘钥
//
//    char *res = AesEncrypt(data, strlen(data), strKey, &outLen);
//    printf("the result: %s\r\n", res);
//
//    char *res2 = AesDecrypt(res, strlen(res), strKey, &outLen);
//    printf("the org: %s \r\n", res2);
//}


// base64 编码
char * base64Encode(const char *buffer, int length, int newLine)
{
    BIO *bmem = NULL;
    BIO *b64 = NULL;
    BUF_MEM *bptr;

    b64 = BIO_new(BIO_f_base64());
    if (!newLine) {
        BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
    }
    bmem = BIO_new(BIO_s_mem());
    b64 = BIO_push(b64, bmem);
    BIO_write(b64, buffer, length);
    BIO_flush(b64);
    BIO_get_mem_ptr(b64, &bptr);
    BIO_set_close(b64, BIO_NOCLOSE);

    char *buff = (char *)malloc(bptr->length + 1);
    memcpy(buff, bptr->data, bptr->length);
    buff[bptr->length] = 0;
    BIO_free_all(b64);

    return buff;
}

// base64 解码
char * base64Decode(char *input, int length, int newLine)
{
    BIO *b64 = NULL;
    BIO *bmem = NULL;
    char *buffer = (char *)malloc(length);
    memset(buffer, 0, length);
    b64 = BIO_new(BIO_f_base64());
    if (!newLine) {
        BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
    }
    bmem = BIO_new_mem_buf(input, length);
    bmem = BIO_push(b64, bmem);
    BIO_read(bmem, buffer, length);
    BIO_free_all(bmem);

    return buffer;
}

/*************************************RSA*********************************************************/


/*************************************************
  Function:    		rsa_encrypt
  Description:		RSA加密
  Input:
  	1.str			需加密的数据字符串
  	2.path_key		公钥存储文件路径
  Output:
  Return:			转化后的字符串指针
  Others:
*************************************************/
char *rsaEncrypt(char *str,char *path_key){
    char *p_en;
    RSA *p_rsa;
    FILE *file;
    int rsa_len;
    int in_len;
    if((file=fopen(path_key,"r"))==NULL){
        perror("open key file error");
        return NULL;
    }
    if((p_rsa=PEM_read_RSA_PUBKEY(file,NULL,NULL,NULL))==NULL){
        //if((p_rsa=PEM_read_RSAPublicKey(file,NULL,NULL,NULL))==NULL){
        ERR_print_errors_fp(stdout);
        return NULL;
    }
    rsa_len=RSA_size(p_rsa);
    p_en=(char *)malloc(rsa_len+1);
    memset(p_en,0,rsa_len+1);

    in_len = (int)strlen(str);

    if(RSA_public_encrypt(in_len,(unsigned char *)str,(unsigned char*)p_en,p_rsa,RSA_PKCS1_PADDING)<0){
        printf("RSA_public_encrypt error! \n");
        return NULL;
    }
    RSA_free(p_rsa);
    fclose(file);
    return p_en;
}


/*************************************************
  Function:    		rsa_decrypt
  Description:		RSA解密
  Input:
  	1.str			需解密的数据字符串
  	2.path_key		私钥存储文件路径
  Output:
  Return:			转化后的字符串指针
  Others:
*************************************************/
char *rsa_decrypt(char *str,char *path_key){
    char *p_de;
    RSA *p_rsa;
    FILE *file;
    int rsa_len;
    int in_len;
    if((file=fopen(path_key,"r"))==NULL){
        perror("open key file error");
        return NULL;
    }
    if((p_rsa=PEM_read_RSAPrivateKey(file,NULL,NULL,NULL))==NULL){
        ERR_print_errors_fp(stdout);
        return NULL;
    }
    rsa_len=RSA_size(p_rsa);
    p_de=(char *)malloc(rsa_len+1);
    memset(p_de,0,rsa_len+1);

    in_len = (int)strlen(str);

    if(RSA_private_decrypt(in_len,(unsigned char *)str,(unsigned char*)p_de,p_rsa,RSA_PKCS1_PADDING)<0){
        printf("RSA_private_decrypt error! \n");
        return NULL;
    }
    RSA_free(p_rsa);
    fclose(file);
    return p_de;
}
