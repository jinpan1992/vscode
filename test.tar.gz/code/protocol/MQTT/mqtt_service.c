#include <pthread.h>
#include <signal.h>
#include "mqtt_service.h"
#include <sys/select.h>
#include <sys/time.h>
#include "mqtt_run_data_pub.h"
#include "persist.h"

extern int32_t correspond_index;
pthread_t history_mqtt;
int history_Send_Flag = 0;
BOOL createMqttOnceFlag = TRUE;
BOOL reCreatMqttThreadFlag = FALSE;
BOOL createTcpOnceFlag = TRUE;
BOOL reCreatTcpThreadFlag = FALSE;
int Net_Flag = 0;   //网络中断标志位,初始化为0，若中断，置为1；恢复网络连接，置为0
pthread_t history_tcp;
pthread_t TH_MQTT;
pthread_t TH_TCP;
pthread_t tcp_recv;

// 判断旧的参数是否存在
BOOL isMqttValueExist() {
    if ((g_webConfigMqttNew.mqtt_port == 0) || (g_webConfigMqttNew.all_upload_period == 0))
        return FALSE;
    return TRUE;
}

// 判断新的参数和旧的参数是否发生了变化
BOOL isMqttAddrChange() {
    if ((g_webConfigMqttNew.mqtt_port != g_webConfigMqttOld.mqtt_port) ||
        (strcmp(g_webConfigMqttNew.mqtt_addr, g_webConfigMqttOld.mqtt_addr) != 0))
        return TRUE;
    return FALSE;
}

// 统一新旧参数信息
void unifyMqttParameters() {
    strcpy(g_webConfigMqttOld.mqtt_addr, g_webConfigMqttNew.mqtt_addr);
    g_webConfigMqttOld.mqtt_port = g_webConfigMqttNew.mqtt_port;
    g_webConfigMqttOld.is_use_mqtt = g_webConfigMqttNew.is_use_mqtt;
    g_webConfigMqttOld.is_encrypt = g_webConfigMqttNew.is_encrypt;
    g_webConfigMqttOld.upload_method = g_webConfigMqttNew.upload_method;
    g_webConfigMqttOld.all_upload_period = g_webConfigMqttNew.all_upload_period;
}


// 参数更新入口
void updateMqttParameters(WEB_CONFIG_MQTT *mqttConfig) {
    /* 将新的参数存入到全局变量中 */
    fillDataWebConfigMqtt(mqttConfig);

    // 创建mqtt线程
    if (TRUE == createMqttOnceFlag) {
        pthread_create(&TH_MQTT, NULL, mqttThread, NULL);
        createMqttOnceFlag = FALSE;
    }

    //创建tcp线程
    if (TRUE == createTcpOnceFlag) {
        pthread_create(&TH_TCP, NULL, tcpThread, NULL);
        createTcpOnceFlag = FALSE;
    }

    // 判断MQTT线程是否存在()
    int32_t kill_mqtt = pthread_kill(TH_MQTT, 0);
    if(EINVAL == kill_mqtt)
        printf("mqtt signal is invalid\n");
    else if (ESRCH == kill_mqtt) {
        printf("the MQTT thread is not exist, id = %lx \n", TH_MQTT);
        pthread_create(&TH_MQTT, NULL, mqttThread, NULL);
        reCreatMqttThreadFlag = TRUE;
    } else{
        printf("the MQTT thread is exist, id = %lx \n", TH_MQTT);
    }

    // 判断TCP线程是否存在()
    int32_t kill_tcp = pthread_kill(TH_TCP, 0);
    if(EINVAL == kill_tcp)
        printf("tcp signal is invalid\n");
    else if (ESRCH == kill_tcp) {
        printf("the TCP thread is not exist, id = %lx \n", TH_TCP);
        pthread_create(&TH_TCP, NULL, tcpThread, NULL);
        reCreatTcpThreadFlag = TRUE;
    } else{
        printf("the TCP thread is exist, id = %lx \n", TH_TCP);
    }
}

// 创建一个mqtt线程,接收来自于web的参数
void *mqttThread(void *arg) {
    int32_t errCode = OK;
    int32_t mqttInitCode = OK;
    char *runDataJson = NULL;
    int32_t res;

    FILE *file;
    FILE *recordsave;
    FILE *recordsaveout;
    long file_size = 0;
    int FileCnt = 0;
    int FileMaxCnt = 0;
    char filename[40] = {0};
    int firstflag = 0;

    PERSIST_NODE_INFO_T runLog;
    time_t now;
    struct tm *timenow;
    char timedata[30] = {0};
    int recordFlg = 0;//记录网络状态以及断点数据记录标志位


    // 初始化mqtt线程参数
    mqttThreadInit();
    printf("g_mqtt_handle.isRunning:%d\n", g_mqtt_handle.isRunning);
    while (g_mqtt_handle.isRunning) {
//         usleep(1000);
        // 获取相关参数变化情况
        BOOL isExist = isMqttValueExist();
        // 如果没有获取到参数，则跳过此次循环
        if (FALSE == isExist) {
            sleep(1);
            continue;
        }

        // 如果不使用mqtt，则跳出此次循环
        BOOL isUseMqtt = getIsUseMqtt();
        if (FALSE == isUseMqtt) {
            sleep(1);
            continue;
        }

        // 网络连通性检测
        errCode = sysPingDetect();
//         errCode = DetectNet();
//         printf("errcode:%d\n", errCode);
        if(OK != errCode)
        {
            IS_MQTT_DISCONNECT = 1;//网络断连后，未调用mqtt回调函数设置连接状态标志位
            //*
            printf("*******Network disconnection**********\n");
            if(recordFlg == 0)
            {
                runLog.pcDescription = "Network disconnection";
                time(&now);
                timenow = localtime(&now);
                sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                strcpy(runLog.date,timedata);
                strcpy( runLog.arrcDevName, "zero carbon gateway");
                Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
                recordFlg = 1;
            }


            if(history_Send_Flag == 2)
            {
                res = pthread_cancel(history_mqtt);
                if (res != 0)
                {
                    printf("线程运行结束or终止 history_mqtt 线程失败\n");
                }
                else if(res == 0)
                {
                    printf("终止 history_mqtt 线程sucess\n");
                }
            }
            history_Send_Flag = 1;

            // 获取南向全量数据
            getAllRunData();

            // 将运行数据转化为json格式
            runDataJson = RunDataEncodeJson(&g_mqtt_handle, 1);

            printf("@@@Send history data packets with clear txt %s\n", runDataJson);

            if(Net_Flag != 2)//第一次中断或网络连接上后中断，将Net_Flag置 1,且初始化一次
            {
                Net_Flag  = 1;
                //先读取文件，判断当前是否还有文件未读取完
                recordsave = fopen("save.txt", "r");
                if(recordsave == NULL)
                {
                    printf("open error! create save.txt\n");
                    firstflag = 1;
                }
                else
                {
                    fscanf(recordsave, "%d %d", &FileCnt, &FileMaxCnt);
                    if(FileCnt != 0 && FileMaxCnt != 0)
                    {
                        printf("save.txt: %d %d\n", FileCnt, FileMaxCnt);
                    }
                    fclose(recordsave);
                    recordsave = NULL;
                }
                if(firstflag == 1)//网络第一次中断，没有save.txt文件，需初始化参数
                {
                    //重新打开并初始化
                    recordsave = fopen("save.txt", "w");
                    fprintf(recordsave, "%d %d", FileCnt+1, FileMaxCnt+1);
                    fclose(recordsave);
                    recordsave = NULL;
                }
            }
//             if(Net_Flag == 1)
            {
                // 首次中断或者内存卡中没有文件，网络中断后初始化一次
                if((FileCnt == 0 && Net_Flag == 1) || (firstflag == 1))
                {
                    //当前存储卡中没有断点续传数据
                    //count从1计数
                    FileCnt = FileCnt + 1;
                    FileMaxCnt = FileCnt;

                    //记录FileCnt, FileMaxCnt
                    recordsave = fopen("save.txt", "w");
                    if(recordsave == NULL)
                    {
                        perror("fopen");
                    }
                    fprintf(recordsave, "%d %d", FileCnt, FileMaxCnt);
                    fclose(recordsave);
                    recordsave = NULL;

//                     sprintf(filename, "/media/mmcblk0p1/count_%d.txt", FileMaxCnt); // 将数字转换为字符串
                    sprintf(filename, "count_%d.txt", FileMaxCnt); // 将数字转换为字符串
                    file = fopen(filename, "a+");
                    if (file == NULL)
                    {
                        printf("can not open filename：%s\n", filename);
                        return NULL;
                    }
                    Net_Flag = 2;
                    firstflag = 0;
                }
                //非首次中断，且网络连接上后数据未全部读取完后又中断，网络中断后初始化一次
                if((FileCnt != 0 && Net_Flag == 1) || (firstflag == 1))
                {
                    //打开文件
//                     sprintf(filename, "/media/mmcblk0p1/count_%d.txt", FileMaxCnt); // 将数字转换为字符串
                    sprintf(filename, "count_%d.txt", FileMaxCnt); // 将数字转换为字符串
                    file = fopen(filename, "a+");

                    if (file == NULL)
                    {
                        printf("can not open filename：%s\n", filename);
                        return NULL;
                    }
                    Net_Flag = 2;
                    firstflag = 0;
                }

                //判断文件个数
                //小于等于40个文件
                if((FileMaxCnt - FileCnt + 1) <= MAX_TXT_NUM)
                {
                    // 检查文件大小是否超过限制
                    fseek(file, 0, SEEK_END);//移动文件指针到文件末尾
                    file_size = ftell(file);//获取文件大小
                    fseek(file, 0, SEEK_SET);//将文件指针恢复到初始位置，不影响文件后续操作
                    printf("size:%ld %ld\n", file_size, strlen(runDataJson));

                    if(labs(file_size - MAX_FILE_SIZE) < (strlen(runDataJson)))
                    {
                        printf("over txt size\n");
                        fclose(file);
                        file = NULL;

                        //创建新的文件
                        FileMaxCnt = FileMaxCnt + 1;//更新文件索引名
                        if((FileMaxCnt - FileCnt + 1) > MAX_TXT_NUM)//记录文件超过40个
                        {
                            //删除FileCnt对应的文件
//                             sprintf(filename, "/media/mmcblk0p1/count_%d.txt", FileCnt); // 将数字转换为字符串
                            sprintf(filename, "count_%d.txt", FileCnt); // 将数字转换为字符串
                            remove(filename);
                            //FileCnt索引更新
                            FileCnt = FileCnt + 1;
                            //record over file num and remove
                            runLog.pcDescription = "delete history data";
                            time(&now);
                            timenow = localtime(&now);
                            sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                            strcpy(runLog.date,timedata);
                            strcpy( runLog.arrcDevName, "zero carbon gateway");
                            Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
                        }
//                         sprintf(filename, "/media/mmcblk0p1/count_%d.txt", FileMaxCnt); // 将数字转换为字符串
                        sprintf(filename, "count_%d.txt", FileMaxCnt); // 将数字转换为字符串

                        file = fopen(filename, "a+");
                        if (file == NULL) {
                            printf("can not open filename：%s\n", filename);
                            return NULL;
                        }
                        //写入数据
                        fprintf(file, "%s\n", runDataJson);
                        printf("new file and write!\n");

                        //将 FileCnt和FileMaxCnt保存到文件中
                        recordsave = fopen("save.txt", "w");
                        if(recordsave == NULL)
                        {
                            perror("fopen");
                        }
                        fprintf(recordsave, "%d %d", FileCnt, FileMaxCnt);
                        fclose(recordsave);
                        recordsave = NULL;
                        printf("save ok!\n");
                    }
                    else
                    {
                        //写入数据
                        fprintf(file, "%s\n", runDataJson);
                        printf("complete write\n");
                    }
                    if(recordFlg == 1)
                    {
                        runLog.pcDescription = "breakpoint data saving";
                        time(&now);
                        timenow = localtime(&now);
                        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                        strcpy(runLog.date,timedata);
                        strcpy( runLog.arrcDevName, "zero carbon gateway");
                        Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
                        recordFlg = 0;
                    }
                }
            }

            //*/
//             sleep(4);
            continue;

        }
        else
        {
            //*
            printf("*******Network is successfully connected*******\n");
            if(Net_Flag != 0)
            {
                fclose(file);
                printf("close history date save!\n");
                file = NULL;

                runLog.pcDescription = "Network restore connection, stop data saving";
                time(&now);
                timenow = localtime(&now);
                sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                strcpy(runLog.date,timedata);
                strcpy( runLog.arrcDevName, "zero carbon gateway");
                Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
            }
            Net_Flag = 0;//网络恢复连接，或者网络本身正常

            recordsaveout = fopen("save.txt", "r");
            if(recordsaveout == NULL)
            {
                printf("open error! no history date\n");
            }
            else
            {
                int count, count_max;
                fscanf(recordsaveout, "%d %d", &count, &count_max);
                fclose(recordsaveout);
                recordsaveout = NULL;
//                 printf("2@count: %d, count_max: %d\n", count, count_max);
                if((count_max != 0)&&(count != 0)&&(history_Send_Flag != 2 ))
                {
                    pthread_attr_t attr;
                    pthread_attr_init (&attr);
                    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
                    int detachstate;
                    // 获取线程属性中的分离状态
                    pthread_attr_getdetachstate(&attr, &detachstate);
                    printf("Detach state after setting: %d PTHREAD_CREATE_DETACHED = %d\n", detachstate,PTHREAD_CREATE_DETACHED);
                    pthread_create(&history_mqtt, &attr, history_mqttThread, NULL);
//                     pthread_create(&history_mqtt, NULL, history_mqttThread, NULL);
                    history_Send_Flag = 2;
                }
            }//*/
        }

        // mqtt 地址是否发生变化
        BOOL mqttAddrChange = isMqttAddrChange();
//         printf("start enter 305->306, %d %d %d\n", mqttAddrChange, reCreatMqttThreadFlag, IS_MQTT_DISCONNECT);//mqtt初始化入口判断
        if (TRUE == mqttAddrChange || TRUE == reCreatMqttThreadFlag || TRUE == IS_MQTT_DISCONNECT)  {

            /* 统一新旧参数信息 */
            unifyMqttParameters();
            printf("mqttAddrChange=%d  reCreatMqttThreadFlag=%d  IS_MQTT_DISCONNECT =%d \n",
                   mqttAddrChange,reCreatMqttThreadFlag,IS_MQTT_DISCONNECT);
            /* 销毁mqtt相关参数、内存空间 */
            errCode = mqttUnInit();
            if (errCode != OK) {
                printf("Failed to destroy the MQTT protocol\n");
                continue;
            }
            /* mqtt相关的初始化 */
            mqttInitCode = mqttInit();
//             printf("%d\n", mqttInitCode);
            if (mqttInitCode != OK) {
                printf("Failed to initialize the MQTT protocol\n");
                mqttUnInit();
                IS_MQTT_DISCONNECT = TRUE;
                continue;
            }

            // 将MQTT断开连接的标志位恢复为FALSE
            if(IS_MQTT_DISCONNECT){
                IS_MQTT_DISCONNECT = FALSE;
            }

            // 重新创建线程
            if (reCreatMqttThreadFlag){
                printf("recreated a new MQTT client successful.\n");
                reCreatMqttThreadFlag = FALSE;
            }

            /* 接收mqtt命令下发指令 */
            errCode = mqttSub(&g_MQTT_CLIENT, getSubTopic());
            if (errCode != OK) {
                printf("Failed to subscribe the MQTT topic:%s\n", getSubTopic());
                mqttUnInit();
                continue;
            }

            /* 接收mqtt回复的报文 */
//             errCode = mqttSub(&g_MQTT_CLIENT, Topic_Sub_Reg);
//             if (errCode != OK) {
//                 printf("Failed to subscribe the MQTT topic:%s\n", Topic_Sub_Reg);
//                 mqttUnInit();
//                 continue;
//             }
        }

        if (OK != mqttInitCode) {
            //printf("The MQTT protocol initialize was failed, and skill loop. \n");
            sleep(5);
            continue;
        }

        BOOL isEncrypt = getIsEncrypt();
        // 如果不加密
        if (FALSE == isEncrypt) {
            /* 发送运行数据 */
            errCode = runDataPub();
//             printf("***427**errCode:%d\n", errCode);
            if (errCode != OK) {
                mqttUnInit();
                printf("mqttUninit done!\n");
                continue;
            }
        }
        else {
            // 如果加密，但秘钥交互未完成
//             if (FALSE == mqttRegSucFlag)
//             {
//                 sleep(10);       // 延时10s
//                 errCode = pubMessage();  // 发送注册报文
//                 if (errCode != OK) {
//                     mqttUnInit();
//                     continue;
//                 }
//                 printf("The MQTT registration packet is sent.\n");
//             }
//                 // 如果加密，且秘钥交互已完成
//             else
            {
                printf("加密数据发送\n");
                /* 发送运行数据 */
                errCode = runDataPub();
                if (errCode != OK) {
                    mqttUnInit();
                    continue;
                }
            }
        }
    }
    /* 销毁mqtt相关参数、内存空间 */
    mqttThreadUnInit();
    return NULL;
}

//读取断点历史mqtt数据包
void *history_mqttThread(void *arg)
{
    struct timeval tmpTime;

    int32_t errCode = OK;
    int i =0,count_Line = 0;
    char name[40]= {};
    char buf[128] = {0};
    int len  = 0 ;
    int read_json_count = 0;

    PERSIST_NODE_INFO_T runLog;
    time_t now;
    struct tm *timenow;
    char timedata[30] = {0};

    FILE *fp = fopen("save.txt", "r");
    if (fp == NULL)
    {
        printf("Failed to open file.\n");
    }
    int count, count_max;
    fscanf(fp, "%d %d", &count, &count_max);
    fclose(fp);
    fp = NULL;
    printf("1@count: %d, count_max: %d\n", count, count_max);
    sleep(2);//获取g_mqtt_handle.MqttDeviceIdNums，但是实时上传解析的g_mqtt_handle.MqttDeviceIdNums还没有赋值所以延时
    printf("g_mqtt_handle.MqttDeviceIdNums: %d %s (L%d)\n", g_mqtt_handle.MqttDeviceIdNums,__func__,__LINE__);
    char *send_buf = (char *)malloc((correspond_index+g_mqtt_handle.MqttDeviceIdNums*3+9)*128*sizeof(char));
    memset(send_buf, 0, (correspond_index+g_mqtt_handle.MqttDeviceIdNums*3+9)*128*sizeof(char));


    //从上一次没有读取完的的文件位置读取数据
    int count_1, offset_1;
    FILE *fp5 = fopen("last_position.txt", "r");
    if(fp5 == NULL)
    {
        printf("open error or ! last_position txt absent! \n");
    }
    else
    {
        fscanf(fp5, "%d %d", &count_1, &offset_1);
        fclose(fp5);
        fp5 = NULL;
        if(count == count_1)
        {
//             sprintf(name,"/media/mmcblk0p1/count_%d.txt",count_1);
            sprintf(name,"count_%d.txt",count_1);
            FILE *fp6 = fopen(name, "r");

            if (fp6 != NULL)
            {
                fseek(fp6,offset_1,SEEK_SET);//?确认位置是否正确
                while (fgets(buf, sizeof(buf), fp6))
                {
                    tmpTime.tv_sec = 10;
                    tmpTime.tv_usec = 0;
                    memcpy(send_buf+len,buf,strlen(buf));
//                     strcat(send_buf, buf);
                    len = len + strlen(buf);
                    count_Line++;
                    if(count_Line == correspond_index+g_mqtt_handle.MqttDeviceIdNums*3+9)
                    {
                        errCode = mqttPub(&g_MQTT_CLIENT, send_buf, getPubTopic());
//                         printf("513**errCode:%d\n", errCode);
                        printf("Send history data packets with clear txt %s\n", send_buf);
                        select(0, NULL, NULL, NULL, &tmpTime);
                        count_Line = 0;
                        len  =0;

                        //读文件指针位置
                        int32_t offset  = ftell(fp6);
                        printf("1@offset = %d %s (L%d)\n",offset,__func__,__LINE__);
                        FILE *fp7 = fopen("last_position.txt", "w");
                        fprintf(fp7, "%d %d", count, offset);
                        fclose(fp7);

                        runLog.pcDescription = "upload breakpoint data";
                        time(&now);
                        timenow = localtime(&now);
                        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                        strcpy(runLog.date,timedata);
                        strcpy( runLog.arrcDevName, "zero carbon gateway");
                        Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
                    }

                }
                fclose(fp6);
                fp6 = NULL;
            }
            count ++;
            remove("last_position.txt");
            FILE *fp8 = fopen("save.txt", "w");
            if (fp8 == NULL)
            {
                printf("Failed to open file.\n");
            }
            fprintf(fp8, "%d %d", count, count_max);
            fclose(fp8);
            fp8 = NULL;
            remove(name);

        }
    }


    for(i=count;i<count_max+1;i++)
	{
//         sprintf(name,"/media/mmcblk0p1/count_%d.txt",count);
        sprintf(name,"count_%d.txt",count);
        FILE *fp1 = fopen(name, "r");
        if (fp1 != NULL)
		{
			while (fgets(buf, sizeof(buf), fp1))
			{

                tmpTime.tv_sec = 10;
                tmpTime.tv_usec = 0;
				memcpy(send_buf+len,buf,strlen(buf));
//                 strcat(send_buf, buf);
				len = len + strlen(buf);
                count_Line++;
//                 printf("***%d %s\n", count_Line, buf);
//                 printf("###%d %s\n", count_Line, send_buf);
                if(count_Line == correspond_index+g_mqtt_handle.MqttDeviceIdNums*3+9)
                {
                    struct timeval t1,t2;
                    gettimeofday(&t1,NULL);
                    errCode = mqttPub(&g_MQTT_CLIENT, send_buf, getPubTopic());

                    printf("Send history data packets with clear txt %s\n", send_buf);
                    printf("****size:%d %d %lu*****\n", count_Line, len, strlen(send_buf));
                    memset(send_buf, 0, len);
                    printf("线程ID<%lu> %s (L%d)\n", pthread_self(),__func__,__LINE__);
                    count_Line = 0;
                    len  =0;
                    read_json_count ++;
                    printf("read_json_count = %d\n",read_json_count);
                    gettimeofday(&t2,NULL);
                    printf("@@@cost_time = %lld\n",((unsigned long long)t2.tv_sec*1000+t2.tv_usec/1000)-((unsigned long long)t1.tv_sec*1000+t1.tv_usec/1000));

                    select(0, NULL, NULL, NULL, &tmpTime);

                    //读文件指针位置
                    int32_t offset  = ftell(fp1);
                    printf("2@offset = %d %s (L%d)\n",offset,__func__,__LINE__);
                    FILE *fp4 = fopen("last_position.txt", "w");
                    fprintf(fp4, "%d %d", count, offset);
                    fclose(fp4);

                    runLog.pcDescription = "upload breakpoint data";
                    time(&now);
                    timenow = localtime(&now);
                    sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                    strcpy(runLog.date,timedata);
                    strcpy( runLog.arrcDevName, "zero carbon gateway");
                    Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
                }
			}
			fclose(fp1);
		}
        count ++;

        remove("last_position.txt");

        FILE *fp2 = fopen("save.txt", "w");
        if (fp2 == NULL)
        {
            printf("Failed to open file.\n");
        }
        fprintf(fp2, "%d %d", count, count_max);
        fclose(fp2);
        fp2 = NULL;
		if(remove(name) != 0)
        {
            printf("%s\n", name);
            perror("rm err!\n");
        }
    }
    free(send_buf);
    send_buf = NULL;
    FILE *fp3 = fopen("save.txt", "w");
    if (fp3 == NULL)
    {
        printf("Failed to open file.\n");
    }
    count = 0;
    count_max = 0;
    fprintf(fp3, "%d %d", count, count_max);
    fclose(fp3);
    fp3 = NULL;
    if(count ==0 && count_max == 0)
    {
        runLog.pcDescription = "End of breakpoint data upload";
        time(&now);
        timenow = localtime(&now);
        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
        strcpy(runLog.date,timedata);
        strcpy( runLog.arrcDevName, "zero carbon gateway");
        Persister_StoreNode(HIS_RECORD_RUN_STATE, &runLog);
    }
}


void *tcpThread(void *arg)
{
    int8_t tcp_first_connect = 0;//tcp首次连接状态
    int8_t tcpConnFlag = 0;
    char *runDataJson = NULL;
    int8_t Tcp_Net_Flag = 0;
    FILE *tcprecordsave;
    FILE *tcprecordsaveout;
    int8_t tcpfirstflag = 0;
    int32_t TcpFileCnt = 0;
    int32_t TcpFileMaxCnt = 0;
    char filename[40] = {0};
    FILE *file;
    long file_size = 0;
    int8_t tcp_history_Send_Flag = 0;


    while(1)
    {
        if(tcp_first_connect != 0)
        {
            int8_t tcpConnCode = tcpConnStus();
            printf("tcp connect status code: %d\n", tcpConnCode);

            //tcp connect failed
            if(tcpConnCode != 0)
            {
                printf("Connection lost. Attempting to reconnect...\n");

                // 关闭并清理套接字
				close(sockfd);
				sockfd = -1;

                // 等待一段时间后重连
                sleep(1);

                // 重连到服务器
				sockfd = socket(AF_INET, SOCK_STREAM, 0);
				if (sockfd < 0) {
					perror("reconnect ERROR opening socket");
					//continue;
					tcpConnFlag = -1;//打开socket失败
				}

				if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
				{
                    //tcp connect failed
					perror("reconnect ERROR connecting");
					tcpConnFlag = -2;//重新连接失败
				}
				else
                {
                    //tcp connect success
                    char *tcpIp = getTcpIp();
					int tcpPort = getTcpPort();
					printf("Reconnected to TCP server[%s][%d]\n", tcpIp, tcpPort);
                }

                if(tcpConnFlag == -1 || tcpConnFlag == -2)
                {
                    //tcp connect failed
                    printf("TCP reconnect failed.\n");

                    //记录tcp断连状态
					IS_TCP_DISCONNECT = TRUE;

                    /*tcp读取离线数据线程关闭*/
                    if(tcp_history_Send_Flag == 2)
					{
						int8_t res = pthread_cancel(history_tcp);
						if (res != 0)
						{
							printf("线程运行结束or终止 history_tcp 线程失败\n");
						}
						else if(res == 0)
						{
							printf("终止 history_tcp 线程sucess\n");
						}
					}
					tcp_history_Send_Flag = 1;
                    /*tcp读取离线数据线程关闭*/

                    //保存tcp离线数据
                    //获取南向全量数据
					getAllRunData();

                    //转换json格式
					runDataJson = RunDataEncodeJson(&g_mqtt_handle, 1);

                    if(Tcp_Net_Flag != 2)//第一次中断或网络连接上后中断，将Tcp_Tcp_Net_Flag置 1,且初始化一次
					{
						Tcp_Net_Flag  = 1;
						//先读取文件，判断当前是否还有文件未读取完
						tcprecordsave = fopen("tcptcpsave.txt", "r");
						if(tcprecordsave == NULL)
						{
							printf("open error! create tcpsave.txt\n");
							tcpfirstflag = 1;
						}
						else
						{
							fscanf(tcprecordsave, "%d %d", &TcpFileCnt, &TcpFileMaxCnt);
							if(TcpFileCnt != 0 && TcpFileMaxCnt != 0)
							{
								printf("tcpsave.txt: %d %d\n", TcpFileCnt, TcpFileMaxCnt);
							}
							fclose(tcprecordsave);
							tcprecordsave = NULL;
						}
						if(tcpfirstflag == 1)//网络第一次中断，没有tcpsave.txt文件，需初始化参数
						{
							//重新打开并初始化
							tcprecordsave = fopen("tcpsave.txt", "w");
							fprintf(tcprecordsave, "%d %d", TcpFileCnt+1, TcpFileMaxCnt+1);
							fclose(tcprecordsave);
							tcprecordsave = NULL;
						}
					}

					{
						// 首次中断或者内存卡中没有文件，网络中断后初始化一次
						if((TcpFileCnt == 0 && Tcp_Net_Flag == 1) || (tcpfirstflag == 1))
						{
							//当前存储卡中没有断点续传数据
							//count从1计数
							TcpFileCnt = TcpFileCnt + 1;
							TcpFileMaxCnt = TcpFileCnt;

							//记录TcpFileCnt, TcpFileMaxCnt
							tcprecordsave = fopen("tcpsave.txt", "w");
							if(tcprecordsave == NULL)
							{
								perror("fopen");
							}
							fprintf(tcprecordsave, "%d %d", TcpFileCnt, TcpFileMaxCnt);
							fclose(tcprecordsave);
							tcprecordsave = NULL;

							sprintf(filename, "tcp_count_%d.txt", TcpFileMaxCnt); // 将数字转换为字符串
							file = fopen(filename, "a+");
							if (file == NULL)
							{
								printf("can not open filename：%s\n", filename);
								return NULL;
							}
							Tcp_Net_Flag = 2;
							tcpfirstflag = 0;
						}
						//非首次中断，且网络连接上后数据未全部读取完后又中断，网络中断后初始化一次
						if((TcpFileCnt != 0 && Tcp_Net_Flag == 1) || (tcpfirstflag == 1))
						{
							//打开文件

							sprintf(filename, "tcp_count_%d.txt", TcpFileMaxCnt); // 将数字转换为字符串
							file = fopen(filename, "a+");

							if (file == NULL)
							{
								printf("can not open filename：%s\n", filename);
								return NULL;
							}
							Tcp_Net_Flag = 2;
							tcpfirstflag = 0;
						}

						//判断文件个数
						//小于等于40个文件
						if((TcpFileMaxCnt - TcpFileCnt + 1) <= TCP_MAX_TXT_NUM)
						{
							// 检查文件大小是否超过限制
							fseek(file, 0, SEEK_END);//移动文件指针到文件末尾
							file_size = ftell(file);//获取文件大小
							fseek(file, 0, SEEK_SET);//将文件指针恢复到初始位置，不影响文件后续操作
							printf("size:%ld %ld\n", file_size, strlen(runDataJson));

							if(labs(file_size - TCP_MAX_FILE_SIZE) < (strlen(runDataJson)))
							{
								printf("over txt size\n");
								fclose(file);
								file = NULL;

								//创建新的文件
								TcpFileMaxCnt = TcpFileMaxCnt + 1;//更新文件索引名
								if((TcpFileMaxCnt - TcpFileCnt + 1) > TCP_MAX_TXT_NUM)//记录文件超过40个
								{
									//删除TcpFileCnt对应的文件

									sprintf(filename, "tcp_count_%d.txt", TcpFileCnt); // 将数字转换为字符串
									remove(filename);
									//TcpFileCnt索引更新
									TcpFileCnt = TcpFileCnt + 1;

								}

								sprintf(filename, "tcp_count_%d.txt", TcpFileMaxCnt); // 将数字转换为字符串

								file = fopen(filename, "a+");
								if (file == NULL) {
									printf("can not open filename：%s\n", filename);
									return NULL;
								}
								//写入数据
								fprintf(file, "%s\n", runDataJson);
								printf("tcp create new file and write!\n");

								//将 TcpFileCnt和TcpFileMaxCnt保存到文件中
								tcprecordsave = fopen("tcpsave.txt", "w");
								if(tcprecordsave == NULL)
								{
									perror("fopen");
								}
								fprintf(tcprecordsave, "%d %d", TcpFileCnt, TcpFileMaxCnt);
								fclose(tcprecordsave);
								tcprecordsave = NULL;
								printf("tcp save ok!\n");
							}
							else
							{
								//写入数据
								fprintf(file, "%s\n", runDataJson);
								printf("tcp data complete write\n");
							}
						}
					}
					continue;
                }
            }
            else
            {
                //tcp recover connect
                tcpConnFlag = 1;

                if(Tcp_Net_Flag != 0)
				{
					fclose(file);
					printf("close history date save!\n");
					file = NULL;
				}
				Tcp_Net_Flag = 0;//网络恢复连接，或者网络本身正常

				tcprecordsaveout = fopen("tcpsave.txt", "r");
				if(tcprecordsaveout == NULL)
				{
					printf("open error! no tcp history date\n");
				}
				else
                {
                    int tcp_count, tcp_count_max;
					fscanf(tcprecordsaveout, "%d %d", &tcp_count, &tcp_count_max);
					fclose(tcprecordsaveout);
					tcprecordsaveout = NULL;

					if((tcp_count_max != 0)&&(tcp_count != 0)&&(tcp_history_Send_Flag != 2 ))
					{
						pthread_attr_t attr;
						pthread_attr_init (&attr);
						pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
						int detachstate;
						// 获取线程属性中的分离状态
						pthread_attr_getdetachstate(&attr, &detachstate);
						printf("Detach state after setting: %d PTHREAD_CREATE_DETACHED = %d\n", detachstate,PTHREAD_CREATE_DETACHED);
						pthread_create(&history_tcp, &attr, history_tcpThread, NULL);
						tcp_history_Send_Flag = 2;
					}
                }
            }
        }

        if(tcp_first_connect == 0)
        {
            //tcp 客户端初始化
            int errCode = tcpInit();
            tcp_first_connect = 1;
            if(errCode != 0)
            {
                printf("tcp init failed.\n");
                continue;
            }
            //tcp初始化成功后开辟线程---消息接受，用于写测点下发指令控制
            int8_t recvResult = pthread_create(&tcp_recv, NULL, tcpRecvThread, NULL);
            if(recvResult != 0)
            {
                perror("tcp recv thread create failed.\n");
            }

        }

        //tcp send data
        int errCode = runDataTcpSend();
        if(errCode != OK)
        {
            //tcp send failed, need uninit tcp and reconnect to tcp server
            printf("tcp send failed.\n");
            continue;
        }
        else
        {
            printf("TCP sends real-time data successfully.\n");
        }


        sleep(1);
    }
}

/*tcp接收指令*/
void *tcpRecvThread(void *arg)
{
//     while(1)
//     {
//         printf("tcp recv thread is running...\n");
//         sleep(2);
//     }

    char buffer[TCP_RECV_SIZE];
    ssize_t bytes_read;

    while (1)
    {
        memset(buffer, 0, sizeof(buffer));
        bytes_read = recv(sockfd, buffer, TCP_RECV_SIZE - 1, 0);
        if (bytes_read > 0)
        {
            buffer[bytes_read] = '\0'; // Null-terminate the string
            printf("Received: %s\n", buffer);
            tcpWriteValue(buffer);

        }
        else if (bytes_read == 0)
        {
            printf("Server closed the connection\n");
            break;
        }
        else
        {
            perror("recv failed");
            break;
        }
    }
}

//tcp接受指令写测点
void tcpWriteValue(char *message)
{
	int i, j;
	MQTT_DATA_T *mqtt_data =(MQTT_DATA_T *)malloc(sizeof(MQTT_DATA_T)*(1));
    extern int Mqtt_point_num;
    extern MQTT_T *mqtt_info1;
    mqtt_data->datacodeall = Mqtt_point_num;
    mqtt_data->deviceId = mqtt_info1[0].gatewayid;
    mqtt_data->dataparacount = g_mqtt_handle.MqttDeviceIdNums;
    mqtt_data->para = (DATA_PARA_T *)calloc(g_mqtt_handle.MqttDeviceIdNums, sizeof(DATA_PARA_T));

    for(i=0;i<g_mqtt_handle.MqttDeviceIdNums;i++)
    {
        for(j=0;j<Mqtt_point_num;j++)
        {
            if(mqtt_info1[j].mqttdeviceid == g_mqtt_handle.MqttDeviceIdKind[i])
            {
                mqtt_data->para[i].datacodeparacount++;
            }
        }

    }
    uint16_t *times = (uint16_t *)calloc(g_mqtt_handle.MqttDeviceIdNums,sizeof(uint16_t));

    for(i=0;i<g_mqtt_handle.MqttDeviceIdNums;i++)
    {
        mqtt_data->para[i].deviceKey = g_mqtt_handle.MqttDeviceIdKind[i];
        mqtt_data->para[i].datacodepara =calloc(mqtt_data->para[i].datacodeparacount,sizeof(DATACODE_PARA_T));
        for(j=0;j<Mqtt_point_num;j++)
        {
            if(mqtt_info1[j].mqttdeviceid == g_mqtt_handle.MqttDeviceIdKind[i])
            {
                    mqtt_data->para[i].datacodepara[times[i]] .datacode = mqtt_info1[j].datacode;
                    times[i]++;
            }
        }
    }

    MQTT_DATA_OUTPARA_T *mqtt_data_out  = NULL;
    mqtt_data_out = MqttAnlysisJson(message, mqtt_data);

    //MqttAnlysisJson解析完后释放开辟内存空间
    for(i=0;i<g_mqtt_handle.MqttDeviceIdNums;i++)
    {
        free(mqtt_data->para[i].datacodepara);
    }

    if (mqtt_data_out != NULL && mqtt_data_out->count != 0)
    {
        MQTT_DATA_PARA_T *mqtt_data_para  = (MQTT_DATA_PARA_T *)calloc(mqtt_data_out->count, sizeof(MQTT_DATA_PARA_T));

        for(i = 0; i < mqtt_data_out->count; i++)
        {
            mqtt_data_para[i]=mqtt_data_out->outpara[i];
        }

        for(j=0; j < mqtt_data_out->count; j++)
        {
            for(i=0; i< Mqtt_point_num; i++)
            {
                if(mqtt_info1[i].date_type == 2 || mqtt_info1[i].date_type == 3)
                {
                    if((mqtt_data_para[j].datacode == mqtt_info1[i].datacode)&&(mqtt_data_para[j].deviceKey==mqtt_info1[i].mqttdeviceid))
                    {
                        mqtt_data_para[j].address = mqtt_info1[i].address;
                        mqtt_data_para[j].devcode = mqtt_info1[i].devcode;
                        mqtt_data_para[j].cmd = mqtt_info1[i].cmd;
                        mqtt_data_para[j].data_id = SDB_ND_GetDataIdByAddr(mqtt_data_para[j].devcode, 1, mqtt_data_para[j].address, mqtt_data_para[j].cmd);
                    }
                }
            }
        }

        for(j = 0; j < mqtt_data_out->count; j++)
        {
            WritePointCommand( mqtt_data_para[j].value, mqtt_data_para[j].devcode, 1, mqtt_data_para[j].data_id);
        }
        free(mqtt_data_para);
    }
    else
    {
        free(mqtt_data->para);
        free(mqtt_data);
        free(times);
    }
	free(mqtt_data_out->outpara);
    free(mqtt_data_out);
    free(mqtt_data->para);
    free(mqtt_data);
    free(times);

}

void *history_tcpThread(void *arg)
{
    struct timeval tmpTime;

    int32_t errCode = OK;
    int i =0,count_Line = 0;
    char name[40]= {};
    char buf[128] = {0};
    int len  = 0 ;
    int read_json_count = 0;

    PERSIST_NODE_INFO_T runLog;
    time_t now;
    struct tm *timenow;
    char timedata[30] = {0};

    FILE *fp = fopen("tcpsave.txt", "r");
    if (fp == NULL)
    {
        printf("Failed to open file.\n");
    }
    int tcp_count, tcp_count_max;
    fscanf(fp, "%d %d", &tcp_count, &tcp_count_max);
    fclose(fp);
    fp = NULL;
    printf("1@tcp_count: %d, tcp_count_max: %d\n", tcp_count, tcp_count_max);
    sleep(2);//获取g_mqtt_handle.MqttDeviceIdNums，但是实时上传解析的g_mqtt_handle.MqttDeviceIdNums还没有赋值所以延时
    printf("g_mqtt_handle.MqttDeviceIdNums: %d %s (L%d)\n", g_mqtt_handle.MqttDeviceIdNums,__func__,__LINE__);
    char *send_buf = (char *)malloc((correspond_index+g_mqtt_handle.MqttDeviceIdNums*3+9)*128*sizeof(char));
    memset(send_buf, 0, (correspond_index+g_mqtt_handle.MqttDeviceIdNums*3+9)*128*sizeof(char));


    //从上一次没有读取完的的文件位置读取数据
    int count_1, offset_1;
    FILE *fp5 = fopen("tcp_last_position.txt", "r");
    if(fp5 == NULL)
    {
        printf("open error or ! tcp_last_position txt absent! \n");
    }
    else
    {
        fscanf(fp5, "%d %d", &count_1, &offset_1);
        fclose(fp5);
        fp5 = NULL;
        if(tcp_count == count_1)
        {
//             sprintf(name,"/media/mmcblk0p1/count_%d.txt",count_1);
            sprintf(name,"count_%d.txt",count_1);
            FILE *fp6 = fopen(name, "r");

            if (fp6 != NULL)
            {
                fseek(fp6,offset_1,SEEK_SET);//?确认位置是否正确
                while (fgets(buf, sizeof(buf), fp6))
                {
                    tmpTime.tv_sec = 1;
                    tmpTime.tv_usec = 0;
                    memcpy(send_buf+len,buf,strlen(buf));
//                     strcat(send_buf, buf);
                    len = len + strlen(buf);
                    count_Line++;
                    if(count_Line == correspond_index+g_mqtt_handle.MqttDeviceIdNums*3+9)
                    {
						//tcp send
						if (send(sockfd, send_buf, strlen(send_buf), 0) == -1)
						{
							perror("send");

						}

                        printf("Send tcp history data packets with clear txt %s\n", send_buf);
                        select(0, NULL, NULL, NULL, &tmpTime);
                        count_Line = 0;
                        len  =0;

                        //读文件指针位置
                        int32_t offset  = ftell(fp6);
                        printf("1@offset = %d %s (L%d)\n",offset,__func__,__LINE__);
                        FILE *fp7 = fopen("tcp_last_position.txt", "w");
                        fprintf(fp7, "%d %d", tcp_count, offset);
                        fclose(fp7);


                    }

                }
                fclose(fp6);
                fp6 = NULL;
            }
            tcp_count ++;
            remove("tcp_last_position.txt");
            FILE *fp8 = fopen("tcpsave.txt", "w");
            if (fp8 == NULL)
            {
                printf("Failed to open file.\n");
            }
            fprintf(fp8, "%d %d", tcp_count, tcp_count_max);
            fclose(fp8);
            fp8 = NULL;
            remove(name);

        }
    }


    for(i = tcp_count; i < tcp_count_max+1; i++)
	{
//         sprintf(name,"/media/mmcblk0p1/count_%d.txt",tcp_count);
        sprintf(name,"tcp_count_%d.txt",tcp_count);
        FILE *fp1 = fopen(name, "r");
        if (fp1 != NULL)
		{
			while (fgets(buf, sizeof(buf), fp1))
			{

                tmpTime.tv_sec = 1;
                tmpTime.tv_usec = 0;
				memcpy(send_buf+len,buf,strlen(buf));
//                 strcat(send_buf, buf);
				len = len + strlen(buf);
                count_Line++;
//                 printf("***%d %s\n", count_Line, buf);
//                 printf("###%d %s\n", count_Line, send_buf);
                if(count_Line == correspond_index+g_mqtt_handle.MqttDeviceIdNums*3+9)
                {
                    struct timeval t1,t2;
                    gettimeofday(&t1,NULL);

					if (send(sockfd, send_buf, strlen(send_buf), 0) == -1)
					{
						perror("send");
					}

                    printf("Send tcp history data packets with clear txt %s\n", send_buf);
                    printf("****size:%d %d %lu*****\n", count_Line, len, strlen(send_buf));
                    memset(send_buf, 0, len);
                    printf("线程ID<%lu> %s (L%d)\n", pthread_self(),__func__,__LINE__);
                    count_Line = 0;
                    len  =0;
                    read_json_count ++;
                    printf("read_json_count = %d\n",read_json_count);
                    gettimeofday(&t2,NULL);
                    printf("@@@cost_time = %lld\n",((unsigned long long)t2.tv_sec*1000+t2.tv_usec/1000)-((unsigned long long)t1.tv_sec*1000+t1.tv_usec/1000));

                    select(0, NULL, NULL, NULL, &tmpTime);

                    //读文件指针位置
                    int32_t offset  = ftell(fp1);
                    printf("2@offset = %d %s (L%d)\n",offset,__func__,__LINE__);
                    FILE *fp4 = fopen("tcp_last_position.txt", "w");
                    fprintf(fp4, "%d %d", tcp_count, offset);
                    fclose(fp4);

                }
			}
			fclose(fp1);
		}
        tcp_count ++;

        remove("tcp_last_position.txt");

        FILE *fp2 = fopen("tcpsave.txt", "w");
        if (fp2 == NULL)
        {
            printf("Failed to open file.\n");
        }
        fprintf(fp2, "%d %d", tcp_count, tcp_count_max);
        fclose(fp2);
        fp2 = NULL;
		if(remove(name) != 0)
        {
            printf("%s\n", name);
            perror("rm err!\n");
        }
    }
    free(send_buf);
    send_buf = NULL;
    FILE *fp3 = fopen("tcpsave.txt", "w");
    if (fp3 == NULL)
    {
        printf("Failed to open file.\n");
    }
    tcp_count = 0;
    tcp_count_max = 0;
    fprintf(fp3, "%d %d", tcp_count, tcp_count_max);
    fclose(fp3);
    fp3 = NULL;

}
