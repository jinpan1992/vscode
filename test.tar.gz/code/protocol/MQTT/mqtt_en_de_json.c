//
// Created by root on 11/24/22.
//
#include"mqtt_en_de_json.h"
#include"sys/time.h"
#include "mqtt_config.h"
int32_t cjson_len;
extern int32_t correspond_index;
/********************************************
* Function name ：getTime
* Description    : 获取时间，并格式化为字符串形式
* Parameter      ：
* Return        ：timeStr
*********************************************/
char *getTime() {
    char *timeStr = (char *) malloc(15);
    time_t timep;
    time(&timep);
    struct tm *p;
    p = gmtime(&timep);
    snprintf(timeStr, 20, "%04d%02d%02d%02d%02d%02d", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday, 8 + p->tm_hour,
             p->tm_min, p->tm_sec);
    return timeStr;
}
//故障解析代码
uint32_t FaultAnlysis(uint32_t *value)
{
    uint32_t recvData;
    uint32_t highData;
    uint32_t lowData;
    uint32_t retnData;
    uint32_t faultCode;
    recvData = *value;
    if(recvData == 0)
    {
    retnData = 6 * 16 + 6;//无故障上传
    return retnData;
    }
    highData = (recvData & 0x0f00) >> 8;
    lowData = (recvData & 0x0f);
    faultCode = highData*10+lowData;
    retnData = highData * 16 + lowData;
    return retnData;
}
/********************************************
* Function name ：PubMessageEncodeJson
* Description   : json编码模功能函数
* Parameter     ：
* Return        ：
*********************************************/
char *PubMessageEncodeJson(char *content) {
    cJSON *cjson_root = NULL;

    /* 创建一个JSON数据对象(链表头结点) */
    cjson_root = cJSON_CreateObject();

    /* 添加一条字符串类型的JSON数据(添加一个链表节点) */
    cJSON_AddStringToObject(cjson_root, "secureContent", content);

    /* 打印JSON对象(整条链表)的所有数据 */
    char *jsonStr = (char *) malloc(strlen(content) + 1);
    if (jsonStr != NULL) {
        jsonStr = cJSON_Print(cjson_root);
        // printf("%s\n", jsonStr);
    }
    cJSON_Delete(cjson_root);
    return jsonStr;
}

/********************************************
* Function name ：SubMessageDecodeJson
* Description    : 解析下发指令的json数据包
* Parameter     ：
* Return        ：
*********************************************/
char *SubMessageDecodeJson(char *message) {
    cJSON *cjson_root = NULL;
    cJSON *cjsonContent = NULL;

    /* 解析整段JSON数据 */
    cjson_root = cJSON_Parse(message);
    if (cjson_root == NULL) {
        printf("parse fail.\n");
        return (char *) -1;
    }
    cjsonContent = cJSON_GetObjectItem(cjson_root, "secureContent");
    //printf("secureContent: %s\n", cjsonContent->valuestring);


// 赋值给全局变量
    char *jsonStr = (char *) malloc(strlen(cjsonContent->valuestring) + 1);
    if (jsonStr != NULL) {
        memcpy(jsonStr, cjsonContent->valuestring, strlen(cjsonContent->valuestring) + 1);
        // jsonStr = cjsonContent->valuestring;
        // printf("赋值的字符串是: %s\n", jsonStr);
    }
    cJSON_Delete(cjson_root);
    return jsonStr;

}

/********************************************
* Function name ：SubMessageDecodeJson
* Description    : mqtt指令下发json解码功能函数
* Parameter     ：
* Return        ：
*********************************************/
int *SubCommandDecodeJson(char *message) {
    cJSON *cjson_root = NULL;
    cJSON *cjsonDeviceCode = NULL;
    cJSON *cjsonIndex = NULL;
    cJSON *cjsonId = NULL;
    cJSON *cjsonValue = NULL;

    /* 解析整段JSON数据 */
    cjson_root = cJSON_Parse(message);
    if (cjson_root == NULL) {
        printf("parse fail.\n");
        return (int32_t *) -1;
    }
    cjsonDeviceCode = cJSON_GetObjectItem(cjson_root, "deviceCode");
    cjsonIndex = cJSON_GetObjectItem(cjson_root, "deviceIndex");
    cjsonId = cJSON_GetObjectItem(cjson_root, "dataId");
    cjsonValue = cJSON_GetObjectItem(cjson_root, "value");

    int32_t *jsonInt = (int32_t *) malloc(sizeof(int32_t) * 4);

    jsonInt[0] = cjsonDeviceCode->valueint;
    jsonInt[1] = cjsonIndex->valueint;
    jsonInt[2] = cjsonId->valueint;
    jsonInt[3] = cjsonValue->valueint;

    return jsonInt;
}



MQTT_DATA_OUTPARA_T *MqttAnlysisJson(char *message, MQTT_DATA_T *data) {
    cJSON *cjson_root = NULL;
    int i, j, k;
    int m;
    cJSON *cjsonDeviceId = NULL;
    cJSON *cjsonData = NULL;
    cJSON *cjsonArrayData = NULL;
    int32_t array_size = 0;

    uint16_t dataparacount = 0;
    char datacodestring[25];
    static uint16_t mqtt_out_count = 0;//实际输出参数个数

    MQTT_DATA_OUTPARA_T *outdata = NULL;//输出结构体指针

    //获取devicKey个数
    dataparacount = data->dataparacount;
    printf("dataparacount: %d\n", dataparacount);
    //获取所有datacode个数

    //开辟输出空间
    outdata = (MQTT_DATA_OUTPARA_T *)malloc(sizeof(MQTT_DATA_OUTPARA_T));
    outdata->outpara = (MQTT_DATA_PARA_T *)malloc(sizeof(MQTT_DATA_PARA_T) * 100);



    /* 解析整段JSON数据 */
    cjson_root = cJSON_Parse(message);
    if (cjson_root == NULL) {
        printf("parse fail.\n");
        return NULL;
    }

    cjsonDeviceId = cJSON_GetObjectItem(cjson_root, "deviceId");
    cjsonData = cJSON_GetObjectItem(cjson_root, "data");
    array_size = cJSON_GetArraySize(cjsonData);//获取数组大小

    outdata->deviceId = atoi(cjsonDeviceId->valuestring);
    printf("array_size, deviceId: %d %d\n", array_size, outdata->deviceId);
    for(i = 0; i < array_size; i++)//遍历数组大小，每个deviceKey下有多个datacode
    {
        cjsonArrayData = cJSON_GetArrayItem(cjsonData, i);

//         jsonInt[1 + i * 3] = atoi(cJSON_GetObjectItem(cjsonArrayData, "deviceKey")->valuestring);
//         jsonInt[2 + i * 3] = atoi(cJSON_GetObjectItem(cjsonArrayData, "901001")->valuestring);
//         jsonInt[3 + i * 3] = atoi(cJSON_GetObjectItem(cjsonArrayData, "901002")->valuestring);


        for(j = 0; j < dataparacount; j++)//获取多少个元素
        {
            if(atoi(cJSON_GetObjectItem(cjsonArrayData, "deviceKey")->valuestring) == data->para[j].deviceKey)//获取deviceKey
            {
                for(k = 0; k < data->para[j].datacodeparacount; k++)//遍历有多少个datacode
                {
                    sprintf(datacodestring, "%d", data->para[j].datacodepara[k].datacode);
//                     itoa(data->para[j].datacodepara[k].datacode, datacodestring, 10);//将datacode转化成字符串，进行搜寻
                    if(cJSON_GetObjectItem(cjsonArrayData, datacodestring) == NULL)//如果没有找到，则继续下一次搜寻
                    {
                        continue;
                    }
                    else
                    {
                        outdata->outpara[mqtt_out_count].deviceKey = atoi(cJSON_GetObjectItem(cjsonArrayData, "deviceKey")->valuestring);//保存获取deviceKey
                        outdata->outpara[mqtt_out_count].datacode = data->para[j].datacodepara[k].datacode;
                        outdata->outpara[mqtt_out_count].value = atoi(cJSON_GetObjectItem(cjsonArrayData, datacodestring)->valuestring);//找到对应的datacode，保存数值
                        mqtt_out_count++;
                        outdata->count = mqtt_out_count;
                    }
                }
            }
        }
    }
    printf("count: %d\n", mqtt_out_count);
    //若下发测点未找到，提示并退出
    if(mqtt_out_count == 0)
    {
        printf("下发测点信息与库中写测点不匹配，确认后重新下发!\n");
        //return NULL;
    }
    for(m=0;m<mqtt_out_count;m++)
    {

        printf("%d %d %d\n", outdata->outpara[m].deviceKey, outdata->outpara[m].datacode, outdata->outpara[m].value);
    }
    mqtt_out_count = 0;
    return outdata;
}

/********************************************
* Function name ：RunDataEncodeJson
* Description   : json运行数据的编码功能函数
* Parameter     ：
* Return        ：
*********************************************/
char *RunDataEncodeJson(MQTT_HANDLE_T *mqtt_handle, int32_t type) {

    cJSON *cjson_root = NULL;
    cJSON *cjson_data_array = NULL;
    cJSON *array_deviceCode = NULL;
    cJSON *array_deviceData = NULL;
    cJSON *cjson_deviceId = NULL;
    cJSON *cjson_devicekey = NULL;
    /* 创建一个JSON数据对象(链表头结点) */
    cjson_root = cJSON_CreateObject();

    /* 添加一条字符串类型的JSON数据(添加一个链表节点) */
//      t1= time(NULL);
    struct timeval t2;
    gettimeofday(&t2,NULL);
//     printf("%lld\n",((unsigned long long)t2.tv_sec*1000+t2.tv_usec/1000)-28800000);
//     printf("%ld   %ld\n",t2.tv_sec,t2.tv_usec);
    char randStr[5];
    char countId[5];
    char breakpointResume[5];
    char commandType[5];
    char timeStr[20];
    sprintf(randStr, "%04d", rand() % 9999);   // NOLINT(cert-msc30-c, cert-msc50-cpp)  注意，这个注释不能删

    char clientId[strlen(getClientId())  + 3];
    sprintf(clientId, "%s", getClientId());
    sprintf(countId, "%s","6" );
    sprintf(breakpointResume, "%s","1");
    sprintf(commandType, "%s","1" );
//     sprintf(timeStr, "%lld",((unsigned long long)t2.tv_sec*1000+t2.tv_usec/1000)-28800000 );
    sprintf(timeStr, "%lld",((unsigned long long)t2.tv_sec*1000+t2.tv_usec/1000) );

    cJSON_AddStringToObject(cjson_root, "clientId", clientId);

    /* 添加一条整数类型的JSON数据(添加一个链表节点) */
    cJSON_AddStringToObject(cjson_root, "countId", countId);

    /* 添加一条浮点类型的JSON数据(添加一个链表节点) */
    cJSON_AddStringToObject(cjson_root, "breakpointResume", breakpointResume);

    /* 添加一条字符型的JSON数据(添加一个链表节点) */
    cJSON_AddStringToObject(cjson_root, "time", timeStr);
        /* 添加一条浮点类型的JSON数据(添加一个链表节点) */
    cJSON_AddStringToObject(cjson_root, "commandType", commandType);

//     /* 添加一个嵌套的JSON数据（添加一个链表节点） */
//     cjson_publicData = cJSON_CreateObject();
//
//     cJSON_AddStringToObject(cjson_publicData, "productCode", "2304");
//     cJSON_AddStringToObject(cjson_publicData, "productName", "eFMC");
//     cJSON_AddStringToObject(cjson_publicData, "productSN", SN);
//     cJSON_AddStringToObject(cjson_publicData, "time", timeStr);
//     cJSON_AddItemToObject(cjson_root, "publicData", cjson_publicData);
    char deviceId[10] = {0};
    sprintf(deviceId, "%d", mqtt_handle->p_all[0].gatewayid);
    cjson_deviceId = cJSON_CreateObject();
    cJSON_AddStringToObject(cjson_root, "deviceId", deviceId);

    /* 添加一个数组类型的JSON数据(添加一个链表节点) */
    cjson_data_array = cJSON_CreateArray();
    cJSON_AddItemToObject(cjson_root, "data", cjson_data_array);

    char deviceCode[20] = {0};
    char datacode[20] = {0};
    char value[20] = {0};
    char dataId[20] = {0};
    char deviceKey[20] = {0};

    // 0为变化上传
    if (type == 0) {
        uint32_t num = mqtt_handle->total_num;     // 获取结构体中数据的数量
        // printf("2消费者获取的数据的数量%d\n", num);
        if (num > 0) {
            ONCE_DATA_T t;

            uint32_t i = 0;
            for (; i < num; i++) {
                memcpy(&t, &mqtt_handle->p[i], sizeof(ONCE_DATA_T));  // 创建一个存储数据结构的一个临时变量
                // memcpy(&temp, g_MSG.p + i, sizeof(g_onceDataQ));  // 这里的i加一就表示指针移动一个指针指向数据类型的长度，不需要再乘以该类型的长度(sizeof)了

                // 格式化字符串
                sprintf(deviceCode, "%d_%d", t.deviceCode, t.index);
                sprintf(dataId, "%d", t.dataId);

                if(t.ucDataType == 0)
                {
                    sprintf(value, "%f", t.data.f32);
                }
                if(t.ucDataType == 1)
                {
                    sprintf(value, "%u", t.data.u32);
                }
                if(t.ucDataType == 2)
                {
                    sprintf(value, "%d", t.data.s32);
                }

                cJSON *arrayObj = cJSON_CreateObject();
                cJSON_AddItemToArray(cjson_data_array, arrayObj);

                array_deviceCode = cJSON_CreateString(deviceCode);
                cJSON_AddItemToObject(arrayObj, "deviceCode", array_deviceCode);

                array_deviceData = cJSON_CreateObject();
                cJSON_AddStringToObject(array_deviceData, "dataId", dataId);
                cJSON_AddStringToObject(array_deviceData, "value", value);
                cJSON_AddItemToObject(arrayObj, "deviceData", array_deviceData);
            }
        }

        // 1为全量上传
    } else if (type == 1) {
        uint32_t num_all = mqtt_handle->total_num_all; // 获取结构体中数据的数量
        if (num_all > 0) {
            int j = 0;
            ONCE_DATA_T t;
            for(j = 0;j < mqtt_handle->MqttDeviceIdNums; j++)
            {
                cjson_devicekey = cJSON_CreateObject();
                sprintf(deviceKey, "%d", mqtt_handle->MqttDeviceIdKind[j]);
                cJSON_AddStringToObject(cjson_devicekey, "deviceKey", deviceKey);
                cJSON_AddStringToObject(cjson_devicekey, "time", timeStr);
                cJSON_AddItemToObject(cjson_data_array, "deviceKey", cjson_devicekey);

                uint32_t i = 0;
                for (; i < correspond_index; i++)
                {
                    memcpy(&t, &mqtt_handle->p_all[i], sizeof(ONCE_DATA_T));  // 创建一个存储数据结构的一个临时变量
                    if(mqtt_handle->MqttDeviceIdKind[j] == mqtt_handle->p_all[i].mqttdeviceid)
                    {
                        sprintf(datacode, "%d", t.datacode);
                        if(t.datacode == 802020)
                        {
                            t.data.u32  = FaultAnlysis(&t.data.u32);
                        }

                                                //sprintf(value, "%d",t.value);

//                             printf("****%d %d %f %d\n", mqtt_handle->p_all[i].ucDataType, t.ucDataType, mqtt_handle->p_all[i].data.f32, mqtt_handle->p_all[i].data.u32);
                        if(t.ucDataType == 0)
                        {
                            sprintf(value, "%f", t.data.f32);
                        }
                        if(t.ucDataType == 1)
                        {
                            sprintf(value, "%u", t.data.u32);
                        }
                        if(t.ucDataType == 2)
                        {
                            sprintf(value, "%d", t.data.s32);
                        }
                        cJSON_AddStringToObject(cjson_devicekey,datacode, value);

                        /*add test for AES and add more data*/
//                         static int datacode1 = 0;
//                         for(int i = 0; i < 25; i++)
//                         {
//                             char datacode2[20] = {0};
//                             datacode1 = datacode1 + 1;
//                             sprintf(datacode2, "%d", datacode1);
//                             cJSON_AddStringToObject(cjson_devicekey,datacode2, value);
//                         }
                        /*add test for AES and add more data*/
                    }
                }
            }
        }
    }
    /* 打印JSON对象(整条链表)的所有数据 */
    char *jsonStr = cJSON_Print(cjson_root);
//     printf("%s jsonStr:%p (L%d)\n", __func__, jsonStr, __LINE__);
    cJSON_Delete(cjson_root);
    return jsonStr;
}
