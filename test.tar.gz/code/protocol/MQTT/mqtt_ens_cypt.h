//
// Created by root on 11/21/22.
//

#ifndef MYCEMS_ENS_CYPT_H
#define MYCEMS_ENS_CYPT_H

#include <errno.h>
#include <string.h>
#include "openssl/aes.h"
#include "openssl/evp.h"
#include "openssl/err.h"
#include "openssl/bio.h"
#include "openssl/buffer.h"
#include "openssl/rsa.h"
#include "openssl/pem.h"

unsigned char *aesEncrypt(unsigned char *src, int srcLen, unsigned char *key, int *outLen);
unsigned char *aesDecrypt(unsigned char *src, int srcLen, unsigned char *key, int *outLen);
char *rsaEncrypt(char *str,char *path_key);
char * base64Encode(const char *buffer, int length, int newLine);

#endif //MYCEMS_ENS_CYPT_H
