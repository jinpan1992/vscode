//
// Created by root on 11/24/22.
//

#ifndef MYCEMS_EN_DE_JSON_H
#define MYCEMS_EN_DE_JSON_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "../../thirdparty/Cjson/cJSON.h"
#include "common.h"
#include "mqtt.h"
#include "mqtt_config.h"

char *PubMessageEncodeJson(char *);
char *SubMessageDecodeJson(char *);
int *SubCommandDecodeJson(char *);
MQTT_DATA_OUTPARA_T *MqttAnlysisJson(char *message, MQTT_DATA_T *data);
char *RunDataEncodeJson(PMQTT_HANDLE_T,int32_t);

#endif //MYCEMS_EN_DE_JSON_H
