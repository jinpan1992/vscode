#ifndef DLT645UART_H_INCLUDED
#define DLT645UART_H_INCLUDED

#include <stdio.h>
#include <unistd.h> //配置串口通用头文件
#include <termios.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <asm-generic/ioctls.h>
#include <sys/ioctl.h>
#include <string.h>
#include "protocol.h"
#include "modbus.h"

uintptr_t DltOpen(START_INFO_T startinfo);
int32_t DltClose (uintptr_t fd);
int SetDltOpt(int32_t fd,int32_t baudrate, int32_t databit, char *stopbit,char parity);
uint16_t CreatMeterSendCmd(uint8_t *meterAddr, MODBUS_CMD_T *cmd_t);
int32_t DltSend (uintptr_t fd, const uint8_t *req, uint8_t req_length);
int32_t DltRecv(uintptr_t fd, uint8_t *rsq);


#endif
