
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <crypt.h>
#include <sys/types.h>
#include <shadow.h>
#include "dlt645uart.h"
#include "protocol.h"
#include "calc.h"

static struct	termios termios_old;

//Open串口(1-6)
uintptr_t DltOpen(START_INFO_T startinfo)
{
    char *pComPort = NULL;
    int32_t fd = 0;

    switch (startinfo.uartId)
    {
    	case 1:
    	{
//     		pComPort = "/dev/ttyO1";//设备接口为 A1B1 COM1
            pComPort = "/dev/ttymxc1";
    		break;
    	}
    	case 2:
    	{
//     		pComPort = "/dev/tty02";//设备接口为 A2B2 COM2
            pComPort = "/dev/ttymxc2";
    		break;
    	}
    	case 3:
    	{
//     		pComPort = "/dev/ttyO3";   //设备接口为 A3B3 COM3
            pComPort = "/dev/ttymxc3";
    		break;
    	}
    	case 4:
    	{
//     		pComPort = "/dev/ttyO4";//设备接口为 A4B4 COM4
            pComPort = "/dev/ttymxc5";
    		break;
    	}
    	case 5:
    	{
//     		pComPort = "/dev/ttyXRUSB0";//设备接口为 A5B5 COM5
            pComPort = "/dev/ttymxc6";
    		break;
    	}
    	case 6:
    	{
//     		pComPort = "/dev/ttyXRUSB1";//设备接口为 A1B1 COM6
            pComPort = "/dev/ttymxc7";
    		break;
    	}
        default:
    	{
    		pComPort = "/dev/ttyO1";//设备接口为 A1B1 COM1
    		break;
    	}
    }

    fd = open(pComPort, O_RDWR | O_NOCTTY | O_NDELAY | O_EXCL );//| O_NDELAY);
    if(fd <= 0)
    {
        EMS_LOG(LL_ERROR, MODULE_C, FALSE, "dlt645uart openfunction fd error.\n");
    }

    EMS_LOG(LL_WARNING, MODULE_DEFAULT, FALSE, "Opening id:%d,%s at fd %d\n", startinfo.uartId, pComPort, fd);

    return (fd <= 0) ? INVALID_VALUE : fd;
}

int SetDltOpt(int32_t fd, int32_t baudrate, int32_t databit, char *stopbit, char parity)
{
	struct termios newtio, oldtio;

	if  (tcgetattr( fd,&oldtio)  !=  0)
    {
        EMS_LOG(LL_ERROR, MODULE_C, FALSE, "dlt645 SetupSerial 1.\n");
		return -1;
	}

	memset( &newtio,0 ,sizeof( newtio ) );
	newtio.c_cflag  |=  CLOCAL | CREAD;
	newtio.c_cflag &= ~CSIZE;

	switch( databit )
	{
		case 7:
			newtio.c_cflag |= CS7;
			break;
		case 8:
			newtio.c_cflag |= CS8;
			break;
	}

	switch( parity )
	{
        case 'O':
            newtio.c_cflag |= PARENB;
            newtio.c_cflag |= PARODD;
            newtio.c_iflag |= (INPCK | ISTRIP);
            break;
        case 'E':
            //newtio.c_iflag |= (INPCK | ISTRIP);
            newtio.c_cflag |= PARENB;
            newtio.c_cflag &= ~PARODD;
            break;
        case 'N':
            newtio.c_cflag &= ~PARENB;
            break;
	}

	switch( baudrate )
	{
		case 2400:
			cfsetispeed(&newtio, B2400);
			cfsetospeed(&newtio, B2400);
			break;
		case 4800:
			cfsetispeed(&newtio, B4800);
			cfsetospeed(&newtio, B4800);
			break;
		case 9600:
			cfsetispeed(&newtio, B9600);
			cfsetospeed(&newtio, B9600);
			break;
		case 115200:
			cfsetispeed(&newtio, B115200);
			cfsetospeed(&newtio, B115200);
			break;
		case 460800:
			cfsetispeed(&newtio, B460800);
			cfsetospeed(&newtio, B460800);
			break;
		default:
			cfsetispeed(&newtio, B9600);
			cfsetospeed(&newtio, B9600);
			break;
	}

	if( 0 == strcmp(stopbit, "1") )
    {
        newtio.c_cflag &=  ~CSTOPB;
    }
	else if (0 == strcmp(stopbit, "2") )
    {
        newtio.c_cflag |=  CSTOPB;
    }

    newtio.c_cc[VTIME]  = 100;///* 设置超时10 seconds*/
    newtio.c_cc[VMIN] = 0;
    tcflush(fd,TCIFLUSH);

	if ((tcsetattr(fd,TCSANOW,&newtio))!=0)
	{
        EMS_LOG(LL_FATAL, MODULE_C, FALSE, "dlt645uart COM set error.\n");
		return -1;
	}

    EMS_LOG(LL_WARNING, MODULE_DEFAULT, FALSE, "bauds:%d (%c, %d, %s), fd:%d\n",
            baudrate, parity, databit, stopbit, fd);

	return 0;
}

/* close serial port by use of file descriptor fd */
int32_t DltClose (uintptr_t fd)
{
    /* flush output data before close and restore old attribute */
    tcsetattr (fd, TCSADRAIN, &termios_old);
    return close (fd);
}

uint8_t DLT645DataCheck(uint8_t *buf, uint8_t buflen)
{
    uint16_t sum = 0;
    uint8_t i = 0;

    for ( i = 0; i < buflen; i++)
    {
        sum = sum + buf[i];
    }

    while (sum > 0xFF)
    {
        sum = sum - 256;
    }

    return (sum & 0xFF);
}

uint16_t CreatMeterSendCmd(uint8_t *meterAddr, MODBUS_CMD_T *cmd_t)
{
    uint16_t k = 0;
    uint32_t meterCmd;
    uint8_t temp[6] = {0};
    CharToHex(temp, (char*)meterAddr, 12);

    meterCmd = cmd_t->address;
    cmd_t->data[k++] = 0x68;
    cmd_t->data[k++] = temp[0];
    cmd_t->data[k++] = temp[1];
    cmd_t->data[k++] = temp[2];
    cmd_t->data[k++] = temp[3];
    cmd_t->data[k++] = temp[4];
    cmd_t->data[k++] = temp[5];
    cmd_t->data[k++] = 0x68;
    cmd_t->data[k++] = 0x11;
    cmd_t->data[k++] = 0x04;
    cmd_t->data[k++] =  (meterCmd & 0x000000FF) + 0x33;
    cmd_t->data[k++] = ((meterCmd >> 8) & 0x000000FF) + 0x33;
    cmd_t->data[k++] = ((meterCmd >>16) & 0x000000FF) + 0x33;
    cmd_t->data[k++] = ((meterCmd >>24) & 0x000000FF) + 0x33;
    cmd_t->data[k++] = DLT645DataCheck(&cmd_t->data[0], 14);
    cmd_t->data[k++] = 0x16;
    cmd_t->buf_len = k;

    return k;
}

int32_t DltSend(uintptr_t fd, const uint8_t *req, uint8_t req_length)
{
    if (fd == INVALID_VALUE)
    {
        return -1;
    }

    int32_t writeLen;
    writeLen = write (fd, req , sizeof(uint8_t)*req_length);

//     printf("\n %s:", __func__);
//     int32_t i = 0;
//     for (i = 0; i < req_length; i++)
//     {
//         printf("0x%x ", req[i]);
//     }
//     printf("\n");

    return writeLen;
}


//得到了一个完整的数据帧
int32_t DltRecv(uintptr_t fd, uint8_t *rsq)
{
    if (fd == INVALID_VALUE)
    {
        return -1;
    }

    int size_i = 0, i = 0;
    uint8_t rsq_length = 0;
    uint8_t datalen = 0;
    uint32_t recverror = 0;

    while(1)
    {
        i = read(fd, rsq+size_i, 50);
        if (i > 0)
        {
            size_i += i;
            if (size_i > 9)
            {
                datalen = rsq[9];
            }

            if (size_i == (datalen+12))
            {
                recverror = 0;
                rsq_length = size_i;

//                 int32_t j = 0;
//                 for(j = 0; j < size_i; j++)
//                 {
//                     printf("rsq_sg_meter[%d]=%x  ",j,rsq[j]);
//                 }
//                 printf("\n");

                return rsq_length;
            }
        }
        else if (size_i == 0)
        {
            recverror++;

            if((recverror % 300) == 0)
            {
                return -1;
            }
        }
    }
}




