#ifndef DAEMONUTILS_H_INCLUDED
#define DAEMONUTILS_H_INCLUDED

#include "common.h"

int32_t ZipFile(IN const char* src, IN const char* dest);
int32_t UnzipFile(IN const char* fileName, IN const char* extractTo);
int32_t SplitZipFile(IN char *dirAndFileName, OUT char* md5, IN uint8_t md5Len);/* 人dirAndFileName 需要包含绝对路径*/
int32_t GenerateMd5(IN char *dirAndFileName, OUT char *outstr, IN uint8_t outstrLen);
int32_t readFileListAndCopy(char *basePath);
#endif // DAEMONUTILS_H_INCLUDED
