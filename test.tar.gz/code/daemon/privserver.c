#include <sys/prctl.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include "privserver.h"
#include "file_operate.h"
#include "HCd.h"
#include "sys.h"
#include "daemonUtils.h"

#define PORTNUM 5800
#define HOSTIP "0.0.0.0"

PRIV_SER_T *g_pSess;

typedef struct ClientCmd
{
	const char *cmd;
	void (*cmdHandler)(PRIV_SER_T *pServer);
} ClientCmd_T;

/*
 * 去掉字符串str中的字符operator
 */
int32_t StrTrim(char *str, char operator)
{
    if (NULL == str)
    {
        return -1;
    }

    int count = 0;
    size_t i;
    for (i = 0; i < strlen(str); ++i)
    {
        if (str[i] != operator)
        {
            str[count++] = str[i];
        }
    }

    str[count] = '\0';

    return count;
}

/*
 * 以字符operator分离字符串
 */
int32_t StrSplit(const char *str, char *left, uint32_t leftLen, char *right, uint32_t rightLen, char operator)
{
    char *p = strchr(str, operator);

    if (p == NULL || leftLen < (p - str))
    {
        return -1;
    }
    else
    {
        strncpy(left, str, p - str);
        strncpy(right, p + 1, rightLen);
    }

    return 0;
}

static void HandleUpg(PRIV_SER_T *pServer)
{
    int32_t ret = 0;
    int32_t err = 0;

    printf("%s start...(tm:%lu.%lu) \n", __func__, get_time_sec(), get_time_usec()/1000);
    uint8_t len = strlen(pServer->arg);
    if (len <= 0)
    {
        ServerReply(-1, "Upgrade file name is empty.");
        return;
    }

    char *pUpgradeName = pServer->arg;
    do
    {
        pServer->isUpg = TRUE;
        ret = SaveUpgradeFileName(pUpgradeName);
        if (ret < 0)
        {
            err = ret;
            break;
        }
        printf("%s 1. save %s OK.\n", __func__, pUpgradeName);

        //do verity
        ret = DoVerify();
        if (ret < 0)
        {
            err = ret;
            break;
        }
        printf("%s 2. verify OK.\n", __func__);

        //save
        ret = SaveUpgradeFlag(TRUE);
        if (ret < 0)
        {
            err = ret;
        }
        printf("%s 3. save upgrade flag OK.\n", __func__);
    }while(0);

    //reply Client
    char *resp = (err == 0) ? "Verify OK." : "Verify NG.";
    ServerReply(err, resp);
    if(err != 0)
    {
        return;
    }

    do
    {
        ret = DoUpgradeForFMC();
        if (ret != 0)
        {
            break;
        }

        printf("%s 4. do upgrade OK.\n", __func__);

        ret = DoCheckRunning();

        if (IsProcessRun(APPNAME))
        {
            printf("%s 5. new app is running OK.\n", __func__);
        }

    }while(0);

    printf("%s (L%d)\n", __func__, __LINE__);
//     char *text = (ret == 0) ? "Upgrade OK." : "Upgrade NG.";
//     ServerReply(ret, text);
    printf("%s (L%d)\n", __func__, __LINE__);

    //升级完成，删除升级压缩包
    char *file = malloc(sizeof(char) * (sizeof(UPLOAD_PATH) + len + 1));
    if (file != NULL)
    {
        memset(file, 0, sizeof(UPLOAD_PATH) + len + 1);
        sprintf(file, "%s%s", UPLOAD_PATH, pUpgradeName);
        RemoveDir(file);
        printf("%s 6. delete file:%s OK.\n", __func__, file);
        free(file);
    }

    pServer->isUpg = FALSE;

    printf("%s complete.(tm:%lu.%lu)\n", __func__, get_time_sec(), get_time_usec()/1000);

    system("reboot");
    return;
}

static void HandleImport(PRIV_SER_T *pServer)
{
    int32_t ret = 0;

    printf("%s start...(tm:%lu.%lu) \n", __func__, get_time_sec(), get_time_usec()/1000);
    uint8_t len = strlen(pServer->arg);
    if (len <= 0)
    {
        ServerReply(-1, "Import file name is empty.");
        return;
    }

    char *pImportFileName = pServer->arg;

    if (IsIn(pImportFileName, UPLOAD_PATH))
    {
        char file[200] = "";
        sprintf(file, "%s%s", UPLOAD_PATH, pImportFileName);
        ret = UnzipFile(file, RUNNING_PATH);

        char *text = (ret == 0) ? "Import OK." : "Import NG.";
        ServerReply(ret, text);
        printf("%s ,ret:%d.... (p:%d, pp:%d)\n", text, ret, getpid(), getppid());

        ret = RemoveDir(file);
        printf("remove pImportFileName:%s ret:%d.... (p:%d, pp:%d)\n", pImportFileName, ret, getpid(), getppid());
    }

    return;
}

static void HandleExport(PRIV_SER_T *pServer)
{
    int32_t ret = 0;

    printf("%s start...(tm:%lu.%lu) \n", __func__, get_time_sec(), get_time_usec()/1000);
    uint8_t len = strlen(pServer->arg);
    if (len <= 0)
    {
        ServerReply(-1, "Import file name is empty.");
        return;
    }

    char *pExportFileName = pServer->arg;
    char file[200] = "";
    sprintf(file, "%s%s", UPLOAD_PATH, pExportFileName);
    if (IsIn(pExportFileName, UPLOAD_PATH))
    {
        ret = RemoveDir(file);
        printf("remove old file:%s ret:%d.... (p:%d, pp:%d)\n", file, ret, getpid(), getppid());
    }
    ret = ZipFile("./conf/", file);
    if (IsIn(pExportFileName, UPLOAD_PATH))
    {
        char *text = (ret == 0) ? "Export OK." : "Export NG.";
        ServerReply(ret, text);
        printf("%s ret:%d.... (p:%d, pp:%d)\n", text, ret, getpid(), getppid());
    }

    return;
}

static void HandleReboot(PRIV_SER_T *pServer)
{
    int32_t ret = 0;

    printf("%s start...(tm:%lu.%lu) \n", __func__, get_time_sec(), get_time_usec()/1000);
    uint8_t len = strlen(pServer->arg);
    if (len <= 0)
    {
        ServerReply(-1, "Import file name is empty.");
        return;
    }

    /* 停止应用程序 */
    if (IsProcessRun(APPNAME))
    {
        ret = system("killall CEMS");
        syslog(LOG_ERR, "Kill %s,ret:%d.... (p:%d, pp:%d)\n", APPNAME, ret, getpid(), getppid());
        printf("%s Kill %s,ret:%d.... (p:%d, pp:%d)\n", __func__, APPNAME, ret, getpid(), getppid());
    }

    return;
}

/*命令映射*/
static ClientCmd_T ctrlCmds[] =
{
    /*控制命令*/
    {"UPGRADE", HandleUpg},
    {"IMPORT", HandleImport},
    {"EXPORT", HandleExport},
    {"REBOOT", HandleReboot},
    {"NULL", NULL}
};

static int32_t HandleClientCmd(PRIV_SER_T *pServer)
{
    int32_t ret = 0;

    ret = StrTrim(pServer->cmdline, '$');
    printf("%s StrTrim ret:%d cmdline:%s\n", __func__, ret, pServer->cmdline);

    ret = StrSplit(pServer->cmdline, pServer->cmd, MAX_COMMAND, pServer->arg, MAX_ARG, ':');

    printf("StrSplit ret:%d cmd:%s arg:%s \n", ret, pServer->cmd, pServer->arg);

    //处理client命令
    int i = 0;
    int size = sizeof(ctrlCmds) / sizeof(ctrlCmds[0]);
    for (i = 0; i < size; ++i)
    {
        if (strcmp(ctrlCmds[i].cmd, pServer->cmd) == 0)
        {
            if (ctrlCmds[i].cmdHandler != NULL)
            {
                ctrlCmds[i].cmdHandler(pServer);
            }
            else
            {
                /*未实现命令*/
                char *resp = "Uncompletement command";
                ServerReply(-1, resp);
            }
            break;
        }
    }

    if (i == size)
    {
        /*不认识命令*/
        char *resp = "Bad command";
        ServerReply(-1, resp);
    }

    return ret;
}

void CmdServerFunc(void)
{
    int32_t listenfd = 0;
	int connfd = 0;
	struct sockaddr_in addr;
    int32_t ret = 0;

    prctl(PR_SET_NAME, "DAEMON_CMD_SERVER_THREAD");

    printf("%s start...\n", __func__);
    syslog(LOG_ERR, "%s start...\n", __func__);

    PRIV_SER_T sess = {0, "", "", "", FALSE};
    g_pSess = &sess;

    do
    {
        ret = sckServer_init(HOSTIP, PORTNUM, &listenfd);
        if (ret != 0)
        {
            printf("%s init server fail.\n", __func__);
        }
        sleep(1);
    }while(ret != 0);

    syslog(LOG_ERR, "%s listenfd:%d (L%d)\n", __func__, listenfd, __LINE__);

    while (1)
    {
        ret = sckServer_accept(listenfd, &connfd, (void*)&addr, 0);
        if (ret == Sck_ErrTimeOut || ret == -1)
        {
            printf("%s accept timeout (L%d)\n", __func__, __LINE__);
            sleep(1);
            continue;
        }

        syslog(LOG_ERR, "%s connfd:%d (L%d)\n", __func__, connfd, __LINE__);
        printf("%s connfd:%d (L%d)\n", __func__, connfd, __LINE__);
        g_pSess->connfd = connfd;

        int32_t len = MAX_COMMAND_LINE;
        while (1)
        {
            memset(g_pSess->cmdline, 0, sizeof(char) * MAX_COMMAND_LINE);
            ret = sckServer_rev(connfd, (unsigned char *)g_pSess->cmdline, &len, 1);
            //syslog(LOG_ERR, "%s recv:%d len:%d (L%d)\n", __func__, ret, len, __LINE__);
            if (ret < 0 || ret > Sck_BaseErr)
            {
                if (ret == Sck_ErrPeerClosed)
                {
                    syslog(LOG_ERR, "%s close fd:%d (L%d)\n", __func__, connfd, __LINE__);
                    printf("%s close fd:%d (L%d)\n", __func__, connfd, __LINE__);
                    close(connfd);
                    g_pSess->connfd = 0;
                    break;
                }
            }
            else if (len > 0)
            {
                /*int i = 0;
                for(i = 0; i < len; i++)
                {
                    printf("%s recv cmdline[%d]:%d (L%d)\n", __func__, i, g_pSess->cmdline[i], __LINE__);
                    syslog(LOG_ERR, "%s recv cmdline %d:%c %d (L%d)\n", __func__, i, g_pSess->cmdline[i], g_pSess->cmdline[i], __LINE__);
                }
                */
                printf("%s len:%d recv cmdline:%s (L%d)\n", __func__, len, g_pSess->cmdline, __LINE__);
                syslog(LOG_ERR, "%s len:%d recv cmdline:%s (L%d)\n", __func__, len, g_pSess->cmdline, __LINE__);

                ret = HandleClientCmd(g_pSess);
            }
        }
    }

    return;
}

void ServerReply(int status, const char *text)
{
    if (text == NULL || g_pSess == NULL || g_pSess->connfd <= 0)
    {
        return;
    }

    char buf[1024] = {0};
    sprintf(buf, "$%d,%s$", status, text);
    writen(g_pSess->connfd, buf, strlen(buf));

    //sckServer_send(g_pSess->connfd, (unsigned char*)buf, strlen(buf), 0);
}

BOOL IsServerDoUpg(void)
{
    return (g_pSess == NULL) ? FALSE : g_pSess->isUpg;
}
