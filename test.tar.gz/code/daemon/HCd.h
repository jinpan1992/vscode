#ifndef HYCTRLD_H_INCLUDED
#define HYCTRLD_H_INCLUDED

#include "common.h"
#include "privserver.h"

// #define EEPROM_PATH "/sys/class/spi_master/spi2/spi2.0/eeprom"
#define EEPROM_PATH "/sys/devices/soc0/soc/2100000.aips-bus/21a0000.i2c/i2c-0/0-0050/eeprom"
#define RUNNING_PATH "/home/SGComm/"
#define BACKUP_PATH "/home/backup/"
#define UPLOAD_PATH "/home/ftp/"
#define APPNAME "CEMS"
#define WEBNAME "webserver"
#define WEB_PATH "/home/SGWeb/webserver"

#define CONF "conf/"

#define MAX_FILE_NAME_LEN 128
#define MD5_LEN 32

#define REBOOT_COUNT 3

typedef struct E2P_DAE
{
    BOOL  bUpgarde;
    char cUpgradeFileName[MAX_FILE_NAME_LEN];
} E2P_DAE_T;

typedef struct PRIV_DAEMON
{
    BOOL g_bFirst;
    E2P_DAE_T e2p;
    pthread_mutex_t mLock;
    uint8_t rebootCount;
    BOOL isDisableWatch;
} PRIV_DAEMON_T;

int32_t SaveUpgradeFileName(char *fileName);
int32_t SaveUpgradeFlag(BOOL flag);
int32_t DoVerify(void);
int32_t DoUpgrade(void);
int32_t DoUpgradeForFMC(void);
int32_t DoCheckRunning(void);

#endif // HYCTRLD_H_INCLUDED
