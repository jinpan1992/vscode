#!/bin/sh

make clean


make


exit 0

