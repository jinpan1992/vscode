#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <syslog.h>
#include <fcntl.h>   /* open */
#include <dirent.h>
#include <sys/stat.h>
#include "e2rom.h"
#include "sys.h"
#include "HCd.h"
#include "daemonUtils.h"
#include "file_operate.h"

PRIV_DAEMON_T g_Daemon;

int32_t SaveUpgradeFileName(char *fileName)
{
    uint8_t len = strlen(fileName);
    int32_t ret = 0;
    int32_t fd = 0;
    if (len <= 0 || len > MAX_FILE_NAME_LEN)
    {
        return -1;
    }

    printf("%s:%s \n", __func__, fileName);
    pthread_mutex_lock(&g_Daemon.mLock);
    strncpy(g_Daemon.e2p.cUpgradeFileName, fileName, MAX_FILE_NAME_LEN);
    pthread_mutex_unlock(&g_Daemon.mLock);

    fd = E2romOpen(EEPROM_PATH);
    if (fd > 0)
    {
        ret = E2romWrite(fd, EEPROM_UPGRADE_FILENAME, &g_Daemon.e2p.cUpgradeFileName, sizeof(g_Daemon.e2p.cUpgradeFileName));
        ret = E2romClose(fd);
    }

    return ret;
}

int32_t SaveUpgradeFlag(BOOL flag)
{
    printf("%s flag:%d\n", __func__, flag);
    int32_t ret = 0;
    int32_t fd = 0;

    pthread_mutex_lock(&g_Daemon.mLock);
    g_Daemon.e2p.bUpgarde = flag;
    pthread_mutex_unlock(&g_Daemon.mLock);

    fd = E2romOpen(EEPROM_PATH);
    if (fd > 0)
    {
        ret = E2romWrite(fd, EEPROM_UPGRADE_FLAG, &g_Daemon.e2p.bUpgarde, sizeof(BOOL));
        ret = E2romClose(fd);
    }

    return ret;
}

void InitDaemonContext()
{
    int32_t i;

    //清除文件掩模
    umask(0);

    printf("%s getdtablesize:%d\n", __func__, getdtablesize());
    //关闭文件描述符
    for(i = 3; i < getdtablesize(); i++)
    {
        close(i);
    }

    //重定向stdin、stdout、stderr
//     int32_t fd = open("/dev/null", O_RDWR);
//     if (fd == -1)
//     {
//         syslog(LOG_ERR, "open(\"/dev/null\") fail. (p:%d, pp:%d)\n", getpid(), getppid());
//         return ;
//     }
//
//     if (dup2(fd, STDIN_FILENO) == -1)
//     {
//         syslog(LOG_ERR, "dup2(STDIN_FILENO) fail. (p:%d, pp:%d)\n", getpid(), getppid());
//     }
//
//     if (dup2(fd, STDOUT_FILENO) == -1)
//     {
//         syslog(LOG_ERR, "dup2(STDOUT_FILENO) fail. (p:%d, pp:%d)\n", getpid(), getppid());
//     }
//
//     if (dup2(fd, STDERR_FILENO) == -1)
//     {
//         syslog(LOG_ERR, "dup2(STDERR_FILENO) fail. (p:%d, pp:%d)\n", getpid(), getppid());
//     }
//
//     close(fd);

    return;
}

void DoCheckFirst(void)
{
    uint8_t buf = 0;
    int32_t fd = 0;
    int32_t ret = 0;

    //需要从e2 里读升级标志位，防止上次掉电g_bUpgrade丢失；
    fd = E2romOpen(EEPROM_PATH);
    if (fd > 0)
    {
        ret = E2romRead(fd, EEPROM_UPGRADE_FLAG, &buf, sizeof(buf));
        if (ret < 0)
        {
            syslog(LOG_ERR, "read e2 fail.\n");
        }
        ret = E2romClose(fd);
    }

    g_Daemon.g_bFirst = FALSE;
    g_Daemon.e2p.bUpgarde = buf;
    g_Daemon.rebootCount = REBOOT_COUNT; ///restart fastly on the first system on.

    syslog(LOG_ERR, "Power on, g_bUpgrade:%d.\n", g_Daemon.e2p.bUpgarde);

    return;
}

int32_t DoVerify(void)
{
    char *ori = NULL;
    char md5[MD5_LEN + 1] = "0";
    char newMd5[MD5_LEN + 1] = "0";
    int32_t ret = 0;

    if (!IsIn(g_Daemon.e2p.cUpgradeFileName, UPLOAD_PATH))
    {
        printf("%s upload path has no file:%s\n", __func__, g_Daemon.e2p.cUpgradeFileName);
        return -1;
    }

    uint8_t fileNameLen = strlen(g_Daemon.e2p.cUpgradeFileName);
    uint8_t filePathLen = strlen(UPLOAD_PATH);
    uint8_t oriLen = fileNameLen + filePathLen;
    ori = malloc(sizeof(char) * (oriLen + 1));
    if (ori == NULL)
    {
        return -1;
    }

    do
    {
        sprintf(ori, "%s%s", UPLOAD_PATH, g_Daemon.e2p.cUpgradeFileName);
        ret = SplitZipFile(ori, md5, MD5_LEN + 1);
        if(ret < 0)
        {
            break;
        }

        GenerateMd5(ori, newMd5, MD5_LEN);
        printf("%s zip md5:%s, newMd5:%s\n", __func__, md5, newMd5);

        if(strncmp(md5, newMd5, MD5_LEN) != 0)
        {
            printf("verify NG!\n");
            ret = -1;
            break;
        }

        printf("verify ok!\n");
    }while(0);

    free(ori);

    return ret;
}

int32_t DoCheckRunning(void)
{
    int32_t ret = 0;
    //if (IsProcessRun("apptest") == FALSE)
    if (IsProcessRun(APPNAME) == FALSE)
    {
        syslog(LOG_ERR, "%s is not running,app count:%d, rebootCount:%d. (p:%d, pp:%d)\n",
               APPNAME, getpid(), getppid(), GetProcessCount(APPNAME), g_Daemon.rebootCount);
        printf("%s is not running,app count:%d, rebootCount:%d. (p:%d, pp:%d)\n",
               APPNAME, getpid(), getppid(), GetProcessCount(APPNAME), g_Daemon.rebootCount);

        if (g_Daemon.rebootCount < REBOOT_COUNT)
        {
            pthread_mutex_lock(&g_Daemon.mLock);
            g_Daemon.rebootCount++;
            pthread_mutex_unlock(&g_Daemon.mLock);
            printf("%s (L%d)\n", __func__, __LINE__);
            return ret;
        }

        //if (IsIn("apptest", RUNNING_PATH))
        if (IsIn(APPNAME, RUNNING_PATH))
        {
            syslog(LOG_ERR, "running path has app. (p:%d, pp:%d)\n", getpid(), getppid());
            printf("running path has app. (p:%d, pp:%d)\n", getpid(), getppid());

            /* 启动应用程序 */
            //system("./apptest &");
            ret = system("./CEMS &");

            /* 删除备份 */
            ret = RemoveDir("/home/backup/SGComm/");

            /* 将当前应用程序和配置文件备份到backup path */
            char c[] = "cp -r /home/SGComm/ /home/backup/";
            ret = system(c);
        }
        else if (IsIn("SGComm", BACKUP_PATH))
        {
            //syslog(LOG_ERR, "backup path has SGComm dir. (p:%d, pp:%d)\n", getpid(), getppid());

            /* 将备份拷贝带runnung path*/
            //char cmd[] = "cp -r /home/backup/SGComm/ /home/SGComm/";
            //ret = system(cmd);
        }
    }
    else
    {
        //syslog(LOG_ERR, "%s is running. (p:%d, pp:%d)\n", APPNAME, getpid(), getppid());
        pthread_mutex_lock(&g_Daemon.mLock);
        g_Daemon.rebootCount = 0;
        pthread_mutex_unlock(&g_Daemon.mLock);
    }

    return ret;
}

int32_t DoUpgrade(void)
{
    int32_t ret = 0;
    printf("%s()... \n", __func__);
    if (IsIn(g_Daemon.e2p.cUpgradeFileName, UPLOAD_PATH))
    {
        syslog(LOG_ERR, "It has upgrade file and do upgrading.... (p:%d, pp:%d)\n", getpid(), getppid());

        /* 停止应用程序 */
        if (IsProcessRun(APPNAME))
        {
            ret = system("killall CEMS");
            syslog(LOG_ERR, "Kill CEMS,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
        }

        if (1)
        {
            /* 解压升级包到tmp path */
            char file[200] = "";
            sprintf(file, "%s%s", UPLOAD_PATH, g_Daemon.e2p.cUpgradeFileName);
            ret = UnzipFile(file, "/tmp");
            syslog(LOG_ERR, "UnZip to /tmp/,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
            printf("UnZip to /tmp/,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());

            /*拷贝应用程序到RUNNING_PATH*/
            ret = system("cp /tmp/SGComm/CEMS /tmp/SGComm/HCd /tmp/SGComm/tinyftpd /home/SGComm/");
            syslog(LOG_ERR, "copy new app, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());

            /* 赋予可执行权限 */
            ret = system("chmod 777 -R /home/SGComm/");
            syslog(LOG_ERR, "chomd /home/SGComm/, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
            printf("chomd /home/SGComm/, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());

            /* 删除/tmp/SGComm*/
            ret = system("rm -rf /tmp/SGComm");
            syslog(LOG_ERR, "rm -rf /tmp/SGComm, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
            printf("rm -rf /tmp/SGComm, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
        }
        else
        {
            /*清空当前应用程序和配置文件*/
            ret = EmptyDir(RUNNING_PATH);
            syslog(LOG_ERR, "Empty current running dir,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
            printf("Empty current running dir,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());

            /* 解压升级包到running path */
            char file[200] = "";
            sprintf(file, "%s%s", UPLOAD_PATH, g_Daemon.e2p.cUpgradeFileName);
            ret = UnzipFile(file, "/home");
            syslog(LOG_ERR, "UnZip to /home/,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
            printf("UnZip to /home/,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
        }

        char *resp = (ret == 0) ? "UnZip OK." : "UnZip NG.";
        ServerReply(ret, resp);
    }

    SaveUpgradeFlag(FALSE);

    printf("%s ret:%d\n", __func__, ret);

    return ret;
}

int32_t DoUpgradeForFMC(void)
{
    int32_t ret = 0;
    printf("%s()... \n", __func__);
    if (IsIn(g_Daemon.e2p.cUpgradeFileName, UPLOAD_PATH))
    {
        syslog(LOG_ERR, "It has upgrade file and do upgrading.... (p:%d, pp:%d)\n", getpid(), getppid());

        /* 停止应用程序 */
        if (IsProcessRun(APPNAME))
        {
            ret = system("killall CEMS");
            syslog(LOG_ERR, "Kill CEMS,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
        }

        if (IsProcessRun(WEBNAME))
        {
            ret = system("killall webserver");
            syslog(LOG_ERR, "Kill webserver,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
        }

        if (1)
        {
            /* 解压升级包到tmp path */
            char file[200] = "";
            sprintf(file, "%s%s", UPLOAD_PATH, g_Daemon.e2p.cUpgradeFileName);
            ret = UnzipFile(file, "/tmp");
            syslog(LOG_ERR, "UnZip to /tmp/,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
            printf("UnZip to /tmp/,ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());

            /*拷贝应用程序到RUNNING_PATH*/
//             ret = system("cp /tmp/SGComm/CEMS /tmp/SGComm/HCd /home/SGComm/");
//             syslog(LOG_ERR, "copy new app, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
            ret = readFileListAndCopy("/tmp/home");

            /* 赋予可执行权限 */
            ret = system("chmod 777 -R /home/SGComm/");
            ret = system("chmod 777 -R /home/SGWeb/");
            syslog(LOG_ERR, "chomd /home/SGComm/, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
            printf("chomd /home/SGComm/, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());

            /* 删除/tmp/SGComm*/
            ret = system("rm -rf /tmp/home");
            syslog(LOG_ERR, "rm -rf /tmp/home, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
            printf("rm -rf /tmp/home, ret:%d.... (p:%d, pp:%d)\n", ret, getpid(), getppid());
        }

//         char *resp = (ret == 0) ? "UnZip OK." : "UnZip NG.";
//         ServerReply(ret, resp);
    }

    SaveUpgradeFlag(FALSE);

    printf("%s ret:%d\n", __func__, ret);

    return ret;
}

int32_t DoCheckWebRunning(void)
{
    int32_t ret = 0;

    if (IsProcessRun(WEBNAME) == FALSE && IsProcessRun(APPNAME) == TRUE)
    {
        syslog(LOG_ERR, "%s is not running,app count:%d, rebootCount:%d. (p:%d, pp:%d)\n",
               WEBNAME, getpid(), getppid(), GetProcessCount(WEBNAME), g_Daemon.rebootCount);
        printf("%s is not running,app count:%d, rebootCount:%d. (p:%d, pp:%d)\n",
               WEBNAME, getpid(), getppid(), GetProcessCount(WEBNAME), g_Daemon.rebootCount);

        if (IsIn(WEBNAME, WEB_PATH))
        {
            syslog(LOG_ERR, "running path has app. (p:%d, pp:%d)\n", getpid(), getppid());
            printf("path:%s has %s. (p:%d, pp:%d)\n", WEB_PATH, WEBNAME, getpid(), getppid());

            /* 启动应用程序 */
            ret = system("./home/SGWeb/webserver/webserver port=8088 &");
        }
    }

    return ret;
}

void DoCheckUpgradeAndRunning(BOOL isDisableWatch)
{
    printf("%s \n", __func__);
    while (1)
    {
        if (!isDisableWatch)
        {
            //开机第一次检查
            if (g_Daemon.g_bFirst)
            {
                DoCheckFirst();
            }

            if (IsServerDoUpg() == FALSE)
            {
                if (g_Daemon.e2p.bUpgarde)
                {
                    DoUpgradeForFMC();
                }

                DoCheckRunning();
            }
        }

        sleep(5);
    }
    return;
}

int main(int argc, char *argv[])
{
    pid_t son;
    pid_t grandson;
    pid_t sid;

    int32_t res;
    pthread_t daemon_server;

    printf("HCD start...(p:%d pp:%d)\n", getpid(), getppid());
//     openlog("daemon_hcd", LOG_PID, LOG_DAEMON);
    syslog(LOG_ERR, "hcd starting....\n");

    memset(&g_Daemon, 0, sizeof(PRIV_DAEMON_T));
    g_Daemon.g_bFirst = TRUE;
    pthread_mutex_init(&g_Daemon.mLock, NULL);

    if (argc > 1)
    {
        const char* argv1 = argv[1];
        if (strcmp(argv1, "1") == 0)
        {
            g_Daemon.isDisableWatch = TRUE;
            syslog(LOG_ERR, "hcd don't watch.\n");
            printf("hcd don't watch.\n");
        }
    }

    son = fork();
    if (son < 0)
    {
        syslog(LOG_ERR, "fork son fail!\n");
        exit(EXIT_SUCCESS);
    }

    if (son == 0)
    {
        syslog(LOG_ERR, "this is son and fork! (p:%d, pp:%d)\n", getpid(), getppid());
        sid = setsid();
        printf("Hcd sid:%d\n", sid);
        grandson = fork();
        if (grandson)
        {
            syslog(LOG_ERR, "this is son and exit. (p:%d, pp:%d)\n", getpid(), getppid());
            exit(EXIT_SUCCESS);
        }
        else
        {
            syslog(LOG_ERR, "this is grandson. (p:%d, pp:%d)\n", getpid(), getppid());

            if (access (RUNNING_PATH, F_OK) != 0)
            {
                res = mkdir(RUNNING_PATH, 0777);
                printf("create RUNNING_PATH, ret:%d\n ", res);
            }

            if (access (BACKUP_PATH, F_OK) != 0)
            {
                res = mkdir(BACKUP_PATH, 0777);
                printf("create BACKUP_PATH, ret:%d\n ", res);
            }

            //更改当前目录
            sid = chdir(RUNNING_PATH);
            if (sid < 0)
            {
                printf("Modify working dir fail!\n");
                exit(EXIT_FAILURE);
            }

            InitDaemonContext();
            syslog(LOG_ERR, "%s init daemon done.(p:%d, pp:%d)\n", __func__, getpid(), getppid());

            //开启cmdserver
            res = pthread_create(&daemon_server, NULL, (void*)CmdServerFunc, NULL);
            if (res != 0)
            {

            }

            //循环检测升级标志/hc 进程，当进程退出时，重新启动hc
            DoCheckUpgradeAndRunning(g_Daemon.isDisableWatch);
        }
    }
    else if(son > 0)
    {
        syslog(LOG_ERR, "this is father,exit! (p:%d, pp:%d)\n", getpid(), getppid());
        closelog();
        exit(EXIT_SUCCESS);
    }

    syslog(LOG_ERR, "%s (p:%d, pp:%d) return.\n", __func__, getpid(), getppid());

    closelog();

    return 0;
}
