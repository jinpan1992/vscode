#ifndef _SCK_CLINT_H_
#define _SCK_CLINT_H_


#ifdef __cplusplus
extern 'C'
{
#endif

#include <netinet/in.h>

//错误码定义

#define Sck_Ok              0
#define Sck_BaseErr         3000

#define Sck_ErrParam        (Sck_BaseErr+1)
#define Sck_ErrTimeOut      (Sck_BaseErr+2)
#define Sck_ErrPeerClosed   (Sck_BaseErr+3)
#define Sck_ErrMalloc       (Sck_BaseErr+4)

//客户端Socket接口

//客户端环境初始化
int sckCliet_init(void **handle, int contime, int sendtime, int revtime, int nConNum);
int sckCliet_getconn(void *handle, char *ip, int port, int *connfd);
//int sckCliet_putconn(int *connfd);
int sckCliet_closeconn(int *connfd);
//客户端发送报文
int sckClient_send(void *handle, int connfd, unsigned char *data, int datalen);
//客户端端接受报文
int sckClient_rev(void *handle, int connfd, unsigned char *out, int *outlen); //1
// 客户端环境释放
int sckClient_destroy(void *handle);


//服务器端初始化
int sckServer_init(const char *address, int port, int *listenfd);
int sckServer_accept(int listenfd, int *connfd, void *addr, int timeout);
//服务器端发送报文
int sckServer_send(int connfd,  unsigned char *data, int datalen, int timeout);
//服务器端端接受报文
int sckServer_rev(int  connfd, unsigned char *out, int *outlen,  int timeout); //1
//服务器端环境释放
int sckServer_destroy(void *handle);

/*********************************** socket related **********************************/

#define ERR_EXIT(m) \
  do \
  { \
    perror(m); \
	exit(EXIT_FAILURE); \
  } \
  while (0)


#define MAX_COMMAND_LINE 1024
#define MAX_COMMAND      32
#define MAX_ARG			 1024

/*创建客户端监听套接字*/
int tcp_client(const char *address, unsigned short port);

/*设置套接字为非阻塞*/
int activate_nonblock(int fd);
/*设置套接字为阻塞*/
int deactivate_nonblock(int fd);

/*带超时的数据接收*/
int read_timeout(int fd, unsigned int wait_seconds);
/*带超时的数据发送*/
int write_timeout(int fd, unsigned int wait_seconds);
/*带超时的accept*/
int accept_timeout(int fd, struct sockaddr_in *addr, unsigned int wait_seconds);
/*带超时的connect*/
int connect_timeout(int fd, struct sockaddr_in *addr, unsigned int wait_seconds);


ssize_t readn(int fd, void *buf, size_t count);
ssize_t writen(int fd, const void *buf, size_t count);
ssize_t recv_peek(int sockfd, void *buf, size_t len);
ssize_t readline(int sockfd, void *buf, size_t maxline);

#ifdef __cpluspluse
}
#endif


#endif
