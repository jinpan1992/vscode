#ifndef PRIVCMD_H_INCLUDED
#define PRIVCMD_H_INCLUDED

#include "common.h"
#include "commsocket.h"

typedef struct PRIV_SER
{
    //控制连接
    int  connfd;
    char cmdline[MAX_COMMAND_LINE];
    char cmd[MAX_COMMAND];
    char arg[MAX_ARG];
    BOOL isUpg;

} PRIV_SER_T;

void CmdServerFunc(void);
void ServerReply(int status, const char *text);
BOOL IsServerDoUpg(void);


#endif // PRIVCMD_H_INCLUDED
