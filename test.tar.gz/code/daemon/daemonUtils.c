#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include "daemonUtils.h"
#include "file_operate.h"

int32_t ZipFile(const char* src, const char* dest)
{
    char command[4096] = {0};
    sprintf(command, "zip -q -r %s %s", dest, src);

    return system(command);
}

int32_t UnzipFile(const char* fileName, const char* extractTo)
{
    char command[4096] = {0};
    sprintf(command, "unzip -o %s -d %s", fileName, extractTo);

    return system(command);
}

//filePrefixName 文件名前缀
int32_t UnzipAllFile(const char* filePrefixName, int32_t start, int32_t end, const char* extractTo)
{
    char command[4096] = {0};
    int16_t i = 0;
    for(i = start; i <= end; i++)
    {
        sprintf(command, "unzip %s%02d.zip -d %s", filePrefixName, i, extractTo);
        system(command);
    }

    return 0;
}

//编写得到文件ms5校验码的函数
int32_t GenerateMd5(IN char *dirAndFileName, OUT char *outstr, IN uint8_t outstrLen)
{
    int32_t ret = 0;
    if (outstr == NULL || outstrLen == 0)
    {
        return -1;
    }
    char buf[4096] = "";
    sprintf(buf,"md5sum %s", dirAndFileName);//添加文件名构成命令，利用popen得到md5校验码

    FILE *fp;
    fp = popen(buf, "r");
    if(NULL != fp)
    {
        ret = fread(outstr, 1, outstrLen, fp);
        //sscanf(c_buf, "%s", outstr);//sscanf函数是通过从字符串中读取想要的内容
    }
    pclose(fp);

    return ret;
}

int32_t SplitZipFile(char *dirAndFileName, char* md5, uint8_t md5Len)
{
    int32_t ret = 0;
    FILE *ftpFileFd = NULL;
    FILE *fin = NULL;
    char readBuf[65535];
    char *new = NULL;
    if (dirAndFileName == NULL || md5 == NULL)
    {
        return -1;
    }

    uint8_t fileNameLen = strlen(dirAndFileName);
    char *ori = dirAndFileName;

    char *tmpfilename = ".bak";
    uint8_t tmpFileNameLen = strlen(tmpfilename);
    new = malloc(sizeof(char) * (fileNameLen + tmpFileNameLen + 1));
    if (ori == NULL || new == NULL)
    {
        return -1;
    }

    do
    {
        ftpFileFd = fopen(ori, "rb");

        sprintf(new, "%s%s", ori, tmpfilename);
        fin = fopen(new, "wb");

        if (ftpFileFd == NULL || fin == NULL)
        {
            ret = -1;
            break;
        }

        //读取md5
        ret = fread(md5, 1, md5Len -1, ftpFileFd);
        if (ret == md5Len -1)
        {
            md5[md5Len] = '\0';
            printf("%s md5:%s\n", __func__, md5);
        }
        else
        {
            ret = -1;
            break;
        }

        while (1)
        {
            memset(readBuf, 0, sizeof(readBuf));
            ret = fread(readBuf, 1, sizeof(readBuf), ftpFileFd);
            if  (ret == -1)
            {
                if (errno == EINTR)
                {
                    continue;
                }
                else
                {
                    break;
                }
            }
            else if (ret == 0)  //传输完成
            {
                break;
            }

            if (fwrite(readBuf, 1, ret, fin) != ret)
            {
                break;
            }
        }

        fclose(ftpFileFd);
        fclose(fin);
        ftpFileFd = NULL;
        fin = NULL;

        if (ret == 0)
        {
            remove(ori);//删除原文件
            rename(new, ori);//将临时文件名改为原文件名
        }

    }while(0);

    if (ftpFileFd != NULL)
    {
        fclose(ftpFileFd);
    }

    if (fin != NULL)
    {
        fclose(fin);
    }

    free(new);

    return ret;
}

int32_t copyFile(char *pcSrcFileAndPath, char *pcDestPath)
{
    int32_t ret = OK;
    char cmd[256] = "0";

    if (!DirExist(pcDestPath))
    {
        mkdir(pcDestPath, 0777);
    }

    sprintf(cmd,"cp %s %s", pcSrcFileAndPath, pcDestPath);
    ret = system(cmd);

    return ret;
}

int32_t readFileListAndCopy(char *basePath)
{
    DIR *dir;
    struct dirent *ptr;
    char base[1000] = "0";

    if ((dir = opendir(basePath)) == NULL)
    {
        perror("Open dir error...");
        exit(1);
    }

    while ((ptr = readdir(dir)) != NULL)
    {
        if(strcmp(ptr->d_name, ".") == 0 || strcmp(ptr->d_name, "..") == 0)    ///current dir OR parrent dir
        {
            continue;
        }
        else if(ptr->d_type == 8)    ///file
        {
            char srcFileAndPath[257] = "0";
            sprintf(srcFileAndPath, "%s/%s", basePath, ptr->d_name);

            char *pcDestPath = strstr(basePath, "/home"); //拷贝到/home 目录
            copyFile(srcFileAndPath, pcDestPath);

            printf("copy d_name:%s/%s to %s\n", basePath, ptr->d_name, pcDestPath);
        }
        else if(ptr->d_type == 10)   ///link file
        {
            printf("d_name:%s/%s\n", basePath, ptr->d_name);
        }
        else if(ptr->d_type == 4)    ///dir
        {
            memset(base, '\0', sizeof(base));
            strcpy(base, basePath);
            strcat(base, "/");
            strcat(base, ptr->d_name);

            printf("base:%s \n", base);
            readFileListAndCopy(base);
        }
    }

    closedir(dir);
    return 1;
}
