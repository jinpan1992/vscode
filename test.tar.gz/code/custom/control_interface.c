#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#include "script_interface.h"
#include "sgdev.h"
#include "processor.h"
#include "sys.h"
#include "logUtil.h"
#include "sdb.h"
#include "common.h"
#include "math.h"
#include "persist.h"
#include "runCfg.h"
#include "control_interface.h"
#include <msg.h>
#include <string.h>
#include <sys/time.h>



SI_HANDLE_T ctrlHandle = {0};
uint16_t localDevcode[MAX_DEVCODE_NUM] = {0};
uint16_t remoteDevcode[MAX_DEVCODE_NUM] = {0};
// static int32_t runCtrlFlag = 0;//运行控制状态标志位
int32_t devIdArr[MAX_DEVCODE_NUM] = {0};//设备编号数组，通过编号获取devcode等信息
int32_t dev_info_num[MAX_DEVCODE_NUM] = {0};//记录第几个dev_info
int32_t allAlgoParaNum = 0;
DEV_INFO_EXT_T *dev_info = NULL;
PID_PARA_T dev_pid_param[MAX_DEVCODE_NUM] = {0};
FUNC_INPARA_T *save_in = NULL;
FUNC_OUTPARA_T *save_out = NULL;
int32_t para_num = 0;//注册个数
static float32_t remotePower[MAX_DEVCODE_NUM] = {0.0};//记录远程第一次下发的无功功率值
static float32_t remotePowerNext[MAX_DEVCODE_NUM] = {0.0};//记录远程二次以上下发的无功功率值
static float32_t returnData = 0;//PID返回值
DATA_U GetData;
RUN_PARAM_T savePara[MAX_DEVCODE_NUM] = {0};
int16_t storage_flag = 0;//储能标志位
int16_t photovoltaic = 0;//光伏标志位


//test
// int32_t testflag = 1;
// static int32_t saveData = 0;

// void setTimer(float seconds)
// {
//     struct timeval temp;
//     temp.tv_sec = seconds;
//     temp.tv_usec = 0;
//     select(0,NULL,NULL,NULL,&temp);
// }

// void RunTimer(unsigned long mSec)
// {
//     struct timeval time;
//     time.tv_sec = mSec / 1000;
//     time.tv_usec = (mSec % 1000) * 1000;
//     select(0,NULL, NULL, NULL, &time);
// }

void registPoint()
{
    //验证该函数运行次数2023/6/19
    printf("enter registPoint!\n");
    int32_t i = 0, m = 0;
    static int32_t j = 0;
    int32_t devcode = 0;
    int32_t index = 0;
    int32_t data_id = 0;
    int32_t dev_id = 0;
//     int32_t para_num = 0;//注册个数
    int32_t MAXNUM = 165;
//     char dataName[2][20] = {"有功功率", "无功功率"};
//     char dataName[3][30] = {"有功功率", "并网恒功率值(AC)", "直流电压"};
//     char dataName[4][30] = {"有功功率", "并网恒功率值(AC)", "总有功功率", "限功率百分比"};
    //并网恒流电流值
    char dataName[5][30] = {"有功功率","无功功率", "并网恒功率值(DC)", "总有功功率", "功率因数设置"};
    int32_t n = sizeof(dataName) / sizeof(dataName[0]);

    save_in = (FUNC_INPARA_T *)malloc(sizeof(FUNC_INPARA_T));
    save_in->inpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*MAXNUM);
    save_out = (FUNC_OUTPARA_T *)malloc(sizeof(FUNC_OUTPARA_T));
    save_out->outpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*MAXNUM);
    memset(save_in->inpara, 0, sizeof(FUNC_PARA_T) * MAXNUM);
    memset(save_out->outpara, 0, sizeof(FUNC_PARA_T) * MAXNUM);
    save_in->in_argc = 0;
    save_out->out_argc = 0;

    //获取北向设备数量
    int32_t NorDevNum = SDB_ND_GetNum();
//     printf("NorDevNum:%d\n", NorDevNum);
    //获取北向设备列表
    dev_info = SDB_ND_GetList();

    for(m = 0; m < n; m++)//输入测点名个数 test for 有功功率 2023/3/9
    {
        for(i = 0; i < NorDevNum; i++)
        {
            //获取设备编号
            dev_id = dev_info[i].stDevUID.dbUID;
//             printf("devno:%d\n", dev_id);
            //获取设备devcode
            devcode = dev_info[i].stDevUID.devCode;
//             printf("devcode:%d\n", devcode);
            //获取设备索引
            index = dev_info[i].stDevUID.devIndex;
//             printf("index:%d\n", index);
            //根据devcode、index、data_name获取data_id

            data_id = SDB_ND_GetDataId(devcode, index, dataName[m]);//根据测点名遍历所有的北向设备
//             printf("get data_id:%d\n", data_id);
            if(data_id  != -1)
            {
                //成功获取data_id
                para_num++;
                devIdArr[j] = dev_id;//记录设备编号
                dev_info_num[j] = i;//记录第几个dev_info[i]
                save_in->inpara[j].dev_code = devcode;
                save_in->inpara[j].index = index;
                save_in->inpara[j].data_id = data_id;
                save_out->outpara[j].dev_code = devcode;
                save_out->outpara[j].index = index;
                save_out->outpara[j].data_id = data_id;
                save_in->in_argc = para_num;
                save_out->out_argc = para_num;
                printf("save_in->inpara[%d].dev_code:   %d\n", j, save_in->inpara[j].dev_code);
//                 printf("save_in->inpara[%d].data_id:    %d\n", j, save_in->inpara[j].data_id);
                j++;

            }
        }
    }
    free(save_out->outpara);
    save_out->outpara = NULL;
    free(save_out);
    save_out = NULL;
    free(save_in->inpara);
    save_in->inpara = NULL;
    free(save_in);
    save_in = NULL;
}

//PID初始化
void PID_init(int32_t i,  float32_t kp, float32_t ki, float32_t kd)
{
//     printf("PID init first!\n");
    dev_pid_param[i].setValue = 0.0;
    dev_pid_param[i].actualValue = 0.0;
    dev_pid_param[i].err = 0.0;
    dev_pid_param[i].errNext = 0.0;
    dev_pid_param[i].errLast = 0.0;
    dev_pid_param[i].kp = kp;
    dev_pid_param[i].ki = ki;
    dev_pid_param[i].kd = kd;
    dev_pid_param[i].returnValue = 0.0;
}

float32_t PID_realize(int32_t i, float32_t setvalue, float32_t value)
{
    //验证参数是否保存
//     printf("dev_pid_param[i].kp: %f\n", dev_pid_param[i].kp);
//     printf("dev_pid_param[i].ki: %f\n", dev_pid_param[i].ki);
//     printf("dev_pid_param[i].kd: %f\n", dev_pid_param[i].kd);
//     printf("setvalue: %f\n", setvalue);
//     printf("dev_pid_param[i].actualValue: %f\n", dev_pid_param[i].actualValue);
//     printf("dev_pid_param[i].err: %f\n", dev_pid_param[i].err);
//     printf("dev_pid_param[i].errNext: %f\n", dev_pid_param[i].errNext);
//     printf("dev_pid_param[i].errLast: %f\n", dev_pid_param[i].errLast);
//     printf("returnData: %f\n", returnData);
//     printf("%f %f\n", setvalue, value);
    static float32_t incrementValue = 0.0;

    dev_pid_param[i].setValue = setvalue;//目标设定值
    dev_pid_param[i].actualValue = value;//设备值
    dev_pid_param[i].err = dev_pid_param[i].setValue - dev_pid_param[i].actualValue;


    incrementValue = dev_pid_param[i].kp * (dev_pid_param[i].err - dev_pid_param[i].errNext) +
                                dev_pid_param[i].ki * dev_pid_param[i].err +
                                dev_pid_param[i].kd*(dev_pid_param[i].err - 2 * dev_pid_param[i].errNext + dev_pid_param[i].errLast);
//     printf("incrementValue: %f\n", incrementValue);

    dev_pid_param[i].returnValue += incrementValue;
//     printf("****dev_pid_param[i].returnValue: %f\n", dev_pid_param[i].returnValue);
//     printf("dev_pid_param[i].setValue: %f\n", dev_pid_param[i].setValue);
//     printf("err: %f\n", dev_pid_param[i].err);
//     printf("errNext: %f\n", dev_pid_param[i].errNext);
//     printf("***returnData: %f\n", returnData);
//     printf("dev_pid_param[i].setValue: %f\n", dev_pid_param[i].setValue);
//     printf("dev_pid_param[i].actualValue: %f\n", dev_pid_param[i].actualValue);
//     printf("incrementValue: %f\n", incrementValue);
//     printf("dev_pid_param[i].err: %f\n", dev_pid_param[i].err);
//     printf("****dev_pid_param[i].returnValue: %f %f\n", dev_pid_param[i].returnValue, savePara[i].stLoopParam.LoopError);
    //2023-6-19优化判断达到稳态输出的条件，即incrementValue趋近于0，没有误差
    if((fabs(dev_pid_param[i].err) < savePara[i].stLoopParam.LoopError) && (fabs(incrementValue) <= 0.2))//1e-6
    {
        //达到稳态后，输出设定值
//         printf("steady output\n");
        dev_pid_param[i].returnValue = setvalue;
//         printf("****dev_pid_param[i].returnValue: %f %f\n", dev_pid_param[i].returnValue, savePara[i].stLoopParam.LoopError);
    }

        //功率保护
    if(dev_pid_param[i].returnValue >= 10)
    {
        dev_pid_param[i].returnValue = 10;
    }
    else if(dev_pid_param[i].returnValue <= -10)
    {
        dev_pid_param[i].returnValue = -10;
    }

//     dev_pid_param[i].actualValue = incrementValue;
    dev_pid_param[i].errLast = dev_pid_param[i].errNext;
    dev_pid_param[i].errNext = dev_pid_param[i].err;

//     printf("dev_pid_param[i].setValue: %f\n", dev_pid_param[i].setValue);
//     printf("dev_pid_param[i].actualValue: %f\n", dev_pid_param[i].actualValue);

//     printf("dev_pid_param[i].err: %f\n", dev_pid_param[i].err);

//     printf("returnData: %f\n", returnData);
//     printf("dev_pid_param[i].errLast: %f\n", dev_pid_param[i].errLast);
//     printf("dev_pid_param[i].errNext: %f\n", dev_pid_param[i].errNext);


    return dev_pid_param[i].returnValue;
}

static int32_t ctrl_set(int32_t dwType, void *pvRetData, int32_t dwRetLen)
{
    int32_t para_num = 0;//算法参数个数
    int32_t i = 0;
    RUN_PARAM_T *algoPara = (RUN_PARAM_T*)pvRetData;
//     RUN_PARAM_T *saveTempPara = NULL;

    //add 2023/3/16 从数据库读已有参数信息
//     int32_t recordNum = 0;
//     RUN_PARAM_T *pstRunParam = NULL;
//
//     sysCfg_Load(CFG_TYPE_RUN_CTRL, (void **)(&pstRunParam), &recordNum);    // 从数据库查找数据
//     if(recordNum > 0)
//     {
//         para_num = recordNum / sizeof(RUN_PARAM_T);
//         sysCfg_Free(pstRunParam);
//     }
    para_num = dwRetLen / sizeof(RUN_PARAM_T);
    allAlgoParaNum = para_num;
//     printf("enter ctrl_set!!!!!\n");
//     printf("allAlgoParaNum:%d\n", allAlgoParaNum);
//     saveTempPara = (RUN_PARAM_T *)malloc(sizeof(RUN_PARAM_T) * para_num);


    switch (dwType)
    {
        case MSG_IPC_PROTECT_STORAGE_PARAM_UPDATE:
        {
            break;
        }
        case MSG_IPC_PROTECT_NET_PARAM_UPDATE:
        {
            break;
        }
        case MSG_IPC_RUN_PARAM_UPDATE:
        {
            for(i = 0; i < para_num; i++)
            {
                savePara[i].DevNo = algoPara[i].DevNo;//设备编号
//                 printf("savePara[i].DevNo: %d\n", savePara[i].DevNo);
                savePara[i].ModeParSet = algoPara[i].ModeParSet;//并/离网参数
                savePara[i].LoopMode = algoPara[i].LoopMode;//开闭环
//                 printf("savePara[i].LoopMode:%d\n", savePara[i].LoopMode);
                savePara[i].ActorPower = algoPara[i].ActorPower;//有功：自动、手动、不设置
                savePara[i].ActorPowerPar = algoPara[i].ActorPowerPar;//有功调节参数
                savePara[i].ReactPower = algoPara[i].ReactPower;//无功：自动、手动、恒功率因数
                savePara[i].ReactPowerPar = algoPara[i].ReactPowerPar;//无功调节参数
                savePara[i].PowerMode = algoPara[i].PowerMode;//功率模式
                memcpy(&savePara[i].JoinOffSelect, &algoPara[i].JoinOffSelect, sizeof(JOIN_OFF_MODE_E));
                memcpy(&savePara[i].ModeSelect, &algoPara[i].ModeSelect, sizeof(WORK_MODE_E));
                memcpy(&savePara[i].CtrlMode, &algoPara[i].CtrlMode, sizeof(CTRL_MODE_E));
                memcpy(&savePara[i].stLoopParam, &algoPara[i].stLoopParam, sizeof(LOOP_PARAM_T));

                printf("savePara[%d].DevNo:%d\n", i, savePara[i].DevNo);//设备编号
                printf("savePara[%d].CtrlMode:%d\n", i, savePara[i].CtrlMode);//0本地 1远程
                printf("savePara[%d].JoinOffSelect:%d\n", i, savePara[i].JoinOffSelect);// 1并网
                printf("savePara[%d].LoopMode:%d\n", i, savePara[i].LoopMode);// 0开环
                printf("savePara[%d].ModeSelect:%d\n", i, savePara[i].ModeSelect);// 1恒流
                printf("savePara[%d].ActorPower:%d\n", i, savePara[i].ActorPower);// 1有功手动调节
                printf("savePara[%d].ReactPower:%d\n", i, savePara[i].ReactPower);// 1无功手动调节
                printf("savePara[%d].PowerMode:%d\n", i, savePara[i].PowerMode);// 功率模式
            }

            break;
        }
        default:
            break;
    }

    return OK;
}

//运行控制函数
int32_t runCtrl(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{
//     printf("data[0].value.data.f32: %f\n", data[0].value.data.f32);
//     printf("********runctrl********:data[0].data_id: %d\n", data[0].data_id);
//     printf("********runctrl********:data[0].dev_code: %d\n", data[0].dev_code);


    float32_t kp = 0.0;
    float32_t ki = 0.0;
    float32_t kd = 0.0;
    int32_t localFlag[MAX_DEVCODE_NUM] = {0};//用于判断是否有重复devcode
    int32_t remoteFlag[MAX_DEVCODE_NUM] = {0};
    float32_t returnValue = 0.0;
    uint16_t saveLocalDevcode = 0;//保存的本地devcode
    uint16_t saveRemoteDevcode = 0;//保存的远程devcode

    FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
    FUNC_OUTPARA_T *pout = (FUNC_OUTPARA_T *)out;

    int32_t in_arg_num = pin->in_argc;//输入参数个数 1
    int32_t i = 0, j = 0, m = 0;
    int32_t para_id = -1;
    static int32_t k = 0;
    static int32_t n = 0;
    int32_t devNoIndex = -1;
    int32_t data_id = -1;
    int32_t SoDevDataid = -1;//南向设备测点
    int32_t runFlag = 0; // 1远程 2本地
    float32_t powerfactor = 0.0;//无功功率因数

    static int32_t ctrlmode[MAX_DEVCODE_NUM] = {0};//用于判断保存运行控制状态
    static int32_t loopmode[MAX_DEVCODE_NUM] = {0};//用于判断保存运行控制状态
    static int32_t powerAC_data_id = 0;
    static int32_t power_data_id = 0;//有功功率ID
    static int32_t reacpower_data_id = 0;//无功功率ID
    static int32_t firstT[MAX_DEVCODE_NUM] = {0};//第一次收到转发过来的指令
    static int32_t openCloseSta[MAX_DEVCODE_NUM] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
                                        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
                                        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};//保存开闭环状态，然后后对firstT操作
    static int8_t FlagOne = 0;//由本地开环或其他进入本地闭环，多次切换，状态标志位
    static int8_t FlagTwo = 0;//由本地开环或其他进入远程闭环，多次切换，状态标志位
    static float32_t saveLocaReactPow[MAX_DEVCODE_NUM] = {0.0};//本地闭环保存的下发无功功率值
    static int32_t powerStatus[MAX_DEVCODE_NUM] = {0};//本地闭环功率模式指令判断，不同则输出不同的运行状态
    static int32_t RemotepowerStatus[MAX_DEVCODE_NUM] = {0};//远程闭环有功指令判断，不同则输出不同的运行状态
    static int32_t powerinfo[MAX_DEVCODE_NUM] = {0}; //保存远程闭环有功无功状态
    PERSIST_NODE_INFO_T ctrlRun;

    char timedata[30] = {0};
    time_t now;
    struct tm *timenow;
    DEV_INFO_T stDevInfo;

    //储能
    if((data[0].dev_code >= STORAGE_CONVERTER_START_NUM) && (data[0].dev_code <= STORAGE_CONVERTER_START_NUM + STORAGE_CONVERTER_DEV_MAX_NUM))
    {
        storage_flag = 1;
    }
    //光伏
    if((data[0].dev_code >= INV_START_NUM) && (data[0].dev_code <= INV_START_NUM + INV_DEV_MAX_NUM))
    {
        photovoltaic = 1;
    }

    if(storage_flag == 1)
    {
        for(i = 0; i < in_arg_num; i++)
        {

            if((data[0].data_id == SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "并网恒功率值(DC)")) && (data[0].dev_code == pin->inpara[i].dev_code))
            {
                //执行远程操作
                powerAC_data_id = data[0].data_id;
                devNoIndex = i;
                runFlag = 1;
            }
            else if((data[0].data_id == SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "有功功率")) && (data[0].dev_code == pin->inpara[i].dev_code))
            {
                //执行本地操作
                power_data_id = data[0].data_id;
                devNoIndex = i;
                runFlag = 2;
            }
            else if((data[0].data_id == SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功功率")) && (data[0].dev_code == pin->inpara[i].dev_code))
            {
                //执行本地操作
                reacpower_data_id = data[0].data_id;
                devNoIndex = i;
                runFlag = 3;
            }
            else//什么条件都不满足，继续下一次循环
            {
                continue;
            }

            if(allAlgoParaNum == 0)//protect
            {
                continue;
            }
            for(j = 0; j < allAlgoParaNum; j++)//allAlgoParaNum不包含本机设备
            {
    //             printf("savePara[j].DevNo: %d\n", savePara[j].DevNo);
                //找到注册的devno，与获取参数的devno比较，找到对应的索引   【savePara为北向获取到的数据，是映射的设备信息】
                if(devIdArr[devNoIndex] == savePara[j].DevNo)//设备编号
                {
                    para_id = j;//根据设备编号找到对应保存算法参数数组中的索引
//                     printf("search para_id: %d\n", para_id);//若只添加一台设备，para_id为0
                    break;
                }
            }
            if(savePara[para_id].CtrlMode == 0 && savePara[para_id].LoopMode == 0)//本地开环，有功触发
            {
                //无功、DC不触发
//                 printf("****enter: %d\n", data[0].data_id);
                if(runFlag == 3 || runFlag == 1)
                {
//                     printf("%d\n", runFlag);
                    break;
                }
            }
            if(savePara[para_id].CtrlMode == 0 && savePara[para_id].ActorPower == 1 && savePara[para_id].PowerMode == 1)//本地闭环有功
            {
                //无功、DC触发不处理
                if(runFlag == 3 || runFlag == 1)
                {
                    break;
                }
            }
            if(savePara[para_id].CtrlMode == 0 && savePara[para_id].ReactPower == 1 && savePara[para_id].PowerMode == 2)//本地闭环无功平
            {
                //有功、DC触发不处理
                if(runFlag == 2 || runFlag == 1)
                {
                    break;
                }
            }
            //savePara[para_id].CtrlMode == 1
            if(savePara[para_id].CtrlMode == 1 && savePara[para_id].ActorPower == 1 && savePara[para_id].ReactPower == 0)//远程闭环有功
            {
                //有功、DC触发不处理
                if(runFlag == 3)
                {
                    break;
                }
            }
            if(savePara[para_id].CtrlMode == 1 && savePara[para_id].ActorPower == 0 && savePara[para_id].ReactPower == 1)//远程闭环无功
            {
                //有功、DC触发不处理
                if(runFlag == 2)
                {
                    break;
                }
            }
            //获取本地还是远程

            if(savePara[para_id].CtrlMode == 0)//本地 并网
            {
//                 printf("enter local\n");
                //获取设备开关机状态
                SoDevDataid = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "开机/关机/热备（待机）");
                if(SoDevDataid < 0)
                {
                    printf("can not get correct data_id, check 开机/关机/热备（待机）!\n");
                    return -1;
                }
                GetData = Process_GetData(pin->inpara[i].dev_code, pin->inpara[i].index, SoDevDataid);
                if(GetData.u32 != 207)
                {
                    savePara[para_id].CtrlMode = -1;//清除本地控制状态
                    savePara[para_id].LoopMode = -1;//清除闭环状态
                    return 0;
                }

                if(runFlag == 2)//有功触发
                {
                    //获取开环还是闭环
                    if(savePara[para_id].LoopMode == 0)//开环
                    {
    //                     printf("enter local open ctrl!\n");
                        //手动调节 有功调节参数
                        //判断并离网模式
                        if(savePara[para_id].JoinOffSelect == 1)//并网
                        {
                            //判断并/离网工作模式
                            if(savePara[para_id].ModeSelect == 1)//恒流 有功不设置、无功不设置
                            {
//                                 if(savePara[para_id].ActorPower == 0 && savePara[para_id].ReactPower == 0)//恒流有功
                                if(savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 2)//有功控制
                                {
                                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                                    pout->outpara[1].dataType = 0;
                                    pout->outpara[1].data.f32 = savePara[para_id].ActorPowerPar;
                                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "并网恒流电流值");//
                                    if(data_id < 0)
                                    {
                                        printf("can not get correct data_id, check 并网恒流电流值!\n");
                                        return -1;
                                    }
                                    pout->outpara[1].data_id = data_id;//
                                    //test
                                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                                    pout->outpara[0].dataType = 1;
                                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "工作模式设置");//
                                    if(data_id < 0)
                                    {
                                        printf("can not get correct data_id, check 工作模式设置!\n");
                                        return -1;
                                    }
                                    pout->outpara[0].data_id = data_id;//
                                    pout->outpara[0].data.u32 = 0;
                                    pout->out_argc = 2;

                                    printf("local open loop constant current set: %f\n", pout->outpara[1].data.f32);//电流
                                }

                                if(savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 2) //恒流无功调节
                                {
                                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                                    pout->outpara[0].dataType = 1;
                                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节选择开关");//
                                    if(data_id < 0)
                                    {
                                        printf("can not get correct data_id, check 无功调节选择开关!\n");
                                        return -1;
                                    }
                                    pout->outpara[0].data_id = data_id;//
                                    pout->outpara[0].data.u32 = 1;
                                    //设置功率因数
                                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                                    pout->outpara[1].dataType = 0;
                                    pout->outpara[1].data.f32 = savePara[para_id].ReactPowerPar; //功率因数
                                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "功率因数设置");//并网恒流电流值 并网恒压限制电流值 并网恒压电压值
                                    if(data_id < 0)
                                    {
                                        printf("can not get correct data_id, check 功率因数设置!\n");
                                        return -1;
                                    }
                                    pout->outpara[1].data_id = data_id;
                                    printf("local open loop reactive power factor set: %f\n", pout->outpara[1].data.f32);

                                    pout->out_argc = 2;
                                }

                            }

                            if(savePara[para_id].ModeSelect == 3)//恒功率AC
                            {
                                //有功 手动
//                                 if(savePara[para_id].ActorPower == 2 && savePara[para_id].ReactPower == 0) //手动调节 恒功率AC有功
                                if(savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 2) //手动调节 恒功率AC有功
                                {
                                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                                    pout->outpara[1].dataType = 0;
                                    pout->outpara[1].data.f32 = savePara[para_id].ActorPowerPar;
                                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "并网恒功率值(AC)");//并网恒流电流值 并网恒压限制电流值 并网恒压电压值
                                    if(data_id < 0)
                                    {
                                        printf("can not get correct data_id, check 并网恒功率值(AC)!\n");
                                        return -1;
                                    }
                                    pout->outpara[1].data_id = data_id;//

                                    //test
                                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                                    pout->outpara[0].dataType = 1;
                                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "工作模式设置");//
                                    if(data_id < 0)
                                    {
                                        printf("can not get correct data_id, check 工作模式设置!\n");
                                        return -1;
                                    }
                                    pout->outpara[0].data_id = data_id;//
                                    pout->outpara[0].data.u32 = 2;
                                    pout->out_argc = 2;
                                    printf("local open loop AC set: %f\n", pout->outpara[1].data.f32);


                                }
                                //无功调节 恒功率因数 待验证2023/5/5 2023/5/8ok
                                if(savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 2)//恒功率AC 无功手动调节
                                {
                                    //无功调节打开：功率因数启用 Pf
                                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                                    pout->outpara[0].dataType = 1;
                                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节选择开关");//
                                    if(data_id < 0)
                                    {
                                        printf("can not get correct data_id, check 无功调节选择开关!\n");
                                        return -1;
                                    }
                                    pout->outpara[0].data_id = data_id;//
                                    pout->outpara[0].data.u32 = 1;
                                    //设置功率因数
                                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                                    pout->outpara[1].dataType = 0;
                                    pout->outpara[1].data.f32 = savePara[para_id].ReactPowerPar; //功率因数
                                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "功率因数设置");//并网恒流电流值 并网恒压限制电流值 并网恒压电压值
                                    if(data_id < 0)
                                    {
                                        printf("can not get correct data_id, check 功率因数设置!\n");
                                        return -1;
                                    }
                                    pout->outpara[1].data_id = data_id;
                                    printf("local open loop reactive power factor set: %f\n", pout->outpara[1].data.f32);

                                    pout->out_argc = 2;
                                }

                            }
                        }
                        FlagOne = 1;
                        FlagTwo = 1;
                        //modify 2023/3/21
    //                     if((ctrlmode[para_id] != 1) || (loopmode[para_id] != 1))
                        {
                            if(savePara[para_id].LoopMode == 0 && savePara[para_id].ModeSelect == 1 && savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 2)
                            {
                                ctrlRun.pcDescription = "本地开环恒流有功调节";
                            }
                            if(savePara[para_id].LoopMode == 0 && savePara[para_id].ModeSelect == 1 && savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 2)
                            {
                                ctrlRun.pcDescription = "本地开环恒流无功调节";
                            }
                            if(savePara[para_id].LoopMode == 0 && savePara[para_id].ModeSelect == 3 && savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 2)
                            {
                                ctrlRun.pcDescription = "本地开环恒功率AC有功调节";
                            }
                            if(savePara[para_id].LoopMode == 0 && savePara[para_id].ModeSelect == 3 && savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 2)
                            {
                                ctrlRun.pcDescription = "本地开环恒功率AC无功调节";
                            }
                            time(&now);
                            timenow = localtime(&now);
                            sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                            strcpy(ctrlRun.date,timedata);
                            SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                            printf("dev_name:%s\n", stDevInfo.dev_name);
                            strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                            Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);
                        }
                        //test 2023/3/22
                        firstT[para_id] = 0;//远程控制初始化
//                         savePara[para_id].LoopMode = -1;//完成一次本地开环操作后，清除状态位
                        savePara[para_id].CtrlMode = -1;
                        storage_flag = 0;//判断设备类型标志位清空
                        return 0;
                    }
                }
                //本地闭环控制
                if(savePara[para_id].LoopMode == 1 && savePara[para_id].ModeSelect == 3 && savePara[para_id].JoinOffSelect == 1)//并网闭环 恒功率AC
                {
//                     printf("enter local pid process!!!!\n");
                    //关机保护
                    if(fabs(data[0].value.data.f32) <= 1e-6)
                    {
                        savePara[para_id].CtrlMode = -1;
                        savePara[para_id].LoopMode = -1;
                        savePara[para_id].ReactPower = -1;
                        savePara[para_id].ActorPower = -1;
//                         printf("power is zero!\n");
                        return 0;
                    }

                    saveLocalDevcode = pin->inpara[i].dev_code;

                    for(m = 0; m < MAX_DEVCODE_NUM; m++)
                    {
                        //检查是否有devcode设备参数初始化过
                        printf("enter check\n");
                        if(saveLocalDevcode == localDevcode[m])//localDevcode全局变量
                        {
                            printf("find same devcode, break\n");
                            localFlag[para_id] = 1;
                            break;
                        }
                    }

                    if(localFlag[para_id] != 1)
                    {
    //                     printf("get run ctrl param\n");
                        //获取kp ki kd参数
                        kp = savePara[para_id].stLoopParam.LoopP;
                        ki = savePara[para_id].stLoopParam.LoopI;
                        kd = savePara[para_id].stLoopParam.LoopD;
                        //PID初始化
                        PID_init(para_id, kp, ki, kd);
//                         saveLocalDevcode = pin->inpara[i].dev_code;
                        //将saveLocalDevcode保存到数组中，用于下次遍历查找
                        memcpy(localDevcode + k, &saveLocalDevcode, sizeof(uint16_t));
                        k++;
                    }
                    //程序一直运行，且多次切换运行模式，需要重新初始化PID参数
                    if(FlagOne == 1 && localFlag[para_id] == 1)//首次进入不初始化，来回切换工作状态需初始化一次
                    {
                        kp = savePara[para_id].stLoopParam.LoopP;
                        ki = savePara[para_id].stLoopParam.LoopI;
                        kd = savePara[para_id].stLoopParam.LoopD;
                        PID_init(para_id, kp, ki, kd);
                        returnData = 0.0;
                    }

                    if(savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 1 && data[0].data_id == power_data_id)//有功自动调节,无功不设置
                    {
                        //首次进入本地PID闭环，完成运行状态的保存，其如其他运行模式，需要将首次进入本地PID状态位置0
                        SoDevDataid = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "额定输出功率");
                        if(SoDevDataid < 0)
                        {
                            printf("can not get correct data_id, check 额定输出功率!\n");
                            return -1;
                        }
                        GetData = Process_GetData(pin->inpara[i].dev_code, pin->inpara[i].index, SoDevDataid);

                        returnValue = PID_realize(para_id, savePara[para_id].ActorPowerPar, data[0].value.data.f32);
                        pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[1].dataType = 0;
                        pout->outpara[1].data.f32 = returnValue / GetData.f32 * 100;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "并网恒功率值(AC)");//
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 并网恒功率值(AC)!\n");
                            return -1;
                        }
                        pout->outpara[1].data_id = data_id;//

                        //test
                        pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[0].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "工作模式设置");//
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 工作模式设置!\n");
                            return -1;
                        }
                        pout->outpara[0].data_id = data_id;//
                        pout->outpara[0].data.u32 = 2;//并网恒功率值(AC)
                        pout->out_argc = 2;
                        printf("local close loop collect:%f set:%f\n", data[0].value.data.f32, pout->outpara[1].data.f32);
                    }

                    if(savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 1 && data[0].data_id == reacpower_data_id)//有功不设置，无功设置为自动调节 待验证2023/5/5
                    {
                        SoDevDataid = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "有功功率");
                        if(SoDevDataid < 0)
                        {
                            printf("can not get correct data_id, check 有功功率!\n");
                            return -1;
                        }
                        GetData = Process_GetData(pin->inpara[i].dev_code, pin->inpara[i].index, SoDevDataid);
                        printf("collect power：%f\n", GetData.f32);
                        //关机保护，无功不控制
                        if(fabs(GetData.f32) <= 1e-6)
                        {
                            savePara[para_id].ReactPower = -1;//清除状态
                            savePara[para_id].ActorPower = -1;
                            printf("power is zero!\n");
                            return 0;
                        }

                        if(saveLocaReactPow[para_id] != savePara[para_id].ReactPowerPar)
                        {
//                             LocalSteadyFlag[para_id] = 0;
                            saveLocaReactPow[para_id] = savePara[para_id].ReactPowerPar;//更新下发有功功率
                        }

                        //PID计算
                        printf("reactive power: %f\n", data[0].value.data.f32);

                        returnValue = PID_realize(para_id, savePara[para_id].ReactPowerPar, data[0].value.data.f32);
                        printf("returnValue: %f\n", returnValue);

                        //将返回值转化成功率因数
                        powerfactor = GetData.f32 / sqrt((GetData.f32) * (GetData.f32) + (returnValue) * (returnValue));
                        if(returnValue < 0)
                        {
                            //PID计算的无功为负，功率因数也得为负2023/5/11
                            powerfactor = -powerfactor;
                        }
                        pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;
                        pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;
                        pout->outpara[0].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节选择开关");
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 无功调节选择开关!\n");
                            return -1;
                        }
                        pout->outpara[0].data_id = data_id;//
                        pout->outpara[0].data.u32 = 1;
                        //设置功率因数
                        pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;
                        pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;
                        pout->outpara[1].dataType = 0;
                        pout->outpara[1].data.f32 = powerfactor; //功率因数
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "功率因数设置");
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 功率因数设置!\n");
                            return -1;
                        }
                        pout->outpara[1].data_id = data_id;
                        pout->out_argc = 2;
                        saveLocaReactPow[para_id] = savePara[para_id].ReactPowerPar;//保存本地闭环下发的无功功率，用于下一次下发功率值比较
                        printf("ractive power factor set: %f\n", powerfactor);

                    }

                    if(powerStatus[para_id] != savePara[para_id].PowerMode)
                    {
                        ctrlmode[para_id] = 0;
                        loopmode[para_id] = 0;
                        powerStatus[para_id] = savePara[para_id].PowerMode;
                    }
                    if((ctrlmode[para_id] != 1) || (loopmode[para_id] != 2))
                    {
//                         printf("change!\n");
                        if(savePara[para_id].ActorPower == 1 && savePara[para_id].PowerMode == 1)
                        {
                            ctrlRun.pcDescription = "本地闭环有功调节";
                        }
                        if(savePara[para_id].ReactPower == 1 && savePara[para_id].PowerMode == 2)
                        {
                            ctrlRun.pcDescription = "本地闭环无功调节";
                        }
                        time(&now);
                        timenow = localtime(&now);
                        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                        strcpy(ctrlRun.date,timedata);
                        SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                        printf("dev_name:%s\n", stDevInfo.dev_name);
                        strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                        Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);

                        //更新参数值
                        ctrlmode[para_id] = 1;
                        loopmode[para_id] = 2;
                    }
                    FlagOne = -1;
                    FlagTwo = 1;
                }
                firstT[para_id] = 0;//远程操控制初始化，等待上位机指令
                storage_flag = 0;//判断设备类型标志位清空
                return 0;
            }

            if(savePara[para_id].CtrlMode == 1/* && runFlag == 1*/)  //远程
            {
                printf("enter remote!\n");
                //开关机检测
                SoDevDataid = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "开机/关机/热备（待机）");
                if(SoDevDataid < 0)
                {
                    printf("can not get correct data_id, check 开机/关机/热备（待机）!\n");
                    return -1;
                }
                GetData = Process_GetData(pin->inpara[i].dev_code, pin->inpara[i].index, SoDevDataid);
                if(GetData.u32 != 207)
                {
                    savePara[para_id].CtrlMode = -1;//清除本地控制状态
                    savePara[para_id].LoopMode = -1;//清除闭环状态
                    savePara[para_id].ReactPower = -1;//清除状态
                    savePara[para_id].ActorPower = -1;
                    printf("savePara[para_id].CtrlMode: %d\n", savePara[para_id].CtrlMode);
                    return 0;
                }
                if(openCloseSta[para_id] != savePara[para_id].LoopMode)//远程开环、闭环切换，需等待上位机指令
                {
//                     printf("openCloseSta\n");
                    firstT[para_id] = 0;
                }
                //判断远程有功、无功闭环状态切换
                //powerinfo
                if(powerinfo[para_id] != savePara[para_id].PowerMode)
                {
                    //如果状态切换，更新
                    powerinfo[para_id] = savePara[para_id].PowerMode;
                    //清除状态，等待上位机指令
                    firstT[para_id] = 0;
                }

                if(firstT[para_id] == 0)
                {
                    if(data[0].moduleID != MODULE_T)//若没有收到上位机下发指令则退出
                    {
//                         printf("data[0].moduleID: %d\n", data[0].moduleID);
                        break;
                    }
                    if(data[0].data_id == SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "并网恒功率值(DC)"))
                    {
                        if(data[0].data_id < 0)
                        {
                            printf("can not get correct data_id, check 并网恒功率值(DC)!\n");
                            return -1;
                        }
                        if(data[0].moduleID == MODULE_T /*&& data[0].data_id == power_data_id*/)
                        {
                            //保存下发的功率设定值
//                             if(data[0].data_id == SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "并网恒功率值(DC)"))
//                             {
                                remotePower[para_id] = data[0].value.data.f32;//仅保远程同一模式下多次下发指令值的第一次下发值
                                openCloseSta[para_id] = 1;//远程闭环进入逻辑：先是恒功率AC保存上位机指令，再进入有功功率闭环调节
                                printf("*****receive remotePower:%f\n", remotePower[para_id]);
//                             }
                            firstT[para_id]++;
                        }
                        else
                        {
                            break;
                        }
                    }
                }

                if(savePara[para_id].LoopMode == 0 && data[0].data_id == powerAC_data_id)//开环 只有恒功率AC的测点触发
                {
//                     printf("enter remote open ctrl!\n");
                    openCloseSta[para_id] = 0;
                    //恒流 有功调节参数
                    if(savePara[para_id].ModeSelect == 1 && savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 2)
                    {
                        pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[1].dataType = 0;
                        pout->outpara[1].data.f32 = remotePower[para_id];//除以系数 0.1 remotePower[para_id] data[0].value.data.f32
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "并网恒流电流值");//
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 并网恒流电流值!\n");
                            return -1;
                        }
                        pout->outpara[1].data_id = data_id;//

                        pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[0].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "工作模式设置");//
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 工作模式设置!\n");
                            return -1;
                        }
                        pout->outpara[0].data_id = data_id;//
                        pout->outpara[0].data.u32 = 0;//并网恒流电流模式test

                        pout->out_argc = 2;
                        printf("remote open loop current set: %f\n", pout->outpara[1].data.f32);
                    }

                    //恒流 无功
                    if(savePara[para_id].ModeSelect == 1 && savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 2)
                    {
                        pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[1].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节选择开关");//
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 无功调节选择开关!\n");
                            return -1;
                        }
                        pout->outpara[1].data_id = data_id;//
                        pout->outpara[1].data.u32 = 1;
                        //设置功率因数
                        pout->outpara[2].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[2].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[2].dataType = 0;
                        pout->outpara[2].data.f32 = data[0].value.data.f32 * 0.01; //功率因数 当前点用的恒功率AC的值，需✖0.01
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "功率因数设置");
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 功率因数设置!\n");
                            return -1;
                        }
                        pout->outpara[2].data_id = data_id;

                        pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[0].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "工作模式设置");//
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 工作模式设置!\n");
                            return -1;
                        }
                        pout->outpara[0].data_id = data_id;//
                        pout->outpara[0].data.u32 = 0;//并网恒流电流模式

                        pout->out_argc = 3;
                        printf("remote open loop power factor set: %f\n", pout->outpara[2].data.f32);
                    }

                    //恒功率 有功
                    if(savePara[para_id].ModeSelect == 3 && savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 2) //手动调节 恒功率AC有功
                    {
                        pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[1].dataType = 0;
                        pout->outpara[1].data.f32 = data[0].value.data.f32;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "并网恒功率值(AC)");//并网恒流电流值 并网恒压限制电流值 并网恒压电压值
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 并网恒功率值(AC)!\n");
                            return -1;
                        }
                        pout->outpara[1].data_id = data_id;//

                        pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[0].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "工作模式设置");//
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 工作模式设置!\n");
                            return -1;
                        }
                        pout->outpara[0].data_id = data_id;//
                        pout->outpara[0].data.u32 = 2;
                        pout->out_argc = 2;
                        printf("remote open loop AC set: %f\n", pout->outpara[1].data.f32);
                    }
                    //恒功率 无功
                    if(savePara[para_id].ModeSelect == 3 && savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 2) //手动调节 恒功率AC有功
                    {
                        pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[1].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节选择开关");//
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 无功调节选择开关!\n");
                            return -1;
                        }
                        pout->outpara[1].data_id = data_id;//
                        pout->outpara[1].data.u32 = 1;
                        //设置功率因数
                        pout->outpara[2].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[2].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[2].dataType = 0;
                        pout->outpara[2].data.f32 = data[0].value.data.f32 * 0.01; //功率因数 当前点用的恒功率AC的值，需✖0.01
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "功率因数设置");
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 功率因数设置!\n");
                            return -1;
                        }
                        pout->outpara[2].data_id = data_id;

                        pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[0].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "工作模式设置");//
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 工作模式设置!\n");
                            return -1;
                        }
                        pout->outpara[0].data_id = data_id;//
                        pout->outpara[0].data.u32 = 2;
                        pout->out_argc = 3;
                        printf("remote open loop AC set: %f\n", pout->outpara[2].data.f32);
                    }

                    if(savePara[para_id].LoopMode == 0)
                    {
                        if(savePara[para_id].ModeSelect == 1 && savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 2)
                        {
                            ctrlRun.pcDescription = "远程开环恒流有功调节";
                        }
                        if(savePara[para_id].ModeSelect == 1 && savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 2)
                        {
                            ctrlRun.pcDescription = "远程开环恒流无功调节";
                        }
                        if(savePara[para_id].ModeSelect == 3 && savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 2)
                        {
                            ctrlRun.pcDescription = "远程开环恒功率有功调节";
                        }
                        if(savePara[para_id].ModeSelect == 3 && savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 2)
                        {
                            ctrlRun.pcDescription = "远程开环恒功率无功调节";
                        }

                        time(&now);
                        timenow = localtime(&now);
                        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                        strcpy(ctrlRun.date,timedata);
                        SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                        printf("dev_name:%s\n", stDevInfo.dev_name);
                        strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                        Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);
                    }

                    firstT[para_id] = 0;//完成一次远程开环后清除状态,需上位机再次下发才能触发
                    FlagOne = 1;
                    FlagTwo = 1;
                    storage_flag = 0;//判断设备类型标志位清空
                    return 0;
                }

                if(data[0].moduleID == MODULE_T && firstT[para_id] == 1 && data[0].data_id == powerAC_data_id)//远程闭环下,第二次收到恒功率DC触发,保存下发数值,并返回；保存数值用于下次有功触发计算
                {
                    remotePowerNext[para_id] = data[0].value.data.f32;//保存多次远程下发数值
                    remotePower[para_id] = remotePowerNext[para_id];
                    printf("AC recv data: %f\n", data[0].value.data.f32);
                    storage_flag = 0;//判断设备类型标志位清空
                    return -1;
                }

                if(savePara[para_id].LoopMode == 1 && (data[0].data_id == power_data_id || data[0].data_id == reacpower_data_id))   //闭环 有功、无功触发
                {
                    openCloseSta[para_id] = 1;

                    saveRemoteDevcode = pin->inpara[i].dev_code;
                    for(m = 0; m < MAX_DEVCODE_NUM; m++)
                    {
                        //检查是否有devcode设备参数初始化过
                        if(saveRemoteDevcode == remoteDevcode[m])
                        {
    //                         printf("find same devcode,break\n");
                            remoteFlag[para_id] = 1;
                            break;
                        }
                    }
                    if(remoteFlag[para_id] != 1)
                    {
//                         printf("PID param get!\n");
                        //获取kp ki kd参数
                        kp = savePara[para_id].stLoopParam.LoopP;
                        ki = savePara[para_id].stLoopParam.LoopI;
                        kd = savePara[para_id].stLoopParam.LoopD;
                        //PID初始化
                        PID_init(para_id, kp, ki, kd);
                        saveRemoteDevcode = pin->inpara[i].dev_code;
                        memcpy(remoteDevcode + n, &saveRemoteDevcode, sizeof(uint16_t));
                        n++;
                    }

                    if(FlagTwo == 1 && remoteFlag[para_id] == 1)//首次进入不初始化，来回切换需初始化一次
                    {
                        kp = savePara[para_id].stLoopParam.LoopP;
                        ki = savePara[para_id].stLoopParam.LoopI;
                        kd = savePara[para_id].stLoopParam.LoopD;
                        PID_init(para_id, kp, ki, kd);
                        returnData = 0.0;
                    }
                    //PID函数
                    //有功power_data_id触发，完成远程闭环调节
                    if(savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 1 && data[0].data_id == power_data_id)
                    {
                        SoDevDataid = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "额定输出功率");
                        if(SoDevDataid < 0)
                        {
                            printf("can not get correct data_id, check 额定输出功率!\n");
                            return -1;
                        }
                        GetData = Process_GetData(pin->inpara[i].dev_code, pin->inpara[i].index, SoDevDataid);
                        returnValue = PID_realize(para_id, remotePower[para_id], data[0].value.data.f32);
                        printf("%f\n", returnValue);
                        pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[1].dataType = 0;
                        pout->outpara[1].data.f32 = returnValue / GetData.f32 * 100;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "并网恒功率值(AC)");
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 并网恒功率值(AC)!\n");
                            return -1;
                        }
                        pout->outpara[1].data_id = data_id;

                        pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode 2849
                        pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index 1
                        pout->outpara[0].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "工作模式设置");
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 工作模式设置!\n");
                            return -1;
                        }
                        pout->outpara[0].data_id = data_id;
                        pout->outpara[0].data.u32 = 2;//并网恒功率值(AC)
                        pout->out_argc = 2;//test
                        printf("remote close loop AC set: %f\n", pout->outpara[1].data.f32);

                    }
                    //无功 自动调节 待验证2023/5/5
                    if(savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 1 && data[0].data_id == reacpower_data_id)
                    {
                        //根据无功功率测点，获取测点值，再与设定的无功功率进行PID调节
                        SoDevDataid = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "有功功率");
                        if(SoDevDataid < 0)
                        {
                            printf("can not get correct data_id, check 有功功率!\n");
                            return -1;
                        }
                        GetData = Process_GetData(pin->inpara[i].dev_code, pin->inpara[i].index, SoDevDataid);
                        printf("collect power: %f\n", GetData.f32);
                        printf("collect reactive power: %f\n", data[0].value.data.f32);
                        //关机状态下有功功率为0，功率控制保护设置
                        if(fabs(GetData.f32) <= 1e-6)
                        {
                            savePara[para_id].ReactPower = -1;//清除状态
                            savePara[para_id].ActorPower = -1;
                            printf("power is zero!\n");
                            return 0;
                        }

                        if(remotePowerNext[para_id] != remotePower[para_id])
                        {
                            remotePower[para_id] = remotePowerNext[para_id];
                        }
                        //上位机下发的无功功率 remotePower
                        //PID计算
                        returnValue = PID_realize(para_id, remotePower[para_id], data[0].value.data.f32);
                        printf("returnValue: %f\n", returnValue);
                        //将返回值转化成功率因数
                        powerfactor = GetData.f32 / sqrt((GetData.f32) * (GetData.f32) + (returnValue) * (returnValue));
                        if(returnValue < 0)
                        {
                            //PID计算的无功为负，功率因数也得为负2023/5/11
                            powerfactor = -powerfactor;
                        }
                        pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;
                        pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;
                        pout->outpara[0].dataType = 1;
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节选择开关");
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 无功调节选择开关!\n");
                            return -1;
                        }
                        pout->outpara[0].data_id = data_id;
                        pout->outpara[0].data.u32 = 1;
                        //设置功率因数
                        pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;
                        pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;
                        pout->outpara[1].dataType = 0;
                        pout->outpara[1].data.f32 = powerfactor; //功率因数
                        data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "功率因数设置");
                        if(data_id < 0)
                        {
                            printf("can not get correct data_id, check 功率因数设置!\n");
                            return -1;
                        }
                        pout->outpara[1].data_id = data_id;
                        pout->out_argc = 2;
                        printf("remote close loop power factor set: %f\n", pout->outpara[1].data.f32);

                    }

                    if(RemotepowerStatus[para_id] != savePara[para_id].PowerMode)
                    {
                        ctrlmode[para_id] = 0;
                        loopmode[para_id] = 0;
                        RemotepowerStatus[para_id] = savePara[para_id].PowerMode;
                    }

                    if((ctrlmode[para_id] != 2) || (loopmode[para_id] != 2))
                    {
                        if(savePara[para_id].PowerMode == 1 && savePara[para_id].ActorPower == 1)
                        {
                            ctrlRun.pcDescription = "远程闭环有功调节";
                        }
                        if(savePara[para_id].PowerMode == 2 && savePara[para_id].ReactPower == 1)
                        {
                            ctrlRun.pcDescription = "远程闭环无功调节";
                        }
                        time(&now);
                        timenow = localtime(&now);
                        sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                        strcpy(ctrlRun.date,timedata);
                        SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                        printf("dev_name:%s\n", stDevInfo.dev_name);
                        strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                        Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);

                        //更新参数值
                        ctrlmode[para_id] = 2;
                        loopmode[para_id] = 2;
                    }
                    FlagOne = 1;
                    FlagTwo = -1;
                    storage_flag = 0;//判断设备类型标志位清空
                    return 0;
                }
                if(runFlag == 1)
                {
                    break;
                }
            }
        }
    }
    storage_flag = 0;
    if(photovoltaic == 1)
    {
//         printf("enter photovoltaic deal!\n");
        //限功率操作
        for(i = 0; i < in_arg_num; i++)
        {
            if((data[0].data_id == SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "总有功功率")) && (data[0].dev_code == pin->inpara[i].dev_code))
            {
                //本地限功率操作
                //找到对应的索引
                devNoIndex = i;
//                 printf("devNoIndex:%d\n", devNoIndex);
            }
//             else if((data[0].data_id == SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "限功率百分比")) && (data[0].dev_code == pin->inpara[i].dev_code))
//             {
//                 devNoIndex = i;
//             }
            else if((data[0].data_id == SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "功率因数设置")) && (data[0].dev_code == pin->inpara[i].dev_code))
            {
                devNoIndex = i;
            }
            else
            {
                //若不匹配，继续下一次循环
                continue;
            }

            if(allAlgoParaNum == 0)//protect
            {
                continue;
            }

            for(j = 0; j < allAlgoParaNum; j++)//allAlgoParaNum不包含本机设备
            {
                //找到注册的devno，与获取参数的devno比较，找到对应的索引   【savePara为北向获取到的数据，是映射的设备信息】
                if(devIdArr[devNoIndex] == savePara[j].DevNo)//设备编号
                {
                    para_id = j;//根据设备编号找到对应保存算法参数数组中的索引
//                     printf("search para_id: %d\n", para_id);//若只添加一台设备，para_id为0
                    break;
                }
            }
            //获取设备开关机状态,如果关机，不做限功率操作
            SoDevDataid = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "开机/关机");
            GetData = Process_GetData(pin->inpara[i].dev_code, pin->inpara[i].index, SoDevDataid);

            //获取本地状态
            if(savePara[para_id].CtrlMode == 0)//本地
            {
                if(GetData.u32 == 206)//关机
                {
                    //清空状态
                    savePara[para_id].ActorPower = -1;
                    savePara[para_id].ReactPower = -1;
                }
                //有功功率设置
                if(savePara[para_id].ActorPower == 1 && savePara[para_id].PowerMode == 1) //限功率
                {
                    printf("power curtailment percentage!\n");
                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[1].dataType = 1;
                    pout->outpara[1].data.u32 = (uint32_t)(savePara[para_id].ActorPowerPar);
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "限功率百分比");//限功率百分比
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 限功率百分比!\n");
                        return -1;
                    }
                    pout->outpara[1].data_id = data_id;

                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[0].dataType = 1;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "限功率开关");
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 限功率开关!\n");
                        return -1;
                    }
                    pout->outpara[0].data_id = data_id;
                    pout->outpara[0].data.u32 = 170;//使能0xAA
                    pout->out_argc = 2;
                    printf("local power curtailment percentage set: %d\n", pout->outpara[1].data.u32);

                    ctrlRun.pcDescription = "本地限功率调节";
                    time(&now);
                    timenow = localtime(&now);
                    sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                    strcpy(ctrlRun.date,timedata);
                    SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                    printf("dev_name:%s\n", stDevInfo.dev_name);
                    strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                    Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);
                    savePara[para_id].ActorPower = -1;//清除功率设置
                    break;
                }
                //无功设置
                if(savePara[para_id].ReactPower == 1 && savePara[para_id].PowerMode == 2)//功率因数设置 有功不设置
                {
                    printf("power factor setting!\n");
                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[1].dataType = 0;
                    pout->outpara[1].data.f32 = savePara[para_id].ReactPowerPar;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "功率因数设置");//
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 功率因数设置!\n");
                        return -1;
                    }
                    pout->outpara[1].data_id = data_id;
                    //test
                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[0].dataType = 1;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节模式");
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 无功调节模式!\n");
                        return -1;
                    }
                    pout->outpara[0].data_id = data_id;
                    pout->outpara[0].data.u32 = 161;//使能0xAA
                    pout->out_argc = 2;
                    printf("local power factor set: %f\n", pout->outpara[1].data.f32);

                    ctrlRun.pcDescription = "本地无功因数调节";
                    time(&now);
                    timenow = localtime(&now);
                    sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                    strcpy(ctrlRun.date,timedata);
                    SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                    printf("dev_name:%s\n", stDevInfo.dev_name);
                    strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                    Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);
                    savePara[para_id].ReactPower = -1;//清除
                    break;
                }
                if(savePara[para_id].ReactPower == 2 && savePara[para_id].PowerMode == 2)//功率比例 有功不设置
                {
                    printf("reactive power ratio setting!\n");
                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[1].dataType = 0;
                    pout->outpara[1].data.f32 = savePara[para_id].ReactPowerPar;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功比例设置");//
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 无功比例设置!\n");
                        return -1;
                    }
                    pout->outpara[1].data_id = data_id;
                    //test
                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[0].dataType = 1;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节模式");
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 无功调节模式!\n");
                        return -1;
                    }
                    pout->outpara[0].data_id = data_id;
                    pout->outpara[0].data.u32 = 162;//使能0xAA
                    pout->out_argc = 2;
                    printf("local reactive power ratio set: %f\n", pout->outpara[1].data.f32);

                    ctrlRun.pcDescription = "本地无功比例调节";
                    time(&now);
                    timenow = localtime(&now);
                    sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                    strcpy(ctrlRun.date,timedata);
                    SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                    printf("dev_name:%s\n", stDevInfo.dev_name);
                    strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                    Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);
                    savePara[para_id].ReactPower = -1;//清除
                    break;
                }
            }
            //远程
            if(savePara[para_id].CtrlMode == 1 && data[0].moduleID == MODULE_T)
            {
                printf("data[0].data_id: %d\n", data[0].data_id);
                printf("data[0].value.data.f32: %f\n", data[0].value.data.f32);

//                 if(data[0].data_id == SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "限功率百分比"))
//                 {
//                     printf("%d\n", data[0].data_id);
//                 }
//                 if(data[0].moduleID != MODULE_T )//若没有收到上位机下发指令则退出
//                 {
//                     printf("data[0].moduleID: %d %d\n", data[0].moduleID, data[0].data_id);
//                     break;
//                 }

                if(GetData.u32 == 206)//关机
                {
                    //清空状态
                    savePara[para_id].ActorPower = -1;
                    savePara[para_id].ReactPower = -1;
                }
                //有功设置
                if(savePara[para_id].ActorPower == 1 && savePara[para_id].PowerMode == 1)  //无功不设置
                {
                    printf("remote power curtailment percentage !\n");
                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[1].dataType = 1;
                    pout->outpara[1].data.u32 = data[0].value.data.f32 * 100;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "限功率百分比");//
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 限功率百分比!\n");
                        return -1;
                    }
                    pout->outpara[1].data_id = data_id;
                    printf("data_id: %d\n", data_id);

                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[0].dataType = 1;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "限功率开关");
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 限功率开关!\n");
                        return -1;
                    }
                    pout->outpara[0].data_id = data_id;
                    pout->outpara[0].data.u32 = 170;//使能0xAA
                    pout->out_argc = 2;
                    printf("remote power curtailment percentage set : %d\n", pout->outpara[1].data.u32 );

                    ctrlRun.pcDescription = "远程限功率调节";
                    time(&now);
                    timenow = localtime(&now);
                    sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                    strcpy(ctrlRun.date,timedata);
                    SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                    printf("dev_name:%s\n", stDevInfo.dev_name);
                    strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                    Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);
                    break;
                }
                //无功设置
                if(savePara[para_id].ReactPower == 1 && savePara[para_id].PowerMode == 2) //有功不设置
                {
                    printf("remote reactive power ratio setting!\n");
                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[1].dataType = 0;
                    pout->outpara[1].data.f32 = data[0].value.data.f32;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "功率因数设置");//
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 功率因数设置!\n");
                        return -1;
                    }
                    pout->outpara[1].data_id = data_id;

                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[0].dataType = 1;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节模式");
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 无功调节模式!\n");
                        return -1;
                    }
                    pout->outpara[0].data_id = data_id;
                    pout->outpara[0].data.u32 = 161;//使能0xAA
                    pout->out_argc = 2;
                    printf("remote reactive power ratio set: %f\n", pout->outpara[1].data.f32);

                    ctrlRun.pcDescription = "远程功率因数调节";
                    time(&now);
                    timenow = localtime(&now);
                    sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                    strcpy(ctrlRun.date,timedata);
                    SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                    printf("dev_name:%s\n", stDevInfo.dev_name);
                    strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                    Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);
                    break;
                }
                if(savePara[para_id].ReactPower == 2 && savePara[para_id].PowerMode == 2)//功率比例  有功不设置
                {
                    printf("remote power ratio setting!\n");
                    pout->outpara[1].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[1].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[1].dataType = 0;
                    pout->outpara[1].data.f32 = data[0].value.data.f32 * 100;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功比例设置");//
                    //获取data_id保护判断
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 无功比例设置!\n");
                        return -1;
                    }
                    pout->outpara[1].data_id = data_id;

                    pout->outpara[0].dev_code = dev_info[dev_info_num[devNoIndex]].stDevUID.devCode;//devcode
                    pout->outpara[0].index = dev_info[dev_info_num[devNoIndex]].stDevUID.devIndex;//index
                    pout->outpara[0].dataType = 1;
                    data_id = SDB_ND_GetDataId(pin->inpara[i].dev_code, pin->inpara[i].index, "无功调节模式");
                    if(data_id < 0)
                    {
                        printf("can not get correct data_id, check 无功调节模式!\n");
                        return -1;
                    }
                    pout->outpara[0].data_id = data_id;
                    pout->outpara[0].data.u32 = 162;//使能0xAA
                    pout->out_argc = 2;
                    printf("remote reactive power ratio set: %f\n", pout->outpara[1].data.f32);

                    ctrlRun.pcDescription = "远程无功比例调节";
                    time(&now);
                    timenow = localtime(&now);
                    sprintf(timedata,"%d-%02d-%02d %02d:%02d:%02d",timenow->tm_year+1900,timenow->tm_mon+1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min, timenow->tm_sec);
                    strcpy(ctrlRun.date,timedata);
                    SDB_GetDevInfoByUID(savePara[para_id].DevNo, &stDevInfo);
                    printf("dev_name:%s\n", stDevInfo.dev_name);
                    strcpy( ctrlRun.arrcDevName, stDevInfo.dev_name);
                    Persister_StoreNode(HIS_RECORD_RUN_STATE, &ctrlRun);
                    break;
                }
            }

        }
    }
    photovoltaic = 0;

    return 0;
}


static int32_t ctrl_get(int32_t dwType, void *pvRetData, int32_t dwRetLen)
{
    return OK;
}

static int32_t ctrl_check(int32_t dwType, void *pvRetData, int32_t dwRetLen)
{
    return OK;
}

int32_t Control_Init()
{
    int32_t ret = OK;

    ctrlHandle.operate.set = ctrl_set;
    ctrlHandle.operate.get = ctrl_get;
    ctrlHandle.operate.check = ctrl_check;
//     printf("ctrl_init ok!\n");

    registPoint();
    ret = Processor_Register(MODULE_RUN, &ctrlHandle.operate);

    ret = ret + Processor_InsertDpFuncNorth(runCtrl, "runCtrl", save_in, save_out);

    pthread_mutex_init(&ctrlHandle.mtx, NULL);

    return ret;
}


