/**
 * NOTE:结构体成员变量的名称要和数据库数据项名称一致
 */

#ifndef RUNCFG_H_INCLUDED
#define RUNCFG_H_INCLUDED

#include "common.h"

/****************************** 算法处理 ****************************************/
typedef enum {
    FILTER_ALGOR_WEIGHT_RECURSIVE_AVE = 0x1, //加权递推平均滤波
    FILTER_ALGOR_LPF, //Low Pass Filter,一阶低通滤波
    FILTER_ALGOR_LIMIT_SHAKE, //限幅消抖滤波
    FILTER_ALGOR_MAX
}FILTER_ALGOR_TYPE_E;

typedef struct{
    int32_t AveNum; //平均滤波-滤波长度
    char AveWeight[1024]; //平均滤波-权值,字符串拼接，例如：1.2-1.3-1.5-1.6-1.2…
}AVE_FILTER_T;

typedef struct{
    float32_t FirstInitValue; //一阶低通-初始滤波值
    float32_t FirstTimeValue; //一阶低通-时间常数
}LPF_PARAM_T;

typedef struct{
    float32_t ALimitMaxVarValue; //限幅消抖-最大变化值
    int32_t ALimitMaxVarCnt; //限幅消抖-最大变化次数
    float32_t ALimitValidValue; //限幅消抖-有效值
}LIMIT_SHAKE_T;

typedef struct{
    uint8_t UartNo;//串口编号
    BOOL Enable; //使能数据处理
    int32_t HistoryNum; //历史数据个数
    int32_t SampleNum; //采样数据个数
    FILTER_ALGOR_TYPE_E FilterAlgor; //滤波算法类型

    union {
        AVE_FILTER_T stAve;
        LPF_PARAM_T  stLPF;
        LIMIT_SHAKE_T stLimit;
    }ALOGR_PARAM_U;

    int32_t MissAlgor; //缺失算法选择,"1：线性回归算法,0：不设置"
    int32_t ValueNum; //缺失回归方程变量数
    int32_t AbnormalAlgor;//异常识别算法,1：箱线图法,2：3Q法,0：未设置
}ALOGR_T;
/********************************* 运行参数 *************************************/
typedef enum{
    MODE_JOIN = 1, //并网模式
    MODE_OFF       //离网模式
}JOIN_OFF_MODE_E;

typedef enum {
    WORK_MODE_CC =1, //Constant current,恒流模式
    WORK_MODE_CV,    //恒压模式
    WORK_MODE_AC,    //恒功率AC模式
    WORK_MODE_DC     //恒功率DC模式
}WORK_MODE_E;

typedef enum {
    CTRL_MODE_LOCAL, //本地
    CTRL_MODE_REMOTE //远程
}CTRL_MODE_E;

typedef struct{
    float32_t LoopP; //闭环P值
    float32_t LoopI; //闭环I值
    float32_t LoopD; //闭环D值
    float32_t LoopError; //闭环控制误差
    int32_t LoopCycle; //闭环控制周期
}LOOP_PARAM_T;

typedef struct{
    int32_t DevNo; //设备编号
    JOIN_OFF_MODE_E JoinOffSelect; //并离网-模式选择
    WORK_MODE_E ModeSelect; //并网/离网工作模式
    float32_t ModeParSet; //并网或者离网参数
    CTRL_MODE_E CtrlMode;
    BOOL LoopMode; //0：开环控制,1：闭环控制
    LOOP_PARAM_T stLoopParam; //LOOP_PARAM_T
    int32_t PowerMode; //有功的值是1  无功的值是2
    int32_t ActorPower; //1：自动调件,2：手动调节,0：不设置   【光伏：1-限功率】
    float32_t ActorPowerPar; //有功自动调节参数 目标值
    int32_t ReactPower; //无功设置,1：自动调节,2：手动调节,3：恒功率因数,0:不设置  【光伏：1-功率因数 2-无功比例 0-不设置】
    float32_t ReactPowerPar; //无功自动调节参数
}RUN_PARAM_T;

/********************************* 保护参数-储 *************************************/
typedef struct{
    float32_t OVL1; //单体过压1级阈值
    float32_t OVL2; //单体过压2级阈值
    float32_t OVL3; //单体过压3级阈值
    float32_t UVL1; //单体欠压1级阈值
    float32_t UVL2; //单体欠压2级阈值
    float32_t UVL3; //单体欠压3级阈值
    float32_t OTL1; //单体高温1级阈值
    float32_t OTL2; //单体高温2级阈值
    float32_t OTL3; //单体高温3级阈值
    float32_t LTL1; //单体低温1级阈值
    float32_t LTL2; //单体低温2级阈值
    float32_t LTL3; //单体低温3级阈值
}PROTECT_CELL_T;

typedef struct{
    float32_t PackOV1; //Pack过压1级阈值
    float32_t PackOV2; //Pack过压2级阈值
    float32_t PackOV3; //Pack过压3级阈值
    float32_t PackUV1; //Pack欠压1级阈值
    float32_t PackUV2; //Pack欠压2级阈值
    float32_t PackUV3; //Pack欠压3级阈值
}PROTECT_PACK_T;

typedef struct{
    float32_t SocUpL1; //Rack SOC上限1级阈值
    float32_t SocUpL2; //Rack SOC上限2级阈值
    float32_t SocUpL3; //Rack SOC上限3级阈值
    float32_t SocDownL1; //Rack SOC下限1级阈值
    float32_t SocDownL2; //Rack SOC下限2级阈值
    float32_t SocDownL3; //Rack SOC下限3级阈值
}PROTECT_RACK_SOC_T;

typedef struct{
    float32_t SohDownL1; //Rack SOH低下限1级阈值
    float32_t SohDownL2; //Rack SOH低下限2级阈值
    float32_t SohDownL3; //Rack SOH低下限3级阈值
}PROTECT_RACK_SOH_T;

typedef struct{
    float32_t RackVUpL1; //Rack电压上限1级阈值
    float32_t RackVUpL2; //Rack电压上限2级阈值
    float32_t RackVUpL3; //Rack电压上限3级阈值
    float32_t RackVDownL1; //Rack电压下限1级阈值
    float32_t RackVDownL2; //Rack电压下限2级阈值
    float32_t RackVDownL3; //Rack电压下限3级阈值
    float32_t RackParUpL1; //Rack压参上限1级阈值
    float32_t RackParUpL2; //Rack压参上限2级阈值
    float32_t RackParUpL3; //Rack压参上限3级阈值
}PROTECT_RACK_V_T;

typedef struct{
    float32_t RackOCL1; //Rack过流上限1级阈值
    float32_t RackOCL2; //Rack过流上限2级阈值
    float32_t RackOCL3; //Rack过流上限3级阈值
    float32_t RackCurL1; //Rack环流大上限1级阈值
    float32_t RackCurL2; //Rack环流大上限2级阈值
    float32_t RackCurL3; //Rack环流大上限3级阈值
}PROTECT_RACK_A_T;

typedef struct{
    PROTECT_RACK_SOC_T stRackSOC;
    PROTECT_RACK_SOH_T stRackSOH;
    PROTECT_RACK_V_T stRackV;
    PROTECT_RACK_A_T stRackA;
}PROTECT_RACK_T;

typedef struct{
    int32_t DevNo; //设备编号
    PROTECT_CELL_T stProtectCell;
    PROTECT_PACK_T stProtectPack;
    PROTECT_RACK_T stProtectRack;
}PROTECTSTORAGE_T;
/********************************* 保护参数-网 *************************************/

typedef struct{
    float32_t TsfCapacity; //变压器额定容量
    float32_t TsfL1; //变压器容量越限限1级阈值
    float32_t TsfL2; //变压器容量越限限2级阈值
    float32_t TsfL3; //变压器容量越限限3级阈值
}PROTECT_TSF_T;

typedef struct{
    float32_t Demand; //需量
    float32_t DemandL1; //需量越限1级阈值
    float32_t DemandL2; //需量越限2级阈值
    float32_t DemandL3; //需量越限3级阈值
}PROTECT_DEMAND_T;

typedef struct{
    float32_t Volt; //母线电压额定值
    float32_t VoltUpL1; //母线电压越限上限1级阈值
    float32_t VoltUpL2; //母线电压越限上限2级阈值
    float32_t VoltUpL3; //母线电压越限上限3级阈值
    float32_t VoltDownL1; //母线电压越限下限1级阈值
    float32_t VoltDownL2; //母线电压越限下限2级阈值
    float32_t VoltDownL3; //母线电压越限下限3级阈值
    float32_t Fre; //母线频率
    float32_t FreUpL1; //母线频率越限上限1级阈值
    float32_t FreUpL2; //母线频率越限上限2级阈值
    float32_t FreUpL3; //母线频率越限上限3级阈值
    float32_t FreDownL1; //母线频率越限下限1级阈值
    float32_t FreDownL2; //母线频率越限下限2级阈值
    float32_t FreDownL3; //母线频率越限下限3级阈值
}PROTECT_VOLT_T;

typedef struct{
    float32_t Feeder; //馈线容量限额
    float32_t FeederUpL1; //馈线容量限额上限1级阈值
    float32_t FeederUpL2; //馈线容量限额上限2级阈值
    float32_t FeederUpL3; //馈线容量限额上限3级阈值
}PROTECT_FEEDER_T;

typedef struct{
    int32_t DevNo; //设备编号（数据库唯一标识）
    PROTECT_DEMAND_T stDemand;
    PROTECT_VOLT_T  stVolt;
    PROTECT_FEEDER_T stFeeder;

}PROTECTNET_T;

/**********************************************************************/

#endif // RUNCFG_H_INCLUDED
