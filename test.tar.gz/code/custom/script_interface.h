#ifndef SCRIPT_INTERFACE_H_INCLUDED
#define SCRIPT_INTERFACE_H_INCLUDED

#include "common.h"
#include "sgdev.h"

#define FILTERWINDOW 3
// #define inputsampledata_num 5
// #define inputhisdate_num 25
// #define outlier_flag 0
// #define algorithm_type1 2
// #define missing_filling 0
// #define num_x1 10 //回归方程自变量数
// #define num_x2 5 //滤波长度
// #define algorithm_type3 3
// #define num_weight1 5
// #define filter_flag 1
// #define time_value1  0.1
// #define max_value1 10
// #define max_count1 1
#define guangfu_dataprocess_datanum  1
#define chuneng_dataprocess_datanum  1
#define guangfu_fault_datanum  1
#define chuneng_fault_datanum  2
#define guangfu_warning_datanum  0
#define chuneng_warning_datanum 11

#define data_processs_debug  0
typedef struct
{
    uint32_t offset;
    uint32_t cap;
    DEV_DATA_T *dataStartAddr;
    int32_t dwParamId;
    int16_t data_id;
}RECORD_Q_T;

typedef struct
{
    RECORD_Q_T *pRec;
    uint32_t recQCount;
    BOOL debug;
    pthread_mutex_t mtx;
    MODULE_OPERATOR_T operate;
}SI_HANDLE_T;
//实时故障告警
typedef struct {
    char time[24];  //故障发生时间
    int devNo;      //设备id
    char fw[20];    //故障/告警
    char type[20];  //故障/告警类型
    int  warLvl;    //告警等级
    char des[64];   //故障/告警描述
}rtfault_t;

int32_t Script_Init();

int32_t Script_UnInit();

#endif // SCRIPT_INTERFACE_H_INCLUDED
