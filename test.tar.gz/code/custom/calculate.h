#ifndef CALCULATE_H_INCLUDED
#define CALCULATE_H_INCLUDED

void calcuNoDevInfo(LOGGER_T *logger);
void *calTimer(void *arg);
int32_t createCalThread();

#endif
