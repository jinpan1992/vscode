#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#include "script_interface.h"
#include "sgdev.h"
#include "processor.h"
#include "sys.h"
#include "logUtil.h"
#include "sdb.h"
#include "common.h"
#include "math.h"
#include "persist.h"
#include "runCfg.h"
#include "msg.h"
#include "stdio.h"
#include "string.h"
#include "mapping.h"
#include <sys/time.h>
#include"unistd.h"
#include "dido.h"
SI_HANDLE_T siHandle = {0};
SI_HANDLE_T dataprocessinghandle = {0};
SI_HANDLE_T fault_handle ={0};
SI_HANDLE_T warning_handle ={0};
// float inputhisdate[10][20+10]={{14,13,15,12,13,24,23,24,23,23,25,30,30,35,36,30,25,28,28,30,28,27,27,26,25,24,24,24,24,24}};
uint16_t times = 0;//linshitest
float testdate[120] = {24,23,24,23,23,25,30,30,35,36,30,25,28,28,30,28,27,27,26,25,24,24,24,24,24};//linshi test
float valid_value1 = 24.0;
ALOGR_T * webin_dataprocessor =NULL;
PROTECTSTORAGE_T *warning_yuzhi =NULL;
FUNC_INPARA_T *pin_processor =NULL;
FUNC_INPARA_T *pin_fault = NULL;
FUNC_INPARA_T *pin_warning =NULL;
FUNC_OUTPARA_T *pout_fault = NULL;
FUNC_OUTPARA_T *pout_warning =NULL;
FUNC_OUTPARA_T *pout_processor =NULL;
HISDATA_ELEMENT_T *pElement =NULL;
int16_t uart_enabe_num = 0;
int16_t data_num = 0;
int16_t guangfu_dev_num = 0,chuneng_dev_num = 0,guangfu_valid_point =0;
int16_t data_num_fault = 0,guangfu_dev_num_fault = 0,chuneng_dev_num_fault = 0;
int16_t data_num_warning = 0,guangfu_dev_num_warning = 0,chuneng_dev_num_warning = 0;
int32_t ND_num = 0;
int32_t Historyread_sucess[100] = {0};
int weight[6][30] = {0};
int32_t yichang_processtimes[100] = {0};
int32_t puata_hw_yichang_processtimes[100] ={0};
float32_t *inputhisdate = NULL;
float32_t *inputhisdate1 = NULL;
int32_t WRA_filter_times[100]= {0};
int32_t low1_filter_times[100]= {0};
int32_t LG_filter_times[100]= {0};
int16_t dataprocess_flag = 0;
int16_t inputhisdate_flag = 0;
int16_t inputhisdate_flag1 = 0;
uint32_t value;
int32_t statusDO1 = 1;
int32_t statusDO2 = 1;
int32_t statusDO3 = 1;
int32_t statusDO4 = 1;
int32_t statusDO5 = 1;
int32_t statusDO6 = 1;
int32_t statusDO7 = 1;
int32_t statusDO8 = 1;
IO_PARAM_T save_io[20] = {0};
uint16_t PointInit()
{
    int32_t data_id = 0;

    int16_t i =0,j= 0,k1 = 0,k1_1 = 0,k1_2 = 0,k2 = 0,k2_1 = 0,k2_2 = 0,k3 = 0,k3_1=0;

    char dataprocessor_dataname[50][20] = {{"总有功功率"},{"有功功率"}};
    char dataprocessor_after_dataname[100][20] = {{"总有功功率1"},{"总有功功率2"},{"总有功功率3"},{"总有功功率4"},{"总有功功率5"},{"总有功功率6"},{"总有功功率7"},{"总有功功率8"},{"总有功功率9"},{"总有功功率10"},
    {"总有功功11"},{"总有功功率12"},{"总有功功率13"},{"总有功功率14"},{"总有功功率15"},{"总有功功率16"},{"总有功功率17"},{"总有功功率18"},{"总有功功率19"},{"总有功功率20"},
    {"总有功功率21"},{"总有功功率22"},{"总有功功率23"},{"总有功功率24"},{"总有功功率25"},{"总有功功率26"},{"总有功功率27"},{"总有功功率28"},{"总有功功率29"},
    {"总有功功率30"},{"总有功功率31"},{"总有功功率32"},{"总有功功率33"},{"总有功功率34"},{"总有功功率35"},{"总有功功率36"},{"总有功功率37"},{"总有功功率38"},{"总有功功率39"},
    {"总有功功率40"},{"总有功功率41"},{"总有功功率42"},{"总有功功率43"},{"总有功功率44"},{"总有功功率45"},{"总有功功率46"},{"总有功功率47"},{"总有功功率48"},{"总有功功率49"},{"总有功功率50"},
    {"有功功率1"},{"有功功率2"},{"有功功率3"},{"有功功率4"},{"有功功率5"},{"有功功率6"},{"有功功率7"},{"有功功率8"},{"有功功率8"},{"有功功率9"}
        ,{"有功功率10"},{"有功功率11"},{"有功功率12"},{"有功功率13"},{"有功功率14"},{"有功功率15"},{"有功功率16"},{"有功功率17"},{"有功功率18"},{"有功功率19"}
        ,{"有功功率20"},{"有功功率21"},{"有功功率22"},{"有功功率23"},{"有功功率24"},{"有功功率25"},{"有功功率26"},{"有功功率27"},{"有功功率28"},{"有功功率29"}
        ,{"有功功率30"},{"有功功率31"},{"有功功率32"},{"有功功率33"},{"有功功率34"},{"有功功率35"},{"有功功率36"},{"有功功率37"},{"有功功率38"},{"有功功率39"}
        ,{"有功功率40"},{"有功功率41"},{"有功功率42"},{"有功功率43"},{"有功功率44"},{"有功功率44"},{"有功功率46"},{"有功功率47"},{"有功功率48"},{"有功功率49"},{"有功功率50"}
    };
    char fault_dataname[10][20] = {{"状态数据1"},{"故障状态1"},{"故障状态2"}};
    char warning_dataname[11][20] = {{"告警运行状态1"},{"告警运行状态2"},{"单体电压"},{"单体温度"},{"Pack电压"},{"RackSOC"},{"RackSOH"},{"Rack电压"},{"Rack压参"},{"Rack过流"},{"Rack环流"}};


    ND_num = SDB_ND_GetNum();
    if(ND_num>1)
    {
        //dataprocess
        pin_processor = (FUNC_INPARA_T *)malloc(sizeof(FUNC_INPARA_T)*1);
        pin_processor->inpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*100);
        pout_processor = (FUNC_OUTPARA_T *)malloc(sizeof(FUNC_OUTPARA_T)*1);
        pout_processor->outpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*100);
        webin_dataprocessor = (ALOGR_T *)malloc(sizeof(ALOGR_T) * 6);
        pElement = (HISDATA_ELEMENT_T *)malloc(sizeof(HISDATA_ELEMENT_T)*100);

        //fault
        pin_fault = (FUNC_INPARA_T *)malloc(sizeof(FUNC_INPARA_T)*1);
        pin_fault->inpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*150);
        pout_fault =  (FUNC_OUTPARA_T *)malloc(sizeof(FUNC_OUTPARA_T)*1);
        pout_fault->outpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*150);

        pin_warning = (FUNC_INPARA_T *)malloc(sizeof(FUNC_INPARA_T)*1);
        pin_warning->inpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*550);
        pout_warning =  (FUNC_OUTPARA_T *)malloc(sizeof(FUNC_OUTPARA_T)*1);
        pout_warning->outpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*550);



        warning_yuzhi = (PROTECTSTORAGE_T *)malloc(sizeof(PROTECTSTORAGE_T)*1);
        DEV_INFO_EXT_T *dev_info = NULL;
        DEV_INFO_EXT_T *dev_info_1 = (DEV_INFO_EXT_T*)malloc(sizeof(DEV_INFO_EXT_T)*ND_num);


        dev_info = SDB_ND_GetList();



        memcpy(dev_info_1, dev_info, sizeof(DEV_INFO_EXT_T)*ND_num);




        printf("ND_num = %d\n",ND_num);


        for(i = 0; i < ND_num;i++)
        {
            if((dev_info_1[i].stDevUID.devCode >= INV_START_NUM)&&(dev_info_1[i].stDevUID.devCode <= INV_START_NUM + INV_DEV_MAX_NUM))
            {
                for(j = 0;j < guangfu_dataprocess_datanum;j++)
                {
                    pin_processor->inpara[j+data_num-k1_1].dev_code = dev_info_1[i].stDevUID.devCode;
                    pElement[j+data_num-k1_1].devCode = dev_info_1[i].stDevUID.devCode;
                    pout_processor->outpara[j+data_num-k1_1].dev_code = 2304;
                    pin_processor->inpara[j+data_num-k1_1].index  = 1;
                    pElement[j+data_num-k1_1].devIndex =   1;
                    pout_processor->outpara[j+data_num-k1_1].index  =1;
                    data_id= SDB_ND_GetDataId(pin_processor->inpara[j+data_num-k1_1].dev_code,pin_processor->inpara[j+data_num-k1_1].index,dataprocessor_dataname[j]);

                    printf("guangfu pin_processor->inpara[j+data_num].data_id  =%d\n",data_id);
                    if(data_id == INVALID_VALUE)
                    {
                        k1++;
                        k1_1++;
                    }
                    else
                    {
                        pin_processor->inpara[j+data_num-k1_1].data_id = data_id;
                        pElement[j+data_num-k1_1].dataId = data_id;
                        data_id= SDB_ND_GetDataId(pout_processor->outpara[j+data_num-k1_1].dev_code,pout_processor->outpara[j+data_num].index,dataprocessor_after_dataname[j+guangfu_dev_num*guangfu_dataprocess_datanum]);
                        pout_processor->outpara[j+data_num-k1_1].data_id =data_id;
                        printf("guangfu pout_processor->outpara[j+data_num-k1_1].data_id  =%d\n",data_id);

                    }

                }
                guangfu_dev_num ++;
            }

            else if((dev_info_1[i].stDevUID.devCode>=STORAGE_CONVERTER_START_NUM)&&(dev_info_1[i].stDevUID.devCode<=STORAGE_CONVERTER_START_NUM+STORAGE_CONVERTER_DEV_MAX_NUM))
            {
                for(j=0;j<chuneng_dataprocess_datanum;j++)
                {
                    pin_processor->inpara[j+data_num-k1_2].dev_code = dev_info_1[i].stDevUID.devCode;
                    pElement[j+data_num-k1_2].devCode = dev_info_1[i].stDevUID.devCode;
                    pout_processor->outpara[j+data_num-k1_2].dev_code  = 2304;
                    pin_processor->inpara[j+data_num-k1_2].index  = 1;
                    pElement[j+data_num-k1_2].devIndex =   1;
                    pout_processor->outpara[j+data_num-k1_2].index =1;
                    data_id = SDB_ND_GetDataId(pin_processor->inpara[j+data_num-k1_2].dev_code,pin_processor->inpara[j+data_num-k1_2].index,dataprocessor_dataname[j+guangfu_dataprocess_datanum]);
                    printf("chuneng pin_processor->inpara[j+data_num].data_id  =%d\n",data_id);
                    if(data_id == INVALID_VALUE)
                    {
                        k1++;//本设备未获得测点id的数量
                        k1_2++;
                    }
                    else
                    {
                        pin_processor->inpara[j+data_num-k1_2].data_id = data_id;
                        pElement[j+data_num-k1_2].dataId = data_id;
                        printf("char = %s\n",dataprocessor_after_dataname[j+guangfu_dev_num*guangfu_dataprocess_datanum+chuneng_dev_num*chuneng_dataprocess_datanum]);
                        data_id= SDB_ND_GetDataId(pout_processor->outpara[j+data_num-k1_2].dev_code,pout_processor->outpara[j+data_num-k1_2].index,dataprocessor_after_dataname[j+guangfu_dev_num*guangfu_dataprocess_datanum+chuneng_dev_num*chuneng_dataprocess_datanum]);
                        pout_processor->outpara[j+data_num-k1_1].data_id =data_id;
                        printf("chuneng pout_processor->outpara[j+data_num-k1_1].data_id  =%d\n",data_id);
                    }

                }
                chuneng_dev_num ++;
            }
            k1_1 = 0;
            k1_2 = 0;
            data_num = guangfu_dev_num*guangfu_dataprocess_datanum+chuneng_dev_num*chuneng_dataprocess_datanum-k1;
        }
        printf("guangfu_dev_num = %d chuneng_dev_num = %d k1 = %d\n",guangfu_dev_num,chuneng_dev_num,k1);
        k1 =0;
        pin_processor->in_argc = data_num;
        pout_processor->out_argc = data_num;

//         printf("data_num = %d\n",data_num);



            /*****************fault******************/
            /*****************fault******************/
            /*****************fault******************/
            /*****************fault******************/
            /*****************fault******************/
            /*****************fault******************/
        if (fault_handle.pRec == NULL)
        {
            fault_handle.pRec = (RECORD_Q_T * )malloc(sizeof(RECORD_Q_T) * 10);
            if (fault_handle.pRec == NULL)
            {
                return 0;
            }
            memset(fault_handle.pRec, 0, sizeof(RECORD_Q_T) * 10);
        }
        for(i = 0; i < ND_num;i++)
        {
            if((dev_info_1[i].stDevUID.devCode >= INV_START_NUM)&&(dev_info_1[i].stDevUID.devCode <= INV_START_NUM + INV_DEV_MAX_NUM))
            {
                for(j = 0;j < guangfu_fault_datanum;j++)
                {
                    pin_fault->inpara[j+data_num_fault-k2_1].dev_code = dev_info_1[i].stDevUID.devCode;
                    pout_fault->outpara[j+data_num_fault-k2_1].dev_code = dev_info_1[i].stDevUID.devCode;
                    pin_fault->inpara[j+data_num_fault-k2_1].index  = dev_info_1[i].stDevUID.devIndex;
                    pout_fault->outpara[j+data_num_fault-k2_1].index = dev_info_1[i].stDevUID.devIndex;
                    data_id= SDB_ND_GetDataId(pin_fault->inpara[j+data_num_fault-k2_1].dev_code,pin_fault->inpara[j+data_num_fault-k2_1].index,fault_dataname[j]);


                    fault_handle.pRec[j+data_num_fault-k2_1].data_id = j;

                    if(data_id == INVALID_VALUE)
                    {
                        k2++;
                        k2_1++;
                    }
                    else
                    {
                        pin_fault->inpara[j+data_num_fault-k2_1].data_id = data_id;
                        pout_fault->outpara[j+data_num_fault-k2_1].data_id = data_id;
                        printf("guangfu:pin_fault->inpara[j+data_num_fault].dev_code =%d  pin_fault->inpara[j+data_num_fault].index = %d pin_fault->inpara[j+data_num_fault].data_id = %d\n",
                        pin_fault->inpara[j+data_num_fault-k2_1].dev_code,
                         pin_fault->inpara[j+data_num_fault-k2_1].index,
                         pin_fault->inpara[j+data_num_fault-k2_1].data_id
                        );
                    }

                }
                guangfu_dev_num_fault ++;
            }
            else if((dev_info_1[i].stDevUID.devCode>=STORAGE_CONVERTER_START_NUM)&&(dev_info_1[i].stDevUID.devCode<=STORAGE_CONVERTER_START_NUM+STORAGE_CONVERTER_DEV_MAX_NUM))
            {
                for(j=0;j<chuneng_fault_datanum;j++)
                {
                    pin_fault->inpara[j+data_num_fault-k2_2].dev_code = dev_info_1[i].stDevUID.devCode;
                    pout_fault->outpara[j+data_num_fault-k2_2].dev_code = dev_info_1[i].stDevUID.devCode;
                    pin_fault->inpara[j+data_num_fault-k2_2].index  = dev_info_1[i].stDevUID.devIndex;
                    pout_fault->outpara[j+data_num_fault-k2_2].index = dev_info_1[i].stDevUID.devIndex;
                    data_id = SDB_ND_GetDataId(pin_fault->inpara[j+data_num_fault-k2_2].dev_code,pin_processor->inpara[j+data_num_fault-k2_2].index,fault_dataname[j+guangfu_fault_datanum]);

                    fault_handle.pRec[j+data_num_fault-k2_2].data_id = j+guangfu_fault_datanum;

                    if(data_id == INVALID_VALUE)
                    {
                        k2++;//本设备未获得测点id的数量
                        k2_2++;
                    }
                    else
                    {
                        pin_fault->inpara[j+data_num_fault-k2_2].data_id = data_id;
                        pout_fault->outpara[j+data_num_fault-k2_2].data_id = data_id;
                        printf("chuneng:pin_fault->inpara[j+data_num_fault].dev_code =%d  pin_fault->inpara[j+data_num_fault].index = %d pin_fault->inpara[j+data_num_fault].data_id = %d\n",
                        pin_fault->inpara[j+data_num_fault-k2_1].dev_code,
                         pin_fault->inpara[j+data_num_fault-k2_1].index,
                         pin_fault->inpara[j+data_num_fault-k2_1].data_id);
                    }

                }
                chuneng_dev_num_fault ++;
            }
            k2_1 = 0;
            k2_2 = 0;
            data_num_fault = guangfu_dev_num_fault*guangfu_fault_datanum+chuneng_dev_num_fault*chuneng_fault_datanum-k2;

        }

        k2 =0;
        pin_fault->in_argc = data_num_fault;
        pout_fault->out_argc = data_num_fault;
        printf("data_num_fault  = %d\n",data_num_fault);



            /*****************warning******************/
            /*****************warning******************/
            /*****************warning******************/
            /*****************warning******************/
            /*****************warning******************/
            /*****************warning******************/
            if (warning_handle.pRec == NULL)
            {
                warning_handle.pRec = (RECORD_Q_T * )malloc(sizeof(RECORD_Q_T) * 10);
                if (warning_handle.pRec == NULL)
                {
                    return 0;
                }
                memset(warning_handle.pRec, 0, sizeof(RECORD_Q_T) * 10);
            }
            for(i = 0; i < ND_num;i++)
            {
                if((dev_info_1[i].stDevUID.devCode >= INV_START_NUM)&&(dev_info_1[i].stDevUID.devCode <= INV_START_NUM + INV_DEV_MAX_NUM))
                {
                    for(j = 0;j < guangfu_warning_datanum;j++)
                    {
                        pin_warning->inpara[j+data_num_warning].dev_code = dev_info_1[i].stDevUID.devCode;
                        pout_warning->outpara[j+data_num_warning].dev_code = dev_info_1[i].stDevUID.devCode;
                        pin_warning->inpara[j+data_num_warning].index  = dev_info_1[i].stDevUID.devIndex;
                        pout_warning->outpara[j+data_num_warning].index = dev_info_1[i].stDevUID.devIndex;

                        data_id= SDB_ND_GetDataId(pin_warning->inpara[j+data_num_warning].dev_code,pin_warning->inpara[j+data_num_warning].index,warning_dataname[j]);

                        warning_handle.pRec[j+data_num_warning].data_id = j;

                        if(data_id == INVALID_VALUE)
                        {
                            k3++;
                        }
                        else
                        {
                            pin_warning->inpara[j+data_num_warning].data_id = data_id;
                            pout_warning->outpara[j+data_num_warning].data_id = data_id;
                        }

                    }
                    guangfu_dev_num_warning ++;
                }
                if((dev_info_1[i].stDevUID.devCode>=STORAGE_CONVERTER_START_NUM)&&(dev_info_1[i].stDevUID.devCode<=STORAGE_CONVERTER_START_NUM+STORAGE_CONVERTER_DEV_MAX_NUM))
                {
                    for(j=0;j<chuneng_warning_datanum;j++)
                    {
                        pin_warning->inpara[j+data_num_warning-k3_1].dev_code = dev_info_1[i].stDevUID.devCode;
                        pout_warning->outpara[j+data_num_warning-k3_1].dev_code = dev_info_1[i].stDevUID.devCode;
                        pin_warning->inpara[j+data_num_warning-k3_1].index  = dev_info_1[i].stDevUID.devIndex;
                        pout_warning->outpara[j+data_num_warning-k3_1].index = dev_info_1[i].stDevUID.devIndex;
                        printf("warning_dataname[j+guangfu_warning_datanum] = %s pin_warning->inpara[j+data_num_warning].dev_code =%d pin_warning->inpara[j+data_num_warning].index =%d\n",warning_dataname[j+guangfu_warning_datanum],pin_warning->inpara[j+data_num_warning-k3_1].dev_code,pin_warning->inpara[j+data_num_warning-k3_1].index);
                        data_id = SDB_ND_GetDataId(pin_warning->inpara[j+data_num_warning-k3_1].dev_code,pin_warning->inpara[j+data_num_warning-k3_1].index,warning_dataname[j+guangfu_warning_datanum]);

                        warning_handle.pRec[j+data_num_warning-k3_1].data_id = j+guangfu_warning_datanum;
                        printf("###dev_code = %d  index = %d\n",pin_warning->inpara[j+data_num_warning-k3_1].dev_code, pin_warning->inpara[j+data_num_warning-k3_1].index);
                        printf("pin_warning->inpara[j+data_num_fault].data_id  =%d\n",data_id);

                        if(data_id == INVALID_VALUE)
                        {
                            k3++;//本设备未获得测点id的数量
                            k3_1++;
                        }
                        else
                        {
                            pin_warning->inpara[j+data_num_warning-k3_1].data_id = data_id;
                            pout_warning->outpara[j+data_num_warning-k3_1].data_id = data_id;
                        }

                    }
                    k3_1=0;
                    chuneng_dev_num_warning ++;
                }
                data_num_warning = guangfu_dev_num_warning*guangfu_warning_datanum+chuneng_dev_num_warning*chuneng_warning_datanum-k3;
            }
            printf("guangfu_dev_num_warning = %d chuneng_dev_num_warning = %d k3 = %d\n",guangfu_dev_num_warning,chuneng_dev_num_warning,k3);

            k3=0;

            printf("data_num_warning = %d\n",data_num_warning);
            pin_warning->in_argc = data_num_warning;
            pout_warning->out_argc = data_num_warning;

    }

}
int32_t initRecord(void *in)
{
    uint8_t i = 0;
    FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
    uint32_t num = pin->in_argc;

    pthread_mutex_lock(&siHandle.mtx);
    if (siHandle.pRec == NULL)
    {
//         siHandle.pRec = malloc(sizeof(RECORD_Q_T) * num);
//         if (siHandle.pRec == NULL)
//         {
//             return 0;
//         }
//         memset(siHandle.pRec, 0, sizeof(RECORD_Q_T) * num);
        siHandle.recQCount = num;
        siHandle.debug = FALSE;

        for (i = 0; i < num; i++)
        {
            if (siHandle.pRec[i].dataStartAddr == NULL)
            {
                siHandle.pRec[i].dataStartAddr = malloc(sizeof(DEV_DATA_T) * FILTERWINDOW); //缓存3s 数据
            }

            siHandle.pRec[i].offset = 0;
            siHandle.pRec[i].cap = FILTERWINDOW;
        }
    }
    pthread_mutex_unlock(&siHandle.mtx);
    return 0;
}
int32_t initdata_processing(void *in,uint8_t dataprocesswindow,uint32_t order)
{
    uint8_t i = 0;
    FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
    uint32_t num = pin->in_argc;

    pthread_mutex_lock(&dataprocessinghandle.mtx);

        dataprocessinghandle.recQCount = num;
        dataprocessinghandle.debug = false;

        for (i = 0; i < num; i++)
        {
            if (dataprocessinghandle.pRec[i].dataStartAddr == NULL)
            {
                if(order == i)
                {
                    dataprocessinghandle.pRec[i].dataStartAddr = malloc(sizeof(DEV_DATA_T) * dataprocesswindow);//开辟测点信息存储空间
                    dataprocessinghandle.pRec[i].offset = 0;
                    dataprocessinghandle.pRec[i].cap = dataprocesswindow;
                }

            }

        }

    pthread_mutex_unlock(&dataprocessinghandle.mtx);
    return 0;
}
int32_t Filter_Average(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{
    FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
    uint32_t num = pin->in_argc;
    uint16_t i = 0, j = 0;
    float32_t sum = 0;
    float32_t avg = 0;
    DEV_DATA_T *pCurDevData = data;
    DEV_DATA_T tmpDevData;

    initRecord(in);

    for (i = 0; i < num; i++)
    {
        if (siHandle.pRec != NULL && siHandle.pRec[i].dataStartAddr != NULL)
        {
            for (j = 0; j < siHandle.pRec[i].cap; j++)
            {
                tmpDevData = siHandle.pRec[i].dataStartAddr[j];
                if (tmpDevData.dev_code == pCurDevData->dev_code && tmpDevData.data_id == pCurDevData->data_id)
                {
                    switch (tmpDevData.data_type){
                        case FLOAT_T:
                            sum += tmpDevData.value.data.f32;
                            break;
                        case U_INT_T:
                            printf("%s j:%d value:%d \n", __func__, j, siHandle.pRec[i].dataStartAddr[j].value.data.u32);
                            sum += tmpDevData.value.data.u32;
                            break;
                        case S_INT_T:
                            sum += tmpDevData.value.data.s32;
                            break;
                        default:
                            break;
                    }
                }
            }

            avg = sum / siHandle.pRec[i].cap;
            printf("%s i:%d avg:%f \n", __func__, i, avg);
        }
    }

    return 0;
}

int32_t Record_1s(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{
    FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
    FUNC_OUTPARA_T *pout = (FUNC_OUTPARA_T *)out;
    uint32_t num = pin->in_argc;
    uint16_t i = 0, j = 0;
    float32_t sum = 0;
    float32_t avg = 0;
    int32_t ret = -1;

    static uint8_t loop = 0;

    loop++;

    initRecord(in);

    DEV_DATA_T *tmp_data = malloc(sizeof(DEV_DATA_T) * num);
    for(i = 0; i < num; i++)
    {
        tmp_data[i].data_type = pin->inpara[i].dataType;
        tmp_data[i].dev_code = pin->inpara[i].dev_code;
        tmp_data[i].index = pin->inpara[i].index;
        tmp_data[i].data_id = pin->inpara[i].data_id;
    }

    SDB_GetRegisterValue(tmp_data, num);

    for (i = 0; i < num; i++)
    {
        if (siHandle.pRec[i].dataStartAddr == NULL)
        {
            return 0;
        }

        sum = 0;
        uint32_t tCurMS = GetTickCount();
        int32_t delta = tCurMS - tmp_data[i].value.dataTimeMS;
        if (siHandle.debug)
            printf("%s i:%d value:%d datatime:%u curTime:%u delta:%d.\n", __func__, i,
                tmp_data[i].value.data.s32,
                tmp_data[i].value.dataTimeMS,
                tCurMS, delta
            );

        if (delta >= 1000 || delta <= -1000)
        {
            tmp_data[i].value.dataTimeMS = tCurMS;
            tmp_data[i].value.data.s32 = INVALID_VALUE;
        }

        memcpy(&(siHandle.pRec[i].dataStartAddr[siHandle.pRec[i].offset]), &(tmp_data[i]), sizeof(DEV_DATA_T));
        siHandle.pRec[i].offset++;
        if (siHandle.pRec[i].offset >= siHandle.pRec[i].cap)
            siHandle.pRec[i].offset = 0;

        if (loop == FILTERWINDOW)
        {
            BOOL hasFakeData = false;
            for (j = 0; j < siHandle.pRec[i].cap; j++)
            {
                DEV_DATA_T tmpDevData = siHandle.pRec[i].dataStartAddr[j];
                if (tmpDevData.value.data.s32 == INVALID_VALUE)
                {
                    hasFakeData = TRUE;
                    break;
                }

                switch (tmpDevData.data_type){
                    case FLOAT_T:
                        sum += tmpDevData.value.data.f32;
                        if (siHandle.debug)
                            printf("%s i:%d j:%d value:%f (L%d)\n", __func__, i, j, tmpDevData.value.data.f32, __LINE__);
                        break;
                    case U_INT_T:
                        sum += tmpDevData.value.data.u32;
                        if (siHandle.debug)
                            printf("%s i:%d j:%d value:%u (L%d)\n", __func__, i, j, tmpDevData.value.data.u32, __LINE__);
                        break;
                    case S_INT_T:
                        sum += tmpDevData.value.data.s32;
                        if (siHandle.debug)
                            printf("%s i:%d j:%d value:%d (L%d)\n", __func__, i, j, tmpDevData.value.data.s32, __LINE__);
                        break;
                    default:
                        break;
                }
            }

            avg = hasFakeData ? INVALID_VALUE : (sum / siHandle.pRec[i].cap);
            if (i == 1)
            {
                pout->outpara[0].data.u32 = avg;
                //pout->outpara[0].dev_code = CEMS_DEV_CODE;
                pout->out_argc = 1;
            }

            if (siHandle.debug)
                printf("%s i:%d hasFakeData:%d avg:%f \n", __func__, i, hasFakeData, avg);
        }

    }

    if (loop == FILTERWINDOW)
    {
        loop = 0;
        ret = 0;
    }

    HCFREE(tmp_data);

    return ret;
}
//快速排序
void qusort(float a[],int left,int right)
{
    int i=left;//i为从左到右的‘key’值
    int j=right;//r为从右到左的'key'值
    float point=a[i];//将基准值设为a[0]
    if(left>right){return;}//防止输入错误
    while(i<j)
    {
        while(i<j&&a[j]>point)
        j--;//如果右边大于基准值，右边左移
        if(i<j){a[i]=a[j];i++;}//如果右边小于基准值，右边填坑基准值的位置，并右移一位
        while(i<j&&a[i]<point)
        i++;//如果左边小于基准值，左边右移
        if(i<j){a[j]=a[i];j--;}//如果左边小于基准值，左边填坑到右边，并左移一位
    }
    a[i]=point;//填坑
    if(i-1>left)
    {
        qusort(a,left,i-1);//右边递归
    }
    if(i+1<right)
    {
        qusort(a,i+1,right);//右边递归
    }

}

void Box_plot(float inputhisdate[],float inputsampledata[],int numbers,int inputsampledata_numbers,int data_order)
{
    int i = 0;
    static int yichangzhi_nums = 0;
    float Q2L = 0,Q1L = 0,Q3L = 0,IRL=0;
    //合并数组
    //memcpy(inputhisdate+numbers-inputsampledata_numbers, inputsampledata, sizeof(int)*inputsampledata_numbers);

    qusort(inputhisdate,0,numbers-1);
    if(numbers % 2 == 0)
    {
        Q2L = (inputhisdate[numbers/2]+inputhisdate[(numbers/2)+1])/2;
        if(numbers % 4 == 0)
        {
            Q1L = (inputhisdate[numbers/4-1]+inputhisdate[(numbers/4)+1-1])/2;
            Q3L = (inputhisdate[numbers*3/4-1]+inputhisdate[(numbers*3/4)+1-1])/2;
            //printf("Q1L = %f  Q3L = %f\n",Q1L,Q3L);
        }
        else
        {
            Q1L = inputhisdate[((numbers/2)+1)/2-1];
            Q3L = inputhisdate[((numbers/2)+1)/2+numbers/2-1];
        }
    }
    else
    {
        Q2L = (inputhisdate[numbers/2-1]+inputhisdate[(numbers/2)+1-1])/2;
        if(numbers % 4 == 1)
        {
            Q1L = (float)3/4*inputhisdate[((int)(numbers/4)+1)-1] + (float)1/4*inputhisdate[((int)(numbers/4)+2)-1];
            Q3L = (float)1/4*inputhisdate[(3*(int)(numbers/4)+1)-1] + (float)3/4*inputhisdate[(3*(int)(numbers/4)+2)-1];
        }
        else
        {
            Q1L = (float)1/4*inputhisdate[((int)(numbers/4)+1)-1] + (float)3/4*inputhisdate[((int)(numbers/4)+2)-1];
            Q3L = (float)3/4*inputhisdate[(3*(int)(numbers/4)+1)-1] + (float)1/4*inputhisdate[(3*(int)(numbers/4)+2)-1];
        }
    }
//     for(i = 0;i<inputhisdate_num;i++)
//     {
//        printf("inputhisdate[%d]=%f ",i,inputhisdate[i]);
//     }
//     printf("\n");
    IRL = Q3L- Q1L ;
//     printf("@@@\n");
    yichang_processtimes[data_order]++;
    for(i = 0;i<inputsampledata_numbers;i++)
    {

        if((inputsampledata[i]>=Q3L+1.5*IRL)||(inputsampledata[i]<=Q1L-1.5*IRL))
        {
                printf("Box_plot_yichangpos  = %d data_order =%d\n",i+yichang_processtimes[data_order]*inputsampledata_numbers-inputsampledata_numbers+numbers-inputsampledata_numbers+1,data_order);
                inputsampledata[i]  = NAN;
                yichangzhi_nums++;
        }
    }
}

void puata_hw(float *input_hisdata, float *input_sampledata, int num_history, int num_sample,int data_order)
{
    //int32 num_his;                //历史数据长度
    //int32 num_smpl;               //采样数据长度
    float mean_ndata;          //平均值
    float std_ndata;           //标准差
    int  j = 0;
    int k = 0;
    int i = 0;
    float sum_need_data = 0.0;
    float sum_need_data_2 = 0.0;
    static int puata_yichangzhi_nums = 0;
    //num_his = num_history;
    //num_smpl = num_sample;

    float *need_data = (float*)malloc(sizeof(float)*(num_history+num_sample));


    memcpy(need_data, input_hisdata, sizeof(float)*(num_history+num_sample));


    //求need_data数据和
    for(j=0;j<num_history+num_sample;j++)
    {
        sum_need_data += need_data[j];
    }
    //计算平均值
    mean_ndata = sum_need_data / (num_history+num_sample);

    //计算标准差
    for(i=0;i<num_history+num_sample;i++)
    {
        need_data[i] = need_data[i] - mean_ndata;
        need_data[i] = need_data[i] * need_data[i];
        sum_need_data_2 += need_data[i];
    }
    std_ndata = sqrt(sum_need_data_2 / (num_history+num_sample));
    puata_hw_yichang_processtimes[data_order]++;
    //依据拉依达准则
    for(k=0;k<num_sample;k++)
    {
        //2022-11-07 by jinpan 测试出现识别错误，vscode编译与gcc编译结果不一致，将abs修改成fabs
        if(fabs(input_sampledata[k] - mean_ndata) > 3 * std_ndata)
        {
//             printf("@@@inputsampledata[k] = %f\n",input_sampledata[k]);
            printf("puata_hw_yichangpos  = %d data_order =%d\n",k+puata_hw_yichang_processtimes[data_order]*num_sample-num_sample+num_history+1,data_order);
            input_sampledata[k]  = NAN;
            puata_yichangzhi_nums++;
        }
    }
//     printf("puata_yichangzhi_nums  = %d puata_hw_yichang_processtimes = %d@@@\n",puata_yichangzhi_nums,puata_hw_yichang_processtimes);
    free(need_data);
    need_data = NULL;
}
/**
 * 使用高斯消元法对矩阵进行求逆
 * timer:2022-10-15
 * */
 //#define N 3
void Gauss(float **A, float **B, int  N)//这里的n指的是n*n的方阵中的n
{
    int   i, j, k,m;
    float max, temp;
    // double t[N][N];                //临时矩阵 【未手动开辟存储空间，存在风险】2022-11-08 by jinpan
    float **t;
    t = (float **)malloc(sizeof(float*)*N); //2022-11-08 by jinpan 防止动态开辟出现内存泄漏

    //将A矩阵存放在临时矩阵t[n][n]中
    for (i = 0; i < N; i++)
    {
        *(t+i) = (float*)malloc(sizeof(float)*N); //2022-11-08 by jinpan 防止动态开辟出现内存泄漏
        for (j = 0; j < N; j++)
        {
            t[i][j] = A[i][j];
        }
    }
    //初始化B矩阵为单位阵
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            B[i][j] = (i == j) ? (double)1 : 0;
        }
    }
    for (i = 0; i < N; i++)
    {
        //寻找主元
        max = t[i][i];
        k = i;
        for (j = i + 1; j < N; j++)
        {
            if (fabs(t[j][i]) > fabs(max))
            {
                max = t[j][i];
                k = j;
            }
        }
        //如果主元所在行不是第i行，进行行交换
        if (k != i)
        {
            for (j = 0; j < N; j++)
            {
                temp = t[i][j];
                t[i][j] = t[k][j];
                t[k][j] = temp;
                //B伴随交换
                temp = B[i][j];
                B[i][j] = B[k][j];
                B[k][j] = temp;
            }
        }
        //判断主元是否为0, 若是, 则矩阵A不是满秩矩阵,不存在逆矩阵
        if (t[i][i] == (double)0)
        {
            printf("There is no inverse matrix!");
            system("pause");
            exit(0);
        }
        //消去A的第i列除去i行以外的各行元素
        temp = t[i][i];
        for (j = 0; j < N; j++)
        {
            t[i][j] = t[i][j] / temp;        //主对角线上的元素变为1
            B[i][j] = B[i][j] / temp;        //伴随计算
        }
        for (j = 0; j < N; j++)        //第0行->第n行
        {
            if (j != i)                //不是第i行
            {
                temp = t[j][i];
                for (k = 0; k < N; k++)        //第j行元素 - i行元素*j列i行元素
                {
                    t[j][k] = t[j][k] - t[i][k] * temp;
                    B[j][k] = B[j][k] - B[i][k] * temp;
                }
            }
        }
    }
    //手动释放存储空间
    for(m = 0; m < N; m++)
    {
        free(*(t+m));
        *(t+m) = NULL;
    }
    free(t);
    t = NULL;
}

void linear_interpolation(float *input_hisdata, float *input_sampledata, int  num_his, int num_sample, int num_x,int data_order)
{
    int num_fit;                    //滑窗长度
    int y_in_row;                   //x_in转置后的二维数组 行数
    int y_in_col;                   //x_in转置后的二维数组 列数
    int x_in_y_in_N;                //求逆行列数大小
    float *need_data_temp = NULL;
    float *sliding_window = NULL;  //滑窗数据指针
    float *y_out = NULL;           //线性回归方程指针

    float **temp_in = NULL;        //temp_in = x_in *y_in
    float pinv_x_in[num_his-num_x][num_x+1];      //inv_temp_in 与x_in点乘 得到pinv(x_in)
    float *output_sampledata = NULL;//输出采样数据指针
    float *need_data = NULL;       //总数据指针 总数据=历史数据+采样数据
    //double y_in[6][3];            //x_in转置后的二维数组 6*3
    //double A[6];
    float A[num_x+1];
    float fit_yout = 0.0;          //缺失数据
    int i = 0,j = 0,k = 0,mm = 0,m = 0,ii = 0,jj = 0,r = 0,s= 0,t=0,o = 0,p = 0,q=0,h = 0,kk = 0,u=0;
    int dd= 0;
    num_fit = num_his;              //滑窗初始化
    y_in_row = num_x+1;
    y_in_col = num_fit-num_x;
    x_in_y_in_N = num_fit-num_x;
    float y_in[y_in_row][y_in_col];
    float x_in[y_in_col][y_in_row];
    output_sampledata = input_sampledata;//输出采样数据指针初始化



    //开辟存储空间
    need_data = (float*)malloc(sizeof(float)*(num_his+num_sample));
    sliding_window = (float*)malloc(sizeof(float)*num_fit);
    need_data_temp = (float*)malloc(sizeof(float)*(num_x+1));
    y_out = (float*)malloc(sizeof(float)*(num_fit-num_x));
//     A = (float*)malloc(sizeof(float)*(num_x+1));

//     x_in = (float**)malloc(sizeof(float*)*(num_fit-num_x));
    temp_in = (float**)malloc(sizeof(float*)*(num_fit-num_x));//x_in[3][6]与y_in[6][3]相乘后的中间数组 temp_in[3][3]
//     pinv_x_in = (float**)malloc(sizeof(float*)*(num_fit-num_x));




    //合并数组
    memcpy(need_data, input_hisdata, sizeof(float)*(num_his+num_sample));
    //memcpy(need_data+num_his, output_sampledata, sizeof(float)*num_sample);

    for(i=0;i<num_sample;i++)
    {
        if(isnan(input_sampledata[i]))
        {
            //滑窗,滑窗数据赋值
            for(j=0;j<num_fit;j++)
            {
                sliding_window[j] = need_data[i+j];  //need_data也需要更新缺失值，否则遇到连续两个缺失项会报错
            }
            //构建线性回归方程
            for(k=0;k<num_fit-num_x;k++)
            {
                y_out[k] = sliding_window[k+num_x];
            }

            for(m=0;m<num_fit-num_x;m++)
            {
//                 *(x_in+m) = (float*)malloc(sizeof(float)*(num_x+1));
                //int nn = num_x+1;
                memcpy(*(x_in+m), sliding_window+m, sizeof(float)*num_x);
                x_in[m][num_x] = 1.0;//最后一个赋值为1
            }

            //x_in 3*6矩阵转置才是文档中对应的x_in矩阵6*3 【对应模拟数据情况】

            for(p=0;p<num_fit-num_x;p++)
            {
                for(q=0;q<num_x+1;q++)
                {
                    y_in[q][p] = x_in[p][q];
                }
            }

            //x_in[3][6]与y_in[6][3]相乘后的中间数组 temp_in[3][3]
            //double temp_in[x_in_y_in_N][x_in_y_in_N];
            //double **temp_in = (double**)malloc(sizeof(double*)*x_in_y_in_N);

            float temp_data = 0.0;
            for(ii=0;ii<num_fit-num_x;ii++)
            {
                //temp_in每一行开辟大小
                *(temp_in+ii) = (float*)malloc(sizeof(float)*(num_fit-num_x));
                for(jj=0;jj<num_fit-num_x;jj++)
                {
                    for(kk=0;kk<num_x+1;kk++)
                    {
                        //temp_data += y_in[ii][kk]*x_in[kk][jj];
                        temp_data += x_in[ii][kk]*y_in[kk][jj];
                    }
                    temp_in[ii][jj] = temp_data;
                    temp_data = 0.0;//清空
                }
            }
            //矩阵求逆 inv(temp_in)*y_in = pinv(x_in)
            float **inv_temp_in = temp_in;
            Gauss(temp_in, inv_temp_in,x_in_y_in_N);//移植需注意，二维数组未手动开辟空间，存在风险

            //将inv_temp_in [3][3]与x_in[3][6]点乘 得到pinv(x_in)
            //double pinv_x_in[3][6];

            for(r=0;r<num_fit-num_x;r++)
            {
//                 *(pinv_x_in+r) = (float*)malloc(sizeof(float)*(num_x+1));
                for(s=0;s<num_x+1;s++)
                {
                    for(t=0;t<num_fit-num_x;t++)
                    {
                        temp_data +=  inv_temp_in[r][t] * x_in[t][s];
                    }
                    pinv_x_in[r][s] = temp_data;
                    temp_data = 0.0;
                }
            }

            //y_out与pinv_x_in相乘
            for(mm=0;mm<1;mm++)
            {
                for(u=0;u<num_x+1;u++)
                {
                    for(h=0;h<num_fit-num_x;h++)
                    {
                        temp_data += y_out[h]*pinv_x_in[h][u];
                    }
                    A[u] = temp_data;
                    temp_data = 0.0;
                }
            }
            //fit_yout
            //double need_data_temp[6];
            //double *need_data_temp;
            //need_data_temp = (double*)malloc(sizeof(double)*(num_x+1));
            memcpy(need_data_temp, need_data+i+num_fit-num_x, sizeof(float)*num_x);
            need_data_temp[num_x] = 1.0;
            for(o=0;o<num_x+1;o++)
            {
                fit_yout += A[o]*need_data_temp[o];
            }
            output_sampledata[i] = fit_yout;
            printf("output_sampledata = %f data_order =%d\n", output_sampledata[i],data_order);
            need_data[i+num_fit] = fit_yout;//填充缺失项数据
            fit_yout = 0.0;

            //注意指针释放顺序，二级指针先释放行
//             for(i=0;i<num_fit-num_x;i++)
//             {
//                 free(*(x_in+i));
//                 *(x_in+i) = NULL;
//             }

            for(dd=0;dd<num_fit-num_x;dd++)
            {
                free(*(temp_in+dd));
                *(temp_in+dd) = NULL;
            }

//             for(i=0;i<num_fit-num_x;i++)
//             {
//                 free(*(pinv_x_in+i));
//                 *(pinv_x_in+i) = NULL;
//             }



        }

    }
    free(need_data);
    need_data = NULL;
    free(sliding_window);
    sliding_window = NULL;
    free(y_out);
    y_out = NULL;
    free(need_data_temp);
    need_data_temp = NULL;
//     free(A);
//     A = NULL;


//     free(x_in);
//     x_in = NULL;


    free(temp_in);
    temp_in = NULL;


//     free(pinv_x_in);
//     pinv_x_in = NULL;
}
// void linear_interpolation(float *input_hisdata, float *input_sampledata, int  num_his, int num_sample, int num_x)
// {
//     int num_fit;                    //滑窗长度
//     int y_in_row;                   //x_in转置后的二维数组 行数
//     int y_in_col;                   //x_in转置后的二维数组 列数
//     int x_in_y_in_N;                //求逆行列数大小
//     float *need_data_temp = NULL;
//     float *sliding_window = NULL;  //滑窗数据指针
//     float *y_out = NULL;           //线性回归方程指针
//     float **x_in = NULL;           //二维数组 3*6
//     float **temp_in = NULL;        //temp_in = x_in *y_in
//     float **pinv_x_in = NULL;      //inv_temp_in 与x_in点乘 得到pinv(x_in)
//     float *output_sampledata = NULL;//输出采样数据指针
//     float *need_data = NULL;       //总数据指针 总数据=历史数据+采样数据
//     //double y_in[6][3];            //x_in转置后的二维数组 6*3
//     //double A[6];
//     float *A = NULL;
//     float fit_yout = 0.0;          //缺失数据
//     int i = 0,j = 0,k = 0,mm = 0,m = 0,ii = 0,jj = 0,r = 0,s= 0,t=0,o = 0,p = 0,q=0,h = 0,kk = 0,u=0;
//     num_fit = num_his;              //滑窗初始化
//     y_in_row = num_x+1;
//     y_in_col = num_fit-num_x;
//     x_in_y_in_N = num_fit-num_x;
//     float y_in[y_in_row][y_in_col];//x_in转置后的二维数组 6*3
//     output_sampledata = input_sampledata;//输出采样数据指针初始化
//
//
//
//     //开辟存储空间
//     need_data = (float*)malloc(sizeof(float)*(num_his+num_sample));
//     sliding_window = (float*)malloc(sizeof(float)*num_fit);
//     need_data_temp = (float*)malloc(sizeof(float)*(num_x+1));
//     y_out = (float*)malloc(sizeof(float)*(num_fit-num_x));
//     A = (float*)malloc(sizeof(float)*(num_x+1));
//
//     x_in = (float**)malloc(sizeof(float*)*(num_fit-num_x));
//     temp_in = (float**)malloc(sizeof(float*)*(num_fit-num_x));//x_in[3][6]与y_in[6][3]相乘后的中间数组 temp_in[3][3]
//     pinv_x_in = (float**)malloc(sizeof(float*)*(num_fit-num_x));
//
//
//
//
//     //合并数组
//     memcpy(need_data, input_hisdata, sizeof(float)*(num_his+num_sample));
//     //memcpy(need_data+num_his, output_sampledata, sizeof(float)*num_sample);
//
//     for(i=0;i<num_sample;i++)
//     {
//         if(isnan(input_sampledata[i]))
//         {
//
//
//             //滑窗,滑窗数据赋值
//             for(j=0;j<num_fit;j++)
//             {
//                 sliding_window[j] = need_data[i+j];  //need_data也需要更新缺失值，否则遇到连续两个缺失项会报错
//             }
//             //构建线性回归方程
//             for(k=0;k<num_fit-num_x;k++)
//             {
//                 y_out[k] = sliding_window[k+num_x];
//             }
//
//             for(m=0;m<num_fit-num_x;m++)
//             {
//                 *(x_in+m) = (float*)malloc(sizeof(float)*(num_x+1));
//                 //int nn = num_x+1;
//                 memcpy(*(x_in+m), sliding_window+m, sizeof(float)*num_x);
//                 x_in[m][num_x] = 1.0;//最后一个赋值为1
//             }
//
//             //x_in 3*6矩阵转置才是文档中对应的x_in矩阵6*3 【对应模拟数据情况】
//
//             for(p=0;p<num_fit-num_x;p++)
//             {
//                 for(q=0;q<num_x+1;q++)
//                 {
//                     y_in[q][p] = x_in[p][q];
//                 }
//             }
//
//             //x_in[3][6]与y_in[6][3]相乘后的中间数组 temp_in[3][3]
//             //double temp_in[x_in_y_in_N][x_in_y_in_N];
//             //double **temp_in = (double**)malloc(sizeof(double*)*x_in_y_in_N);
//
//             float temp_data = 0.0;
//             for(ii=0;ii<num_fit-num_x;ii++)
//             {
//                 //temp_in每一行开辟大小
//                 *(temp_in+ii) = (float*)malloc(sizeof(float)*(num_fit-num_x));
//                 for(jj=0;jj<num_fit-num_x;jj++)
//                 {
//                     for(kk=0;kk<num_x+1;kk++)
//                     {
//                         //temp_data += y_in[ii][kk]*x_in[kk][jj];
//                         temp_data += x_in[ii][kk]*y_in[kk][jj];
//                     }
//                     temp_in[ii][jj] = temp_data;
//                     temp_data = 0.0;//清空
//                 }
//             }
//             //矩阵求逆 inv(temp_in)*y_in = pinv(x_in)
//             float **inv_temp_in = temp_in;
//             Gauss(temp_in, inv_temp_in,x_in_y_in_N);//移植需注意，二维数组未手动开辟空间，存在风险
//
//             //将inv_temp_in [3][3]与x_in[3][6]点乘 得到pinv(x_in)
//             //double pinv_x_in[3][6];
//
//             for(r=0;r<num_fit-num_x;r++)
//             {
//                 *(pinv_x_in+r) = (float*)malloc(sizeof(float)*(num_x+1));
//                 for(s=0;s<num_x+1;s++)
//                 {
//                     for(t=0;t<num_fit-num_x;t++)
//                     {
//                         temp_data +=  inv_temp_in[r][t] * x_in[t][s];
//                     }
//                     pinv_x_in[r][s] = temp_data;
//                     temp_data = 0.0;
//                 }
//             }
//
//             //y_out与pinv_x_in相乘
//             for(mm=0;mm<1;mm++)
//             {
//                 for(u=0;u<num_x+1;u++)
//                 {
//                     for(h=0;h<num_fit-num_x;h++)
//                     {
//                         temp_data += y_out[h]*pinv_x_in[h][u];
//                     }
//                     A[u] = temp_data;
//                     temp_data = 0.0;
//                 }
//             }
//             //fit_yout
//             //double need_data_temp[6];
//             //double *need_data_temp;
//             //need_data_temp = (double*)malloc(sizeof(double)*(num_x+1));
//             memcpy(need_data_temp, need_data+i+num_fit-num_x, sizeof(float)*num_x);
//             need_data_temp[num_x] = 1.0;
//             for(o=0;o<num_x+1;o++)
//             {
//                 fit_yout += A[o]*need_data_temp[o];
//             }
//             output_sampledata[i] = fit_yout;
//             need_data[i+num_fit] = fit_yout;//填充缺失项数据
//             fit_yout = 0.0;
//
//             //注意指针释放顺序，二级指针先释放行
//             for(i=0;i<num_fit-num_x;i++)
//             {
//                 free(*(x_in+i));
//                 *(x_in+i) = NULL;
//             }
//
//             for(i=0;i<num_fit-num_x;i++)
//             {
//                 free(*(temp_in+i));
//                 *(temp_in+i) = NULL;
//             }
//
//             for(i=0;i<num_fit-num_x;i++)
//             {
//                 free(*(pinv_x_in+i));
//                 *(pinv_x_in+i) = NULL;
//             }
//
//
//
//         }
//
//     }
//     free(need_data);
//     need_data = NULL;
//     free(sliding_window);
//     sliding_window = NULL;
//     free(y_out);
//     y_out = NULL;
//     free(need_data_temp);
//     need_data_temp = NULL;
//     free(A);
//     A = NULL;
//
//
//     free(x_in);
//     x_in = NULL;
//
//
//     free(temp_in);
//     temp_in = NULL;
//
//
//     free(pinv_x_in);
//     pinv_x_in = NULL;
// }
void WRA_filter(float input_hisdata[], float input_sampledata[], int num_hisory, int num_sample, int num_x, int *weight, int num_weight,int data_order)
{
    float *need_data = NULL;                                           //总数据指针
    int sum_weight = 0;                                                 //权和
    float filter_out = 0.0;                                            //数据与权值相乘累加和
    int i = 0,j=0;
    // double *temp_filter_out = NULL;                                     //滤波数据指针


    int  num_his = num_hisory;                                           //历史数据长度

    int num_smpl = num_sample;                                          //采样数据长度

    need_data = (float *)malloc(sizeof(float)*(num_his+num_smpl));    //总数据开辟数据空间

    //数组合并
    memcpy(need_data, input_hisdata, sizeof(float)*(num_his+num_smpl));
    memcpy(need_data+num_his, input_sampledata, sizeof(float)*(num_smpl));

    int weight_len = num_weight;                        //权值数据大小
    for(i=0;i<weight_len;i++)
    {
        sum_weight += weight[i];                        //权值求和
    }
//     printf("need  =");
//     for(i=0;i<num_his+num_smpl;i++)
//     {
//         printf("%f ",need_data[i]);
//     }
//      printf("@\n");
    for(i=0;i<num_smpl;i++)
    {
        for(j=0;j<num_x;j++)
        {
            filter_out += weight[j]*need_data[num_his-(num_x-1)+i+j];     //对应数组元素相乘并相加 根据matlab代码修改need_data数组中的下标 （matlab下标从1开始，嵌入式c语言中从0开始）
        }
        WRA_filter_times[data_order]++;
        input_sampledata[i] = filter_out/sum_weight;     //滤波数据
        printf("input_sampledata = %f  WRA_filter_times[data_order] =%d,data_order = %d\n",input_sampledata[i], WRA_filter_times[data_order],data_order);
        filter_out = 0.0;                               //每一轮结束后清空
    }
    free(need_data);                                                     //手动释放开辟空间
    need_data = NULL;

}
void low1_filter(float *last_filter, float *input_sampledata, int  num_sample, float time_value,int data_order)
{
    int num_smpl;                           //采样数据长度
    float middle_filter;                   //滤波结果
    float filter_out;                      //滤波后数据
    int i=0;
    middle_filter = *last_filter;           //滤波结果初始化
    num_smpl = num_sample;                  //采样数据长度


    for(i=0;i<num_smpl;i++)             //求解滤波后数据
    {
        low1_filter_times[data_order]++;
//         printf("before input_sampledata = %f low1_filter_times =%d\n",input_sampledata[i],low1_filter_times);
        filter_out = input_sampledata[i] * time_value + middle_filter * (1 - time_value);
        input_sampledata[i] = filter_out;
        printf("after input_sampledata = %f  low1_filter_times[data_order] =%d,data_order =%d\n",input_sampledata[i], low1_filter_times[data_order],data_order);
        middle_filter = filter_out;
        *last_filter = middle_filter;   //2022-11-11 middle_filter更新迭代
    }
}
void LG_filter(float *input_hisdata, float *input_sampledata, int num_history, int num_sample, int max_value, int max_count, float *valid_value,int data_order)
{
    int num_his,num_smpl;                           //历史数据长度 采样数据长度
    static int count = 0;                           //计数
    float filter_out0;                             //滤波输出
    float *need_data = NULL;                       //总数据
    int i = 0,ii=0;

    float input_hisdata1 = input_hisdata[num_history-1];
    num_smpl = num_sample;
    num_his = num_history;
    need_data = (float*)malloc(sizeof(float)*(num_his+num_smpl));//开辟数据空间
    //数组合并
    memcpy(need_data, &input_hisdata1, sizeof(float));
    memcpy(need_data+1, input_sampledata, sizeof(float)*num_smpl);
    for( i=0;i<num_smpl;i++)                     //计算滤波后数据
    {
        LG_filter_times[data_order]++;
        //限幅
        if(fabs(need_data[i+1] - need_data[i]) < max_value)
        {
            filter_out0 = need_data[i+1];
        }
        else
        {
            filter_out0 = need_data[i];
        }
        //消抖
        if(filter_out0 == *valid_value)
        {
            input_sampledata[i] = filter_out0;
        }
        else
        {
            count = count + 1;
            if(count > max_count)
            {
                *valid_value = filter_out0;
                input_sampledata[i] = *valid_value;
                count = 0;
            }
            else
            {
                input_sampledata[i] = *valid_value;
            }
        }
        printf("input_sampledata = %f  LG_filter_times[data_order] =%d data_order  =%d\n",input_sampledata[i], LG_filter_times[data_order],data_order);
    }
//     if(i == num_smpl)
//     {
//         count  =0;
//     }
    free(need_data);
    need_data = NULL;

}
int32_t Data_porcessing(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{

    if(dataprocess_flag == 0)
    {
        return 0;
    }
    FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
    FUNC_OUTPARA_T *pout = (FUNC_OUTPARA_T *)out;
    uint32_t num = pin->in_argc;
    uint16_t i = 0, j = 0, k= 0,f = 0,jj=0,ii=0;
    uint16_t inputsampledata_num = 0,inputhisdate_num = 0 ,data_order = 0;
    uint16_t sampledata_inputhisdate_total =0;
    int32_t ret = -1;
    int32_t valueCount = 0;
    int transmit_dataid = 0,transmit_devcode= 0,transmit_index = 0;
    static float ALimitValidValue[20] = {0};
    static float FirstInitValue[20] = {0};
    pout->out_argc = num;
    for(i = 0; i < num; i++)
    {
        if((data->dev_code ==pin->inpara[i].dev_code)&&(data->index == pin->inpara->index)&&(data->data_id == pin->inpara[i].data_id))
        {
            data_order = i;
        }
    }
    transmit_dataid = pout->outpara[data_order].data_id;
    transmit_devcode = pout->outpara[data_order].dev_code;
    transmit_index = pout->outpara[data_order].index;

    inputsampledata_num = webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].SampleNum;

    inputhisdate_num = webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].HistoryNum;

    float inputsampledata[num][inputsampledata_num];

    static float transmit_inputsampledata[20][30];

    float inputhisdate_process[num][inputsampledata_num+inputhisdate_num];

    sampledata_inputhisdate_total =inputhisdate_num +inputsampledata_num;
    float32_t *inputhisdate_hsitory = NULL;//(float32_t*)malloc(sampledata_inputhisdate_total* sizeof(float32_t));

    switch (dataprocessinghandle.pRec[data_order].dwParamId)
    {
        case 0:
        if(Historyread_sucess[data_order] == 0)
        {
            if(inputhisdate_flag == 0)
            {
                inputhisdate=  (float32_t*)malloc(num*sampledata_inputhisdate_total* sizeof(float32_t));
                inputhisdate_flag = 1;
            }
            Persister_QueryElement(pElement+data_order, 1, sampledata_inputhisdate_total, &inputhisdate_hsitory, &valueCount);

            memcpy(inputhisdate+data_order*sampledata_inputhisdate_total, inputhisdate_hsitory, sizeof(float)*sampledata_inputhisdate_total);

            if(data_processs_debug == 1)
            {
                printf("@@@inputhisdate_hsitory = ");

                printf("###inputhisdate = ");
                for(i=data_order*sampledata_inputhisdate_total;i<data_order*sampledata_inputhisdate_total+sampledata_inputhisdate_total;i++)
                {
                    printf("%f  ",inputhisdate[i]);
                }
                printf("data_order = %d",data_order);
                printf("\n");
            }

            if(valueCount<sampledata_inputhisdate_total)
            {

            }
            else
            {
                Historyread_sucess[data_order] =1;
                printf("Historyread_sucess[data_order] = %d\n",Historyread_sucess[data_order]);
                FirstInitValue[data_order] = webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLPF.FirstInitValue;
                ALimitValidValue[data_order] = webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitValidValue;
            }
        }


        if(Historyread_sucess[data_order] == 1)
        {
            initdata_processing(in,inputsampledata_num,data_order);

    //         printf("Enable =%d AbnormalAlgor =%d\n",webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].Enable,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].AbnormalAlgor);
    //         printf("FilterAlgor =%d MissAlgor =%d\n",webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].MissAlgor);

    //     printf("dataprocessinghandle.debug =%d dataprocessinghandle.pRec[data_order].cap = %d\n",dataprocessinghandle.debug,dataprocessinghandle.pRec[data_order].cap);
            if((data->dev_code ==pin->inpara[data_order].dev_code)&& (data->index == pin->inpara->index)&&(data->data_id == pin->inpara[data_order].data_id))
            {

                if (dataprocessinghandle.pRec[data_order].dataStartAddr == NULL)
                {
                    return 0;
                }





                memcpy(&(dataprocessinghandle.pRec[data_order].dataStartAddr[dataprocessinghandle.pRec[data_order].offset]), &(data[0]), sizeof(DEV_DATA_T));
                switch (data->data_type){
                        case FLOAT_T:

                            break;
                        case U_INT_T:

                            break;
                        case S_INT_T:

                            break;
                        default:
                            break;
                    }
                pout->outpara[data_order].data.s32 = transmit_inputsampledata[data_order][dataprocessinghandle.pRec[data_order].offset];
                pout->outpara[data_order].data_id = transmit_dataid;
                pout->outpara[data_order].dev_code = transmit_devcode;
                pout->outpara[data_order].index = transmit_index;
    //         dataprocessinghandle.pRec[data_order].dataStartAddr[dataprocessinghandle.pRec[data_order].offset].value.data.u32 = data->value.data.u32;
                dataprocessinghandle.pRec[data_order].offset++;

    //         printf("dataprocessinghandle.pRec[data_order].offset =%d\n",dataprocessinghandle.pRec[data_order].offset);
            }
            if (dataprocessinghandle.pRec[data_order].offset >= dataprocessinghandle.pRec[data_order].cap)
            {
                for(k = 0;k < inputhisdate_num;k++)
                {
                    inputhisdate[data_order*sampledata_inputhisdate_total+k] =  inputhisdate[data_order*sampledata_inputhisdate_total+k+inputsampledata_num];
                }
                for (j = 0; j < dataprocessinghandle.pRec[data_order].cap; j++)
                {
                    DEV_DATA_T tmpDevData = dataprocessinghandle.pRec[data_order].dataStartAddr[j];
                    switch (tmpDevData.data_type){
                        case FLOAT_T:
                            inputsampledata[data_order][j] =tmpDevData.value.data.f32;
                            if (dataprocessinghandle.debug)
                                printf("%s i:%d j:%d value:%f (L%d)\n", __func__, i, j, tmpDevData.value.data.f32, __LINE__);
                            break;
                        case U_INT_T:
                            inputsampledata[data_order][j] =tmpDevData.value.data.u32;
                            if (dataprocessinghandle.debug)

                                printf("%s i:%d j:%d value:%u (L%d)\n", __func__, i, j, tmpDevData.value.data.u32, __LINE__);
                            break;
                        case S_INT_T:
                            inputsampledata[data_order][j] =tmpDevData.value.data.s32;
                            if (dataprocessinghandle.debug)
                                printf("%s i:%d j:%d value:%d (L%d)\n", __func__, i, j, tmpDevData.value.data.s32, __LINE__);
                            break;
                        default:
                            break;
                    }
                }
                if(times<20)
                {
    //             memcpy(testdate+inputhisdate_num+times*dataprocessinghandle.pRec[data_order].cap,inputsampledata[data_order],sizeof(float)*inputsampledata_num);
                    if(dataprocessinghandle.debug)
                    {
                        printf("inputsampledata = ");
                        for(i=0;i<inputsampledata_num;i++)
                        {
                            printf("%f  ",inputsampledata[data_order][i]);
                        }
                        printf("data_order =%d ",data_order);
                        printf("\n");
                    }
                }

                times++;
                if(times == 60000)
                {
                    times = 1;
                }
                    memcpy(inputhisdate+data_order*sampledata_inputhisdate_total+inputhisdate_num, inputsampledata[data_order], sizeof(float)*inputsampledata_num);
                    memcpy(inputhisdate_process[data_order], inputhisdate+data_order*sampledata_inputhisdate_total, sizeof(float)*(inputsampledata_num+inputhisdate_num));
                    //异常值识别
                    if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].Enable ==1)
                    {
                        if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].AbnormalAlgor == 1)
                        {
                            Box_plot(inputhisdate_process[data_order],inputsampledata[data_order],inputhisdate_num+inputsampledata_num,inputsampledata_num,data_order);
                        }
                        else if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].AbnormalAlgor == 2)
                        {
                            puata_hw(inputhisdate_process[data_order],inputsampledata[data_order], inputhisdate_num, inputsampledata_num,data_order);
                        }
                        //缺失项填充
                        if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].MissAlgor ==1)
                        {
                            linear_interpolation(inputhisdate+data_order*sampledata_inputhisdate_total+inputhisdate_num-webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ValueNum-1,inputsampledata[data_order],webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ValueNum+1,inputsampledata_num ,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ValueNum,data_order);
                            memcpy(inputhisdate+data_order*sampledata_inputhisdate_total+inputhisdate_num, inputsampledata[data_order], sizeof(float)*inputsampledata_num);
                        }
                        //滤波算法
                        if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor== 1)
                        {
//                             printf("data_id = %d dev_code = %d data_order =%d\n",data->data_id,data->dev_code,data_order);
                            WRA_filter(inputhisdate+data_order*sampledata_inputhisdate_total, inputsampledata[data_order], inputhisdate_num, inputsampledata_num, webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stAve.AveNum, weight[dataprocessinghandle.pRec[data_order].dwParamId],webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stAve.AveNum,data_order);
                        }
                        else if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor == 2)
                        {
//                             printf("data_id = %d dev_code = %d data_order =%d\n",data->data_id,data->dev_code,data_order);
//                             printf("data_order = %d FirstInitValue = %f  FirstTimeValue =%f\n",data_order,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLPF.FirstInitValue,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLPF.FirstTimeValue);
                            low1_filter(FirstInitValue+data_order, inputsampledata[data_order], inputsampledata_num, webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLPF.FirstTimeValue,data_order);
                        }
                        //&last_filter
                        else if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor == 3)
                        {
//                             printf("ALimitMaxVarValue = %f  ALimitMaxVarCnt =%d ALimitValidValue =%f data_order = %d\n",webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitMaxVarValue,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitMaxVarCnt,ALimitValidValue[data_order],data_order);
//                             printf("data_id = %d dev_code = %d \n",data->data_id,data->dev_code);
//                             for(jj=data_order*sampledata_inputhisdate_total;jj<data_order*sampledata_inputhisdate_total+sampledata_inputhisdate_total;jj++)
//                             {
//                                 printf("%f ",inputhisdate[jj]);
//                             }
//                             printf("###\n");
//                             printf("inputhisdate[data_order*sampledata_inputhisdate_total+inputhisdate_num-1] =%f\n",inputhisdate[data_order*sampledata_inputhisdate_total+inputhisdate_num-1]);
                            LG_filter(inputhisdate+data_order*sampledata_inputhisdate_total, inputsampledata[data_order], inputhisdate_num, inputsampledata_num, webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitMaxVarValue, webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitMaxVarCnt,ALimitValidValue+data_order,data_order);
                        }
                        else if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor == 0)
                        {

                        }
                    dataprocessinghandle.pRec[data_order].offset = 0;
                    }
                    memcpy(transmit_inputsampledata[data_order],inputsampledata[data_order],sizeof(float)*inputsampledata_num);

//                     printf("transmit_dataid  =%d transmit_devcode = %d transmit_index =%d\n",transmit_dataid,transmit_devcode,transmit_index);


                        POINT_T tmpPoint;
                        tmpPoint.iPointId = transmit_dataid;
                        tmpPoint.dPointValue = pout->outpara[data_order].data.s32;
                        tmpPoint.ucDataType = FLOAT_T;
                        tmpPoint.unDataValue.f32 = pout->outpara[data_order].data.s32;
                        ShareRTDB_Update(2304, 1,
                        &tmpPoint, 1
                        );
            }
        }
    break;
    case 1://##################case 1:
        if(Historyread_sucess[data_order] == 0)
        {
            if(inputhisdate_flag1 == 0)
            {
                inputhisdate1=  (float32_t*)malloc(num*sampledata_inputhisdate_total* sizeof(float32_t));
                inputhisdate_flag1 = 1;
            }

            Persister_QueryElement(pElement+data_order, 1, sampledata_inputhisdate_total, &inputhisdate_hsitory, &valueCount);
            memcpy(inputhisdate1+data_order*sampledata_inputhisdate_total, inputhisdate_hsitory, sizeof(float)*sampledata_inputhisdate_total);
            if(data_processs_debug == 1)
            {
                printf("@@@inputhisdate_hsitory = ");
                for(i=0;i<sampledata_inputhisdate_total;i++)
                {
                    printf("%f  ",inputhisdate_hsitory[i]);
                }
                printf("\n");
                printf("###inputhisdate1 = ");
                for(i=data_order*sampledata_inputhisdate_total;i<data_order*sampledata_inputhisdate_total+sampledata_inputhisdate_total;i++)
                {
                    printf("%f  ",inputhisdate1[i]);
                }
                printf("data_order = %d",data_order);
                printf("\n");
            }
            if(valueCount<sampledata_inputhisdate_total)
            {

            }
            else
            {
                Historyread_sucess[data_order] =1;
                printf("Historyread_sucess[data_order] = %d\n",Historyread_sucess[data_order]);
                FirstInitValue[data_order] = webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLPF.FirstInitValue;
                ALimitValidValue[data_order] = webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitValidValue;
            }
        }
        if(Historyread_sucess[data_order] == 1)
        {
            initdata_processing(in,inputsampledata_num,data_order);

    //         printf("Enable =%d AbnormalAlgor =%d\n",webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].Enable,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].AbnormalAlgor);
    //         printf("FilterAlgor =%d MissAlgor =%d\n",webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].MissAlgor);

    //     printf("dataprocessinghandle.debug =%d dataprocessinghandle.pRec[data_order].cap = %d\n",dataprocessinghandle.debug,dataprocessinghandle.pRec[data_order].cap);
            if((data->dev_code ==pin->inpara[data_order].dev_code)&& (data->index == pin->inpara->index)&&(data->data_id == pin->inpara[data_order].data_id))
            {

                if (dataprocessinghandle.pRec[data_order].dataStartAddr == NULL)
                {
                    return 0;
                }
                memcpy(&(dataprocessinghandle.pRec[data_order].dataStartAddr[dataprocessinghandle.pRec[data_order].offset]), &(data[0]), sizeof(DEV_DATA_T));
                switch (data->data_type){
                        case FLOAT_T:

                            break;
                        case U_INT_T:

                            break;
                        case S_INT_T:

                            break;
                        default:
                            break;
                    }
                pout->outpara[data_order].data.s32 = transmit_inputsampledata[data_order][dataprocessinghandle.pRec[data_order].offset];
                pout->outpara[data_order].data_id = transmit_dataid;
                pout->outpara[data_order].dev_code = transmit_devcode;
                pout->outpara[data_order].index = transmit_index;
    //         dataprocessinghandle.pRec[data_order].dataStartAddr[dataprocessinghandle.pRec[data_order].offset].value.data.u32 = data->value.data.u32;
                dataprocessinghandle.pRec[data_order].offset++;

//             printf("dataprocessinghandle.pRec[%d].offset =%d  f32= %f\n",data_order,dataprocessinghandle.pRec[data_order].offset,dataprocessinghandle.pRec[data_order].dataStartAddr[dataprocessinghandle.pRec[data_order].offset].value.data.f32);
            }
            if (dataprocessinghandle.pRec[data_order].offset >= dataprocessinghandle.pRec[data_order].cap)
            {
                for(k = 0;k < inputhisdate_num;k++)
                {
                    inputhisdate1[data_order*sampledata_inputhisdate_total+k] =  inputhisdate1[data_order*sampledata_inputhisdate_total+k+inputsampledata_num];
                }
                for (j = 0; j < dataprocessinghandle.pRec[data_order].cap; j++)
                {
    //                 printf("dataprocessinghandle.pRec[data_order].dataStartAddr[j] =%d data_order =%d j= %d\n",dataprocessinghandle.pRec[data_order].dataStartAddr[j].value.data.u32,data_order,j);
                    DEV_DATA_T tmpDevData = dataprocessinghandle.pRec[data_order].dataStartAddr[j];
                    switch (tmpDevData.data_type){
                        case FLOAT_T:
                            inputsampledata[data_order][j] =tmpDevData.value.data.f32;
                            if (dataprocessinghandle.debug)
                                printf("%s i:%d j:%d value:%f (L%d)\n", __func__, i, j, tmpDevData.value.data.f32, __LINE__);
                            break;
                        case U_INT_T:
                            inputsampledata[data_order][j] =tmpDevData.value.data.u32;
                            if (dataprocessinghandle.debug)

                                printf("%s i:%d j:%d value:%u (L%d)\n", __func__, i, j, tmpDevData.value.data.u32, __LINE__);
                            break;
                        case S_INT_T:
                            inputsampledata[data_order][j] =tmpDevData.value.data.s32;
                            if (dataprocessinghandle.debug)
                                printf("%s i:%d j:%d value:%d (L%d)\n", __func__, i, j, tmpDevData.value.data.s32, __LINE__);
                            break;
                        default:
                            break;
                    }
                }
                if(times<20)
                {
    //             memcpy(testdate+inputhisdate_num+times*dataprocessinghandle.pRec[data_order].cap,inputsampledata[data_order],sizeof(float)*inputsampledata_num);
                    if(dataprocessinghandle.debug)
                    {
                        printf("inputsampledata = ");
                        for(i=0;i<inputsampledata_num;i++)
                        {
                            printf("%f  ",inputsampledata[data_order][i]);
                        }
                        printf("data_order =%d ",data_order);
                        printf("\n");
                    }
                }

                times++;
                if(times == 60000)
                {
                    times = 1;
                }
                    memcpy(inputhisdate1+data_order*sampledata_inputhisdate_total+inputhisdate_num, inputsampledata[data_order], sizeof(float)*inputsampledata_num);

                    memcpy(inputhisdate_process[data_order], inputhisdate1+data_order*sampledata_inputhisdate_total, sizeof(float)*(inputsampledata_num+inputhisdate_num));
                    //异常值识别
                    if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].Enable ==1)
                    {
                        if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].AbnormalAlgor == 1)
                        {
                            Box_plot(inputhisdate_process[data_order],inputsampledata[data_order],inputhisdate_num+inputsampledata_num,inputsampledata_num,data_order);
                        }
                        else if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].AbnormalAlgor == 2)
                        {
                            puata_hw(inputhisdate_process[data_order],inputsampledata[data_order], inputhisdate_num, inputsampledata_num,data_order);
                        }
                        //缺失项填充
                        if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].MissAlgor ==1)
                        {
                            linear_interpolation(inputhisdate1+data_order*sampledata_inputhisdate_total+inputhisdate_num-webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ValueNum-1,inputsampledata[data_order],webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ValueNum+1,inputsampledata_num ,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ValueNum,data_order);
                            memcpy(inputhisdate1+data_order*sampledata_inputhisdate_total+inputhisdate_num, inputsampledata[data_order], sizeof(float)*inputsampledata_num);
                        }
                        //滤波算法
                        if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor== 1)
                        {
//                             printf("data_id = %d dev_code = %d data_order =%d\n",data->data_id,data->dev_code,data_order);
                            WRA_filter(inputhisdate1+data_order*sampledata_inputhisdate_total, inputsampledata[data_order], inputhisdate_num, inputsampledata_num, webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stAve.AveNum, weight[dataprocessinghandle.pRec[data_order].dwParamId],webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stAve.AveNum,data_order);
                        }
                        else if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor == 2)
                        {
//                             printf("data_id = %d dev_code = %d data_order =%d\n",data->data_id,data->dev_code,data_order);
//                             printf("FirstInitValue = %f  FirstTimeValue =%f\n",FirstInitValue[data_order],webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLPF.FirstTimeValue);
//                             for(jj=0;jj<inputsampledata_num;jj++)
//                             {
//                                 printf("%f ",inputsampledata[data_order][jj]);
//                             }
//                             printf("###\n");
                            low1_filter(FirstInitValue+data_order, inputsampledata[data_order], inputsampledata_num, webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLPF.FirstTimeValue,data_order);
                        }
                        //&last_filter
                        else if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor == 3)
                        {
//                             printf("ALimitMaxVarValue = %f  ALimitMaxVarCnt =%d ALimitValidValue =%f data_order = %d\n",webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitMaxVarValue,webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitMaxVarCnt,ALimitValidValue[data_order],data_order);
//                             printf("data_id = %d dev_code = %d \n",data->data_id,data->dev_code);
//                             for(jj=data_order*sampledata_inputhisdate_total;jj<data_order*sampledata_inputhisdate_total+sampledata_inputhisdate_total;jj++)
//                             {
//                                 printf("%f ",inputhisdate1[jj]);
//                             }
//                             printf("###\n");
//                             printf("inputhisdate1[data_order*sampledata_inputhisdate_total+inputhisdate_num-1] =%f\n",inputhisdate1[data_order*sampledata_inputhisdate_total+inputhisdate_num-1]);
                            LG_filter(inputhisdate1+data_order*sampledata_inputhisdate_total, inputsampledata[data_order], inputhisdate_num, inputsampledata_num, webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitMaxVarValue, webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].ALOGR_PARAM_U.stLimit.ALimitMaxVarCnt,ALimitValidValue+data_order,data_order);
                        }
                        else if(webin_dataprocessor[dataprocessinghandle.pRec[data_order].dwParamId].FilterAlgor == 0)
                        {

                        }
                    dataprocessinghandle.pRec[data_order].offset = 0;
                    }
                    memcpy(transmit_inputsampledata[data_order],inputsampledata[data_order],sizeof(float)*inputsampledata_num);
//                     printf("transmit_dataid  =%d transmit_devcode = %d transmit_index =%d\n",transmit_dataid,transmit_devcode,transmit_index);


                        POINT_T tmpPoint;
                        tmpPoint.iPointId = transmit_dataid;
                        tmpPoint.dPointValue = pout->outpara[data_order].data.s32;
                        tmpPoint.ucDataType = FLOAT_T;
                        tmpPoint.unDataValue.f32 = pout->outpara[data_order].data.s32;
                        //                 printf("tmpPoint.dPointValue  = %f tmpPoint.iPointId =%d\n",tmpPoint.dPointValue,tmpPoint.iPointId);
                        ShareRTDB_Update(2304, 1,
                        &tmpPoint, 1
                        );
            }
        }
        break;
    default:
        break;
    }
    return 0;
}

int32_t eFmc_Fault(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{
        printf("%s (L%d)\n", __func__, __LINE__);
//      printf("eFmc_Fault enter\n");
     int32_t ret = OK;
     int32_t length = 0;
     FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
     char timedata[50] = {0};
     uint16_t data_order = 0;
     uint32_t num = pin->in_argc;
     DEV_INFO_T *tmp_info = calloc(num, sizeof(DEV_INFO_T));
     time_t now;
     struct tm *timenow;
     struct timeval t1;
     uint16_t i =0 ;
     PERSIST_NODE_INFO_T *Fault  = malloc(sizeof(PERSIST_NODE_INFO_T) * num);
     rtfault_t *Real_time_Fault = calloc(num, sizeof(rtfault_t));
    for(i = 0; i < num; i++)
    {
        if((data->dev_code ==pin->inpara[i].dev_code)&&(data->index == pin->inpara->index)&&(data->data_id == pin->inpara[i].data_id))
        {
            DEV_UID_T pN = {data->dev_code, data->index};
            DEV_UID_T pS;
            ret = N2SDev_GetValue(&pN, &pS);

            SDB_GetDevInfoByCode(&tmp_info[i], pS.devCode, pS.devIndex);//????????
            data_order = i;
        }
    }
        DEV_INFO_EXT_T *dev_info = NULL;
//         DEV_INFO_EXT_T *dev_info_1 = (DEV_INFO_EXT_T*)malloc(sizeof(DEV_INFO_EXT_T));
        dev_info = SDB_ND_Get(data->dev_code,data->index);
//         memcpy(dev_info_1, dev_info, sizeof(DEV_INFO_EXT_T)*ND_num);

//         printf("tmp_info[data_order].cslave_id = %d data_order =%d\n",tmp_info[data_order].cslave_id,data_order);
        Fault[data_order].uiDevID = tmp_info[data_order].cslave_id;
        strcpy( Fault[data_order].arrcDevName,tmp_info[data_order].dev_name);
        printf("fault_handle.pRec[%d].data_id= %d data->dev_code =%d\n",data_order,fault_handle.pRec[data_order].data_id,data->dev_code);
        if((data->dev_code >= INV_START_NUM)&&(data->dev_code <= INV_START_NUM + INV_DEV_MAX_NUM))//光伏
        {
//             printf("data->dev_code =%d data->index = %d data->data_id =%d data->value.data.u32 =%d",data->dev_code,data->index,data->data_id,data->value.data.u32);
            if(fault_handle.pRec[data_order].data_id == 0)
            {

                switch(data->value.data.u32)
                {
                    case 002 :

                        printf("电网电压高于设定的保护值\n");
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "电网电压高于设定的保护值";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电网电压高于设定的保护值");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 003:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "一定时间内电网电压高于设定的保护值";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"一定时间内电网电压高于设定的保护值");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 004:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "电网电压低于设定的保护值";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电网电压低于设定的保护值");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 005:
                        printf("逆变器检测到电网电压过低\n");
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变器检测到电网电压过低";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器检测到电网电压过低");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 006:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流输出电流超过逆变器允许上限";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流输出电流超过逆变器允许上限");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 007:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变器检测到交流瞬时过流";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器检测到交流瞬时过流");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 8:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "电网频率超过逆变器允许上限";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电网频率超过逆变器允许上限");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 9:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "电网频率超过逆变器允许下限";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电网频率超过逆变器允许下限");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 10:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "孤岛";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"孤岛");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 11:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流电流直流分量超过逆变器设定保护范围";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流电流直流分量超过逆变器设定保护范围");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 12:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变器检测到漏电流超过设定保护范围";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器检测到漏电流超过设定保护范围");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 14:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "平均电网电压超出允许范围10 分钟";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"平均电网电压超出允许范围10");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 15:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "电网电压超过逆变器允许范围";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电网电压超过逆变器允许范围");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 16:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变器负载过大";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器负载过大");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 28:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "PV1正负端是否接反";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"PV1正负端是否接反");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 29:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "PV2正负端是否接反";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"PV2正负端是否接反");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 100:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流输出电流超过逆变器允许上限";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流输出电流超过逆变器允许上限");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 101:
                        Fault[data_order].FAULT_INFO_T.pcFaultType= "电气";
                        Fault[data_order].pcDescription = "电网频率超过逆变器允许上限";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电网频率超过逆变器允许上限");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 102:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "电网频率低于逆变器允许下限";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电网频率低于逆变器允许下限");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 106:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变器没有接地线";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器没有接地线");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 19:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "母线瞬时电压超过设定值";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"母线瞬时电压超过设定值");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 20:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "母线电压过高";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"母线电压过高");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 21:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变器检测到PV输入过流";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器检测到PV输入过流");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 22:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变器检测到PV2输入过流";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器检测到PV2输入过流");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 36:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "散热器温度过高";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"散热器温度过高");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 37:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "逆变器内部温度过高";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器内部温度过高");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 39:
                        Fault[data_order].FAULT_INFO_T.pcFaultType= "电气";
                        Fault[data_order].pcDescription = "逆变器对地绝缘阻抗偏低低";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器对地绝缘阻抗偏低低");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 38:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "继电器故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"继电器故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 41:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "漏电流自检异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"漏电流自检异常");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 43:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "环境温度低";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"环境温度低");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 44:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变开环自检故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变开环自检故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 45:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "PV1升压电路故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"PV1升压电路故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 46:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "PV2升压电路故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"PV2升压电路故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 48:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流电流采样通道异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流电流采样通道异常");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 53:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "辅助DSP电网电压超出设定的保护值";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"辅助DSP电网电压超出设定的保护值");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 54:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "辅助DSP检测电网频率超出设定的保护值";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"辅助DSP检测电网频率超出设定的保护值");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 56:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变器辅助DSP检测到漏电流超过设定保护范围";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器辅助DSP检测到漏电流超过设定保护范围");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 59:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "主辅DSP通讯异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"主辅DSP通讯异常");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 61:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "机型未设定";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"机型未设定");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 70:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "风扇异常,";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"风扇异常");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 84:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "电表反接告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电表反接告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 85:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "软件版本不匹配故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"软件版本不匹配故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 87:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "拉弧自检异常告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"拉弧自检异常告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 88:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "拉弧异常告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"拉弧异常告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 89:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "拉弧检测关闭告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"拉弧检测关闭告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 92:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "并网箱防雷失效告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"并网箱防雷失效告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 93:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "并网箱开关跳闸告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"并网箱开关跳闸告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 200:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "母线电压过高";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"母线电压过高");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 202:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "PV电流过流";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"PV电流过流");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 201:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "母线电压过低";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"母线电压过低");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 203:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "逆变器电压采样异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变器电压采样异常");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 306:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "输入输出不匹配故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"输入输出不匹配故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 315:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "PV1电流采样通道故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"PV1电流采样通道故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 316:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "PV2电流采样通道故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"PV2电流采样通道故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 320:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "漏电流CT自检故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"漏电流CT自检故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 409:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "环境高温传感器及逆变温度传感器一起故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"环境高温传感器及逆变温度传感器一起故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 501:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "FRAM读取告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"FRAM读取告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 503:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "环境温度传感器开路告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"环境温度传感器开路告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 504:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "环境温度传感器短路告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"环境温度传感器短路告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 505:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "逆变温度传感器开路告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变温度传感器开路告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 506:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "逆变温度传感器短路告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"逆变温度传感器短路告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    case 514:
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "通讯";
                        Fault[data_order].pcDescription = "电表通讯异常告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电表通讯异常告警");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                        break;
                    default:
                        break;
                }

            }

        }
        else if((data->dev_code>=STORAGE_CONVERTER_START_NUM)&&(data->dev_code<=STORAGE_CONVERTER_START_NUM+STORAGE_CONVERTER_DEV_MAX_NUM))
        {
            printf("@fault_handle.pRec[%d].data_id= %d data->dev_code =%d data->value.data.u32 =%d\n",data_order,fault_handle.pRec[data_order].data_id,data->dev_code,data->value.data.u32);
            switch(fault_handle.pRec[data_order].data_id )
            {
                case 1 :
                    if((data->value.data.u32)&1)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "直流欠压";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"直流欠压");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&2)
                    {
                        printf("直流过压\n");
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "直流过压";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"直流过压");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&4)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流欠压";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流欠压");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&8)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流过压";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流过压");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&16)
                    {
                        printf("交流欠频\n");
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流欠频";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流欠频");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
//                         printf("jiaoliuqianpin");
                    }
                    else if((data->value.data.u32)&32)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType= "电气";
                        Fault[data_order].pcDescription = "交流过频";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流过频");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));

                    }
                    else if((data->value.data.u32)&64)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "交流接触器故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流接触器故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&128)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType= "电气";
                        Fault[data_order].pcDescription = "孤岛保护";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"孤岛保护");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&512)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "PDP保护";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"PDP保护");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&1024)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "模块过温";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"模块过温");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&2048)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "电抗器过温";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电抗器过温");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&4096)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "变压器过温";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"变压器过温");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&8192)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "漏电流保护";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"漏电流保护");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&32768)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "过载保护";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"过载保护");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&131072)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "风机故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"风机故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&262144)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "直流熔断器故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"直流熔断器故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&1048576)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "直流过流";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"直流过流");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&2097152)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流过流";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流过流");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&8388608)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "环温异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"环温异常");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&16777216)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "硬件故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"硬件故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    break;
                case 2 :
                    if((data->value.data.u32)&0x0001)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "绝缘阻抗";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"绝缘阻抗");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&0x0010)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流防雷器故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流防雷器故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&0x0100)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "采样故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"采样故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&0x1000)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "电池极性反接";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电池极性反接");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&32)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "计量板通迅异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"计量板通迅异常");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&64)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流电流不平衡";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流电流不平衡");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&128)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType= "器件";
                        Fault[data_order].pcDescription = "主机故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"主机故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&256)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "直流防雷器故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"直流防雷器故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&512)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "直流软启故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"直流软启故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&1024)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "直流分量故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"直流分量故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&2048)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "直流开关故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"直流开关故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&4096)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "机器码重复故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"机器码重复故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&8192)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "并机通讯故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"并机通讯故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&16384)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault->pcDescription = "控制柜温度故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"控制柜温度故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&65536)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "交流电压不平衡";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流电压不平衡");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&131072)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "电池通信故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"电池通信故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&262144)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "BMS电池故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"BMS电池故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&524288)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流开关故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流开关故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&1048576)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "交流软启故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流软启故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&2097152)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "直流电压采样故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"直流电压采样故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&8388608)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "交流电流不平衡2";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流电流不平衡2");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&16777216)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "交流电流不平衡3";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"交流电流不平衡3");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&33554432)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "电气";
                        Fault[data_order].pcDescription = "驱动板故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"驱动板故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&67108864)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "环境";
                        Fault[data_order].pcDescription = "中点电位偏移";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"中点电位偏移");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    else if((data->value.data.u32)&134217728)
                    {
                        Fault[data_order].FAULT_INFO_T.pcFaultType = "器件";
                        Fault[data_order].pcDescription = "载波同步故障";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
//                         gettimeofday(&t1, NULL);
                        strcpy( Fault[data_order].date,timedata);
                        strcpy( Real_time_Fault[data_order].time,timedata);
                        strcpy(Real_time_Fault[data_order].fw,"故障");
                        strcpy(Real_time_Fault[data_order].type ,"电气");
                        strcpy(Real_time_Fault[data_order].des,"载波同步故障");
                        Real_time_Fault[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_FAULT,&Fault[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_Fault[data_order], sizeof(Real_time_Fault[data_order]));
                    }
                    break;
                default:
                        break;
            }
            if(fault_handle.pRec[data_order].data_id == 1 && data->dev_code == 2849)//目前限定一个设备
            {
                //DO1
                printf("enter!!!!!!!!!!!!!!!!!!!!!!!\n");
                printf("%d %d %d\n", save_io[0].ID, save_io[0].DIEnable, save_io[0].DIFunction);
                if(save_io[0].ID == 1 && save_io[0].DIEnable == 1 && save_io[0].DIFunction == 1)//使能为1
                {
                    if(((data->value.data.u32)&1) == 1)
                    {
                        printf("enter dido_1 test\n");

                        DiReadValue(1, &value);
                        printf("read ok!\n");
                        printf("value:%d\n", value);

                        statusDO1 = DoRead(1);
                        printf("before statusDO1 = %d\n", statusDO1);

                        //DO1拉低电平
                        DoWriteL(1);

                        //读取DO1状态
                        statusDO1 = DoRead(1);
                        printf("after statusDO1 = %d\n", statusDO1);
                    }
                    if(((data->value.data.u32)) == 0)
                    {
                        DoWriteH(1);
                        //读取DO1状态
                        statusDO1 = DoRead(1);
                        DiReadValue(1, &value);
                        printf("after value:%d\n", value);
                        printf("after statusDO1 = %d\n", statusDO1);
                    }
                }

                //DO2
                if(save_io[1].ID == 2 && save_io[1].DIEnable == 1 && save_io[1].DIFunction == 1)//使能为1
                {
                    if(((data->value.data.u32)&2) == 2)
                    {
                        printf("enter dido_2 test\n");

                        DiReadValue(2, &value);
                        printf("read ok!\n");
                        printf("value:%d\n", value);

                        statusDO2 = DoRead(2);
                        printf("before statusDO1 = %d\n", statusDO2);

                        //DO1拉低电平
                        DoWriteL(2);

                        //读取DO1状态
                        statusDO1 = DoRead(2);
                        printf("after statusDO2 = %d\n", statusDO2);
                    }
                    if(((data->value.data.u32)) == 256)
                    {
                        DoWriteH(2);
                        //读取DO1状态
                        statusDO2 = DoRead(2);
                        DiReadValue(2, &value);
                        printf("after value:%d\n", value);
                        printf("after statusDO2 = %d\n", statusDO2);
                    }
                }

                //DO3
                if(save_io[2].ID == 3 && save_io[2].DIEnable == 1 && save_io[2].DIFunction == 1)//使能为1
                {
                    if(((data->value.data.u32)&4) == 4)
                    {
                        printf("enter dido_3 test\n");

                        DiReadValue(3, &value);
                        printf("read ok!\n");
                        printf("value:%d\n", value);

                        statusDO3 = DoRead(3);
                        printf("before statusDO3 = %d\n", statusDO3);

                        //DO1拉低电平
                        DoWriteL(3);

                        //读取DO1状态
                        statusDO1 = DoRead(3);
                        printf("after statusDO3 = %d\n", statusDO3);
                    }
                    if(((data->value.data.u32)) == 512)
                    {
                        DoWriteH(3);
                        //读取DO1状态
                        statusDO3 = DoRead(3);
                        printf("after statusDO3 = %d\n", statusDO3);
                    }
                }

                //DO4
                if(save_io[3].ID == 4 && save_io[3].DIEnable == 1 && save_io[3].DIFunction == 1)//使能为1
                {
                    if(((data->value.data.u32)&8) == 8)
                    {
                        printf("enter dido_4 test\n");

                        DiReadValue(4, &value);
                        printf("read ok!\n");
                        printf("value:%d\n", value);

                        statusDO4 = DoRead(4);
                        printf("before statusDO4 = %d\n", statusDO4);

                        //DO1拉低电平
                        DoWriteL(4);

                        //读取DO1状态
                        statusDO4 = DoRead(4);
                        printf("after statusDO4 = %d\n", statusDO4);
                    }
                    if(((data->value.data.u32)) == 1024)
                    {
                        DoWriteH(4);
                        //读取DO1状态
                        statusDO4 = DoRead(4);
                        printf("after statusDO4 = %d\n", statusDO4);
                    }
                }

                //DO5
                if(save_io[4].ID == 5 && save_io[4].DIEnable == 1 && save_io[4].DIFunction == 1)//使能为1
                {
                    if(((data->value.data.u32)&16) == 16)
                    {
                        printf("enter dido_5 test\n");

                        DiReadValue(5, &value);
                        printf("read ok!\n");
                        printf("value:%d\n", value);

                        statusDO5 = DoRead(5);
                        printf("before statusDO5 = %d\n", statusDO5);

                        //DO1拉低电平
                        DoWriteL(5);

                        //读取DO1状态
                        statusDO5 = DoRead(5);
                        printf("after statusDO5 = %d\n", statusDO5);
                    }
                    if(((data->value.data.u32)) == 2048)
                    {
                        DoWriteH(5);
                        //读取DO1状态
                        statusDO5 = DoRead(5);
                        printf("after statusDO5 = %d\n", statusDO5);
                    }
                }


                //DO6
                if(save_io[5].ID == 6 && save_io[5].DIEnable == 1 && save_io[5].DIFunction == 1)//使能为1
                {
                    if(((data->value.data.u32)&32) == 32)
                    {
                        printf("enter dido_6 test\n");

                        DiReadValue(6, &value);
                        printf("read ok!\n");
                        printf("value:%d\n", value);

                        statusDO6 = DoRead(6);
                        printf("before statusDO6 = %d\n", statusDO6);

                        //DO1拉低电平
                        DoWriteL(6);

                        //读取DO1状态
                        statusDO6 = DoRead(6);
                        printf("after statusDO6 = %d\n", statusDO6);
                    }
                    if(((data->value.data.u32)) == 4096)
                    {
                        DoWriteH(6);
                        //读取DO1状态
                        statusDO6 = DoRead(6);
                        printf("after statusDO6 = %d\n", statusDO6);
                    }
                }

                //DO7
                if(save_io[6].ID == 7 && save_io[6].DIEnable == 1 && save_io[6].DIFunction == 1)//使能为1
                {
                    if(((data->value.data.u32)&64) == 64)
                    {
                        printf("enter dido_7 test\n");

                        DiReadValue(7, &value);
                        printf("read ok!\n");
                        printf("value:%d\n", value);

                        statusDO7 = DoRead(7);
                        printf("before statusDO7 = %d\n", statusDO7);

                        //DO1拉低电平
                        DoWriteL(7);

                        //读取DO1状态
                        statusDO7 = DoRead(7);
                        printf("after statusDO7 = %d\n", statusDO7);
                    }
                    if(((data->value.data.u32)) == 8192)
                    {
                        DoWriteH(7);
                        //读取DO1状态
                        statusDO7 = DoRead(7);
                        printf("after statusDO7 = %d\n", statusDO7);
                    }
                }

                //DO8
                if(save_io[7].ID == 8 && save_io[7].DIEnable == 1 && save_io[7].DIFunction == 1)//使能为1
                {
                    if(((data->value.data.u32)&128) == 128)
                    {
                        printf("enter dido_8 test\n");

                        DiReadValue(8, &value);
                        printf("read ok!\n");
                        printf("value:%d\n", value);

                        statusDO8 = DoRead(8);
                        printf("before statusDO8 = %d\n", statusDO8);

                        //DO1拉低电平
                        DoWriteL(8);

                        //读取DO1状态
                        statusDO8 = DoRead(8);
                        printf("after statusDO8 = %d\n", statusDO8);
                    }
                    if(((data->value.data.u32)) == 16384)
                    {
                        DoWriteH(8);
                        //读取DO1状态
                        statusDO8 = DoRead(8);
                        printf("after statusDO8 = %d\n", statusDO8);
                    }
                }

            }

        }

     free(tmp_info);

     free(Fault);

//      free(Real_time_Fault);
//      free(dev_info_1);
     return 1;
}
int32_t eFmc_Warning(void *in, void *out, DEV_DATA_T *data, DATA_U *old)
{
        printf("%s (L%d)\n", __func__, __LINE__);
     FUNC_INPARA_T *pin = (FUNC_INPARA_T *)in;
     char timedata[30] = {0};
     uint32_t num = pin->in_argc;
     uint16_t data_order = 0,ret =0;
     DEV_INFO_T *tmp_info = malloc(sizeof(DEV_INFO_T) * num);
     time_t now;
     struct tm *timenow;
     uint16_t i =0 ;
     PERSIST_NODE_INFO_T *Warning = malloc(sizeof(PERSIST_NODE_INFO_T) * num);
     rtfault_t *Real_time_warning = calloc(num, sizeof(rtfault_t));
     DEV_INFO_EXT_T *dev_info = NULL;
     dev_info = SDB_ND_Get(data->dev_code,data->index);
//      warning_yuzhi->stProtectCell.OVL1 =10;
//      warning_yuzhi->stProtectCell.OVL2 =20;
//      warning_yuzhi->stProtectCell.OVL3 =30;
//      PROTECTSTORAGE_T    *grade = malloc(sizeof(PROTECTSTORAGE_T) * num);
     for(i = 0; i < num; i++)
     {
        if((data->dev_code ==pin->inpara[i].dev_code)&& (data->index == pin->inpara->index)&&(data->data_id == pin->inpara[i].data_id))
        {
            DEV_UID_T pN = {data->dev_code, data->index};
            DEV_UID_T pS;
            ret = N2SDev_GetValue(&pN, &pS);

            SDB_GetDevInfoByCode(&tmp_info[i], pS.devCode, pS.devIndex);//????????
            data_order = i;

        }
     }
    printf("data_order = %d\n",data_order);
     if((data->dev_code ==pin->inpara[data_order].dev_code)|| (data->index == pin->inpara[data_order].index||(data->data_id == pin->inpara[data_order].data_id)))
     {
        Warning[data_order].uiDevID = tmp_info[data_order].cslave_id;
        strcpy( Warning[data_order].arrcDevName,tmp_info[data_order].dev_name);
        if((data->dev_code >= INV_START_NUM)&&(data->dev_code <= INV_START_NUM + INV_DEV_MAX_NUM))
        {

        }
        else if((data->dev_code>=STORAGE_CONVERTER_START_NUM)&&(data->dev_code<=STORAGE_CONVERTER_START_NUM+STORAGE_CONVERTER_DEV_MAX_NUM))
        {
            printf("warning_handle.pRec[data_order].data_id = %d \n",warning_handle.pRec[data_order].data_id);
            if(warning_handle.pRec[data_order].data_id  == 0)
            {
                printf("data->value.data.u32 =%d  data_order = %d data->dev_code  =%d\n",data->value.data.u32,data_order,data->dev_code);
                switch(data->value.data.u32)
                {
                    case 1:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "温度异常告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"温度异常告警");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    case 4:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "GFRT运行";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"GFRT运行");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    case 16:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "直流熔丝异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"直流熔丝异常");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    case 32:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "BMS电池告警";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"BMS电池告警");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    case 64:
                            Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                            Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                            Warning[data_order].pcDescription = "直流传感器异常";
                            time(&now);
                            strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                            strcpy( Warning[data_order].date,timedata);
                            strcpy( Real_time_warning[data_order].time,timedata);
                            strcpy(Real_time_warning[data_order].fw,"告警");
                            strcpy(Real_time_warning[data_order].type ,"电气");
                            strcpy(Real_time_warning[data_order].des,"直流传感器异常");
                            Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                            Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                            Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    case 512:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "充电条件不满足";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"充电条件不满足");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    case 1024:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "放电条件不满足";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"放电条件不满足");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    case 4096:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "直流开关异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"直流开关异常");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    case 8192:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "风机异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"风机异常");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    default:
                        break;
                }

            }
            else if(warning_handle.pRec[data_order].data_id  == 1)
            {
                printf("data->value.data.u32 =%d  data_order = %d data->dev_code =%d\n",data->value.data.u32,data_order,data->dev_code);
                switch(data->value.data.u32)
                {

                    case 1:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "支路板通讯异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"支路板通讯异常");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    case 2:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "交流开关异常";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"交流开关异常");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        printf("交流开关异常");
                        break;
                    case 10:
                        Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                        Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                        Warning[data_order].pcDescription = "交流主接触器异";
                        time(&now);
                        strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                        strcpy( Warning[data_order].date,timedata);
                        strcpy( Real_time_warning[data_order].time,timedata);
                        strcpy(Real_time_warning[data_order].fw,"告警");
                        strcpy(Real_time_warning[data_order].type ,"电气");
                        strcpy(Real_time_warning[data_order].des,"交流主接触器异");
                        Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                        Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                        Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                        break;
                    default:
                        break;
                }
            }
            else if(warning_handle.pRec[data_order].data_id== 2)
            {

                printf("warning_handle.pRec[data_order].data_id= %d warning_yuzhi->stProtectCell.OVL1 =%f warning_yuzhi->stProtectCell.OVL2 =%f\n",warning_handle.pRec[data_order].data_id,warning_yuzhi->stProtectCell.OVL1 ,warning_yuzhi->stProtectCell.OVL2);
                printf("data->value.data.u32= %d warning_yuzhi->stProtectCell.OVL3 =%f\n",data->value.data.u32,warning_yuzhi->stProtectCell.OVL3);
                if(data->value.data.u32<warning_yuzhi->stProtectCell.UVL3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "单体欠压3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体欠压3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体欠压3级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectCell.UVL3)&&(data->value.data.u32<=warning_yuzhi->stProtectCell.UVL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "单体欠压2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体欠压2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体欠压2级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectCell.UVL2)&&(data->value.data.u32<=warning_yuzhi->stProtectCell.UVL1))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "单体欠压1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体欠压1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体欠压1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectCell.OVL1)&&(data->value.data.u32<=warning_yuzhi->stProtectCell.OVL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "单体过压1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体过压1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体过压1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectCell.OVL2)&&(data->value.data.u32<=warning_yuzhi->stProtectCell.OVL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "单体过压2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体过压2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体过压2级阈值\n");
                }
                else if(data->value.data.u32>warning_yuzhi->stProtectCell.OVL3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "单体过压3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体过压3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体过压3级阈值\n");
                }
            }
            else if(warning_handle.pRec[data_order].data_id== 3)
            {

                printf("warning_handle.pRec[data_order].data_id= %d\n",warning_handle.pRec[data_order].data_id);
                printf("data->value.data.u32= %d \n",data->value.data.u32);
                if(data->value.data.u32<warning_yuzhi->stProtectCell.LTL3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "单体低温3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体低温3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体低温3级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectCell.LTL3)&&(data->value.data.u32<=warning_yuzhi->stProtectCell.LTL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "单体低温2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体低温2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体低温2级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectCell.LTL2)&&(data->value.data.u32<=warning_yuzhi->stProtectCell.LTL1))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "单体低温1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体低温1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体低温1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectCell.OTL1)&&(data->value.data.u32<=warning_yuzhi->stProtectCell.OTL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "单体高温1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体高温1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体高温1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectCell.OTL2)&&(data->value.data.u32<=warning_yuzhi->stProtectCell.OTL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "单体高温2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体高温2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体高温2级阈值\n");
                }
                else if(data->value.data.u32>warning_yuzhi->stProtectCell.OTL3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "单体高温3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体高温3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("单体高温3级阈值\n");
                }
            }
            else if(warning_handle.pRec[data_order].data_id== 4)
            {

                printf("warning_handle.pRec[data_order].data_id= %d\n",warning_handle.pRec[data_order].data_id);
                printf("data->value.data.u32= %d \n",data->value.data.u32);
                if(data->value.data.u32<warning_yuzhi->stProtectPack.PackUV3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "Pack欠压3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Pack欠压3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Pack欠压3级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectPack.PackUV3)&&(data->value.data.u32<=warning_yuzhi->stProtectPack.PackUV2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "Pack欠压2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Pack欠压2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Pack欠压2级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectPack.PackOV2)&&(data->value.data.u32<=warning_yuzhi->stProtectPack.PackOV3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "Pack欠压1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Pack欠压1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Pack欠压1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectPack.PackUV1)&&(data->value.data.u32<=warning_yuzhi->stProtectPack.PackUV2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "Pack过压1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Pack过压1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Pack过压1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectPack.PackUV2)&&(data->value.data.u32<=warning_yuzhi->stProtectPack.PackUV3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "Pack过压2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Pack过压2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Pack过压2级阈值\n");
                }
                else if(data->value.data.u32>warning_yuzhi->stProtectPack.PackUV3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "Pack过压3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"单体高温3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Pack过压3级阈值\n");
                }
            }
            else if(warning_handle.pRec[data_order].data_id== 5)
            {

                printf("warning_handle.pRec[data_order].data_id= %d\n",warning_handle.pRec[data_order].data_id);
                printf("data->value.data.u32= %d \n",data->value.data.u32);
                if(data->value.data.u32<warning_yuzhi->stProtectRack.stRackSOC.SocDownL3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "RackSOC下限3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"RackSOC下限3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("RackSOC下限3级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackSOC.SocDownL3)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackSOC.SocDownL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "RackSOC下限2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"RackSOC下限2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("RackSOC下限2级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackSOC.SocDownL2)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackSOC.SocDownL1))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "RackSOC下限1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"RackSOC下限1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("RackSOC下限1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackSOC.SocUpL1)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackSOC.SocUpL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "RackSOC上限1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"RackSOC上限1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("RackSOC上限1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackSOC.SocUpL2)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackSOC.SocUpL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "RackSOC上限2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"RackSOC上限2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("RackSOC上限2级阈值\n");
                }
                else if(data->value.data.u32>warning_yuzhi->stProtectRack.stRackSOC.SocUpL3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "RackSOC上限3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"RackSOC上限3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("RackSOC上限3级阈值\n");
                }
            }
            else if(warning_handle.pRec[data_order].data_id== 6)
            {

                printf("warning_handle.pRec[data_order].data_id= %d\n",warning_handle.pRec[data_order].data_id);
                printf("data->value.data.u32= %d \n",data->value.data.u32);
                if(data->value.data.u32<warning_yuzhi->stProtectRack.stRackSOH.SohDownL3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "RackSOH低下限3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"RackSOH低下限3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("RackSOH低下限3级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackSOH.SohDownL2)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackSOH.SohDownL1))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "RackSOH低下限2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"RackSOH低下限2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("RackSOH低下限2级阈值\n");
                }
                else if(data->value.data.u32>warning_yuzhi->stProtectRack.stRackSOC.SocDownL1)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "RackSOH低下限1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"RackSOH低下限1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("RackSOH低下限1级阈值\n");
                }
            }
            else if(warning_handle.pRec[data_order].data_id== 7)
            {

                printf("warning_handle.pRec[data_order].data_id= %d\n",warning_handle.pRec[data_order].data_id);
                printf("data->value.data.u32= %d \n",data->value.data.u32);
                if(data->value.data.u32<warning_yuzhi->stProtectRack.stRackV.RackVDownL3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "Rack电压下限3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack电压下限3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack电压下限3级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackV.RackVDownL3)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackV.RackVDownL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "Rack电压下限2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack电压下限2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack电压下限2级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackV.RackVDownL2)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackV.RackVDownL1))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "Rack电压下限1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack电压下限1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack电压下限1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackV.RackParUpL1)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackV.RackParUpL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "Rack电压上限1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack电压上限1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack电压上限1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackV.RackParUpL2)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackV.RackParUpL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "Rack电压上限2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack电压上限2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack电压上限2级阈值\n");
                }
                else if(data->value.data.u32>warning_yuzhi->stProtectRack.stRackV.RackParUpL3)
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "Rack电压上限3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack电压上限3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack电压上限3级阈值\n");
                }
            }
            else if(warning_handle.pRec[data_order].data_id== 8)
            {

                printf("warning_handle.pRec[data_order].data_id= %d\n",warning_handle.pRec[data_order].data_id);
                printf("data->value.data.u32= %d \n",data->value.data.u32);
                if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackV.RackParUpL1)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackV.RackParUpL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "Rack压参上限1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack压参上限1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack压参上限1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackV.RackParUpL2)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackV.RackParUpL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "Rack压参上限2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack压参上限2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack压参上限2级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackV.RackParUpL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "Rack压参上限3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack压参上限3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack压参上限3级阈值\n");
                }
            }
            else if(warning_handle.pRec[data_order].data_id== 9)
            {

                printf("warning_handle.pRec[data_order].data_id= %d\n",warning_handle.pRec[data_order].data_id);
                printf("data->value.data.u32= %d \n",data->value.data.u32);
                if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackA.RackOCL1)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackA.RackOCL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "Rack过流上限1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack过流上限1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack过流上限1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackA.RackOCL2)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackA.RackOCL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "Rack过流上限2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack过流上限2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack过流上限2级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackA.RackOCL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "Rack过流上限3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack过流上限3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack过流上限3级阈值\n");
                }
            }
            else if(warning_handle.pRec[data_order].data_id== 10)
            {

                printf("warning_handle.pRec[data_order].data_id= %d\n",warning_handle.pRec[data_order].data_id);
                printf("data->value.data.u32= %d \n",data->value.data.u32);
                if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackA.RackCurL1)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackA.RackCurL2))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 3;
                    Warning[data_order].pcDescription = "Rack环流大上限1级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack环流大上限1级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack环流大上限1级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackA.RackCurL2)&&(data->value.data.u32<=warning_yuzhi->stProtectRack.stRackA.RackCurL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 2;
                    Warning[data_order].pcDescription = "Rack环流大上限2级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack环流大上限2级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack环流大上限2级阈值\n");
                }
                else if((data->value.data.u32>warning_yuzhi->stProtectRack.stRackA.RackCurL3))
                {
                    Warning[data_order].WARNING_INFO_T.pcWarnType = "电气";
                    Warning[data_order].WARNING_INFO_T.uiWarnLevel = 1;
                    Warning[data_order].pcDescription = "Rack环流大上限3级阈值";
                    time(&now);
                    strftime(timedata, sizeof(timedata), "%Y-%m-%d %H:%M:%S", localtime(&now));
                    strcpy( Warning[data_order].date,timedata);
                    strcpy( Real_time_warning[data_order].time,timedata);
                    strcpy(Real_time_warning[data_order].fw,"告警");
                    strcpy(Real_time_warning[data_order].type ,"电气");
                    strcpy(Real_time_warning[data_order].des,"Rack环流大上限3级阈值");
                    Real_time_warning[data_order].devNo =  dev_info->stDevUID.dbUID;
                    Persister_StoreNode(HIS_RECORD_WARNING,&Warning[data_order]);
                    Processor_SendMsg(MSG_IPC_RT_FAULT_WARNING, &Real_time_warning[data_order], sizeof(Real_time_warning[data_order]));
                    printf("Rack环流大上限3级阈值\n");
                }
            }

        }
     }
     free(tmp_info);
     free(Warning);
     return 1;

}
// static int32_t si_set(int32_t dwType, void *pvData, int32_t dwDataLen)
// {
//     int32_t ret = OK;
//     int32_t data_id = 0;
//     int32_t ND_num = 0;
//     int16_t i =0,ii=0,j= 0,k = 0;
//     int16_t uart_enabe_num = 0;
//     char dataprocessor_dataname[50][20] = {{"总直流功率"},{"总有功功率"},{"有功功率"}};
//     char fault_dataname[10][20] = {{"状态数据1"},{"故障状态1"},{"故障状态2"}};
//     char warning_dataname[10][20] = {{"告警状态1"},{"告警状态2"},{"单体电压"}};
//
//
//     int16_t data_num = 0,guangfu_dev_num = 0,chuneng_dev_num = 0;
// //     int16_t data_num_fault = 0,guangfu_dev_num_fault = 0,chuneng_dev_num_fault = 0;
// //     int16_t data_num_warning = 0,guangfu_dev_num_warning = 0,chuneng_dev_num_warning = 0;
//
//
//
//
//
//     pin_processor = malloc(sizeof(FUNC_INPARA_T)*1);
//     pin_processor->inpara = malloc(sizeof(FUNC_PARA_T)*50);
// //     FUNC_INPARA_T *pin_fault = malloc(sizeof(FUNC_INPARA_T)*1);
// //     pin_fault->inpara = malloc(sizeof(FUNC_PARA_T)*10);
// //     FUNC_INPARA_T *pin_warning = malloc(sizeof(FUNC_INPARA_T)*1);
// //     pin_warning->inpara = malloc(sizeof(FUNC_PARA_T)*10);
//
//     pout_processor = malloc(sizeof(FUNC_OUTPARA_T)*1);
//     pout_processor->outpara = malloc(sizeof(FUNC_PARA_T)*50);
// //     FUNC_OUTPARA_T *pout_fault = malloc(sizeof(FUNC_OUTPARA_T)*1);
// //     FUNC_OUTPARA_T *pout_warning = malloc(sizeof(FUNC_OUTPARA_T)*1);
//     ND_num = SDB_ND_GetNum();
//     DEV_INFO_EXT_T *dev_info = NULL;
//     DEV_INFO_EXT_T *dev_info_1 = malloc(sizeof(DEV_INFO_EXT_T)*ND_num);
//
//
//     dev_info = SDB_ND_GetList();
//
//     printf("devCode =%d\n",dev_info[1].stDevUID.devCode);
//
//     memcpy(dev_info_1, dev_info, sizeof(DEV_INFO_EXT_T)*ND_num);
//
//
//     if (dataprocessinghandle.pRec == NULL)
//     {
//         dataprocessinghandle.pRec = malloc(sizeof(RECORD_Q_T) * 50);
//         if (dataprocessinghandle.pRec == NULL)
//         {
//             return 0;
//         }
//         memset(dataprocessinghandle.pRec, 0, sizeof(RECORD_Q_T) * 50);
//     }
//     if (fault_handle.pRec == NULL)
//     {
//         fault_handle.pRec = malloc(sizeof(RECORD_Q_T) * 10);
//         if (fault_handle.pRec == NULL)
//         {
//             return 0;
//         }
//         memset(fault_handle.pRec, 0, sizeof(RECORD_Q_T) * 10);
//     }
// //     //1. 根据webin 串口号找设备，
// //     webin[i].UartNo
//
//     switch (dwType)
//     {
//         case MSG_IPC_ALGO_PARAM_UPDATE:
//         {
//             uart_enabe_num = dwDataLen/(sizeof(ALOGR_T));
//
//             printf("dwType:%x dwDataLen = %d\n", dwType, dwDataLen);
//             printf("uart_num = %d\n",uart_enabe_num);
//
//             webin_dataprocessor = malloc(sizeof(ALOGR_T) * uart_enabe_num);
//             memcpy(webin_dataprocessor, pvData, sizeof(ALOGR_T)*uart_enabe_num);
//
//             printf("ND_num = %d\n",ND_num);
//             printf("SampleNum = %d HistoryNum = %d AbnormalAlogr = %d UartNo = %d\n",webin_dataprocessor[0].SampleNum,webin_dataprocessor[0].HistoryNum,webin_dataprocessor[0].AbnormalAlgor,webin_dataprocessor[0].UartNo);
//
//             for(i = 0; i < ND_num;i++)
//             {
//                 if((dev_info_1[i].stDevUID.devCode >= INV_START_NUM)&&(dev_info_1[i].stDevUID.devCode <= INV_START_NUM + INV_DEV_MAX_NUM))
//                 {
//                     for(j = 0;j < guangfu_dataprocess_datanum;j++)
//                     {
//                         pin_processor->inpara[j+data_num].dev_code = dev_info_1[i].stDevUID.devCode;
//                         pin_processor->inpara[j+data_num].index  = 1;
//                         data_id= SDB_ND_GetDataId(pin_processor->inpara[j+data_num].dev_code,pin_processor->inpara[j+data_num].index,dataprocessor_dataname[j]);
//
//                         printf("pin_processor->inpara[j+data_num].data_id  =%d\n",data_id);
//
//                         for(ii = 0;ii<uart_enabe_num;ii++)
//                         {
//                             if(webin_dataprocessor[ii].UartNo == dev_info_1[i].dwCommId)
//                             {
//                                 dataprocessinghandle.pRec[j+data_num].dwParamId = ii;
//                             }
//
//                         }
//                         if(data_id == INVALID_VALUE)
//                         {
//                             k++;
//                         }
//                         else
//                         {
//                             pin_processor->inpara[j+data_num].data_id = data_id;
//                         }
//
//                     }
//                     guangfu_dev_num ++;
//
//                     printf("guangfu_dev_num  =%d\n",guangfu_dev_num);
//
//                 }
//                 else if((dev_info_1[i].stDevUID.devCode>=STORAGE_CONVERTER_START_NUM)&&(dev_info_1[i].stDevUID.devCode<=STORAGE_CONVERTER_START_NUM+STORAGE_CONVERTER_DEV_MAX_NUM))
//                 {
//                     for(j=0;j<chuneng_dataprocess_datanum;j++)
//                     {
//                         pin_processor->inpara[j+data_num].dev_code = dev_info_1[i].stDevUID.devCode;
//                         pin_processor->inpara[j+data_num].index  = 1;
//                         pin_processor->inpara[j+data_num].data_id = SDB_ND_GetDataId(pin_processor->inpara[j+data_num].dev_code,pin_processor->inpara[j+data_num].index,dataprocessor_dataname[j+guangfu_dataprocess_datanum]);
//                         for(ii = 0;ii<uart_enabe_num;ii++)
//                         {
//                            if(webin_dataprocessor[ii].UartNo == dev_info_1[i].dwCommId)
//                            {
//                                 dataprocessinghandle.pRec[j+data_num].dwParamId = ii;
//                            }
//
//                         }
//                         if(data_id == INVALID_VALUE)
//                         {
//                             k++;//本设备未获得测点id的数量
//                         }
//                         else
//                         {
//                             pin_processor->inpara[j+data_num].data_id = data_id;
//                         }
//
//                     }
//                     chuneng_dev_num ++;
//                 }
//                 data_num = guangfu_dev_num*guangfu_dataprocess_datanum+chuneng_dev_num*chuneng_dataprocess_datanum-k;
//                 k =0;
//             }
//             pin_processor->in_argc = data_num;
//
//             printf("data_num = %d\n",data_num);
//             printf("index = %d data_id = %d dev_code = %d\n",pin_processor[0].inpara[0].index,pin_processor[0].inpara[0].data_id,pin_processor[0].inpara[0].dev_code);
//
// //             ret = Processor_InsertDpFuncNorth(Data_porcessing, "Data_porcessing",pin_processor,pout_processor);
//
//             printf("ret = %d\n",ret);
//
// //             free(dev_info_1);
// //             free(pout_processor);
// //
// //             free(pin_processor);
//
// //             free(webin_dataprocessor);
//             break;
//         }
//         case MSG_IPC_PROTECT_STORAGE_PARAM_UPDATE:
//         {
//             break;
//         }
//         case MSG_IPC_PROTECT_NET_PARAM_UPDATE:
//         {
//             break;
//         }
//         case MSG_IPC_DEV_UPDATE:
//         {
//             /*****************fault******************/
// //             for(i = 0; i < ND_num;i++)
// //             {
// //                 if((dev_info_1[i].stDevUID.devCode >= INV_START_NUM)&&(dev_info_1[i].stDevUID.devCode <= INV_START_NUM + INV_DEV_MAX_NUM))
// //                 {
// //                     for(j = 0;j < guangfu_fault_datanum;j++)
// //                     {
// //                         pin_fault->inpara[j+data_num_fault].dev_code = dev_info_1[i].stDevUID.devCode;
// //                         pin_fault->inpara[j+data_num_fault].index  = dev_info_1[i].stDevUID.devIndex;
// //                         data_id= SDB_ND_GetDataId(pin_fault->inpara[j+data_num_fault].dev_code,pin_fault->inpara[j+data_num_fault].index,fault_dataname[j]);
// //
// //                         warning_handle.pRec[j+data_num_fault].data_id = j;
// //
// //                         if(data_id == INVALID_VALUE)
// //                         {
// //                             k++;
// //                         }
// //                         else
// //                         {
// //                             pin_fault->inpara[j+data_num_fault].data_id = data_id;
// //                         }
// //
// //                     }
// //                     guangfu_dev_num_fault ++;
// //                 }
// //                 else if((dev_info_1[i].stDevUID.devCode>=STORAGE_CONVERTER_START_NUM)&&(dev_info_1[i].stDevUID.devCode<=STORAGE_CONVERTER_START_NUM+STORAGE_CONVERTER_DEV_MAX_NUM))
// //                 {
// //                     for(j=0;j<chuneng_fault_datanum;j++)
// //                     {
// //                         pin_fault->inpara[j+data_num_fault].dev_code = dev_info_1[i].stDevUID.devCode;
// //                         pin_fault->inpara[j+data_num_fault].index  = dev_info_1[i].stDevUID.devIndex;
// //                         pin_fault->inpara[j+data_num_fault].data_id = SDB_ND_GetDataId(pin_fault->inpara[j+data_num_fault].dev_code,pin_processor->inpara[j+data_num_fault].index,fault_dataname[j+guangfu_fault_datanum]);
// //
// //                         warning_handle.pRec[j+data_num_fault].data_id = j+guangfu_fault_datanum;
// //
// //                         if(data_id == INVALID_VALUE)
// //                         {
// //                             k++;//本设备未获得测点id的数量
// //                         }
// //                         else
// //                         {
// //                             pin_fault->inpara[j+data_num_fault].data_id = data_id;
// //                         }
// //
// //                     }
// //                     chuneng_dev_num_fault ++;
// //                 }
// //                 data_num_fault = guangfu_dev_num_fault*guangfu_fault_datanum+chuneng_dev_num_fault*chuneng_fault_datanum-k;
// //                 k =0;
// //             }
// //             pin_fault->in_argc = data_num_fault;
// //             ret = Processor_InsertDpFuncNorth(eFmc_Fault, "eFmc_Fault",pin_fault,pout_fault);
// // //             free(dev_info_1);
// //             free(pin_fault);
// //
// //
// //             /*****************warning******************/
// //             for(i = 0; i < ND_num;i++)
// //             {
// //                 if((dev_info_1[i].stDevUID.devCode >= INV_START_NUM)&&(dev_info_1[i].stDevUID.devCode <= INV_START_NUM + INV_DEV_MAX_NUM))
// //                 {
// //                     for(j = 0;j < guangfu_warning_datanum;j++)
// //                     {
// //                         pin_warning->inpara[j+data_num_warning].dev_code = dev_info_1[i].stDevUID.devCode;
// //                         pin_warning->inpara[j+data_num_warning].index  = dev_info_1[i].stDevUID.devIndex;
// //                         data_id= SDB_ND_GetDataId(pin_warning->inpara[j+data_num_warning].dev_code,pin_warning->inpara[j+data_num_warning].index,warning_dataname[j]);
// //
// //                         warning_handle.pRec[j+data_num_warning].data_id = j;
// //
// //                         if(data_id == INVALID_VALUE)
// //                         {
// //                             k++;
// //                         }
// //                         else
// //                         {
// //                             pin_warning->inpara[j+data_num_warning].data_id = data_id;
// //                         }
// //
// //                     }
// //                     guangfu_dev_num_warning ++;
// //                 }
// //                 if((dev_info_1[i].stDevUID.devCode>=STORAGE_CONVERTER_START_NUM)&&(dev_info_1[i].stDevUID.devCode<=STORAGE_CONVERTER_START_NUM+STORAGE_CONVERTER_DEV_MAX_NUM))
// //                 {
// //                     for(j=0;j<chuneng_warning_datanum;j++)
// //                     {
// //                         pin_warning->inpara[j+data_num_warning].dev_code = dev_info_1[i].stDevUID.devCode;
// //                         pin_warning->inpara[j+data_num_warning].index  = dev_info_1[i].stDevUID.devIndex;
// //                         pin_warning->inpara[j+data_num_warning].data_id = SDB_ND_GetDataId(pin_warning->inpara[j+data_num_warning].dev_code,pin_processor->inpara[j+data_num_warning].index,warning_dataname[j+guangfu_warning_datanum]);
// //
// //                         warning_handle.pRec[j+data_num_warning].data_id = j+guangfu_warning_datanum;
// //
// //                         if(data_id == INVALID_VALUE)
// //                         {
// //                             k++;//本设备未获得测点id的数量
// //                         }
// //                         else
// //                         {
// //                             pin_warning->inpara[j+data_num_warning].data_id = data_id;
// //                         }
// //
// //                     }
// //                     chuneng_dev_num_warning ++;
// //                 }
// //                 data_num_warning = guangfu_dev_num_warning*guangfu_warning_datanum+chuneng_dev_num_warning*chuneng_warning_datanum-k;
// //                 k =0;
// //             }
// //             pin_warning->in_argc = data_num_warning;
// //             ret = Processor_InsertDpFuncNorth(eFmc_Warning, "eFmc_Warning",pin_warning,pout_warning);
// //             free(pin_warning);
// //             break;
//         }
//         default:
//             break;
//     }
//
//     return ret;
// }
static int32_t si_set(int32_t dwType, void *pvData, int32_t dwDataLen)
{

    int32_t ret = OK;

    int16_t i =0,ii=0,j=0,k=0,jj=0,kk=0,num_weight2 =0;
    int16_t data_id = 0,point_num =0;

    char dataprocessor_dataname[50][20] = {{"总有功功率"},{"有功功率"}};




    ND_num = SDB_ND_GetNum();
    DEV_INFO_EXT_T *dev_info = NULL;
    FUNC_INPARA_T *scan_point =NULL;
    DEV_INFO_EXT_T *dev_info_1 = NULL;
    if(ND_num>1)
    {

        dev_info_1 = malloc(sizeof(DEV_INFO_EXT_T)*ND_num);
        scan_point = (FUNC_INPARA_T *)malloc(sizeof(FUNC_INPARA_T)*1);
        scan_point->inpara = (FUNC_PARA_T *)malloc(sizeof(FUNC_PARA_T)*50);

        dev_info = SDB_ND_GetList();
        memcpy(dev_info_1, dev_info, sizeof(DEV_INFO_EXT_T)*ND_num);
    }
    if (dataprocessinghandle.pRec == NULL)
    {
        dataprocessinghandle.pRec =(RECORD_Q_T *) malloc(sizeof(RECORD_Q_T) * 50);
        if (dataprocessinghandle.pRec == NULL)
        {
            return 0;
        }
        memset(dataprocessinghandle.pRec, 0, sizeof(RECORD_Q_T) * 50);
    }

//     printf("%s (L%d)\n", __func__, __LINE__);

    switch (dwType)
    {
        case MSG_IPC_ALGO_PARAM_UPDATE:
        {
            dataprocess_flag  = 1;//可以进行算法处理操作标志位为1可以进行算法处理，为0不可以；
            uart_enabe_num = dwDataLen/(sizeof(ALOGR_T));
            printf("dwType:%x dwDataLen = %d\n", dwType, dwDataLen);
            printf("uart_num = %d\n",uart_enabe_num);

            memcpy(webin_dataprocessor, pvData, sizeof(ALOGR_T)*uart_enabe_num);
            for(kk=0;kk<uart_enabe_num;kk++)
            {
                num_weight2 = strlen(webin_dataprocessor[kk].ALOGR_PARAM_U.stAve.AveWeight);
                printf("num_weight2 = %d\n",num_weight2);
                for(ii=0;ii<num_weight2;ii=ii+2)
                {
                weight[kk][jj] = atol(&webin_dataprocessor[kk].ALOGR_PARAM_U.stAve.AveWeight[ii]);
                jj++;
                }
                for(ii=0;ii<jj;ii++)
                {
                printf("%d ",weight[kk][ii]);
                }
                printf("\n");
                jj=0;
            }

            printf("SampleNum = %d HistoryNum = %d AbnormalAlogr = %d UartNo = %d\n",webin_dataprocessor[0].SampleNum,webin_dataprocessor[0].HistoryNum,webin_dataprocessor[0].AbnormalAlgor,webin_dataprocessor[0].UartNo);
            if(ND_num>1)
            {
                for(i = 0; i < ND_num;i++)
                {
                    if((dev_info_1[i].stDevUID.devCode >= INV_START_NUM)&&(dev_info_1[i].stDevUID.devCode <= INV_START_NUM + INV_DEV_MAX_NUM))
                    {
                        printf("ND_num = %d\n",ND_num);
                        for(j = 0;j < guangfu_dataprocess_datanum;j++)
                        {
                            scan_point->inpara[j+data_num].dev_code = dev_info_1[i].stDevUID.devCode;

                            scan_point->inpara[j+data_num].index  = 1;

                            data_id= SDB_ND_GetDataId(scan_point->inpara[j+data_num].dev_code,scan_point->inpara[j+data_num].index,dataprocessor_dataname[j]);

                            printf("ND_num = %d data_id = %d\n",ND_num,data_id);
                            if(data_id == INVALID_VALUE)
                            {
                                k++;
                                printf("j= %d\n",j);
                            }
                            else
                            {
                                scan_point->inpara[j+data_num].data_id = data_id;
                                for(ii = 0;ii<uart_enabe_num;ii++)
                                {
                                    if(webin_dataprocessor[ii].UartNo == dev_info_1[i].dwCommId)
                                    {
                                        dataprocessinghandle.pRec[point_num].dwParamId = ii;
                                        printf(" dataprocessinghandle.pRec[point_num].dwParamId= %d AbnormalAlgor =%d Enable =%d  HistoryNum = %d SampleNum =%d\n",dataprocessinghandle.pRec[point_num].dwParamId,webin_dataprocessor[ii].AbnormalAlgor,webin_dataprocessor[ii].Enable,webin_dataprocessor[ii].HistoryNum,webin_dataprocessor[ii].SampleNum);
                                        point_num++;
                                    }
                                }
                            }

                        }
                        guangfu_dev_num ++;
                    }
                    else if((dev_info_1[i].stDevUID.devCode>=STORAGE_CONVERTER_START_NUM)&&(dev_info_1[i].stDevUID.devCode<=STORAGE_CONVERTER_START_NUM+STORAGE_CONVERTER_DEV_MAX_NUM))
                    {
                        for(j=0;j<chuneng_dataprocess_datanum;j++)
                        {
                            scan_point->inpara[j+data_num].dev_code = dev_info_1[i].stDevUID.devCode;

                            scan_point->inpara[j+data_num].index  = 1;

                            data_id = SDB_ND_GetDataId( scan_point->inpara[j+data_num].dev_code, scan_point->inpara[j+data_num].index,dataprocessor_dataname[j+guangfu_dataprocess_datanum]);

                            if(data_id == INVALID_VALUE)
                            {
                                k++;//本设备未获得测点id的数量
                            }
                            else
                            {
                                scan_point->inpara[j+data_num].data_id = data_id;
                                for(ii = 0;ii<uart_enabe_num;ii++)
                                {
                                    if(webin_dataprocessor[ii].UartNo == dev_info_1[i].dwCommId)
                                    {
                                        dataprocessinghandle.pRec[point_num].dwParamId = ii;
                                        printf(" dataprocessinghandle.pRec[point_num].dwParamId= %d AbnormalAlgor =%d Enable =%d  HistoryNum = %d SampleNum =%d\n",dataprocessinghandle.pRec[point_num].dwParamId,webin_dataprocessor[ii].AbnormalAlgor,webin_dataprocessor[ii].Enable,webin_dataprocessor[ii].HistoryNum,webin_dataprocessor[ii].SampleNum);
                                        point_num++;
                                    }

                                }
                            }
                        }
                        chuneng_dev_num ++;
                    }
                    data_num = guangfu_dev_num*guangfu_dataprocess_datanum+chuneng_dev_num*chuneng_dataprocess_datanum-k;
                    k =0;
                }
            }
            break;
        }
        case MSG_IPC_PROTECT_STORAGE_PARAM_UPDATE:
        {
            printf("%s (L%d)\n", __func__, __LINE__);
            memcpy(warning_yuzhi, pvData, sizeof(PROTECTSTORAGE_T)*1);
            printf("stProtectCell.OVL1=%f stProtectCell.OVL2=%f stProtectCell.OVL3=%f \n",
                   warning_yuzhi->stProtectCell.OVL1,
                   warning_yuzhi->stProtectCell.OVL2,
                   warning_yuzhi->stProtectCell.OVL3);
            printf("%s (L%d)\n", __func__, __LINE__);
            break;
        }
        case MSG_IPC_PROTECT_NET_PARAM_UPDATE:
        {
            break;
        }
        case MSG_IPC_DEV_UPDATE:
        {
//             PointInit();
            if(ND_num>1)
            {
                ret = ret+Processor_InsertDpFuncNorth(Data_porcessing, "Data_porcessing",pin_processor,pout_processor);
                free(pin_processor);
                free(pout_processor);
            }
            break;
        }
		case MSG_IPC_IO:
        {
            int32_t i, io_num;
            io_num = dwDataLen / sizeof(IO_PARAM_T);
            printf("io_num: %d\n", io_num);
            IO_PARAM_T *para_io = (IO_PARAM_T *)pvData;
//             IO_PARAM_T *save_io = NULL;
//             save_io = malloc(sizeof(IO_PARAM_T) * io_num);
            for(i = 0; i < io_num; i++)
            {

                save_io[i].DIEnable = para_io[i].DIEnable;//1：开启,0：禁止
                save_io[i].ID = para_io[i].ID;
                save_io[i].DIFunction = para_io[i].DIFunction;//故障1、告警2
                save_io[i].DIMode = para_io[i].DIMode;//常开1、常闭2
                printf("save_io[%d].IO_PARAM_U.stDIParam.DIEnable: %d\n", i, para_io[i].DIEnable);
                printf("save_io[%d].ID: %d\n", i, para_io[i].ID);
                printf("save_io[%d].IO_PARAM_U.stDIParam.DIFunction: %d\n", i, para_io[i].DIFunction);
                printf("save_io[%d].IO_PARAM_U.stDIParam.DIMode: %d\n", i, para_io[i].DIMode);
            }
			break;
        }
        default:
            printf("%s default dwType:0x%x\n", __func__, dwType);
            break;
    }

    return ret;
}

static int32_t si_get(int32_t dwType, void *pvRetData, int32_t dwRetLen)
{
    return OK;
}

static int32_t si_check(int32_t dwType, void *pvRetData, int32_t dwRetLen)
{
    return OK;
}




int32_t Script_Init()
{
    int32_t ret = OK;





    siHandle.operate.set = si_set;
    siHandle.operate.get = si_get;
    siHandle.operate.check = si_check;

//     PointInit();
    ret = Processor_Register(MODULE_ALGO, &siHandle.operate);


    if(ND_num>1)
    {
        ret = ret+Processor_InsertDpFuncNorth(Data_porcessing, "Data_porcessing",pin_processor,pout_processor);
        free(pin_processor);
        free(pout_processor);
        printf("start\n");
        ret = ret+Processor_InsertDpFuncNorth(eFmc_Fault, "eFmc_Fault",pin_fault,pout_fault);
        printf("end\n");
        free(pin_fault);
        free(pout_fault);
        ret = ret+Processor_InsertDpFuncNorth(eFmc_Warning, "eFmc_Warning",pin_warning,pout_warning);
        free(pin_warning);
        free(pout_warning);
    }



    pthread_mutex_init(&siHandle.mtx, NULL);

    return ret;
}

