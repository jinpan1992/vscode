#ifndef CONTROL_INTERFACE_H_INCLUDED
#define CONTROL_INTERFACE_H_INCLUDED

#include "common.h"
#include "sgdev.h"


#define MAX_PARA_NUM 10
#define MAX_DEVCODE_NUM 100

typedef struct
{
    float32_t setValue;//定义设定值
    float32_t actualValue;//实际值
    float32_t err;//偏差值
    float32_t errNext;//上一个偏差值
    float32_t errLast;//最上前的偏差值
    float32_t kp,ki,kd;//比例、积分、微分系数
    float32_t returnValue;//返回值
}PID_PARA_T;

void registPoint();
void PID_init(int32_t i,  float32_t kp, float32_t ki, float32_t kd);
float32_t PID_realize(int32_t i, float32_t setvalue, float32_t value);
int32_t Control_Init();
// void setTimer(float seconds);//秒级定时器
// void RunTimer(unsigned long mSec);//毫秒级定时器








#endif
