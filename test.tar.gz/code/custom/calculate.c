#include <signal.h>
#include <sys/time.h>
#include <string.h>
#include <math.h>
#include "config.h"
#include "calculate.h"
#include "ShareRTDB.h"
#include "data_script.h"

extern LOGGER_T logger;

void calcuNoDevInfo(LOGGER_T *logger)
{
	//获取北向设备数量
	int32_t ND_num = 0;
    int32_t devLocalCode = 2304;
    int32_t localIndex = 1;
    int32_t localDataid = 0;
    int32_t dataid = 0;
	ND_num = SDB_ND_GetNum();//所有设备数量
    POINT_T *tmpPoint = (POINT_T *)malloc(sizeof(POINT_T));
    memset(tmpPoint, 0, sizeof(POINT_T));
//     printf("ND_num: %d\n", ND_num);

	int32_t i = 0, k = 0;
// 	int32_t dev_num = 0;//同类型设备数量
    float32_t valuetotal[6][8] = {0};//光伏、风电、发电机、变压器、充电桩、储能
    float32_t valueother[2][3] = {0};//母线

    //获取设备列表
	DEV_INFO_EXT_T *dev_info;
	dev_info = SDB_ND_GetList();

    //本机xml列表
//     SGDEV_T *sglocaldev = logger->map[devLocalCode];

	for(i = 1; i < ND_num; i++)
	{
//         printf("get dev info!\n");
		//获取设备devcode
		int32_t devcode = dev_info[i].stDevUID.devCode;
		SGDEV_T *sgdev = logger->map[devcode];
        int32_t index = dev_info[i].stDevUID.devIndex;//设备索引
//         printf("devcode: %d\n", devcode);

		// 光伏逆变器
        if((devcode >= INV_START_NUM) && (devcode <= INV_START_NUM + INV_DEV_MAX_NUM))
		{
			//循环获取dataname
//             printf("sgdev->point_num: %d\n", sgdev->point_num);
			for(k = 0; k < sgdev->point_num; k++)
			{
				if(0 == strcmp("总有功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "总有功功率");
                    valuetotal[0][0] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
//                     printf("valuetotal[0][0]: %f\n", valuetotal[0][0]);
				}
				if(0 == strcmp("总无功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "总无功功率");
                    valuetotal[0][1] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
//                     printf("valuetotal[0][1]: %f\n", valuetotal[0][1]);
			    }
			    if(0 == strcmp("总有功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "总有功电量");
                    valuetotal[0][2] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("总无功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "总无功电量");
                    valuetotal[0][3] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
                if(0 == strcmp("总电流", sgdev->point_attr[k].data_name))
                {
                    dataid = SDB_ND_GetDataId(devcode, index, "总电流");
                    valuetotal[0][4] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			}
		}

        //风电
        if((devcode >= FAN_START_NUM) && (devcode <= FAN_START_NUM + FAN_DEV_MAX_NUM))
		{
			//循环获取dataname
			for(k = 0; k < sgdev->point_num; k++)
			{
				if(0 == strcmp("有功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "有功功率");
                    valuetotal[1][0] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
				}
				if(0 == strcmp("无功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "无功功率");
                    valuetotal[1][1] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("有功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "有功电量");
                    valuetotal[1][2] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("无功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "无功电量");
                    valuetotal[1][3] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
                if(0 == strcmp("电流", sgdev->point_attr[k].data_name))
                {
                    dataid = SDB_ND_GetDataId(devcode, index, "电流");
                    valuetotal[1][4] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			}

		}

		//发电机
        if((devcode >= FAN_START_NUM) && (devcode <= FAN_START_NUM + FAN_DEV_MAX_NUM))
		{
			//循环获取dataname
			for(k = 0; k < sgdev->point_num; k++)
			{
				if(0 == strcmp("有功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "有功功率");
                    valuetotal[2][0] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
				}
				if(0 == strcmp("无功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "无功功率");
                    valuetotal[2][1] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("有功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "有功电量");
                    valuetotal[2][2] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("无功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "无功电量");
                    valuetotal[2][3] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
                if(0 == strcmp("电流", sgdev->point_attr[k].data_name))
                {
                    dataid = SDB_ND_GetDataId(devcode, index, "电流");
                    valuetotal[2][4] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			}

		}

        //变压器
        if((devcode >= TRANSFORMER_START_NUM) && (devcode <= TRANSFORMER_START_NUM + TRANSFORMER_DEV_MAX_NUM))
		{
			//循环获取dataname
			for(k = 0; k < sgdev->point_num; k++)
			{
				if(0 == strcmp("有功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "有功功率");
                    valuetotal[3][0] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
				}
				if(0 == strcmp("无功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "无功功率");
                    valuetotal[3][1] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("有功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "有功电量");
                    valuetotal[3][2] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("无功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "无功电量");
                    valuetotal[3][3] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
                if(0 == strcmp("电流", sgdev->point_attr[k].data_name))
                {
                    dataid = SDB_ND_GetDataId(devcode, index, "电流");
                    valuetotal[3][4] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			}
		}

        //充电桩
        if((devcode >= CHARGE_START_NUM) && (devcode <= CHARGE_START_NUM + CHARGE_DEV_MAX_NUM))
		{
			//循环获取dataname
			for(k = 0; k < sgdev->point_num; k++)
			{
				if(0 == strcmp("有功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "有功功率");
                    valuetotal[4][0] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
				}
				if(0 == strcmp("无功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "无功功率");
                    valuetotal[4][1] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("有功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "有功电量");
                    valuetotal[4][2] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("无功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "无功电量");
                    valuetotal[4][3] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
                if(0 == strcmp("电流", sgdev->point_attr[k].data_name))
                {
                    dataid = SDB_ND_GetDataId(devcode, index, "电流");
                    valuetotal[4][4] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			}

		}

        // if(devcode == 储电)
        //储
        if((devcode >= STORAGE_CONVERTER_START_NUM) && (devcode <= STORAGE_CONVERTER_START_NUM + STORAGE_CONVERTER_DEV_MAX_NUM))
		{
//             printf("devcode： %d\n", devcode)的;
			//循环获取dataname
			for(k = 0; k < sgdev->point_num; k++)
			{
				if(0 == strcmp("有功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "有功功率");
                    valuetotal[5][0] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
//                     printf("valuetotal[5][0]: %f\n", valuetotal[5][0]);
				}
				if(0 == strcmp("无功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "无功功率");
                    valuetotal[5][1] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("有功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "有功电量");
                    valuetotal[5][2] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("无功电量", sgdev->point_attr[k].data_name))
			    {
                    dataid = SDB_ND_GetDataId(devcode, index, "无功电量");
                    valuetotal[5][3] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
                if(0 == strcmp("电流", sgdev->point_attr[k].data_name))
                {
                    dataid = SDB_ND_GetDataId(devcode, index, "电流");
                    valuetotal[5][4] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			    if(0 == strcmp("总充电量", sgdev->point_attr[k].data_name))
                {
                    dataid = SDB_ND_GetDataId(devcode, index, "总充电量");
                    valuetotal[5][5] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.s32;
                }
                if(0 == strcmp("总放电量", sgdev->point_attr[k].data_name))
                {
                    dataid = SDB_ND_GetDataId(devcode, index, "总放电量");
                    valuetotal[5][6] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.s32;
                }
			}

		}

        //母线
        if((devcode >= MUXIAN_START_NUM) && (devcode <= MUXIAN_START_NUM + MUXIAN_DEV_MAX_NUM))
		{
			//循环获取dataname
			for(k = 0; k < sgdev->point_num; k++)
			{
				if(0 == strcmp("有功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "有功功率");
                    valueother[0][0] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
				}
				if(0 == strcmp("无功功率", sgdev->point_attr[k].data_name))
				{
                    dataid = SDB_ND_GetDataId(devcode, index, "无功功率");
                    valueother[0][1] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
                if(0 == strcmp("电流", sgdev->point_attr[k].data_name))
                {
                    dataid = SDB_ND_GetDataId(devcode, index, "电流");
                    valueother[0][2] += sgdev->gdata[sgdev->map[dataid]][index-1].stValueInfo.data.f32;
			    }
			}
		}

	}


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "光伏-总有功功率");
    if(localDataid != -1)//判断data_id是否有效
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][0];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
//         printf("%f %d\n", tmpPoint->dPointValue, tmpPoint->unDataValue.u32);
    }

    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "光伏-总无功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
//         printf("%f %d\n", tmpPoint->dPointValue, tmpPoint->unDataValue.u32);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "光伏-总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "光伏-总无功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][3];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][3];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "光伏-总电流");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][4];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][4];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "风电-总有功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[1][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[1][0];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "风电-总无功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[1][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[1][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "风电-总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[1][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[1][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "风电-总无功电量");
    if(localDataid != -1)
    {
       tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[1][3];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[1][3];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "风电-总电流");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[1][4];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[1][4];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "发电机-总有功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[2][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[2][0];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "发电机-总无功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[2][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[2][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "发电机-总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[2][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[2][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "发电机-总无功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[2][3];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[2][3];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "发电机-总电流");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[2][4];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[2][4];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "变压器-总有功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][0];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "变压器-总无功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "变压器-总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "变压器-总无功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][3];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][3];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "变压器-总电流");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][4];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][4];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "充电桩-总有功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][0];
    ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }

    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "充电桩-总无功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "充电桩-总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "充电桩-总无功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][3];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][3];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "充电桩-总电流");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][4];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][4];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "储电-总有功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[5][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[5][0];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
//         printf("%f %f", valuetotal[5][0], tmpPoint->unDataValue.f32);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "储电-总无功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[5][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[5][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //储电-充电总有功量
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "储电-充电总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[5][5];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[5][5];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //储电-放电总有功量
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "储电-放电总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[5][6];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[5][6];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "储电-总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[5][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[5][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "储电-总无功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[5][3];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[5][3];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "储电-总电流");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[5][4];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[5][4];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "储电-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->ucDataType = 0;
        if((valuetotal[5][0]) * valuetotal[5][0] + (valuetotal[5][1] * valuetotal[5][1]) == 0)
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = valuetotal[5][0] / sqrt((valuetotal[5][0]) * valuetotal[5][0] + (valuetotal[5][1] * valuetotal[5][1]));//有功/sqrt（有功2+无功2）
            tmpPoint->unDataValue.f32 = valuetotal[5][0] / sqrt((valuetotal[5][0]) * valuetotal[5][0] + (valuetotal[5][1] * valuetotal[5][1]));
        }
    //     printf("tmpPoint->dPointValue tmpPoint->unDataValue.f32: %f %f %f %f\n", valuetotal[5][0], valuetotal[5][1], tmpPoint->dPointValue, tmpPoint->unDataValue.f32);
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }




    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "母线-总有功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valueother[0][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valueother[0][0];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "母线-总无功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valueother[0][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valueother[0][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "母线-总电流");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valueother[0][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valueother[0][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }



    //光伏总功率因数49
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "光伏-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->ucDataType = 0;
//     sglocaldev->gdata[sglocaldev->map[localDataid]][1-1].data.s32 = valuetotal[0][0] / (valuetotal[0][0] * valuetotal[0][0] + valuetotal[0][1] * valuetotal[0][1]);
        tmpPoint->iPointId = localDataid;
        if((valuetotal[0][0] * valuetotal[0][0] + valuetotal[0][1] * valuetotal[0][1]) == 0)
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else if(isnan(valuetotal[0][0] * valuetotal[0][0] + valuetotal[0][1] * valuetotal[0][1]))
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = valuetotal[0][0] / sqrt(valuetotal[0][0] * valuetotal[0][0] + valuetotal[0][1] * valuetotal[0][1]);
            tmpPoint->unDataValue.f32 = valuetotal[0][0] / sqrt(valuetotal[0][0] * valuetotal[0][0] + valuetotal[0][1] * valuetotal[0][1]);
        }
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //风电总功率因数55
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "风电-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->ucDataType = 0;
        if((valuetotal[1][0] * valuetotal[1][0] + valuetotal[1][1] * valuetotal[1][1]) == 0)
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = valuetotal[1][0] / sqrt(valuetotal[1][0] * valuetotal[1][0] + valuetotal[1][1] * valuetotal[1][1]);
            tmpPoint->unDataValue.f32 = valuetotal[1][0] / sqrt(valuetotal[1][0] * valuetotal[1][0] + valuetotal[1][1] * valuetotal[1][1]);
        }
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //发电机总功率因数61
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "发电机-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->ucDataType = 0;
        if((valuetotal[2][0] * valuetotal[2][0] + valuetotal[2][1] * valuetotal[2][1]) == 0)
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = valuetotal[2][0] / sqrt(valuetotal[2][0] * valuetotal[2][0] + valuetotal[2][1] * valuetotal[2][1]);
            tmpPoint->unDataValue.f32 = valuetotal[2][0] / sqrt(valuetotal[2][0] * valuetotal[2][0] + valuetotal[2][1] * valuetotal[2][1]);
        }
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //源总有功功率41
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "源-总有功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //源总无功功率42
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "源-总无功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][1] + valuetotal[1][1] + valuetotal[2][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][1] + valuetotal[1][1] + valuetotal[2][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //源总功率因数43
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "源-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->ucDataType = 0;
        if((((valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0]) * (valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0]) + (valuetotal[0][1] + valuetotal[1][1] + valuetotal[2][1]) * (valuetotal[0][1] + valuetotal[1][1] + valuetotal[2][1]))) == 0)
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = (valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0]) / sqrt((valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0]) * (valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0]) + (valuetotal[0][1] + valuetotal[1][1] + valuetotal[2][1]) * (valuetotal[0][1] + valuetotal[1][1] + valuetotal[2][1]));
            tmpPoint->unDataValue.f32 = (valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0]) / sqrt((valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0]) * (valuetotal[0][0] + valuetotal[1][0] + valuetotal[2][0]) + (valuetotal[0][1] + valuetotal[1][1] + valuetotal[2][1]) * (valuetotal[0][1] + valuetotal[1][1] + valuetotal[2][1]));
    //         printf("tmpPoint->dPointValue: %f\n", tmpPoint->dPointValue);
        }
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //源总有功电量44
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "源-总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][2] + valuetotal[1][2] + valuetotal[2][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][2] + valuetotal[1][2] + valuetotal[2][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //源总无功电量45
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "源-总无功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][3] + valuetotal[1][3] + valuetotal[2][3];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][3] + valuetotal[1][3] + valuetotal[2][3];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //源总电流46
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "源-总电流");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][4] + valuetotal[1][4] + valuetotal[2][4];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][4] + valuetotal[1][4] + valuetotal[2][4];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }



    //变压器总功率因数73
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "变压器-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->ucDataType = 0;
        if((valuetotal[3][0] * valuetotal[3][0] + valuetotal[3][1] * valuetotal[3][1]) == 0)
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = valuetotal[3][0] / sqrt(valuetotal[3][0] * valuetotal[3][0] + valuetotal[3][1] * valuetotal[3][1]);
            tmpPoint->unDataValue.f32 = valuetotal[3][0] / sqrt(valuetotal[3][0] * valuetotal[3][0] + valuetotal[3][1] * valuetotal[3][1]);
        }
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //网总有功功率65
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "网-总有功功率");
    if(localDataid != -1)
    {
       tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][0];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //网总无功功率66
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "网-总无功功率");
    if(localDataid != -1)
    {
       tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //网总功率因数67
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "网-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->ucDataType = 0;
        if((valuetotal[3][0] * valuetotal[3][0] + valuetotal[3][1] * valuetotal[3][1]) == 0)
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = valuetotal[3][0] / sqrt(valuetotal[3][0] * valuetotal[3][0] + valuetotal[3][1] * valuetotal[3][1]);
            tmpPoint->unDataValue.f32 = valuetotal[3][0] / sqrt(valuetotal[3][0] * valuetotal[3][0] + valuetotal[3][1] * valuetotal[3][1]);
        }
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //网总有功电量68
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "网-总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //网总无功电量69
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "网-总无功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][3];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][3];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //网总电流70
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "网-总电流");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][4];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][4];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //充电桩总功率因数105
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "充电桩-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->ucDataType = 0;
        if((valuetotal[4][0] * valuetotal[4][0] + valuetotal[4][1] * valuetotal[4][1]) == 0)
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = valuetotal[4][0] / sqrt(valuetotal[4][0] * valuetotal[4][0] + valuetotal[4][1] * valuetotal[4][1]);
            tmpPoint->unDataValue.f32 = valuetotal[4][0] / sqrt(valuetotal[4][0] * valuetotal[4][0] + valuetotal[4][1] * valuetotal[4][1]);
        }
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //荷总有功功率97
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "荷-总有功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][0];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][0];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //荷总无功功率98
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "荷-总无功功率");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][1];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][1];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //荷总功率因数99
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "荷-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->ucDataType = 0;
        if((valuetotal[4][0] * valuetotal[4][0] + valuetotal[4][1] * valuetotal[4][1]) == 0)
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = valuetotal[4][0] / sqrt(valuetotal[4][0] * valuetotal[4][0] + valuetotal[4][1] * valuetotal[4][1]);
            tmpPoint->unDataValue.f32 = valuetotal[4][0] / sqrt(valuetotal[4][0] * valuetotal[4][0] + valuetotal[4][1] * valuetotal[4][1]);
        }
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //荷总有功电量100
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "荷-总有功电量");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //荷总无功电量101
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "荷-总无功电量");
    if(localDataid != -1)
    {
            tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][3];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][3];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //荷总电流102
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "荷-总电流");
    if(localDataid != -1)
    {
         tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[4][4];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[4][4];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    //母线总功率因数79
    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "母线-总功率因数");
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->ucDataType = 0;
        if((valueother[0][0] * valueother[0][0] + valueother[0][1] * valueother[0][1]) == 0)//判断保护
        {
            tmpPoint->dPointValue = 0;
            tmpPoint->unDataValue.f32 = 0;
        }
        else
        {
            tmpPoint->dPointValue = valueother[0][0] / (valueother[0][0] * valueother[0][0] + valueother[0][1] * valueother[0][1]);
            tmpPoint->unDataValue.f32 = valueother[0][0] / (valueother[0][0] * valueother[0][0] + valueother[0][1] * valueother[0][1]);
        }
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }



    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "自产电量");//风+光+发电+储
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][2] + valuetotal[1][2] + valuetotal[2][2] + valuetotal[5][6];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][2] + valuetotal[1][2] + valuetotal[2][2] + valuetotal[5][6];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "外购电量");//网
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[3][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[3][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    localDataid = SDB_ND_GetDataId(devLocalCode, localIndex, "损耗电量");//自产+外购-储能充电-充电
    if(localDataid != -1)
    {
        tmpPoint->iPointId = localDataid;
        tmpPoint->dPointValue = valuetotal[0][2] + valuetotal[1][2] + valuetotal[2][2] + valuetotal[5][6] + valuetotal[3][2] - valuetotal[5][5] - valuetotal[4][2];
        tmpPoint->ucDataType = 0;
        tmpPoint->unDataValue.f32 = valuetotal[0][2] + valuetotal[1][2] + valuetotal[2][2] + valuetotal[5][6] + valuetotal[3][2] - valuetotal[5][5] - valuetotal[4][2];
        ShareRTDB_Update(2304, 1, tmpPoint, 1);
    }


    free(tmpPoint);
    tmpPoint = NULL;

    SetVersion(logger);
    SetSN(logger);
    InsertTime();


}

void *calTimer(void *arg)
{
    LOGGER_T *logger =(LOGGER_T*)arg;
    struct timeval tmpTime;

    while(1)
    {
        tmpTime.tv_sec = 10;
        tmpTime.tv_usec = 0;
        select(0, NULL, NULL, NULL, &tmpTime);
        calcuNoDevInfo(logger);
    }
}

int32_t createCalThread()
{
    printf("enter cal thread!\n");
    pthread_t cal_thread;
    int32_t ret = OK;

    ret = pthread_create(&cal_thread, NULL, calTimer, (void *)&logger);
    if(ret < 0)
    {
        perror("create error!");
    }
    printf("pthread_create ok!, ret: %d\n", ret);

//     (void)pthread_attr_destroy(&cal_thread);

    return ret;


}
