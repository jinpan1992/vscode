#include "SGQueue.h"
#include "common.h"
#include "collect.h"
#include "logUtil.h"
#include "processor.h"
#include "net.h"
#include "gpio.h"
#include "transmit.h"
#include "commonTest.h"
#include "sys.h"
#include "sdb.h"
#include "file_operate.h"
#include "config.h"
#include "IMC.h"
#include "ShareRTDB.h"

Q_DEFINE(DEV_DATA_T, dataInQ, Queue_NUM);
Q_DEFINE(DEV_DATA_T, dataOutQ, Queue_NUM);
Q_DEFINE(DEV_DATA_T, cmdqInQ, Queue_NUM);
Q_DEFINE(DEV_DATA_T, cmdqOutQ, Queue_NUM);

PLAT_STATISTICS_T g_PlatStic;
PLAT_SR_T g_PlatSR[TEST_NUM];

static void printMcuVer()
{
    char *softwareVerion = malloc(sizeof(char) * 25);
    PLATFORMVER_T *val = malloc(sizeof(PLATFORMVER_T));
    if((softwareVerion == NULL) || (val == NULL))
    {
       return;
    }

    SDB_GetVer(CEMS_DEV_CODE, val);
    sprintf (softwareVerion, "%s_%s_%s\n", val->machineModel, val->machineVer, val->softWareVer);
    printf("\n---------------------------------------------\n");
    printf("softWareVerion:%s", softwareVerion);
    printf("---------------------------------------------\n\n\n\n");


    HCFREE(softwareVerion);
    HCFREE(val);

    return;
}

void InitDaemonContext()
{
    int32_t i;

    //清除文件掩模
    umask(0);

    //关闭文件描述符
    for(i = 3; i < getdtablesize(); i++)
    {
        close(i);
    }

    return;
}

void MakeDaemon()
{
    pid_t son;
    pid_t sid;
    son = fork();
    if (son < 0)
    {
        exit(EXIT_SUCCESS);
    }

    if (son > 0)
    {
        exit(EXIT_SUCCESS);
    }

    sid = setsid();
    printf("Hc sid:%d\n", sid);

    sid = chdir("/home/SGComm/");
    InitDaemonContext();

    return;
}

int main()
{

    printf("CEMS start...v1.0(p:%d pp:%d)\n", getpid(), getppid());

    uintptr_t cHandle, pHandle, tHandle;

    //InitDaemonContext();

    logInit(NULL, TRUE);
    logSetDebugMode(OFF); /* 调试模式会打开所有调试信息，默认只印error和warning信息*/
    logSetPrintfEnable(ON);

    /* 初始化网口，虚拟机没有eth0，做此操作会导致svn 连不上，目前注释后续放开*/
#if INTERFANCE
#else
//     NetPortConfig(ETH_FILE_PATH);
//     LedInit();
#endif

    Q_INIT(dataInQ, Queue_NUM);     /* dataInQ:data from collect*/
    Q_INIT(dataOutQ, Queue_NUM);    /* dataOutQ:data from dataprocess*/
    Q_INIT(cmdqInQ, Queue_NUM);     /* cmdqInQ:data from transmit*/
    Q_INIT(cmdqOutQ, Queue_NUM);    /* cmdqOutQ:data from dataprocess*/

    /* 创建通信模块 */
    IMC_Create();

    /* 创建实时数据库*/
    int16_t ret = ShareRTDB_Init(SHARE_KEY_FOR_RTDB);
    if (ret != OK)
    {
        EMS_LOG(LL_ERROR, MODULE_DEFAULT, FALSE, "init share failed! ret:%d\n", ret);
    }

    /* 解析采集配置信息和设备信息 */
    SDB_Init();

    /* 采集模块的代码实现*/
    cHandle = Collector_Create();

    /* 数据处理模块的代码实现*/
    pHandle = Processor_Create();

    /* 转发模块的代码实现*/
    tHandle = Transmitor_Create();


    EMS_LOG(LL_WARNING, MODULE_DEFAULT, FALSE, "CEMS100 Init Done.\n");

    printMcuVer();

    while(1)
    {
#ifdef PLAT_STATISTICS_TEST
        printf("\n");
        printf("Collector: [recv]:%d createCmd:%d, [send]CmdFromSelf:%d CmdFromTrsmt:%d, [response]R:%d W:%d \n",
               g_PlatStic.recvCmdCntClctr, g_PlatStic.createCmdCntClctr,
               g_PlatStic.sendCmdFromSelfCntClctr, g_PlatStic.sendCmdFromTrsmtCntClctr,
               g_PlatStic.recvRRespCntClctr, g_PlatStic.recvWRespCntClctr);
        printf("transmitter: [recv]:%d, [sent]to Clctrt:%d, [response]R:%d W:%d \n",
               g_PlatStic.recvCmdCntTrsmt, g_PlatStic.sendToClctrCnt, g_PlatStic.respRTrsmt, g_PlatStic.respWTrsmt);
        printf("\n");
#endif

#if 0
        if (IsProcessRun("HCd") == FALSE)
        {
            //syslog(LOG_ERR, "%s is not running. (p:%d, pp:%d)\n", APPNAME, getpid(), getppid());
            char current_absolute_path[256];
            //获取当前目录绝对路径
            if (NULL == getcwd(current_absolute_path, 256))
            {
                printf("Get absolute path fail.\n");
            }
            /* 启动守护进程 */
            int ret = 0;
            if (IsIn("HCd", current_absolute_path))
            {
                ret = system("./HCd");
            }

            EMS_LOG(LL_WARNING, MODULE_DEFAULT, false, "HCd is not run:%d.\n", ret);
        }
        else
        {
            //printf("HCd is running......(p%d pp%d)\n", getpid(), getppid());
        }
#endif
        NanoSleep(5000);
    }

    Transmitor_Destroy(tHandle);
    Processor_Destroy(pHandle);
    Collector_Destroy(cHandle);
    SDB_Destory();
    ShareRTDB_UnInit();
    LedUninit();

    IMC_Destroy();

    Q_DESTROY(dataInQ);
    Q_DESTROY(dataOutQ);
    Q_DESTROY(cmdqInQ);
    Q_DESTROY(cmdqOutQ);
    return 0;
}
