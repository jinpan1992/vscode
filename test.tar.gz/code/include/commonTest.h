#ifndef COMMON_TEST_H
#define COMMON_TEST_H
#include "common.h"

#define TEST_NUM 100
//#define SR_TEST 1

//For Test
typedef struct
{
    //Collector
    uint32_t recvCmdCntClctr;
    uint32_t createCmdCntClctr;
    uint32_t sendCmdFromSelfCntClctr;
    uint32_t sendCmdFromTrsmtCntClctr;
    uint32_t recvWRespCntClctr;
    uint32_t recvRRespCntClctr;

    //Transmitter
    uint32_t recvCmdCntTrsmt;
    uint32_t sendToClctrCnt;
    uint32_t respWTrsmt;
    uint32_t respRTrsmt;

} PLAT_STATISTICS_T;

typedef struct
{
    struct timeval startT;       /* 转发放入queue 时间 */
    struct timeval getCmdT;      /* 采集获取转发放入queue 时间 */
    struct timeval createCmdT;   /* 创建命令的时间 */
    struct timeval sendT;        /* 采集发给协议栈时间 */
    struct timeval respT;        /* 采集结束响应时间 */
    uint32_t costMs;             /*一次收发总的消耗时间 */
    uint32_t u32Tag;

} PLAT_SR_T; /* send and receive time statistics*/

#endif
