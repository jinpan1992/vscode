#ifndef ERR_H_INCLUDED
#define ERR_H_INCLUDED

#include "common.h"

typedef int32_t err_t;

#define ERROR_MODULE_BITS   15
#define ERROR_BITS          16

#define ERROR_MARK      (1 << (ERROR_MODULE_BITS + ERROR_BITS))

#define ERROR_BEGIN(_module_id) ((_module_id) << ERROR_BITS)

#define ERROR_T(_module_error) (ERROR_MARK | (_module_error))

/* 从一个错误码中得到其所对应的模块标识和模块消息标识 */
#define MODULE_ERROR(err_t) ((err_t) & ((1 << ERROR_BITS) - 1))

enum {
    // for default.
    ERR_DEFAULT_NOT_INIT = ERROR_BEGIN (MODULE_DEFAULT),
    ERR_DEFAULT_ALREADY_INIT,
    ERR_DEFAULT_INVALID_PARAM,
    ERR_DEFAULT_NOT_EXIST,
    ERR_DEFAULT_ALREADY_EXIST,
    ERR_DEFAULT_NO_MEM,
    ERR_DEFAULT_INTERNAL_ERROR,
    ERR_DEFAULT_OPERATOR_NOT_ALLOW,
    ERR_DEFAULT_NOT_FOUND
};
#endif // ERR_H_INCLUDED
