#ifndef MSG_H_INCLUDED
#define MSG_H_INCLUDED

#include "common.h"

typedef int32_t msg_t;

#define MODULE_BITS   15
#define MSG_BITS      16

#define MSG_MARK      (1 << (MODULE_BITS + MSG_BITS))

#define MSG_BEGIN(_module_id) ((_module_id) << MSG_BITS)

/* 从一个消息码中得到其所对应的模块标识和模块消息标识 */
#define MODULE_MSG(_msg_t) ((_msg_t) & ((1 << MSG_BITS) - 1))
#define MODULE_ID(_msg_t)  (MODULE_ID_E)(((_msg_t) & ~(MSG_MARK)) >> MSG_BITS)

enum {
    // for collect
    MSG_COLLECT_SOUTH_CALIBRATION = MSG_BEGIN (MODULE_C),
};

enum {
    // for transmit
    MSG_TRANSIMIT_RESET_IP = MSG_BEGIN (MODULE_T),
    MSG_TRANSIMIT_IEC_PORT,
    MSG_TRANSIMIT_MODBUS_INFO,
    MSG_TRANSIMIT_MQTT

};

enum {
    // for Processor
    MSG_PROCESSOR_HOT_PLUG = MSG_BEGIN (MODULE_D),
};

enum {
    // for SDB
    MSG_SDB_UPDATED = MSG_BEGIN (MODULE_SDB),
};

enum {
    MSG_IPC_SYSTEM_MAINTAIN   = MSG_BEGIN (MODULE_IPC),
    MSG_IPC_TRANSMIT_PROTOCOL_SETTING, //Modbus 端口、IEC104 转发端口、MQTT 设置
    MSG_IPC_SERIAL_SETTING, //串口设置
    MSG_IPC_ALGO_PARAM_UPDATE, //算法参数
    MSG_IPC_PROTECT_STORAGE_PARAM_UPDATE, //保护参数-储
    MSG_IPC_PROTECT_NET_PARAM_UPDATE, //保护参数-网
    MSG_IPC_RUN_PARAM_UPDATE, //运行参数
    MSG_IPC_CALIBRATION_INFO,  //对时信息
    MSG_IPC_DEV_UPDATE,  //南向设备更新，0：新增，1：删除，3：修改
    MSG_IPC_DEV_CTRL,  //南向设备控制，开机、关机、待机
    MSG_IPC_IO,  //数字量IO配置
    MSG_IPC_DEV_MAPPING,  //南向设备和测点映射成北向设备和测点
    MSG_IPC_RT_FAULT_WARNING, //实时故障告警消息（发送给web）
    MSG_IPC_MAX
};

#endif // MSG_H_INCLUDED
