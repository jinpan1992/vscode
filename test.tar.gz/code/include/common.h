#ifndef COMMON_H
#define COMMON_H
#include <stdlib.h>
#include "def.h"
#include "SGQueue.h"

//定义输入参数标记
#define IN

//定义输出参数标记
#define OUT

//定义输入输出参数标记
#define INOUT

//正确返回0
#define OK 0

//错误返回-1
#define ERR -1

//定义是为1
#define TRUE 1

//定义否为0
#define FALSE 0

//定义打开为1
#define ON 1

//定义关闭为0
#define OFF 0

#define FLOAT_T 0  //浮点
#define U_INT_T 1  //无符号数
#define S_INT_T 2  //有符号数

#define INVALID_VALUE 0xFFFFFFFF

#define CEMS_DEV_CODE   2304

#define Queue_NUM 1000

#define HCFREE(pointer)\
if (pointer != NULL)\
{\
    free(pointer);\
    pointer = NULL;\
}

typedef unsigned char uint8_t;
typedef signed char int8_t;
typedef unsigned short int uint16_t;
typedef signed short int int16_t;
typedef unsigned int uint32_t;
typedef signed int int32_t;
typedef float float32_t;
typedef unsigned char BOOL;

typedef enum {
    MODULE_STATE_NONE    = 0,
    MODULE_STATE_INIT    = 1,
    MODULE_STATE_READY   = 2,
    MODULE_STATE_RUNNING = 3,
    MODULE_STATE_STOPPED = 4,
} MODULE_STATE_E;

typedef enum
{
    MODULE_DEFAULT = 0,
    MODULE_C,               /* 采集 */
    MODULE_T,               /* 转发 */
    MODULE_D,               /* 处理 */
    MODULE_MODBUS,          /* Modbus protocol */
    MODULE_CAN,             /* CAN protocol */
    MODULE_MSG_SERVER,      /* socket sever */
    MODULE_LOG,             /* 日志 */
    MODULE_SDB,             /* SDB */
    MODULE_IPC,
    MODULE_ALGO,            /* 算法处理模块 */
    MODULE_RUN,             /* 运行控制模块 */
    MODULE_MAX
} MODULE_ID_E;

//消息数据结构
typedef struct sg_msg_st
{
    uint32_t udwMsgType;       //消息类型
    uint32_t udwPara;          //参数,message id.
    uint32_t udwlen;           //消息长度
    uint8_t *pData;            //消息内容
}SG_MSG_T;

typedef struct {
    int32_t (*set)(int32_t dwType, void *pvData, int32_t dwDataLen);
    int32_t (*get)(int32_t dwType, void *pvRetData, int32_t dwRetLen);
    int32_t (*check)(int32_t dwType, void *pvRetData, int32_t dwRetLen);
}MODULE_OPERATOR_T;

typedef union {
    uint32_t u32;
    int32_t  s32;
    float f32;
}DATA_U;

typedef struct {
    DATA_U data;
    uint32_t dataTimeMS;        /* 数据时间 */
    uint8_t ucDataType;       /* 数据类型 */
}VALUE_INFO_T;

//DataQueue数据结构
typedef struct {
    uint16_t dev_code;           /* 设备类型编码 */
    uint16_t index;              /* 设备索引 */
    uint16_t data_id;            /* 测点编码 */
    struct
    {
        uint8_t data_type:4;     /* 数据类型 */
        uint8_t wr_type:4;       /* 读写类型 0-设置，1-回读 */
    };
    MODULE_ID_E moduleID;
    //DATA_U data;                 /* 数据值 */
    VALUE_INFO_T value;
    uint32_t u32Tag;
    uint32_t cmd;
}DEV_DATA_T;

//命令队列数据属性
typedef struct
{
    uint16_t  transaction;
    uint16_t  protocolType;
    uint8_t id;                  /* 站号 */
    uint8_t cmd;                 /* 命令类型 */
    uint8_t ctrlcmd;            /*CJT控制码*/
    uint32_t address;            /* 寄存器地址 */
    uint16_t registerCount;      /* 寄存器个数 */
    uint8_t data[256];           /* 数据指针 */
    uint8_t buf_len;             /* 发送字节数 */
    uint8_t sending;             /* 发送中标 */
    uint32_t timeout;
    uint8_t cyc;                /* cycles */
    uint8_t priority;           /* 优先级 */
    uint8_t send_cnt;           /* 发送次数 */
    uint8_t wr_type;
    uint32_t u32Tag;
}MODBUS_CMD_T;

Q_TYPE_DEFINE(DEV_DATA_T, Queue_NUM);
Q_TYPE_DEFINE(SG_MSG_T, Queue_NUM);

#endif
